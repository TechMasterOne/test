﻿using ArcanumTechnology.nKode;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArcanumTechnology.nKode.Provider.JSON
{
    public class CreateNKodResult
    {
        public bool Success { get; set; }

        public bool NKodCompareFailed { get; set; }

        public NKodPolicyCompareResult PolicyCompareResult { get; set; }
    }
}
