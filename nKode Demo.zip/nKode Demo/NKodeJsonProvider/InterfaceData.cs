﻿using ArcanumTechnology.DataTranslation;
using ArcanumTechnology.nKode;
using ArcanumTechnology.nKode.DataTranslation;
using ArcanumTechnology.nKode.Provider.JSON;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArcanumTechnology.nKode.Provider.JSON
{
    public class InterfaceData
    {
        public RawDARCData KeypadDarcData { get; set; } //Holds phase 1 of DARC data for the keypad key selection

        public string UserTemplateIdentifier { get; set; }

        public RawMutualEphemeralKeys KeypadMutualEphemeralKeys { get; set; }

        public List<List<byte>> AttributeDarcData { get; set; } //Holds phase 4 of DARC data for attribute anonymization 

        public string SessionId { get; set; }
    }
}
