﻿using System;
using System.Collections.Generic;
using System.Linq;
using ArcanumTechnology.ArcanumCommon;
using ArcanumTechnology.DataTranslation.Common;
using ArcanumTechnology.nKode.DataTranslation;
using ArcanumTechnology.DataTranslation;
using ArcanumTechnology.nKode.ServerDataProviders;
using Newtonsoft.Json;
using System.Configuration;
using ArcanumTechnology.nKode;
using System.Runtime.Caching;
using DataTranslationIndex = ArcanumTechnology.nKode.DataTranslation.DataTranslationIndex;
using ArcanumTechnology.nKode.Provider.JSON;
using System.Threading.Tasks;

namespace ArcanumTechnology.nKode.Provider.JSON
{
    public class nKodeJsonProvider
    {
        private const string SessionConfigCachePrefix = "Session|";
        private const string CustomerInfoCachePrefix = "Customer|";
        const NKodEngine.EntryVerification verify = NKodEngine.EntryVerification.KeyAttributeSetUniqueness | NKodEngine.EntryVerification.KeyAttributeSets | NKodEngine.EntryVerification.KeyAttributeUniqueness | NKodEngine.EntryVerification.KeyAttributes;
            
        private readonly NKodEngine _engine;

        private const int SessionCacheSeconds = 300;
        private const int CustomerCacheMinutes = 20;
        
        const byte HEIGHT = 10; //Number of keys
        const byte WIDTH = 7; //Number of attributes per key: Position, color, shape, number, A-H, I-Q, R-Z for example
        const byte MEDIUM_HEIGHT = 10; //Should always equal number of keys for DARC.  The medium is the carrier of the information. 

        public static NKodServerDataProvider GetNKodeDataProviderInstance()
        {
            switch (ConfigurationManager.AppSettings["DBProvider"])
            {
                case "SQLServer":
                    return new NKodSQLServerDataProvider(ConfigurationManager.AppSettings["NKodSqlServerConnectionString"]);
                case "MySql":
                    return new NKodMySQLServerDataProvider(ConfigurationManager.AppSettings["NKodMySqlConnectionString"]);
                default:
                    throw new InvalidOperationException($"{ConfigurationManager.AppSettings["DBProvider"]} is not a valid provider.  Please use 'SQLServer' or 'MySql'");
            }
        }

        public nKodeJsonProvider()
        {
            _engine = new NKodEngine(GetNKodeDataProviderInstance());
        }     

        private Session GetCachedSessionConfig(string sessionId)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            return memoryCache.Get(SessionConfigCachePrefix + sessionId) as Session;
        }    
        
        private void RemoveSessionConfigFromCache(string sessionId)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            memoryCache.Remove(SessionConfigCachePrefix + sessionId);
        }

        private void CacheSessionConfig(Session session)
        {
            MemoryCache memoryCache = MemoryCache.Default;            
            memoryCache.Add(SessionConfigCachePrefix + Common.FormatGUID(session.GUID, GUIDFormats.Format.None), session, new DateTimeOffset(DateTime.Now.AddSeconds(SessionCacheSeconds)));      
        }

        //Only used for development and testing, should not store session data in database in production implementation
        private Session GetSessionInfo(string sessionId)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            Session session = memoryCache.Get(SessionConfigCachePrefix + sessionId) as Session;

            if (session == null)
                throw new InvalidOperationException("Invalid Session");
            //if (session == null) //Not in cache, pull from DB
            //{
            //    session = _engine.ServerDataProvider.GetSessionInfo(sessionId);
            //    memoryCache.Add(SessionConfigCachePrefix + ArcanumTechnology.ArcanumCommon.Common.FormatGUID(session.GUID, GUIDFormats.Format.None), session, new DateTimeOffset(DateTime.Now.AddSeconds(SessionCacheSeconds)));
            //}

            return session;
        }

        private async Task<Customer> GetCustomerInfo(Guid customerGuid)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            Customer customer = memoryCache.Get(CustomerInfoCachePrefix + Common.FormatGUID(customerGuid,GUIDFormats.Format.None)) as Customer;

            if (customer == null) //Not in cache, pull from DB
            {
                customer = await _engine.ServerDataProvider.GetCustomerInfoAsync(customerGuid,ConfigurationManager.AppSettings["EncryptionKey"]);
                memoryCache.Add(CustomerInfoCachePrefix + Common.FormatGUID(customerGuid, GUIDFormats.Format.None), customer, new DateTimeOffset(DateTime.Now.AddMinutes(CustomerCacheMinutes)));
            }

            return customer;
        }

        private void RemoveCustomerFromCache(Guid customerGuid)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            memoryCache.Remove(CustomerInfoCachePrefix + Common.FormatGUID(customerGuid, GUIDFormats.Format.None));
        }

        /// <summary>
        /// Stores the user's nKode and returns the dispersed interface the user will use to confirm his/her nKode
        /// </summary>
        /// <param name="customerGuid"></param>
        /// <param name="sessionId"></param>
        /// <param name="userName"></param>
        /// <param name="rawKeyList"></param>
        /// <param name="clientIdentifier"></param>
        /// <param name="attributeP1DARCData"></param>
        /// <param name="attributeMutualEphemeralKeys"></param>
        /// <returns></returns>
        public async Task<InterfaceData> CreateNKodeStep1(Guid customerGuid, string sessionId, string userName, List<List<byte>> rawKeyList, DARCData attributeP1DARCData, MutualEphemeralKeys attributeMutualEphemeralKeys)
        {
            return await GenerateInterfaceWithClearCustomerRetry(customerGuid, sessionId, userName, rawKeyList, null, attributeP1DARCData, attributeMutualEphemeralKeys);
        }

        /// <summary>
        /// This will call the main GenerateInterface method.  If an AttributeNotFoundException occurs, it will clear the cached customer information and retry.  This should only
        /// happen when attributes have been renewed and the cached Customer doesn't have those updated attribute values yet.
        /// </summary>
        /// <param name="customerGuid"></param>
        /// <param name="sessionId"></param>
        /// <param name="userName"></param>
        /// <param name="rawKeyList"></param>
        /// <param name="clientIdentifier"></param>
        /// <param name="attributeP1DARCData"></param>
        /// <param name="attributeMutualEphemeralKeys"></param>
        /// <returns></returns>
        private async Task<InterfaceData> GenerateInterfaceWithClearCustomerRetry(Guid customerGuid, string sessionId, string userName, List<List<byte>> rawKeyList, NKodClientIdentifier clientIdentifier, DARCData attributeP1DARCData, MutualEphemeralKeys attributeMutualEphemeralKeys)
        {
            try
            {
                return await GenerateInterface(customerGuid, sessionId, userName, rawKeyList, clientIdentifier, attributeP1DARCData, attributeMutualEphemeralKeys);
            }
            catch(AttributeNotFoundException ex)
            {
                RemoveCustomerFromCache(customerGuid);
                return await GenerateInterface(customerGuid, sessionId, userName, rawKeyList, clientIdentifier, attributeP1DARCData, attributeMutualEphemeralKeys);
            }
        }

        private async Task<InterfaceData> GenerateInterface(Guid customerGuid, string sessionId, string userName, List<List<byte>> rawKeyList, NKodClientIdentifier clientIdentifier, DARCData attributeP1DARCData, MutualEphemeralKeys attributeMutualEphemeralKeys)
        {
            if(customerGuid == null)
                throw new InvalidOperationException("Parameter customerGuid cannot be null or blank");

            bool isLoginInterface = !string.IsNullOrWhiteSpace(userName) && rawKeyList == null;
            bool isDispersion = !string.IsNullOrWhiteSpace(userName) && rawKeyList != null && !string.IsNullOrWhiteSpace(sessionId);
            List<Task> taskList = new List<Task>();

            try
            {
                await _engine.ServerDataProvider.ConnectAsync();

                Customer customer = await GetCustomerInfo(customerGuid);

                if (!customer.Active)
                {
                    string customerName = customer.Name;
                    if (!string.IsNullOrWhiteSpace(customer.Branch))
                        customerName += $" [{customer.Branch}]";
                    throw new Exception($"Customer: {customerName} is inactive");
                }
                               
                NKodKeyList ui;
              
                TranslationData<byte> translation = new TranslationData<byte>();
                InterfaceData interfaceData = new InterfaceData();

                //Engine Method process to use
                if (isDispersion) //Confirming new NKod
                {
                    Session cachedSession = GetCachedSessionConfig(sessionId); //Get session from cache                    
                   
                    RemoveSessionConfigFromCache(Common.FormatGUID(cachedSession.GUID, GUIDFormats.Format.None));
                    
                    TranslationData<byte> receivedKeyInput = new TranslationData<byte>(rawKeyList);

                    ServerRx received = new ServerRx()
                    {
                        ServerEphemeralKeys = cachedSession.ServerEphemeralKeys,
                        MutualEphemeralKeys = cachedSession.MutualEphemeralKeys,
                        ServerPersistentKeys = customer.InterfaceDarcServerConfig,
                        Alphabet = cachedSession.KeyConfig.GetAlphabet()
                    };

                    translation = received.Translate(receivedKeyInput);
                    ui = NKodEngine.DisperseAttributes(cachedSession.KeyConfig, customer.InterfaceConfig.AttributeSets);
                }
                else if (isLoginInterface) //User login with potential previously stored interface
                {   
                    User user = await _engine.ServerDataProvider.GetUserWithClientRecordAsync(userName, customer.GUID, clientIdentifier.ClientTypeId, clientIdentifier.ClientFingerprint);

                    if(user != null)
                        interfaceData.UserTemplateIdentifier = user.TemplateIdentifier;

                    NKodClient nKodClient = null;

                    if(user != null && user.UserClients != null)
                        nKodClient = user.UserClients.FirstOrDefault();

                    if (nKodClient == null) //Create record
                    {
                        ui =  NKodEngine.RandomConfig(customer.InterfaceConfig.Keys, customer.InterfaceConfig.AttributeSets); //No last starting point, just do random shuffle

                        //Guid? userGuid = _engine.ServerDataProvider.GetUserGUID(userName);
                        if (user != null) //If is null, user doesn't exist, but continue as normal anyway so as to not let user know username is invalid
                        {
                            nKodClient = new NKodClient(clientIdentifier) { UserGuid = user.GUID, Username = userName };
                            nKodClient.KeyConfig = ui;
                            taskList.Add(_engine.ServerDataProvider.CreateUserClientRecordAsync(nKodClient));
                        }
                    }
                    else //Do shuffle based on last key config
                    {                        
                        taskList.Add(_engine.ServerDataProvider.UpdateUserClientLastSeenAsync(nKodClient.GUID));
                        ui = NKodEngine.ShuffleAttributes(nKodClient.KeyConfig, customer.InterfaceConfig.AttributeSets, customer.InterfaceConfig.StaticAttribute); 
                    }
                }
                else
                {
                    ui = NKodEngine.RandomConfig(customer.InterfaceConfig.Keys,customer.InterfaceConfig.AttributeSets); //Completely random
                }
                
                ServerEphemeralKeys serverEphemeralKeys = new ServerEphemeralKeys().GenerateInstanceTranslations(WIDTH, HEIGHT, MEDIUM_HEIGHT);
                MutualEphemeralKeys mutualEphemeralKeys = new MutualEphemeralKeys().GenerateInstanceTranslations(WIDTH, HEIGHT, MEDIUM_HEIGHT, false);

                Session engineSession = new Session { CustomerGUID = customerGuid, ServerEphemeralKeys = serverEphemeralKeys, MutualEphemeralKeys = mutualEphemeralKeys };
                
                //***********TESTING FROM SAVED SESSION
                //engineSession = (_engine.ServerDataProvider as NKodMySQLServerDataProvider).GetSessionInfo("8cc2eef3d44c4b7fa718b3b667717899");
                //ui = JsonConvert.DeserializeObject<NKodInterface>(engineSession.InterfaceConfig);
                //***********END TESTING FROM SAVED SESSION

                //If has user set passcodeTemp for processing
                if (isDispersion)
                    engineSession.PasscodeTemp = translation;

                engineSession.KeyConfig = ui;

                CacheSessionConfig(engineSession);
                                                
                ServerTx keysServerTx = new ServerTx { ServerPersistentKeys = customer.InterfaceDarcServerConfig, Alphabet = ui.GetAlphabet(), ServerEphemeralKeys = engineSession.ServerEphemeralKeys, MutualEphemeralKeys = engineSession.MutualEphemeralKeys };
                                
                interfaceData.KeypadDarcData = new RawDARCData(keysServerTx.Transmit());                
                interfaceData.KeypadMutualEphemeralKeys = new RawMutualEphemeralKeys(engineSession.MutualEphemeralKeys);
                interfaceData.SessionId = Common.FormatGUID(engineSession.GUID, GUIDFormats.Format.None);
                interfaceData.AttributeDarcData = GetAnonymizedAttributes(customer.InterfaceConfig.AttributeSets, customer.AttributesDarcClientConfig, ui, attributeP1DARCData, attributeMutualEphemeralKeys);
                
                return interfaceData;
            }
            finally
            {
                if (_engine != null && _engine.ServerDataProvider != null)
                {                    
                    await Task.WhenAll(taskList);                    
                    _engine.ServerDataProvider.Disconnect();
                }
            }
        }

        private List<List<byte>> GetAnonymizedAttributes(NKodAttributeSetList customerAttributeSets,ClientPersistentKeys customerAttributesDarcClientConfig, NKodKeyList shuffledKeys, DARCData attributeP1DARCData, MutualEphemeralKeys attributeMutualEphemeralKeys)
        {
            ClientEphemeralKeys clientEphemeralKeys = new ClientEphemeralKeys();
            clientEphemeralKeys.GenerateInstanceTranslations(3, 70, 70);

            ClientRx receive = new ClientRx { ClientPersistentKeys = customerAttributesDarcClientConfig, ClientEphemeralKeys = clientEphemeralKeys, MutualEphemeralKeys = attributeMutualEphemeralKeys };
            DARCData attributePhase2DARCData = receive.Receive(attributeP1DARCData);

            ClientTx attributeClientTx = new ClientTx { ClientPersistentKeys = customerAttributesDarcClientConfig, ClientEphemeralKeys = clientEphemeralKeys, MutualEphemeralKeys = attributeMutualEphemeralKeys };
            DARCData attributePhase3DARCData = attributeClientTx.Transmit(attributePhase2DARCData);

            ClientMerge merge = new ClientMerge { ClientPersistentKeys = customerAttributesDarcClientConfig, ClientEphemeralKeys = clientEphemeralKeys, MutualEphemeralKeys = attributeMutualEphemeralKeys };

            List<ulong> attributeSetValues = customerAttributeSets.GetFlattenedValues();
            Dictionary<int, int> attributeValueOrdinalLookup = new Dictionary<int, int>();
            for (int x = 0; x < attributeSetValues.Count; x++)
                attributeValueOrdinalLookup.Add((int)attributeSetValues[x], x);

            //Will hold attribute information for all keys.  
            //Note that although not separated in the data structure, each 7 positions will represent a single key's attributes.  
            List<int> keyData = new List<int>();
            foreach (NKodKey shuffledKey in shuffledKeys)
            {
                foreach (NKodAttribute attribute in shuffledKey.Attributes)
                {
                    int lookupValue;
                    if(attributeValueOrdinalLookup.TryGetValue((int)attribute.Value,out lookupValue))
                        keyData.Add(lookupValue); //Use ordinal posiiton of attribute alphabet to pass to DARC as input selection
                    else //Renew Attributes requires Customer cache to be updated.  This is the earliest opportunity to determine if Customer cache is outdated.
                        throw new AttributeNotFoundException("Attribute " + attribute.SerializeToJSON() + " does not exist.");
                } 
            }

            TranslationData<byte> attributeDARCMessage = merge.MergeMessage(attributePhase3DARCData, keyData);

            return attributeDARCMessage.Values;
        }
               
       /// <summary>
       /// 
       /// </summary>
       /// <param name="cid"></param>
       /// <param name="attributeP1DARCData"></param>
       /// <param name="attributeMutualEphemeralKeys"></param>
       /// <returns></returns>
        public async Task<InterfaceData> GenerateInterface(Guid cid, DARCData attributeP1DARCData, MutualEphemeralKeys attributeMutualEphemeralKeys)
        {
            return await GenerateInterfaceWithClearCustomerRetry(cid, null, null, null, null, attributeP1DARCData, attributeMutualEphemeralKeys);
        }

       /// <summary>
       /// 
       /// </summary>
       /// <param name="cid"></param>
       /// <param name="username"></param>
       /// <param name="clientIdentifier"></param>
       /// <param name="attributeP1DARCData"></param>
       /// <param name="attributeMutualEphemeralKeys"></param>
       /// <returns></returns>
        public async Task<InterfaceData> GetLoginInterface(Guid cid,string username,NKodClientIdentifier clientIdentifier, DARCData attributeP1DARCData, MutualEphemeralKeys attributeMutualEphemeralKeys)
        {
            return await GenerateInterfaceWithClearCustomerRetry(cid, null, username, null, clientIdentifier,attributeP1DARCData,attributeMutualEphemeralKeys);          
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="cid"></param>
        /// <param name="sessionId"></param>
        /// <param name="userName"></param>
        /// <param name="rawKeyList"></param>
        /// <returns></returns>
        public async Task<(AuthStatus authStatus,User user)> IsValidUser(Guid cid, string sessionId, string userName, List<List<byte>> rawKeyList)
        {
            try
            {
                await _engine.ServerDataProvider.ConnectAsync();
                //  TRANSLATE INCOMING DATA                
                TranslationData<byte> rxData = new TranslationData<byte>(rawKeyList);

                Customer customer = await GetCustomerInfo(cid);
                Session session = GetCachedSessionConfig(sessionId);

                RemoveSessionConfigFromCache(Common.FormatGUID(session.GUID, GUIDFormats.Format.None)); //A new session must be generated for any further operations                               

                ServerRx received = new ServerRx()
                {
                    ServerEphemeralKeys = session.ServerEphemeralKeys,
                    MutualEphemeralKeys = session.MutualEphemeralKeys,
                    ServerPersistentKeys = customer.InterfaceDarcServerConfig,
                    Alphabet = session.KeyConfig.GetAlphabet()
                };

                TranslationData<byte> translation = received.Translate(rxData);

                NKodKeyList keyList = GetKeyList(translation.Values, session.KeyConfig);

                return await _engine.ValidateEntryAsync(customer, keyList, verify, userName, false);
            }
            finally
            {
                _engine.ServerDataProvider.Disconnect();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cid"></param>
        /// <param name="sessionId"></param>
        /// <param name="userName"></param>
        /// <param name="templateIdentifier"></param>
        /// <param name="isNewUser"></param>
        /// <param name="rawKeyList"></param>
        /// <param name="clientIdentifier"></param>
        /// <returns></returns>
        public async Task<(CreateNKodResult, NKodLicenseUserInfo)> ConfirmNKode(Guid cid, string sessionId, string userName, string templateIdentifier, bool isNewUser, List<List<byte>> rawKeyList, NKodClientIdentifier clientIdentifier)
        {            
            CreateNKodResult result = new CreateNKodResult();
            NKodLicenseUserInfo nKodLicenseUserInfo = null;

            try
            {
                await _engine.ServerDataProvider.ConnectAsync();
                Customer customer = await GetCustomerInfo(cid);
                Session session = GetCachedSessionConfig(sessionId);
                                
                TranslationData<byte> rxData = new TranslationData<byte>(rawKeyList);

                ServerRx received = new ServerRx()
                {
                    ServerEphemeralKeys = session.ServerEphemeralKeys,
                    MutualEphemeralKeys = session.MutualEphemeralKeys,
                    ServerPersistentKeys = customer.InterfaceDarcServerConfig,
                    Alphabet = session.KeyConfig.GetAlphabet()
                };                

                TranslationData<byte> translation = received.Translate(rxData);
                                
                //  FLATTEN THE RAWKEYLIST
                NKodKeyList keyList1 = GetKeyList(translation.Values, session.KeyConfig);
                NKodKeyList keyList2 = GetKeyList(session.PasscodeTemp.Values, session.KeyConfig);
                NKodAttributeList passcode = NKodEngine.CompareEntries(keyList1, keyList2);
                if (passcode.Count >= 1)
                {
                    //Verify that the passcode meets requirements.
                    NKodMetricsEval metricsEval = new NKodMetricsEval(passcode);
                    result.PolicyCompareResult = metricsEval.ComparePolicy(customer.NKodPolicy);
                    if (!result.PolicyCompareResult.PolicyIsValid)
                        return (result,null);

                    if(isNewUser)
                    {
                        Guid userGuid = Guid.NewGuid();
                        nKodLicenseUserInfo = await _engine.RegisterUserAsync(customer, userGuid, userName, passcode, templateIdentifier, false);
                        if (clientIdentifier != null)
                        {
                            NKodClient nKodClient = new NKodClient(clientIdentifier) { UserGuid = userGuid, KeyConfig = session.KeyConfig, Username = userName };
                            await _engine.ServerDataProvider.CreateUserClientRecordAsync(nKodClient);
                        }
                    }
                    else //Reset nKode
                    {
                        await _engine.UpdateUserPasscodeAsync(customer, userName, passcode, templateIdentifier, false);
                    }
                    
                    result.Success = true;
                    return (result,nKodLicenseUserInfo);
                }
                else
                    result.NKodCompareFailed = true;

                return (result, null);
            }
            finally
            {
              

                if (_engine.ServerDataProvider != null)
                    _engine.ServerDataProvider.Disconnect();
            }
        }    

        /// <summary>
        /// 
        /// </summary>
        /// <param name="keys"></param>
        /// <param name="userInterfaceKeys"></param>
        /// <returns></returns>
        private NKodKeyList GetKeyList(List<List<byte>> keys, NKodKeyList userInterfaceKeys)
        {
            //  CREATE DICTIONARY LOOKUP OF ALL ATTRIBUTES            
            Dictionary<ulong,NKodAttribute> attributeLookup = userInterfaceKeys.SelectMany(x => x.Attributes).ToDictionary(x => x.Value, x => x);

            NKodKeyList newKeyList = new NKodKeyList(EnumerationFlags.NoCompare);
            foreach (List<byte> rawKey in keys)
            {
                NKodAttributeList attributeList = new NKodAttributeList(EnumerationFlags.NoCompare);
                foreach (byte attribute in rawKey)
                {                    
                    NKodAttribute nKodAttribute;
                    if(attributeLookup.TryGetValue(attribute,out nKodAttribute))
                        attributeList.Add(new NKodAttribute() { Value = attribute,Set = nKodAttribute.Set });
                }
                newKeyList.Add(new NKodKey {  Attributes = attributeList });
            }
            return newKeyList;
        }
    }
}
