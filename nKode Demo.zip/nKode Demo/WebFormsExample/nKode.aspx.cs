﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace nKode.WebFormsExample
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!string.IsNullOrWhiteSpace(Request.Params["action"]) && Request.Params["action"].ToLower() == "change" && !User.Identity.IsAuthenticated)
            {
                Response.Redirect("/nKode.aspx");
            }
        }
    }
}