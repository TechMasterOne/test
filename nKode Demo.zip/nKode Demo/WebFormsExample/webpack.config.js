process.traceDeprecation = true;
const webpack = require('webpack');
const path = require('path');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');

module.exports = (env = {}) => {

    return {
        entry: { index: './nKodeSrcScripts/nKodeImplementation.js' },        
        output: {
            path: path.resolve(__dirname, 'nKodeScriptDist'),
            filename: '[name].js'
        },
        optimization: {
            minimizer: [new UglifyJsPlugin({
                sourceMap: true
            })],
            splitChunks: {
                cacheGroups: {
                    vendor: {
                        test: /[\\/]node_modules[\\/]/,
                        name: 'vendor',
                        chunks: 'all'
                    }
                }
            }
        },
        module: {
            rules: [{
                test: /\.js$/,
                use: {
                    loader: 'babel-loader'
                }
            },
            {
                test: /\.js$/,
                use: ["source-map-loader"],
                enforce: "pre"
            }]
        },
        devtool: env.development ? "inline-source-map" : false,
        plugins: [
            new webpack.NormalModuleReplacementPlugin(/(.*)BUILD_MODE(\.*)/, function (resource) {
                resource.request = resource.request.replace(/BUILD_MODE/, `${env.development ? 'dev' : 'prod'}`);
            })
        ]
    };
}