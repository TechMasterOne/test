﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Filters;

namespace nKode.WebFormsExample
{
    public class CustomExceptionFilterAttribute : ExceptionFilterAttribute
    {
        public override void OnException(HttpActionExecutedContext context)
        {
            //EventLogWriter _el = new EventLogWriter("Arcanum nKode Admin");
            //_el.LogError(new System.Diagnostics.StackFrame(), context.Exception);
            //context.Response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
            //{
            //    Content = new StringContent(context.Exception.Message),
            //    ReasonPhrase = (context.Exception is LicenseException) ? "License Exception" : "Internal Server Error"
            //};
            base.OnException(context);
        }
    }
}