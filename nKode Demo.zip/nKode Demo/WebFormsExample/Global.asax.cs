﻿using ArcanumTechnology.nKode;
using ArcanumTechnology.nKode.Provider.JSON;
using ArcanumTechnology.nKode.ServerDataProviders;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;

namespace nKode.WebFormsExample
{
    public class Global : HttpApplication
    {
        async void Application_Start(object sender, EventArgs e)
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);
                      
            // Code that runs on application startup
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            //Example of how to update encryption keys--just create a blank file named "updateEncryptionKeys.txt" put it in the root of the application so that 
            //keys are updated upon startup
            string updateKeysFilePath = Path.Combine(Server.MapPath("~"), "updateEncryptionKeys.txt");

            if(File.Exists(updateKeysFilePath))
            {
                NKodServerDataProvider dataProvider = nKodeJsonProvider.GetNKodeDataProviderInstance();
                try
                {
                    //Update is done within a transcation in an all or none operation.  If it fails, rerun it.
                    await dataProvider.UpdateEncryptionKeyAsync(ConfigurationManager.AppSettings["OldEncryptionKey"],
                                                                ConfigurationManager.AppSettings["EncryptionKey"]);

                    File.Delete(updateKeysFilePath); //Update succeeded, remove file
                }
                catch (Exception ex)
                {
                    //Log/handle error however you wish
                    throw;
                }
            }
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            Exception exception = Server.GetLastError();
            if (exception != null)
            {
                //log the error
            }
        }
    }
}