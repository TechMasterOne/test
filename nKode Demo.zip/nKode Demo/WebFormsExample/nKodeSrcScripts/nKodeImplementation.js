import "core-js/stable";
import "regenerator-runtime/runtime";
import 'url-search-params-polyfill';
import Fingerprint2 from 'fingerprintjs2';
import config from './config.BUILD_MODE';
import nKode from './nKode.BUILD_MODE';

let fingerprint = "";
const fingerprintUnavailableValue = "unavailable";
let isPasscodeSet = false;
let newUser = false;
let isChange = false;
const urlParams = new URLSearchParams(window.location.search);

nKode.setKodChangedCallback(() => {
    let text = "";

    let keyLength = nKode.currentNKodLength();

    for (let i = 1; i <= keyLength; i++) {
        text += "*";
    }

    $("#login-password").val(text);
});

function performWaitForFingerprintAction(functionToCall, tryCount)
{
    if (!tryCount)
        tryCount = 1;
    else
        tryCount++;

    if (fingerprint === "") {
        if (tryCount > 2) {
            fingerprint = fingerprintUnavailableValue;
            functionToCall();
        }
        else {
            setTimeout(function () {
                performWaitForFingerprintAction(functionToCall, tryCount);
            }, 250);
        }
    }
    else
        functionToCall();
}


const clickLogin = async () => {
    try {
        $("#errorContainer,#failureMessageContainer").hide();
        if (newUser) {
            if (!usernameIsEntered("#login-username"))
                return;

            if (nKode.currentNKodLength() < 4) {
                $("#nKodTooShort").modal("show");
                return;
            }

            setInterfaceWaitDisplay();

            if (!isPasscodeSet) {
                let data = await nKode.createNKodeStep1($("#login-username").val(), { isChange: isChange });
                if (data.userExists) {
                    $("#usernameAlreadyExists").modal("show");
                    $("#login-username").val("");
                    //Interface will be regenerated when user closes modal notification
                }
                else {
                    isPasscodeSet = true;
                    $("#interfaceSelectionContainer,#signUpStep1Message").hide();
                    $("#login-password")[0].placeholder = "Re-enter your nKode to confirm";
                    $("#login").text("Finish");

                    if (!isChange)
                    {
                        $("#loggingInAs").text($("#login-username").val());
                        $("#usernameAction").text("Registering as:");
                        $("#loggingInAsContainer").show();
                    }
                   
                    $('#userPassContainer,#passwordContainer,#loginContainer,#nkod,.instruct,#signUpStep2Message').show();
                }
            }
            else {
                performWaitForFingerprintAction(async function () {
                    let data = await nKode.createNKodeStep2($("#login-username").val(), fingerprint, $("input[name='rdoInterface']:checked").val(), { isChange: isChange });

                    if (data.Success) {
                        if (isChange)
                            location.replace('/nkodeChangeSuccess.aspx');
                        else
                            location.replace('/nkode.aspx?registrationSuccessful=true&username=' + $("#login-username").val());
                    }
                    else {
                        if (data.NKodLengthUnequal) //Client side check of two lengths failed
                        {
                            $("#nKodLengthDoesNotMatch").modal("show");
                        }
                        else if (data.NKodCompareFailed) //Server side compare of entered nKode failed
                        {
                            $("#nkodDoesNotMatchModal").modal("show");
                        }
                        else if (data.PolicyCompareResult) //Server side policy validation results
                        {
                            document.getElementById("minLengthError").style.display = data.PolicyCompareResult.MinLengthIsValid ? "none" : "block";
                            document.getElementById("maxLengthError").style.display = data.PolicyCompareResult.MaxLengthIsValid ? "none" : "block";
                            document.getElementById("complexityError").style.display = data.PolicyCompareResult.ComplexityIsValid ? "none" : "block";
                            document.getElementById("disparityError").style.display = data.PolicyCompareResult.DisparityIsValid ? "none" : "block";

                            $("#invalidNKodModal").modal("show");
                        }
                    }
                });
            }
        }
        else {
            setInterfaceWaitDisplay();
            try {
                let success = await nKode.login($("#login-username").val(), { isVerifyLoginForNKodeChange: isChange });

                if (success) {
                    if (isChange)                         
                        showSignUpInterface();                    
                    else
                        location.replace('/ProtectedPages/SampleProtectedPage.aspx');
                }
               
            }
            catch (ex) {
                // Show login error
                switch (ex.status) {
                    case 401:
                        let responseText = (ex.responseText || "").replace(/^"+|"+$/g, '');

                        if (responseText === "Account Inactive")
                            $('#failureMessage').text("Invalid nKode -- this account is inactive");
                        else if (responseText === "Account Locked")
                            $('#failureMessage').text("Invalid nKode -- this account is currently locked out");
                        else
                            $('#failureMessage').text("Invalid nKode");
                        $('#failureMessageContainer').show();
                        break;
                    //case 500:
                    //    $('#failureMessage').text("An unexpected server error occurred");
                    //    break;
                    default:
                        handleError(ex);
                        break;
                }

                if (isChange)
                    showConfirmNKodeDisplay();
                else
                    getSignInInterface();                

                
            }
        }
    }
    catch (e) {
        handleError(e);
    }
    finally {
        $('#spinnerContainer').hide();
    }
};


function setInterfaceWaitDisplay()
{
    $("#emailContainer,#userPassContainer,#passwordContainer,#loginContainer,#nkod,.instruct,#interfaceSelectionContainer").hide();    
    $('#spinnerContainer').show();       
}

function handleKeydown(e) {
    if (e.keyCode === 8) {
        e.preventDefault();
        nKode.removeLastEntry();
    }
}

function usernameIsEntered(usernameInputId) {
    var $usernameInput = $(usernameInputId);
    if ($usernameInput.val() === "") {
        $usernameInput.addClass("error");
        return false;
    }

    $usernameInput.removeClass("error");
    return true;
}

$("#nkodDoesNotMatchModal,#invalidNKodModal,#nKodLengthDoesNotMatch").on("hide.bs.modal",async function ()
{       
    await showSignUpInterface();
});

//Add your own error handling/logging here
function handleError(e, ) {    
    $("#errorMessage").text(`An unexpected error occurred: ${e.message}. HTTP status code: ${e.status}, status text: ${e.statusText }`);
    $("#errorContainer").show();
    console.log(e);
}

$("#signInModal").on("hide.bs.modal", function () {
    $("#nkod").empty();
    $('#spinnerContainer').show();
    $('#userPassContainer,#loginContainer').hide();    
});

$("#usernameAlreadyExists").on("hide.bs.modal", function () {
    if ($("#signUpInModal").length > 0)
        $("#signInModal").modal("hide");
    else
        showSignUpInterface();
});

$("#signInModal").on("show.bs.modal", async function (e) {
    if ($("#nKodeModalHeader").text() === "Sign Up")
        showSignUpInterface();
    else
        getSignInInterface();
});

function getSignInInterface() {
    newUser = false;
    isPasscodeSet = false;
        
    var username = $('#login-username').val();

    performWaitForFingerprintAction(async function () {
        try {
            setInterfaceWaitDisplay();
            await nKode.generateLoginInterface(username, 'shapes', fingerprint);

            $("#signUpStep1Message,#signUpStep2Message,#loggingInAsContainer").hide();
            $('#userPassContainer,#passwordContainer,#loginContainer,#nkod,.instruct').show(); 

            $("#login-password")[0].placeholder = "Enter Your nKode";

            if (isChange) {
                $("#emailContainer").hide();
                $("#pageHeader").text("Change nKode");
                $('#confirmnKode').show();
                $("#login").text("Confirm nKode");
            } 
            else
            {                
                $("#usernameAction").text("Logging in as:");
                $("#loggingInAsContainer").show();
                $('#loggingInAs').text($("#login-username").val());
            }
        }
        catch (e) {
            handleError(e);
        }
        finally {
            $('#spinnerContainer').hide();
        }
    });    
}

async function showSignUpInterface () { //    THIS IS FOR SIGN UP
    try {
        newUser = true;
        isPasscodeSet = false;
        let rdoInterface = $("input[name='rdoInterface']:checked").val();

        if (!isChange) {
            $("#emailContainer").show();
            $("#pageHeader").text("Sign Up");
        }

        $("#signUpStep1Message,#interfaceSelectionContainer,#userPassContainer,#passwordContainer,#loginContainer,#nkod,.instruct").show();
        $("#loginContainer,#loggingInAsContainer,#signIn,#signUpStep2Message,#confirmnKode,#signUpContainer").hide();

        $("#login-password").attr("placeholder", "Enter your nKode");
        $("#login").html("Next");
        $("#nkod").empty().show();

        $('#spinnerContainer').show();

        await nKode.generateRegisterInterface(rdoInterface);
        $('#signUpStep1Message,#userPassContainer,#loginContainer').show();

    } catch (e) {
        handleError(e);
    }
    finally {
        $('#spinnerContainer').hide();
    }
}

async function setFingerprint() {
    Fingerprint2.getPromise().then(components => {
        fingerprint = Fingerprint2.x64hash128(components.map(function (pair) { return pair.value; }).join(), 31);
    });
}

if (window.requestIdleCallback) {
    window.requestIdleCallback(setFingerprint);
} else {
    setTimeout(setFingerprint, 500);
}

nKode.setConfig(config);

//  ASYNC IIFE TO CALL ASYNC methods
(async () => {
    var action = urlParams.get('action');
    if (action && action.toLowerCase() == "register")           
        await showSignUpInterface();
    else if (action && action.toLowerCase() == "change")
    {             
        isChange = true;        
        getSignInInterface();
    }
    else //Logging in
    {    
        $("#signIn").show();
        if (urlParams.get("registrationSuccessful")) {
            $("#registrationSuccessful").show();
            var username = urlParams.get("username");
            if (username)
            {
                $("#login-username").val(username);
                getSignInInterface();
            }
        }
    }

})();

function showConfirmNKodeDisplay() {    
    newUser = false;
    isChange = true;
    $("#emailContainer").hide();
    getSignInInterface();
}

$(function () {
  $('[data-toggle="tooltip"]').tooltip();
})

$('input').tooltip({
   trigger: 'manual'
});
$(document).ready(function() {
    $(".interfaceSelection").change(showSignUpInterface);
    $('input:visible').tooltip('show');

    $("#signIn").click(function () {
        if (!usernameIsEntered("#login-username"))
            return;

        getSignInInterface();
    });

    $("#signInWithModal,#signUpInModal").click(function (e) {
        if (!usernameIsEntered("#login-username"))
            return;

        if( $(e.target).is("#signUpInModal"))        
            $("#nKodeModalHeader").text("Sign Up");
        else
            $("#nKodeModalHeader").text("Sign In");

        $("#signInModal").modal("show");
    });

    $("#selectInterface").click(showSignUpInterface);

    $("#clearNKod").click(function () {
        nKode.clear();
    });

    $("#login").click(clickLogin);
    $("#nkodBackspace").click(nKode.removeLastEntry);

    $("#signUpButton").click(async function () {              
        await showSignUpInterface();
    });

    $("#changeUsername").click(async function () {
        if ($("#signIn").length == 0)//On modal
        {
            $("#signInModal").modal("hide");
        }
        else{
            if (newUser)
                await showSignUpInterface();
            else {
                $("#emailContainer").show();
                $("#nkod,#loggingInAsContainer,.instruct,#loginContainer").hide();
            }
        }        

        $("#login-username").val("").focus();
    });
});
