//  ---------------------------------
//  ENVIRONMENT VARIABLES
//  ---------------------------------

var config = {
    API_URL: "http://localhost:48966",      
    HTML_TEMPLATE_PATH: "/nKodeTemplates/${templateIdentifier}.html",    
    CLIENT_ID: "7ee607425af741dabc12e416afa02a47",
    INTERFACE_HTML_PLACEHOLDER_ID: "nkod",   
    MAX_NKOD_LENGTH: 10,
    MIN_NKOD_LENGTH: 4,
    DEBUG: true 
};

export default config;
