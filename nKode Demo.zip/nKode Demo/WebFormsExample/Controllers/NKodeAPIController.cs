﻿using ArcanumTechnology.DataTranslation;
using ArcanumTechnology.nKode;
using ArcanumTechnology.nKode.DataTranslation;
using ArcanumTechnology.nKode.Provider.JSON;
using ArcanumTechnology.nKode.ServerDataProviders;
using Newtonsoft.Json;
using NKodeAdminPortal.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.Caching;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Security;

//See https://docs.microsoft.com/en-us/aspnet/web-api/overview/getting-started-with-aspnet-web-api/using-web-api-with-aspnet-web-forms for adding Web API controller to web forms project.
namespace nKode.WebFormsExample.Controllers
{
    [RoutePrefix("api/nkod"), CustomExceptionFilterAttribute]
    public class NKodeAPIController : ApiController
    {
        static readonly HashSet<string> ManuallyHandledClaimTypes = new HashSet<string>() { NKodRoleClaim.CustomerGUIDClaimType };
        private const int SessionCacheSeconds = 300;
        private const string UsernameVerified = "UsernameVerified|{0}";
        private const string UniqueIdCookieName = "NKodClientIdentifier";

        private void CacheUserLoginVerifiedForChange(string userName)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            memoryCache.Add(string.Format(UsernameVerified, userName), "", new DateTimeOffset(DateTime.Now.AddSeconds(SessionCacheSeconds)));
        }

        private bool IsUsernameVerifiedForChange(string userName)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            string key = string.Format(UsernameVerified, userName);
            bool isVerified = memoryCache.Get(key) != null;
                       
            return isVerified;
        }

        private void RemoveVerifiedUsernameFromCache(string userName)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            string key = string.Format(UsernameVerified, userName);
            memoryCache.Remove(key);
        }

        [HttpPost]
        [Route("generateInterface")]
        public async Task<HttpResponseMessage> GenerateInterface([FromBody]NKodBindingModel data)
        {
            DARCData attributeP1DARCData = new DARCData(JsonConvert.DeserializeObject<RawDARCData>(data.AttributeP1DARCData));
            MutualEphemeralKeys attributeMutualEphemeralKeys = new MutualEphemeralKeys(JsonConvert.DeserializeObject<RawMutualEphemeralKeys>(data.AttributeMutualEphemeralKeys));

            nKodeJsonProvider provider = new nKodeJsonProvider();
            InterfaceData interfaceData = await provider.GenerateInterface(data.ClientId, attributeP1DARCData, attributeMutualEphemeralKeys);

            return Request.CreateResponse(HttpStatusCode.OK, interfaceData);
        }

        [HttpPost]
        [Route("getLoginInterface")]
        public async Task<HttpResponseMessage> GetLoginInterface([FromBody]NKodBindingModel passcode)
        {
            DARCData attributeP1DARCData = new DARCData(JsonConvert.DeserializeObject<RawDARCData>(passcode.AttributeP1DARCData));
            MutualEphemeralKeys attributeMutualEphemeralKeys = new MutualEphemeralKeys(JsonConvert.DeserializeObject<RawMutualEphemeralKeys>(passcode.AttributeMutualEphemeralKeys));

            NKodClientIdentifier identifier = CreateClientIdentifierFromFingerprint(passcode.Fingerprint);
            nKodeJsonProvider provider = new nKodeJsonProvider();
            InterfaceData interfaceData = await provider.GetLoginInterface(passcode.ClientId, passcode.UserName, identifier, attributeP1DARCData, attributeMutualEphemeralKeys);

            return Request.CreateResponse(HttpStatusCode.OK, interfaceData);
        }


        private NKodClientIdentifier CreateClientIdentifierFromFingerprint(string fingerprint)
        {
            if (fingerprint == "unknown") //Browser was unable to generate a fingerprint for some reason
                return null;

            return new NKodClientIdentifier() { ClientType = ClientTypes.WebBrowser, ClientFingerprint = fingerprint };
        }


        // POST: api/PinDragon/login
        /// <summary>
        /// Confirms the user's authentication
        /// </summary>
        /// <param name="value">Keys passed in from UI</param>
        /// <returns>PindragonReturnStatus with code regarding success of failure of login</returns>
        [HttpPost, HttpOptions]
        [Route("")]
        public async Task<HttpResponseMessage> Login(NKodBindingModel login)
        {
            Dictionary<string, bool> loginOptions = JsonConvert.DeserializeObject<Dictionary<string, bool>>(login.AdditionalData);
            bool isVerifyForChange = loginOptions["isVerifyLoginForNKodeChange"];
            
            if (isVerifyForChange && (!User.Identity.IsAuthenticated || login.UserName.ToLower() != User.Identity.Name.ToLower()))
                return Request.CreateResponse(HttpStatusCode.Unauthorized, "Confirm username doesn't match logged in user.");
            
            List<List<byte>> keys = JsonConvert.DeserializeObject<List<List<byte>>>(login.Keys);
            nKodeJsonProvider jsonProvider = new nKodeJsonProvider();

            (AuthStatus result, User user) = await jsonProvider.IsValidUser(login.ClientId, login.SessionId, login.UserName, keys);
            switch (result)
            {
                case AuthStatus.Pass:                   
                    if (isVerifyForChange)
                        CacheUserLoginVerifiedForChange(login.UserName);

                    var resp = Request.CreateResponse(HttpStatusCode.OK, true, "application/json");

                    if(!isVerifyForChange)
                        FormsAuthentication.SetAuthCookie(login.UserName, false);
                    
                    return resp;
                case AuthStatus.Fail:
                    return Request.CreateResponse(HttpStatusCode.Unauthorized);
                case AuthStatus.AccountLocked:
                    return Request.CreateResponse(HttpStatusCode.Unauthorized, "Account Locked");
                case AuthStatus.AccountInactive:
                    return Request.CreateResponse(HttpStatusCode.Unauthorized, "Account Inactive");
                default:
                    return Request.CreateResponse(HttpStatusCode.Unauthorized);
            }
        }        

        [HttpPost, HttpOptions]
        [Route("confirm")]
        public async Task<HttpResponseMessage> Confirm(NKodBindingModel confirmation)
        {
            Dictionary<string, string> options = JsonConvert.DeserializeObject<Dictionary<string, string>>(confirmation.AdditionalData);
            //if(User.Identity.IsAuthenticated)
            bool isChange = bool.Parse(options["isChange"]);
            if (isChange)
            {
                //AuthenticationTicket ticket = Startup.OAuthOptions.AccessTokenFormat.Unprotect(options["bearerToken"]);
                if (!User.Identity.IsAuthenticated || User.Identity.Name != confirmation.UserName || !IsUsernameVerifiedForChange(confirmation.UserName))
                    return Request.CreateResponse(HttpStatusCode.Unauthorized);
            }

            List<List<byte>> keys = JsonConvert.DeserializeObject<List<List<byte>>>(confirmation.Keys);
            nKodeJsonProvider jsonProvider = new nKodeJsonProvider();

            NKodClientIdentifier identifier = CreateClientIdentifierFromFingerprint(confirmation.Fingerprint);

            (CreateNKodResult createNKodResult, NKodLicenseUserInfo licenseUserInfo) = await jsonProvider.ConfirmNKode(confirmation.ClientId, confirmation.SessionId, confirmation.UserName, confirmation.TemplateIdentifier, !isChange, keys, identifier);

            if (licenseUserInfo != null) //Perform license checks here to see if you're getting close to the user limit if applicable
            {
                if (licenseUserInfo.CurrentActiveUsers >= 0.9 * licenseUserInfo.LicenseUserLimit)
                {
                    //The number of users is within 10% of the license limit, send notification 

                }
            }

            if (createNKodResult.Success)
                RemoveVerifiedUsernameFromCache(confirmation.UserName);

            return Request.CreateResponse(HttpStatusCode.OK, createNKodResult);
        }

        [HttpPost, HttpOptions]
        [Route("set")]
        public async Task<HttpResponseMessage> SetPasscode([FromBody]NKodBindingModel passcode)
        {
            Dictionary<string, bool> options = JsonConvert.DeserializeObject<Dictionary<string, bool>>(passcode.AdditionalData);
            List<List<byte>> keys = JsonConvert.DeserializeObject<List<List<byte>>>(passcode.Keys);
            DARCData attributeP1DARCData = new DARCData(JsonConvert.DeserializeObject<RawDARCData>(passcode.AttributeP1DARCData));
            MutualEphemeralKeys attributeMutualEphemeralKeys = new MutualEphemeralKeys(JsonConvert.DeserializeObject<RawMutualEphemeralKeys>(passcode.AttributeMutualEphemeralKeys));

            if (!options["isChange"]) //New user, ensure username doesn't exist
            {
                NKodServerDataProvider serverDataProvider = nKodeJsonProvider.GetNKodeDataProviderInstance();
                if (await serverDataProvider.UserExistsAsync(passcode.UserName, passcode.ClientId))
                    return Request.CreateResponse(HttpStatusCode.OK, new { userExists = true });
            }

            var jsonProvider = new nKodeJsonProvider();

            //Perform dispersion shuffle so that user can confim NKod
            InterfaceData interfaceData = await jsonProvider.CreateNKodeStep1(passcode.ClientId, passcode.SessionId, passcode.UserName, keys, attributeP1DARCData, attributeMutualEphemeralKeys);

            return Request.CreateResponse(HttpStatusCode.OK, interfaceData);
        }
    }
}