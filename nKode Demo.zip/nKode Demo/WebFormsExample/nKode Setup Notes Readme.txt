﻿The MySqlConnector dll must be included.  The Nuget package is used in this particular demo.
The WebApiConfig must be referenced in the Global.asax.cs Application_Start as shown in the demo for references to work.  
Look at the web.config <appSettings> section for the nKode related config keys used.  