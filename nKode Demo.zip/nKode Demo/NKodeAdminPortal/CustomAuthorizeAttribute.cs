﻿using ArcanumTechnology.nKode;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;

namespace NKodeAdminPortal
{
    public enum Permissions
    {
        /// <summary>
        /// System Administrator
        /// </summary>
        All=0, 
        Dashboard=1,
        ManageUsers=2,
        ManageUserRoles=3
    }

    public class CustomAuthorizeAttribute: AuthorizeAttribute
    {
        public readonly Permissions[] Permissions;

        public CustomAuthorizeAttribute(params Permissions[] permissions)
        {
            this.Permissions = permissions;
        }

        protected override bool IsAuthorized(HttpActionContext actionContext)
        {
            if (!base.IsAuthorized(actionContext))
                return false;

            IEnumerable<Permissions> userPermissions = (HttpContext.Current.User.Identity as ClaimsIdentity).Claims.Where(x => x.Type == NKodRoleClaim.PermissionIdClaimType).Select(x => (Permissions)int.Parse(x.Value));

            if (Permissions.Any())
                return (HttpContext.Current.User.Identity as ClaimsIdentity).HasPermission(Permissions);

            return true;
        }

        protected override void HandleUnauthorizedRequest(HttpActionContext actionContext)
        {
            if (HttpContext.Current.User.Identity.IsAuthenticated)
                actionContext.Response = new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.Forbidden,
                    Content = new StringContent("You are forbidden to access this resource")
                };            
            else
                actionContext.Response = new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.Unauthorized,
                    Content = new StringContent("You are unauthorized to access this resource")
                };
        }
    }
}