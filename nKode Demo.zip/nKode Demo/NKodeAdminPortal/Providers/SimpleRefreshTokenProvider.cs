﻿using ArcanumTechnology.ArcanumCommon;
using ArcanumTechnology.nKode;
using ArcanumTechnology.nKode.Provider.JSON;
using ArcanumTechnology.nKode.ServerDataProviders;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.Infrastructure;
using NKodeAdminPortal.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace NKodeAdminPortal.Providers
{
    public class SimpleRefreshTokenProvider : IAuthenticationTokenProvider
    {
        private NKodServerDataProvider _dal =  nKodeJsonProvider.GetNKodeDataProviderInstance();

        public async Task CreateAsync(AuthenticationTokenCreateContext context)
        {
            //var clientid = context.Ticket.Properties.Dictionary["as:client_id"];

            //if (string.IsNullOrEmpty(clientid))
            //{
            //    return;
            //}
            

            string refreshTokenId = Common.FormatGUID(Guid.NewGuid(), GUIDFormats.Format.None);
            TimeSpan refreshTokenLifeTime = TimeSpan.FromMinutes(double.Parse(ConfigurationManager.AppSettings["RefreshTokenLifeMinutes"]));

            RefreshToken refreshToken = new RefreshToken()
            {
                TokenId = Utils.GetHash(refreshTokenId),
                User = context.Ticket.Identity.Name,
                CustomerGUID = Guid.Parse(context.Ticket.Properties.Dictionary["CustomerGUID"]),
                IssuedUtc = DateTime.UtcNow,
                ExpiresUtc = DateTime.UtcNow.Add(refreshTokenLifeTime)
            };          

            context.Ticket.Properties.IssuedUtc = refreshToken.IssuedUtc;
            context.Ticket.Properties.ExpiresUtc = refreshToken.ExpiresUtc;

            refreshToken.ProtectedTicket = context.SerializeTicket();
            await _dal.AddRefreshTokenAsync(refreshToken);
            context.SetToken(refreshTokenId); 
        }

        public async Task ReceiveAsync(AuthenticationTokenReceiveContext context)
        {

            //var allowedOrigin = context.OwinContext.Get<string>("as:clientAllowedOrigin");
            

            string hashedTokenId = Utils.GetHash(context.Token);            
            RefreshToken refreshToken = await _dal.GetRefreshTokenAsync(hashedTokenId);

            if (refreshToken != null)
            {
                //Get protectedTicket from refreshToken class
                context.DeserializeTicket(refreshToken.ProtectedTicket);
                //var result = await _repo.RemoveRefreshToken(hashedTokenId);
            }
        }

        public void Create(AuthenticationTokenCreateContext context)
        {
            throw new NotImplementedException();
        }

        public void Receive(AuthenticationTokenReceiveContext context)
        {
            throw new NotImplementedException();
        }
    }
}
