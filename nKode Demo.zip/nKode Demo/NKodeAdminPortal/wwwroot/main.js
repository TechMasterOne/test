(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-SG": "./node_modules/moment/locale/en-SG.js",
	"./en-SG.js": "./node_modules/moment/locale/en-SG.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/moment/locale/ku.js",
	"./ku.js": "./node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) { // check for number or string
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return id;
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/admin-template/admin-template.component.css":
/*!*************************************************************!*\
  !*** ./src/app/admin-template/admin-template.component.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "body {\r\n  font-size: .875rem;\r\n}\r\n\r\n.feather {\r\n  width: 16px;\r\n  height: 16px;\r\n  vertical-align: text-bottom;\r\n}\r\n\r\n/*\r\n * Sidebar\r\n */\r\n\r\n.sidebar {\r\n  position: fixed;\r\n  top: 0;\r\n  bottom: 0;\r\n  left: 0;\r\n  z-index: 100; /* Behind the navbar */\r\n  padding: 0;\r\n  box-shadow: inset -1px 0 0 rgba(0, 0, 0, .1);\r\n}\r\n\r\n.sidebar-sticky {\r\n  position: -webkit-sticky;\r\n  position: sticky;\r\n  top: 48px; /* Height of navbar */\r\n  height: calc(100vh - 48px);\r\n  padding-top: .5rem;\r\n  overflow-x: hidden;\r\n  overflow-y: auto; /* Scrollable contents if viewport is shorter than content. */\r\n}\r\n\r\n.sidebar .nav-link {\r\n  font-weight: 500;\r\n  color: #333;\r\n}\r\n\r\n.sidebar .nav-link .feather {\r\n    margin-right: 4px;\r\n    color: #999;\r\n  }\r\n\r\n.sidebar .nav-link.active {\r\n    color: #007bff;\r\n  }\r\n\r\n.sidebar .nav-link:hover .feather,\r\n    .sidebar .nav-link.active .feather {\r\n      color: inherit;\r\n    }\r\n\r\n.sidebar-heading {\r\n  font-size: .75rem;\r\n  text-transform: uppercase;\r\n}\r\n\r\n/*\r\n * Navbar\r\n */\r\n\r\n.navbar-brand {\r\n  padding-top: .75rem;\r\n  padding-bottom: .75rem;\r\n  font-size: 1rem;\r\n  background-color: rgba(0, 0, 0, .25);\r\n  box-shadow: inset -1px 0 0 rgba(0, 0, 0, .25);\r\n}\r\n\r\n.navbar .form-control {\r\n  padding: .75rem 1rem;\r\n  border-width: 0;\r\n  border-radius: 0;\r\n}\r\n\r\n.form-control-dark {\r\n  color: #fff;\r\n  background-color: rgba(255, 255, 255, .1);\r\n  border-color: rgba(255, 255, 255, .1);\r\n}\r\n\r\n.form-control-dark:focus {\r\n    border-color: transparent;\r\n    box-shadow: 0 0 0 3px rgba(255, 255, 255, .25);\r\n  }\r\n\r\n/*\r\n * Utilities\r\n */\r\n\r\n.border-top {\r\n  border-top: 1px solid #e5e5e5;\r\n}\r\n\r\n.border-bottom {\r\n  border-bottom: 1px solid #e5e5e5;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWRtaW4tdGVtcGxhdGUvYWRtaW4tdGVtcGxhdGUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osMkJBQTJCO0FBQzdCOztBQUVBOztFQUVFOztBQUVGO0VBQ0UsZUFBZTtFQUNmLE1BQU07RUFDTixTQUFTO0VBQ1QsT0FBTztFQUNQLFlBQVksRUFBRSxzQkFBc0I7RUFDcEMsVUFBVTtFQUNWLDRDQUE0QztBQUM5Qzs7QUFFQTtFQUNFLHdCQUF3QjtFQUN4QixnQkFBZ0I7RUFDaEIsU0FBUyxFQUFFLHFCQUFxQjtFQUNoQywwQkFBMEI7RUFDMUIsa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQixnQkFBZ0IsRUFBRSw2REFBNkQ7QUFDakY7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEIsV0FBVztBQUNiOztBQUVFO0lBQ0UsaUJBQWlCO0lBQ2pCLFdBQVc7RUFDYjs7QUFFQTtJQUNFLGNBQWM7RUFDaEI7O0FBRUU7O01BRUUsY0FBYztJQUNoQjs7QUFFSjtFQUNFLGlCQUFpQjtFQUNqQix5QkFBeUI7QUFDM0I7O0FBRUE7O0VBRUU7O0FBRUY7RUFDRSxtQkFBbUI7RUFDbkIsc0JBQXNCO0VBQ3RCLGVBQWU7RUFDZixvQ0FBb0M7RUFDcEMsNkNBQTZDO0FBQy9DOztBQUVBO0VBQ0Usb0JBQW9CO0VBQ3BCLGVBQWU7RUFDZixnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSxXQUFXO0VBQ1gseUNBQXlDO0VBQ3pDLHFDQUFxQztBQUN2Qzs7QUFFRTtJQUNFLHlCQUF5QjtJQUN6Qiw4Q0FBOEM7RUFDaEQ7O0FBRUY7O0VBRUU7O0FBRUY7RUFDRSw2QkFBNkI7QUFDL0I7O0FBRUE7RUFDRSxnQ0FBZ0M7QUFDbEMiLCJmaWxlIjoic3JjL2FwcC9hZG1pbi10ZW1wbGF0ZS9hZG1pbi10ZW1wbGF0ZS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiYm9keSB7XHJcbiAgZm9udC1zaXplOiAuODc1cmVtO1xyXG59XHJcblxyXG4uZmVhdGhlciB7XHJcbiAgd2lkdGg6IDE2cHg7XHJcbiAgaGVpZ2h0OiAxNnB4O1xyXG4gIHZlcnRpY2FsLWFsaWduOiB0ZXh0LWJvdHRvbTtcclxufVxyXG5cclxuLypcclxuICogU2lkZWJhclxyXG4gKi9cclxuXHJcbi5zaWRlYmFyIHtcclxuICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgdG9wOiAwO1xyXG4gIGJvdHRvbTogMDtcclxuICBsZWZ0OiAwO1xyXG4gIHotaW5kZXg6IDEwMDsgLyogQmVoaW5kIHRoZSBuYXZiYXIgKi9cclxuICBwYWRkaW5nOiAwO1xyXG4gIGJveC1zaGFkb3c6IGluc2V0IC0xcHggMCAwIHJnYmEoMCwgMCwgMCwgLjEpO1xyXG59XHJcblxyXG4uc2lkZWJhci1zdGlja3kge1xyXG4gIHBvc2l0aW9uOiAtd2Via2l0LXN0aWNreTtcclxuICBwb3NpdGlvbjogc3RpY2t5O1xyXG4gIHRvcDogNDhweDsgLyogSGVpZ2h0IG9mIG5hdmJhciAqL1xyXG4gIGhlaWdodDogY2FsYygxMDB2aCAtIDQ4cHgpO1xyXG4gIHBhZGRpbmctdG9wOiAuNXJlbTtcclxuICBvdmVyZmxvdy14OiBoaWRkZW47XHJcbiAgb3ZlcmZsb3cteTogYXV0bzsgLyogU2Nyb2xsYWJsZSBjb250ZW50cyBpZiB2aWV3cG9ydCBpcyBzaG9ydGVyIHRoYW4gY29udGVudC4gKi9cclxufVxyXG5cclxuLnNpZGViYXIgLm5hdi1saW5rIHtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIGNvbG9yOiAjMzMzO1xyXG59XHJcblxyXG4gIC5zaWRlYmFyIC5uYXYtbGluayAuZmVhdGhlciB7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDRweDtcclxuICAgIGNvbG9yOiAjOTk5O1xyXG4gIH1cclxuXHJcbiAgLnNpZGViYXIgLm5hdi1saW5rLmFjdGl2ZSB7XHJcbiAgICBjb2xvcjogIzAwN2JmZjtcclxuICB9XHJcblxyXG4gICAgLnNpZGViYXIgLm5hdi1saW5rOmhvdmVyIC5mZWF0aGVyLFxyXG4gICAgLnNpZGViYXIgLm5hdi1saW5rLmFjdGl2ZSAuZmVhdGhlciB7XHJcbiAgICAgIGNvbG9yOiBpbmhlcml0O1xyXG4gICAgfVxyXG5cclxuLnNpZGViYXItaGVhZGluZyB7XHJcbiAgZm9udC1zaXplOiAuNzVyZW07XHJcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxufVxyXG5cclxuLypcclxuICogTmF2YmFyXHJcbiAqL1xyXG5cclxuLm5hdmJhci1icmFuZCB7XHJcbiAgcGFkZGluZy10b3A6IC43NXJlbTtcclxuICBwYWRkaW5nLWJvdHRvbTogLjc1cmVtO1xyXG4gIGZvbnQtc2l6ZTogMXJlbTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsIC4yNSk7XHJcbiAgYm94LXNoYWRvdzogaW5zZXQgLTFweCAwIDAgcmdiYSgwLCAwLCAwLCAuMjUpO1xyXG59XHJcblxyXG4ubmF2YmFyIC5mb3JtLWNvbnRyb2wge1xyXG4gIHBhZGRpbmc6IC43NXJlbSAxcmVtO1xyXG4gIGJvcmRlci13aWR0aDogMDtcclxuICBib3JkZXItcmFkaXVzOiAwO1xyXG59XHJcblxyXG4uZm9ybS1jb250cm9sLWRhcmsge1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMjU1LCAyNTUsIDI1NSwgLjEpO1xyXG4gIGJvcmRlci1jb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAuMSk7XHJcbn1cclxuXHJcbiAgLmZvcm0tY29udHJvbC1kYXJrOmZvY3VzIHtcclxuICAgIGJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICBib3gtc2hhZG93OiAwIDAgMCAzcHggcmdiYSgyNTUsIDI1NSwgMjU1LCAuMjUpO1xyXG4gIH1cclxuXHJcbi8qXHJcbiAqIFV0aWxpdGllc1xyXG4gKi9cclxuXHJcbi5ib3JkZXItdG9wIHtcclxuICBib3JkZXItdG9wOiAxcHggc29saWQgI2U1ZTVlNTtcclxufVxyXG5cclxuLmJvcmRlci1ib3R0b20ge1xyXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZTVlNWU1O1xyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/admin-template/admin-template.component.html":
/*!**************************************************************!*\
  !*** ./src/app/admin-template/admin-template.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nav class=\"navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0\">\r\n  <a class=\"navbar-brand col-sm-3 col-md-2 mr-0\" href=\"#\">Arcanum nKode</a>\r\n \r\n  <ul class=\"navbar-nav px-3\">\r\n    <!--<li class=\"nav-item text-nowrap\">\r\n    <a class=\"nav-link\" (click)=\"signOut()\">Sign out ({{loggedInUser}})</a>\r\n  </li>-->\r\n    <li class=\"nav-item\" ngbDropdown  placement=\"bottom-right\">\r\n      <!--<a class=\"nav-link dropdown-toggle\" ngbDropdownToggle href=\"#\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">Dropdown</a>-->\r\n      <a id=\"dropdownBasic1\" class=\"nav-link\" role=\"button\" ngbDropdownToggle>{{loggedInUser}}</a>\r\n      <div ngbDropdownMenu aria-labelledby=\"dropdownBasic1\">\r\n        <button ngbDropdownItem (click)=\"changeNkode()\">Change nKode</button>\r\n        <button ngbDropdownItem (click)=\"signOut()\">Sign Out</button>        \r\n      </div>\r\n    </li>\r\n  </ul>\r\n</nav>\r\n\r\n<div class=\"container-fluid\">\r\n  <div class=\"row\">\r\n    <nav class=\"col-md-2 d-none d-md-block bg-light sidebar\">\r\n      <div class=\"sidebar-sticky\">\r\n        <ul class=\"nav flex-column\">\r\n          <li class=\"nav-item\" *ngIf=\"authService.userHasPermission(permissions.All)\">\r\n            <a class=\"nav-link\" [routerLink]=\"['customerManagement']\" routerLinkActive=\"active\">\r\n              <fa-icon icon=\"cogs\"></fa-icon>\r\n              Customer Management\r\n            </a>\r\n          </li>\r\n          <li class=\"nav-item\" *ngIf=\"authService.userHasPermission(permissions.Dashboard)\">\r\n            <a class=\"nav-link\" [routerLink]=\"['dashboard']\" routerLinkActive=\"active\">\r\n              <fa-icon icon=\"tachometer-alt\"></fa-icon>\r\n              Dashboard <span class=\"sr-only\">(current)</span>\r\n            </a>\r\n          </li>\r\n          <li class=\"nav-item\" *ngIf=\"authService.userHasPermission(permissions.ManageUsers)\">\r\n            <a class=\"nav-link\" [routerLink]=\"['users']\" routerLinkActive=\"active\">\r\n              <fa-icon icon=\"users\"></fa-icon>\r\n              Users\r\n            </a>\r\n          </li>\r\n          <li class=\"nav-item\" *ngIf=\"authService.userHasPermission(permissions.All)\">\r\n            <a class=\"nav-link\" [routerLink]=\"['roles']\" routerLinkActive=\"active\">\r\n              <fa-icon icon=\"user-secret\"></fa-icon>\r\n              Roles &amp; Permissions\r\n            </a>\r\n          </li>\r\n          <!--<li class=\"nav-item\">\r\n    <a class=\"nav-link\" href=\"#\">\r\n      <fa-icon icon=\"chart-line\"></fa-icon>\r\n      Reports\r\n    </a>\r\n  </li>-->\r\n        </ul>\r\n       \r\n      </div>\r\n    </nav>\r\n\r\n    <main role=\"main\" class=\"col-md-9 ml-sm-auto col-lg-10 pt-3 px-4\">\r\n      <app-error></app-error>\r\n      <router-outlet></router-outlet>\r\n      <app-wait-display></app-wait-display>\r\n    </main>\r\n  </div>\r\n</div>\r\n\r\n"

/***/ }),

/***/ "./src/app/admin-template/admin-template.component.ts":
/*!************************************************************!*\
  !*** ./src/app/admin-template/admin-template.component.ts ***!
  \************************************************************/
/*! exports provided: AdminTemplateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminTemplateComponent", function() { return AdminTemplateComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _authorization_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! .././authorization.service */ "./src/app/authorization.service.ts");
/* harmony import */ var _permissions_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../permissions-enum */ "./src/app/permissions-enum.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");





var AdminTemplateComponent = /** @class */ (function () {
    function AdminTemplateComponent(authService, _router) {
        this.authService = authService;
        this._router = _router;
        this.permissions = _permissions_enum__WEBPACK_IMPORTED_MODULE_3__["Permissions"];
    }
    AdminTemplateComponent.prototype.ngOnInit = function () {
        this.loggedInUser = this.authService.getBearerTokenInformation().userName;
    };
    AdminTemplateComponent.prototype.signOut = function () {
        this.authService.signOut();
    };
    AdminTemplateComponent.prototype.changeNkode = function () {
        this._router.navigateByUrl("/changeNKode");
    };
    AdminTemplateComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-admin-template',
            template: __webpack_require__(/*! ./admin-template.component.html */ "./src/app/admin-template/admin-template.component.html"),
            styles: [__webpack_require__(/*! ./admin-template.component.css */ "./src/app/admin-template/admin-template.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_authorization_service__WEBPACK_IMPORTED_MODULE_2__["AuthorizationService"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], AdminTemplateComponent);
    return AdminTemplateComponent;
}());



/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _n_kode_n_kode_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./n-kode/n-kode.component */ "./src/app/n-kode/n-kode.component.ts");
/* harmony import */ var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./dashboard/dashboard.component */ "./src/app/dashboard/dashboard.component.ts");
/* harmony import */ var _admin_template_admin_template_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./admin-template/admin-template.component */ "./src/app/admin-template/admin-template.component.ts");
/* harmony import */ var _users_users_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./users/users.component */ "./src/app/users/users.component.ts");
/* harmony import */ var _roles_roles_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./roles/roles.component */ "./src/app/roles/roles.component.ts");
/* harmony import */ var _edit_role_edit_role_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./edit-role/edit-role.component */ "./src/app/edit-role/edit-role.component.ts");
/* harmony import */ var _forbidden_forbidden_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./forbidden/forbidden.component */ "./src/app/forbidden/forbidden.component.ts");
/* harmony import */ var _customer_management_customer_management_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./customer-management/customer-management.component */ "./src/app/customer-management/customer-management.component.ts");
/* harmony import */ var _auth_guard_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./auth-guard.service */ "./src/app/auth-guard.service.ts");












var routes = [
    { path: '', redirectTo: '/admin', pathMatch: 'full' },
    { path: 'forbidden', component: _forbidden_forbidden_component__WEBPACK_IMPORTED_MODULE_9__["ForbiddenComponent"] },
    {
        path: 'admin', component: _admin_template_admin_template_component__WEBPACK_IMPORTED_MODULE_5__["AdminTemplateComponent"], canActivate: [_auth_guard_service__WEBPACK_IMPORTED_MODULE_11__["AuthGuardService"]],
        children: [
            { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
            { path: 'dashboard', component: _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_4__["DashboardComponent"] },
            { path: 'users', component: _users_users_component__WEBPACK_IMPORTED_MODULE_6__["UsersComponent"] },
            { path: 'roles', component: _roles_roles_component__WEBPACK_IMPORTED_MODULE_7__["RolesComponent"] },
            { path: 'editRole/:id', component: _edit_role_edit_role_component__WEBPACK_IMPORTED_MODULE_8__["EditRoleComponent"] },
            { path: 'customerManagement', component: _customer_management_customer_management_component__WEBPACK_IMPORTED_MODULE_10__["CustomerManagementComponent"] }
        ]
    },
    { path: 'signup', component: _n_kode_n_kode_component__WEBPACK_IMPORTED_MODULE_3__["NKodeComponent"] },
    { path: 'login', component: _n_kode_n_kode_component__WEBPACK_IMPORTED_MODULE_3__["NKodeComponent"] },
    { path: 'changeNKode', component: _n_kode_n_kode_component__WEBPACK_IMPORTED_MODULE_3__["NKodeComponent"] }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n<router-outlet></router-outlet>\r\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'nKodeAdminAngular';
    }
    AppComponent.prototype.ngOnInit = function () {
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var ng2_charts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng2-charts */ "./node_modules/ng2-charts/fesm5/ng2-charts.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _n_kode_n_kode_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./n-kode/n-kode.component */ "./src/app/n-kode/n-kode.component.ts");
/* harmony import */ var _select_interface_select_interface_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./select-interface/select-interface.component */ "./src/app/select-interface/select-interface.component.ts");
/* harmony import */ var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./dashboard/dashboard.component */ "./src/app/dashboard/dashboard.component.ts");
/* harmony import */ var _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @fortawesome/angular-fontawesome */ "./node_modules/@fortawesome/angular-fontawesome/fesm5/angular-fontawesome.js");
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @fortawesome/fontawesome-svg-core */ "./node_modules/@fortawesome/fontawesome-svg-core/index.es.js");
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ "./node_modules/@fortawesome/free-solid-svg-icons/index.es.js");
/* harmony import */ var _admin_template_admin_template_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./admin-template/admin-template.component */ "./src/app/admin-template/admin-template.component.ts");
/* harmony import */ var _users_users_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./users/users.component */ "./src/app/users/users.component.ts");
/* harmony import */ var _roles_roles_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./roles/roles.component */ "./src/app/roles/roles.component.ts");
/* harmony import */ var _wait_display_wait_display_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./wait-display/wait-display.component */ "./src/app/wait-display/wait-display.component.ts");
/* harmony import */ var _custom_http_interceptor__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./custom-http-interceptor */ "./src/app/custom-http-interceptor.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _confirm_delete_modal_confirm_delete_modal_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./confirm-delete-modal/confirm-delete-modal.component */ "./src/app/confirm-delete-modal/confirm-delete-modal.component.ts");
/* harmony import */ var _edit_role_edit_role_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./edit-role/edit-role.component */ "./src/app/edit-role/edit-role.component.ts");
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ng-select/ng-select */ "./node_modules/@ng-select/ng-select/fesm5/ng-select.js");
/* harmony import */ var _forbidden_forbidden_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./forbidden/forbidden.component */ "./src/app/forbidden/forbidden.component.ts");
/* harmony import */ var _customer_management_customer_management_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./customer-management/customer-management.component */ "./src/app/customer-management/customer-management.component.ts");
/* harmony import */ var _error_error_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./error/error.component */ "./src/app/error/error.component.ts");


























var AppModule = /** @class */ (function () {
    function AppModule() {
        _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_12__["library"].add(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_13__["faSpinner"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_13__["faBackspace"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_13__["faFrown"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_13__["faTachometerAlt"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_13__["faUsers"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_13__["faUserSecret"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_13__["faCogs"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_13__["faChartLine"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_13__["faUserLock"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_13__["faUser"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_13__["faUserTimes"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_13__["faTrash"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_13__["faEdit"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_13__["faTimes"]);
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"],
                _n_kode_n_kode_component__WEBPACK_IMPORTED_MODULE_8__["NKodeComponent"],
                _select_interface_select_interface_component__WEBPACK_IMPORTED_MODULE_9__["SelectInterfaceComponent"],
                _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_10__["DashboardComponent"],
                _admin_template_admin_template_component__WEBPACK_IMPORTED_MODULE_14__["AdminTemplateComponent"],
                _users_users_component__WEBPACK_IMPORTED_MODULE_15__["UsersComponent"],
                _roles_roles_component__WEBPACK_IMPORTED_MODULE_16__["RolesComponent"],
                _wait_display_wait_display_component__WEBPACK_IMPORTED_MODULE_17__["WaitDisplayComponent"],
                _confirm_delete_modal_confirm_delete_modal_component__WEBPACK_IMPORTED_MODULE_20__["ConfirmDeleteModalComponent"],
                _edit_role_edit_role_component__WEBPACK_IMPORTED_MODULE_21__["EditRoleComponent"],
                _forbidden_forbidden_component__WEBPACK_IMPORTED_MODULE_23__["ForbiddenComponent"],
                _customer_management_customer_management_component__WEBPACK_IMPORTED_MODULE_24__["CustomerManagementComponent"],
                _error_error_component__WEBPACK_IMPORTED_MODULE_25__["ErrorComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_6__["AppRoutingModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"],
                _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_11__["FontAwesomeModule"],
                ng2_charts__WEBPACK_IMPORTED_MODULE_5__["ChartsModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_19__["NgbModule"],
                _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_22__["NgSelectModule"]
            ],
            providers: [{
                    provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HTTP_INTERCEPTORS"],
                    useClass: _custom_http_interceptor__WEBPACK_IMPORTED_MODULE_18__["CustomHttpInterceptor"],
                    multi: true
                }],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
            entryComponents: [_confirm_delete_modal_confirm_delete_modal_component__WEBPACK_IMPORTED_MODULE_20__["ConfirmDeleteModalComponent"]]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/auth-guard.service.ts":
/*!***************************************!*\
  !*** ./src/app/auth-guard.service.ts ***!
  \***************************************/
/*! exports provided: AuthGuardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuardService", function() { return AuthGuardService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _authorization_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./authorization.service */ "./src/app/authorization.service.ts");




var AuthGuardService = /** @class */ (function () {
    function AuthGuardService(_authorizationService, _router) {
        this._authorizationService = _authorizationService;
        this._router = _router;
    }
    AuthGuardService.prototype.canActivate = function () {
        if (!this._authorizationService.isAuthenticated()) {
            this._router.navigateByUrl('/login');
            return false;
        }
        return true;
    };
    AuthGuardService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_authorization_service__WEBPACK_IMPORTED_MODULE_3__["AuthorizationService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], AuthGuardService);
    return AuthGuardService;
}());



/***/ }),

/***/ "./src/app/authorization.service.ts":
/*!******************************************!*\
  !*** ./src/app/authorization.service.ts ***!
  \******************************************/
/*! exports provided: AuthorizationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthorizationService", function() { return AuthorizationService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _permissions_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./permissions-enum */ "./src/app/permissions-enum.ts");




var AuthorizationService = /** @class */ (function () {
    function AuthorizationService(_router) {
        this._router = _router;
        this.bearerTokenInfo = null;
    }
    AuthorizationService_1 = AuthorizationService;
    AuthorizationService.prototype.checkForAndHandleUnauthorizedUser = function () {
        if (!this.isAuthenticated()) {
            this._router.navigateByUrl("/login");
            return false;
        }
        return true;
    };
    AuthorizationService.prototype.isAuthenticated = function () {
        var bearerToken = this.getBearerTokenInformation();
        if (!bearerToken)
            return false;
        return true;
    };
    AuthorizationService.prototype.getLoggedInUser = function () {
        var bearerToken = this.getBearerTokenInformation();
        return bearerToken ? bearerToken.userName : "";
    };
    AuthorizationService.prototype.storeBearerTokenInformation = function (bearerToken) {
        bearerToken.permissionIds = JSON.parse(bearerToken.permissionIds);
        this.bearerTokenInfo = bearerToken;
        window.localStorage.setItem(AuthorizationService_1.BearerTokenKey, JSON.stringify(bearerToken));
    };
    AuthorizationService.prototype.userHasPermission = function (permission) {
        var bearerToken = this.getBearerTokenInformation();
        return bearerToken && bearerToken.permissionIds && bearerToken.permissionIds.some(function (x) { return x == _permissions_enum__WEBPACK_IMPORTED_MODULE_3__["Permissions"].All || x == permission; });
    };
    AuthorizationService.prototype.getBearerTokenInformation = function () {
        if (this.bearerTokenInfo == null) {
            var bearerInfoString = window.localStorage.getItem(AuthorizationService_1.BearerTokenKey);
            if (!bearerInfoString)
                return null;
            this.bearerTokenInfo = JSON.parse(bearerInfoString);
        }
        return this.bearerTokenInfo;
    };
    AuthorizationService.prototype.signOut = function () {
        this.bearerTokenInfo = null;
        window.localStorage.removeItem(AuthorizationService_1.BearerTokenKey);
        this._router.navigateByUrl("/login");
    };
    var AuthorizationService_1;
    AuthorizationService.BearerTokenKey = "nKodBearerToken";
    AuthorizationService = AuthorizationService_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], AuthorizationService);
    return AuthorizationService;
}());



/***/ }),

/***/ "./src/app/confirm-delete-modal/confirm-delete-modal.component.css":
/*!*************************************************************************!*\
  !*** ./src/app/confirm-delete-modal/confirm-delete-modal.component.css ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbmZpcm0tZGVsZXRlLW1vZGFsL2NvbmZpcm0tZGVsZXRlLW1vZGFsLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/confirm-delete-modal/confirm-delete-modal.component.html":
/*!**************************************************************************!*\
  !*** ./src/app/confirm-delete-modal/confirm-delete-modal.component.html ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"modal-header\">\r\n  <h4 class=\"modal-title\" id=\"modal-basic-title\">Confirm Delete</h4>\r\n  <button type=\"button\" class=\"close\" aria-label=\"Close\" (click)=\"activeModal.dismiss()\">\r\n    <span aria-hidden=\"true\">&times;</span>\r\n  </button>\r\n</div>\r\n<div class=\"modal-body\">\r\n  {{deleteMessage}}\r\n</div>\r\n<div class=\"modal-footer\">\r\n  <button type=\"button\" class=\"btn btn-primary\" (click)=\"activeModal.close()\">Delete</button>\r\n  <button type=\"button\" class=\"btn btn-danger\" ngbAutofocus (click)=\"activeModal.dismiss()\">Cancel</button>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/confirm-delete-modal/confirm-delete-modal.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/confirm-delete-modal/confirm-delete-modal.component.ts ***!
  \************************************************************************/
/*! exports provided: ConfirmDeleteModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfirmDeleteModalComponent", function() { return ConfirmDeleteModalComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");



var ConfirmDeleteModalComponent = /** @class */ (function () {
    function ConfirmDeleteModalComponent(activeModal) {
        this.activeModal = activeModal;
    }
    ConfirmDeleteModalComponent.prototype.ngOnInit = function () {
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], ConfirmDeleteModalComponent.prototype, "deleteMessage", void 0);
    ConfirmDeleteModalComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-confirm-delete-modal',
            template: __webpack_require__(/*! ./confirm-delete-modal.component.html */ "./src/app/confirm-delete-modal/confirm-delete-modal.component.html"),
            styles: [__webpack_require__(/*! ./confirm-delete-modal.component.css */ "./src/app/confirm-delete-modal/confirm-delete-modal.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__["NgbActiveModal"]])
    ], ConfirmDeleteModalComponent);
    return ConfirmDeleteModalComponent;
}());



/***/ }),

/***/ "./src/app/custom-http-interceptor.ts":
/*!********************************************!*\
  !*** ./src/app/custom-http-interceptor.ts ***!
  \********************************************/
/*! exports provided: CustomHttpInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomHttpInterceptor", function() { return CustomHttpInterceptor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _authorization_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./authorization.service */ "./src/app/authorization.service.ts");
/* harmony import */ var _wait_display_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./wait-display.service */ "./src/app/wait-display.service.ts");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./http.service */ "./src/app/http.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./error.service */ "./src/app/error.service.ts");









var CustomHttpInterceptor = /** @class */ (function () {
    function CustomHttpInterceptor(_authorizationService, _waitDisplayService, httpService, router, errorService) {
        this._authorizationService = _authorizationService;
        this._waitDisplayService = _waitDisplayService;
        this.httpService = httpService;
        this.router = router;
        this.errorService = errorService;
        this.isRefreshingToken = false;
        this.tokenSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"]("refreshing");
    }
    CustomHttpInterceptor.prototype.intercept = function (request, next) {
        var _this = this;
        this.errorService.errorMessage = "";
        this._waitDisplayService.showWait = true;
        return next.handle(this.addTokenToRequest(request)).pipe(
        /*retryWhen(errors => errors
          .pipe(
            concatMap((error, count) => {
              if (count < 2 && error.status != 401 && error.status != 500 && ) {
                return of(error.status);
              }
  
              return throwError(error);
            }),
            delay(200)
          )
        ),*/ Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])(function (err) {
            return _this.handleError(request, err, next);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["finalize"])(function () { return _this._waitDisplayService.showWait = false; }));
    };
    //See http://ericsmasal.com/2018/07/02/angular-6-with-jwt-and-refresh-tokens-and-a-little-rxjs-6/ for article on refreshing token
    CustomHttpInterceptor.prototype.handleError = function (request, err, next) {
        var _this = this;
        switch (err.status) {
            case 400:
                this._authorizationService.signOut();
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])(err);
            case 401:
                var token = this._authorizationService.getBearerTokenInformation();
                if (token != null) //Try to refresh
                 {
                    if (!this.isRefreshingToken) {
                        this.isRefreshingToken = true;
                        this.tokenSubject.next("refreshing");
                        return this.httpService.refreshToken(token.refresh_token).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["switchMap"])(function (data) {
                            _this.tokenSubject.next("refreshed");
                            _this.isRefreshingToken = false;
                            return next.handle(_this.addTokenToRequest(request));
                        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])(function (err) {
                            return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])(err);
                        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["finalize"])(function () { return _this.isRefreshingToken = false; }));
                    }
                    else {
                        this.isRefreshingToken = false;
                        return this.tokenSubject
                            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["filter"])(function (call) { return call != "refreshing"; }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["switchMap"])(function (call) {
                            return next.handle(_this.addTokenToRequest(request));
                        }));
                    }
                }
                else {
                    this._authorizationService.signOut();
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])(err);
                }
            case 403:
                this.router.navigateByUrl("/forbidden");
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])(err);
            default:
                this.errorService.errorMessage = err.message;
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])(err);
        }
        throw err;
    };
    CustomHttpInterceptor.prototype.addTokenToRequest = function (request) {
        if (!this.isRefreshingToken) {
            var token = this._authorizationService.getBearerTokenInformation();
            if (token) {
                var headers = request.headers.set("Authorization", "Bearer " + token.access_token);
                return request.clone({ headers: headers });
            }
        }
        return request;
    };
    CustomHttpInterceptor = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_authorization_service__WEBPACK_IMPORTED_MODULE_4__["AuthorizationService"], _wait_display_service__WEBPACK_IMPORTED_MODULE_5__["WaitDisplayService"], _http_service__WEBPACK_IMPORTED_MODULE_6__["HttpService"], _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"], _error_service__WEBPACK_IMPORTED_MODULE_8__["ErrorService"]])
    ], CustomHttpInterceptor);
    return CustomHttpInterceptor;
}());



/***/ }),

/***/ "./src/app/customer-management/customer-management.component.css":
/*!***********************************************************************!*\
  !*** ./src/app/customer-management/customer-management.component.css ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "#clientDarcKeysEncryptionKey { height: 190px}\r\n#clientDarcKeys {\r\n  height: 600px\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY3VzdG9tZXItbWFuYWdlbWVudC9jdXN0b21lci1tYW5hZ2VtZW50LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsK0JBQStCLGFBQWE7QUFDNUM7RUFDRTtBQUNGIiwiZmlsZSI6InNyYy9hcHAvY3VzdG9tZXItbWFuYWdlbWVudC9jdXN0b21lci1tYW5hZ2VtZW50LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjY2xpZW50RGFyY0tleXNFbmNyeXB0aW9uS2V5IHsgaGVpZ2h0OiAxOTBweH1cclxuI2NsaWVudERhcmNLZXlzIHtcclxuICBoZWlnaHQ6IDYwMHB4XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/customer-management/customer-management.component.html":
/*!************************************************************************!*\
  !*** ./src/app/customer-management/customer-management.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row mb-2\" [hidden]=\"!customers\">\r\n  <div class=\"col-12 col-lg-4\">\r\n    <span class=\"form-control-static mr-3\">Manage Customer: </span>\r\n    <!--see https://stackblitz.com/edit/ng-select for demo-->\r\n    <ng-select [items]=\"customers\"\r\n               bindLabel=\"NameForDisplay\"\r\n               placeholder=\"Select Customer\"\r\n               [(ngModel)]=\"selectedCustomer\"\r\n               (change)=\"selectedCustomerChanged()\"\r\n               *ngIf=\"customers && customers.length > 1\">\r\n    </ng-select>\r\n    <span *ngIf=\"customers && customers.length == 1\">{{customers[0].NameForDisplay}}</span>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"row mb-2\">\r\n  <div class=\"col-12 col-lg-4\">\r\n    <button type=\"button\" class=\"btn btn-primary\" (click)=\"addNewCustomer()\">Add New Customer</button>\r\n  </div>\r\n</div>\r\n\r\n<div *ngIf=\"customer\" class=\"col-12 col-lg-6\">\r\n  <ngb-tabset>\r\n    <ngb-tab title=\"General Information\">\r\n      <ng-template ngbTabContent>\r\n        <form (ngSubmit)=\"customerInfoFormSubmitted()\" novalidate class=\"mb-2\">\r\n          <div [formGroup]=\"customerInfoForm\">\r\n            <div class=\"form-group row\">\r\n              <label for=\"inputEmail3\" class=\"{{labelColClass}} col-form-label\">Id</label>\r\n              <div class=\"{{dataColClass}}\">\r\n                {{customer.GUID}}\r\n              </div>\r\n            </div>\r\n            <div class=\"form-group row\">\r\n              <label for=\"inputEmail3\" class=\"{{labelColClass}} col-form-label\">Name</label>\r\n              <div class=\"{{dataColClass}}\">\r\n                <input type=\"text\" class=\"form-control\" formControlName=\"Name\" [ngClass]=\"{ 'is-invalid': customerFormIsSubmitted && f.Name?.invalid }\" placeholder=\"Customer Name\">\r\n                <div *ngIf=\"customerFormIsSubmitted && f.Name?.invalid\" class=\"invalid-feedback\">\r\n                  <div *ngIf=\"f.Name.errors.required\">Customer name is required</div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div class=\"form-group row\">\r\n              <label for=\"inputEmail3\" class=\"{{labelColClass}} col-form-label\">Branch</label>\r\n              <div class=\"{{dataColClass}}\">\r\n                <input type=\"text\" formControlName=\"Branch\" class=\"form-control\" placeholder=\"Customer Branch\">\r\n              </div>\r\n            </div>\r\n            <div class=\"form-group row\">\r\n              <label for=\"inputEmail3\" class=\"{{labelColClass}}\">Active?</label>\r\n              <div class=\"{{dataColClass}}\">\r\n                <div class=\"form-check\">\r\n                  <input type=\"checkbox\" class=\"form-check-input\" formControlName=\"Active\">\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div class=\"form-group row\">\r\n              <label for=\"inputEmail3\" class=\"{{labelColClass}} col-form-label\">Login Lockout Tries</label>\r\n              <div class=\"{{dataColClass}}\">\r\n                <input type=\"number\" step=\"1\" formControlName=\"UserLoginLockoutTries\" class=\"form-control\" [ngClass]=\"{ 'is-invalid': customerFormIsSubmitted && f.UserLoginLockoutTries.invalid }\" placeholder=\"Login Lockout Tries\" required>\r\n                <div *ngIf=\"customerFormIsSubmitted && f.UserLoginLockoutTries.invalid\" class=\"invalid-feedback\">\r\n                  <div *ngIf=\"f.UserLoginLockoutTries.errors.required\">Login lockout tries is required</div>\r\n                  <div *ngIf=\"f.UserLoginLockoutTries.errors.min\">Login lockout tries cannot be less than {{f.UserLoginLockoutTries.errors.min.min}}</div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div class=\"form-group row\">\r\n              <label for=\"inputEmail3\" class=\"{{labelColClass}} col-form-label\">Login Lockout Duration (minutes)</label>\r\n              <div class=\"{{dataColClass}}\">\r\n                <input type=\"number\" step=\"1\" formControlName=\"UserLoginLockoutDurationMinutes\" class=\"form-control\" [ngClass]=\"{ 'is-invalid': customerFormIsSubmitted && f.UserLoginLockoutDurationMinutes.invalid }\" placeholder=\"Login Lockout Duration (Minutes)\" required>\r\n                <div *ngIf=\"customerFormIsSubmitted && f.UserLoginLockoutDurationMinutes.invalid\" class=\"invalid-feedback\">\r\n                  <div *ngIf=\"f.UserLoginLockoutDurationMinutes.errors.required\">Login lockout duration is required</div>\r\n                  <div *ngIf=\"f.UserLoginLockoutDurationMinutes.errors.min\">Login lockout duration cannot be less than {{f.UserLoginLockoutDurationMinutes.errors.min.min}}</div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div formGroupName=\"NKodPolicy\">\r\n              <div class=\"form-group row\">\r\n                <label for=\"inputEmail3\" class=\"{{labelColClass}} col-form-label\">Min nKode Length</label>\r\n                <div class=\"{{dataColClass}}\">\r\n                  <input type=\"number\" step=\"1\" formControlName=\"MinLength\" class=\"form-control\" [ngClass]=\"{ 'is-invalid': customerFormIsSubmitted && f.NKodPolicy.controls.MinLength.invalid }\" required placeholder=\"Min nKodeLength\">\r\n                  <div *ngIf=\"customerFormIsSubmitted && f.NKodPolicy.controls.MinLength.invalid\" class=\"invalid-feedback\">\r\n                    <div *ngIf=\"f.NKodPolicy.controls.MinLength.errors.required\">Min nKode length is required</div>\r\n                    <div *ngIf=\"f.NKodPolicy.controls.MinLength.errors.min\">Minimum nKode length cannot be less than {{f.NKodPolicy.controls.MinLength.errors.min.min}}.</div>\r\n                    <div *ngIf=\"f.NKodPolicy.controls.MinLength.errors.max\">Minimum nKode length cannot be greater than {{f.NKodPolicy.controls.MinLength.errors.max.max}}.</div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n              <div class=\"form-group row\">\r\n                <label for=\"inputEmail3\" class=\"{{labelColClass}} col-form-label\">Max nKode Length</label>\r\n                <div class=\"{{dataColClass}}\">\r\n                  <input type=\"number\" step=\"1\" formControlName=\"MaxLength\" class=\"form-control\" [ngClass]=\"{ 'is-invalid': customerFormIsSubmitted && f.NKodPolicy.controls.MaxLength?.invalid }\" required placeholder=\"Max nKodeLength\">\r\n                  <div *ngIf=\"customerFormIsSubmitted && f.NKodPolicy.controls.MaxLength.invalid\" class=\"invalid-feedback\">\r\n                    <div *ngIf=\"f.NKodPolicy.controls.MaxLength.errors.required\">Min nKode length is required</div>\r\n                    <div *ngIf=\"f.NKodPolicy.controls.MaxLength.errors.max\">Maximum nKode length cannot be greater than {{f.NKodPolicy.controls.MaxLength.errors.max.max}}.</div>\r\n\r\n                  </div>\r\n                </div>\r\n              </div>\r\n              <div class=\"form-group row\">\r\n                <label for=\"inputEmail3\" class=\"{{labelColClass}} col-form-label\">Complexity</label>\r\n                <div class=\"{{dataColClass}}\">\r\n                  <input type=\"number\" step=\"1\" min=\"2\" max=\"10\" formControlName=\"Complexity\" class=\"form-control\" [ngClass]=\"{ 'is-invalid': customerFormIsSubmitted && f.NKodPolicy.controls.Complexity?.invalid }\" required placeholder=\"nKode Complexity\">\r\n                </div>\r\n              </div>\r\n              <div class=\"form-group row\">\r\n                <label for=\"inputEmail3\" class=\"{{labelColClass}} col-form-label\">Disparity</label>\r\n                <div class=\"{{dataColClass}}\">\r\n                  <input type=\"number\" step=\"1\" formControlName=\"Disparity\" class=\"form-control\" [ngClass]=\"{ 'is-invalid': customerFormIsSubmitted && f.NKodPolicy.controls.Disparity?.invalid }\" required placeholder=\"nKode Disparity\">\r\n                </div>\r\n              </div>\r\n\r\n            </div>\r\n          </div>\r\n          <div class=\"form-group row\" [hidden]=\" !customer || customer.GUID || !customers || customers.length === 0\">\r\n            <label for=\"inputEmail3\" class=\"{{labelColClass}} col-form-label\">Use Key Config From Existing Customer?</label>\r\n            <div class=\"{{dataColClass}}\">\r\n              <input type=\"checkbox\" [(ngModel)]=\"useKeyConfigFromExistingCustomer\" name=\"useKeyConfigFromExistingCustomer\" />\r\n            </div>\r\n          </div>\r\n          <div class=\"form-group row\" [hidden]=\"!useKeyConfigFromExistingCustomer\">\r\n            <label for=\"inputEmail3\" class=\"{{labelColClass}} col-form-label\">Customer to Copy From </label>\r\n            <div class=\"{{dataColClass}}\">\r\n              <ng-select [items]=\"customers\"\r\n                         bindLabel=\"NameForDisplay\"\r\n                         placeholder=\"Select Customer\"\r\n                         [(ngModel)]=\"customerToCopyFrom\"\r\n                         *ngIf=\"customers && customers.length > 0\"\r\n                         name=\"customerToCopyFrom\">\r\n              </ng-select>\r\n            </div>\r\n          </div>\r\n\r\n          <div *ngIf=\"customerFormIsSubmitted && f.NKodPolicy.invalid\" class=\"text-danger\">\r\n            <div *ngIf=\"f.NKodPolicy.errors.minNKodeLengthExceedsMaxNKodeLength\">Max nKode length cannot be less than the min nKode length.</div>\r\n            <div *ngIf=\"f.NKodPolicy.errors.disparityExceedsMinNKodeLength\">Disparity cannot exceed min nKode length.</div>\r\n            <div *ngIf=\"f.NKodPolicy.errors.complexityExceedsDisparity\">Complexity cannot exceed disparity.</div>\r\n          </div>\r\n          <button type=\"submit\" class=\"btn btn-primary\">Save</button>\r\n        </form>\r\n      </ng-template>\r\n    </ngb-tab>\r\n    <ngb-tab title=\"Client Information\">\r\n      <ng-template ngbTabContent>\r\n        <ngb-tabset>\r\n          <ngb-tab title=\"Client Attribute Values\">\r\n            <ng-template ngbTabContent>\r\n              <p>Use the values for each attribute set below to define the keypad interface.  For example, if you want to have one attribute set that is smilie faces you will need\r\n              to use all the values for a particular set and associate each value with a different smilie face.  Note that one attribute set will be used for key positioning.\r\n              That attribute set and its associated values are not shown below.</p>\r\n              <ul class=\"mt-3 list-unstyled\">\r\n                <li *ngFor=\"let values of clientAttributeSetsAndValues; let i = index\">\r\n                  <strong>Attribute Set {{i+1}}:</strong> {{values}}\r\n                </li>\r\n              </ul>\r\n            </ng-template>\r\n          </ngb-tab>\r\n          <ngb-tab title=\"DARC Key Information\">\r\n            <ng-template ngbTabContent>\r\n              <div class=\"row\">\r\n                <div class=\"col-12 col-lg-4\"><strong>Encrypted symmetric Keys:</strong></div>\r\n                <div class=\"col-12 col-lg-8\"><textarea class=\"form-control\" id=\"clientDarcKeysEncryptionKey\">{{customer.ClientDarcKeysEncryptionKey}}</textarea></div>\r\n              </div>\r\n              <div class=\"row mt-1\">\r\n                <div class=\"col-12 col-lg-4\"><strong>Encrypted DARC Client Keys:</strong></div>\r\n                <div class=\"col-12 col-lg-8 text-wrap\"><textarea class=\"form-control\" id=\"clientDarcKeys\">{{customer.ClientDarcKeys}}</textarea></div>\r\n              </div>\r\n            </ng-template>\r\n          </ngb-tab>\r\n        </ngb-tabset>\r\n      </ng-template>\r\n    </ngb-tab>   \r\n  </ngb-tabset>\r\n\r\n  \r\n</div>\r\n\r\n"

/***/ }),

/***/ "./src/app/customer-management/customer-management.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/customer-management/customer-management.component.ts ***!
  \**********************************************************************/
/*! exports provided: CustomerManagementComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerManagementComponent", function() { return CustomerManagementComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../http.service */ "./src/app/http.service.ts");
/* harmony import */ var _models_customer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/customer */ "./src/app/models/customer.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _validators_customerInfoValidators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../validators/customerInfoValidators */ "./src/app/validators/customerInfoValidators.ts");
/* harmony import */ var _assets_config_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../assets/config.js */ "./src/assets/config.js");
/* harmony import */ var _models_NKodPolicy__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../models/NKodPolicy */ "./src/app/models/NKodPolicy.ts");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils */ "./src/app/utils.ts");
/* harmony import */ var _assets_nKode_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../assets/nKode.js */ "./src/assets/nKode.js");
/* harmony import */ var _assets_nKode_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_assets_nKode_js__WEBPACK_IMPORTED_MODULE_9__);










var CustomerManagementComponent = /** @class */ (function () {
    function CustomerManagementComponent(httpService, fb) {
        this.httpService = httpService;
        this.fb = fb;
        this.customerFormIsSubmitted = false;
        this.labelColClass = "col-sm-5";
        this.dataColClass = "col-sm-7";
        this.customerInfoForm = this.fb.group({
            Name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            Branch: [''],
            Active: [''],
            UserLoginLockoutTries: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].min(2)]],
            UserLoginLockoutDurationMinutes: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].min(0)]],
            NKodPolicy: this.fb.group({
                MinLength: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].min(_assets_config_js__WEBPACK_IMPORTED_MODULE_6__["default"].MIN_NKOD_LENGTH), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].max(_assets_config_js__WEBPACK_IMPORTED_MODULE_6__["default"].MAX_NKOD_LENGTH)]],
                MaxLength: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].max(_assets_config_js__WEBPACK_IMPORTED_MODULE_6__["default"].MAX_NKOD_LENGTH)]],
                Complexity: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].min(1), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].max(7)]],
                Disparity: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].min(1), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].max(_assets_config_js__WEBPACK_IMPORTED_MODULE_6__["default"].MAX_NKOD_LENGTH)]]
            }, { validators: [_validators_customerInfoValidators__WEBPACK_IMPORTED_MODULE_5__["MinNKodeLengthExceedsMaxNKodeLength"], _validators_customerInfoValidators__WEBPACK_IMPORTED_MODULE_5__["DisparityExceedsMinNKodeLength"], _validators_customerInfoValidators__WEBPACK_IMPORTED_MODULE_5__["ComplexityExceedsDisparity"]] })
        });
    }
    CustomerManagementComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.httpService.getCustomersForUser().subscribe(function (data) {
            _this.customers = data;
            if (_this.customers && _this.customers.length == 1) {
                _this.selectedCustomer = _this.customers[0];
                _this.selectedCustomerChanged();
            }
        });
    };
    CustomerManagementComponent.prototype.selectedCustomerChanged = function () {
        var _this = this;
        this.customer = null;
        this.useKeyConfigFromExistingCustomer = false;
        this.httpService.getCustomer(this.selectedCustomer.GUID).subscribe(function (data) {
            _this.customer = data;
            _this.resetForm();
            _this.customerInfoForm.patchValue(_this.customer);
        });
    };
    CustomerManagementComponent.prototype.resetForm = function () {
        this.customerInfoForm.reset();
        this.customerFormIsSubmitted = false;
    };
    Object.defineProperty(CustomerManagementComponent.prototype, "f", {
        get: function () {
            return this.customerInfoForm.controls;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CustomerManagementComponent.prototype, "clientAttributeSetsAndValues", {
        get: function () {
            return _assets_nKode_js__WEBPACK_IMPORTED_MODULE_9___default.a.getClientAttributeSetsAndValues().slice(0, 6);
        },
        enumerable: true,
        configurable: true
    });
    CustomerManagementComponent.prototype.customerInfoFormSubmitted = function () {
        var _this = this;
        this.customerFormIsSubmitted = true;
        if (!this.customerInfoForm.valid)
            return;
        this.customer = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, this.customer, this.customerInfoForm.value);
        if (this.customer.GUID) {
            this.httpService.saveCustomer(this.customer);
        }
        else {
            if (this.useKeyConfigFromExistingCustomer) {
                this.httpService.createCustomerFromExisting(this.customer, this.customerToCopyFrom.GUID).subscribe(function (x) { _this.processNewlyAddedCustomer(x); });
            }
            else {
                this.httpService.createCustomer(this.customer).subscribe(function (x) { _this.processNewlyAddedCustomer(x); });
            }
        }
    };
    CustomerManagementComponent.prototype.processNewlyAddedCustomer = function (customer) {
        _utils__WEBPACK_IMPORTED_MODULE_8__["Utils"].setCustomerNameForDisplay(customer);
        this.customer = customer;
        //this.customers.push(customer);
        this.customers = this.customers.concat([customer]); //Must add this way for ng-select to detect change
        this.selectedCustomer = customer;
        this.customerToCopyFrom = null;
        this.useKeyConfigFromExistingCustomer = false;
    };
    CustomerManagementComponent.prototype.addNewCustomer = function () {
        this.selectedCustomer = null;
        this.customer = new _models_customer__WEBPACK_IMPORTED_MODULE_3__["Customer"]();
        this.resetForm();
        this.customerInfoForm.patchValue(this.customer);
        if (this.customers && this.customers.length > 0) {
            this.useKeyConfigFromExistingCustomer = true;
            this.customerToCopyFrom = this.customers[0];
        }
        else {
            this.useKeyConfigFromExistingCustomer = false;
            this.customerToCopyFrom = null;
        }
        this.customer.Active = true;
        this.customer.UserLoginLockoutTries = 3;
        this.customer.UserLoginLockoutDurationMinutes = 5;
        this.customer.NKodPolicy = new _models_NKodPolicy__WEBPACK_IMPORTED_MODULE_7__["NKodPolicy"]();
        this.customer.NKodPolicy.MinLength = 4;
        this.customer.NKodPolicy.MaxLength = 4;
        this.customer.NKodPolicy.Complexity = 2;
        this.customer.NKodPolicy.Disparity = 2;
        this.customerInfoForm.patchValue(this.customer);
    };
    CustomerManagementComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-customer-management',
            template: __webpack_require__(/*! ./customer-management.component.html */ "./src/app/customer-management/customer-management.component.html"),
            styles: [__webpack_require__(/*! ./customer-management.component.css */ "./src/app/customer-management/customer-management.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]])
    ], CustomerManagementComponent);
    return CustomerManagementComponent;
}());



/***/ }),

/***/ "./src/app/dashboard/dashboard.component.css":
/*!***************************************************!*\
  !*** ./src/app/dashboard/dashboard.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".infoBox {\r\n  min-height: 90px;\r\n  box-shadow: 0 1px 1px rgba(0,0,0,.1);\r\n  border-radius: 2px;\r\n  background-color: #f8f9fa;\r\n}\r\n.infoBoxIcon {\r\n  float: left;\r\n  \r\n  text-align: center;\r\n  line-height: 90px;\r\n  width: 90px;\r\n  display: block;\r\n  font-size: 36px;\r\n}\r\n.allUsersInfoBox {\r\n  background-color: #1ab496;\r\n}\r\n.activeUsersInfoBox {\r\n  background-color: #00a65a;\r\n}\r\n.inactiveUsersInfoBox {\r\n  background-color: yellow;\r\n}\r\n.lockedOutUsersInfoBox {\r\n  background-color: red;\r\n}\r\n.infoBoxContent { float:left; padding:15px;}\r\n#chartContainer { height:350px}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGFzaGJvYXJkL2Rhc2hib2FyZC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQWdCO0VBQ2hCLG9DQUFvQztFQUNwQyxrQkFBa0I7RUFDbEIseUJBQXlCO0FBQzNCO0FBQ0E7RUFDRSxXQUFXOztFQUVYLGtCQUFrQjtFQUNsQixpQkFBaUI7RUFDakIsV0FBVztFQUNYLGNBQWM7RUFDZCxlQUFlO0FBQ2pCO0FBRUE7RUFDRSx5QkFBeUI7QUFDM0I7QUFFQTtFQUNFLHlCQUF5QjtBQUMzQjtBQUVBO0VBQ0Usd0JBQXdCO0FBQzFCO0FBRUE7RUFDRSxxQkFBcUI7QUFDdkI7QUFFQSxrQkFBa0IsVUFBVSxFQUFFLFlBQVksQ0FBQztBQUczQyxrQkFBa0IsWUFBWSIsImZpbGUiOiJzcmMvYXBwL2Rhc2hib2FyZC9kYXNoYm9hcmQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5pbmZvQm94IHtcclxuICBtaW4taGVpZ2h0OiA5MHB4O1xyXG4gIGJveC1zaGFkb3c6IDAgMXB4IDFweCByZ2JhKDAsMCwwLC4xKTtcclxuICBib3JkZXItcmFkaXVzOiAycHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y4ZjlmYTtcclxufVxyXG4uaW5mb0JveEljb24ge1xyXG4gIGZsb2F0OiBsZWZ0O1xyXG4gIFxyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBsaW5lLWhlaWdodDogOTBweDtcclxuICB3aWR0aDogOTBweDtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBmb250LXNpemU6IDM2cHg7XHJcbn1cclxuXHJcbi5hbGxVc2Vyc0luZm9Cb3gge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMxYWI0OTY7XHJcbn1cclxuXHJcbi5hY3RpdmVVc2Vyc0luZm9Cb3gge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMwMGE2NWE7XHJcbn1cclxuXHJcbi5pbmFjdGl2ZVVzZXJzSW5mb0JveCB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogeWVsbG93O1xyXG59XHJcblxyXG4ubG9ja2VkT3V0VXNlcnNJbmZvQm94IHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiByZWQ7XHJcbn1cclxuXHJcbi5pbmZvQm94Q29udGVudCB7IGZsb2F0OmxlZnQ7IHBhZGRpbmc6MTVweDt9XHJcblxyXG5cclxuI2NoYXJ0Q29udGFpbmVyIHsgaGVpZ2h0OjM1MHB4fVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/dashboard/dashboard.component.html":
/*!****************************************************!*\
  !*** ./src/app/dashboard/dashboard.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom\">\r\n  <h1 class=\"h2\">Dashboard</h1>\r\n</div>\r\n\r\n<div class=\"row form-inline mb-2\">\r\n  <div class=\"col-12 col-lg-4\">\r\n    <span class=\"form-control-static mr-3\">Showing Data For: </span>\r\n    <ng-select [items]=\"customers\"\r\n               bindLabel=\"NameForDisplay\"\r\n               placeholder=\"All Customers\"\r\n               [(ngModel)]=\"customer\"\r\n              (change)=\"loadDashboardInfo()\"\r\n               *ngIf=\"customers && customers.length > 1\">\r\n    </ng-select>\r\n    <span *ngIf=\"customers && customers.length == 1\">{{customers[0].NameForDisplay}}</span>\r\n  </div>\r\n</div>\r\n\r\n<section class=\"row\" *ngIf=\"dashboardSummary\">\r\n  <div class=\"col-lg-3 \">\r\n    <div class=\"infoBox\">\r\n      <span class=\"infoBoxIcon allUsersInfoBox\">\r\n        <fa-icon icon=\"users\"></fa-icon>\r\n      </span>\r\n      <div class=\"infoBoxContent\">\r\n        <div class=\"infoBoxHeading\">TOTAL USERS</div>\r\n        <div class=\"infoBoxNumber\"><strong>{{dashboardSummary.TotalUsers}}</strong></div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"col-lg-3 \">\r\n    <div class=\"infoBox\">\r\n      <span class=\"infoBoxIcon activeUsersInfoBox\">\r\n        <fa-icon icon=\"user\"></fa-icon>\r\n      </span>\r\n      <div class=\"infoBoxContent\">\r\n        <div class=\"infoBoxHeading\">ACTIVE USERS</div>\r\n        <div class=\"infoBoxNumber\"><strong>{{dashboardSummary.ActiveUsers}}</strong></div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"col-lg-3 \">\r\n    <div class=\"infoBox\">\r\n      <span class=\"infoBoxIcon inactiveUsersInfoBox\">\r\n        <fa-icon icon=\"user-times\"></fa-icon>\r\n      </span>\r\n      <div class=\"infoBoxContent\">\r\n        <div class=\"infoBoxHeading\">INACTIVE USERS</div>\r\n        <div class=\"infoBoxNumber\"><strong>{{dashboardSummary.InactiveUsers}}</strong></div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"col-lg-3 \">\r\n    <div class=\"infoBox\">\r\n      <span class=\"infoBoxIcon lockedOutUsersInfoBox\">\r\n        <fa-icon icon=\"user-lock\"></fa-icon>\r\n      </span>\r\n      <div class=\"infoBoxContent\">\r\n        <div class=\"infoBoxHeading\">LOCKED OUT USERS</div>\r\n        <div class=\"infoBoxNumber\"><strong>{{dashboardSummary.LockedOutUsers}}</strong></div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n\r\n  <div id=\"chartContainer\" >\r\n    <canvas baseChart [colors]=\"barChartColors\" [datasets]=\"barChartData\" [labels]=\"barChartLabels\"\r\n            [options]=\"barChartOptions\" [legend]=\"barChartLegend\" [chartType]=\"barChartType\"></canvas>\r\n  </div>\r\n\r\n\r\n<!--<h2>Section title</h2>\r\n<div class=\"table-responsive\">\r\n  <table class=\"table table-striped table-sm\">\r\n    <thead>\r\n      <tr>\r\n        <th>#</th>\r\n        <th>Header</th>\r\n        <th>Header</th>\r\n        <th>Header</th>\r\n        <th>Header</th>\r\n      </tr>\r\n    </thead>\r\n    <tbody>\r\n      <tr>\r\n        <td>1,001</td>\r\n        <td>Lorem</td>\r\n        <td>ipsum</td>\r\n        <td>dolor</td>\r\n        <td>sit</td>\r\n      </tr>\r\n\r\n    </tbody>\r\n  </table>\r\n</div>-->\r\n"

/***/ }),

/***/ "./src/app/dashboard/dashboard.component.ts":
/*!**************************************************!*\
  !*** ./src/app/dashboard/dashboard.component.ts ***!
  \**************************************************/
/*! exports provided: DashboardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardComponent", function() { return DashboardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var ng2_charts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng2-charts */ "./node_modules/ng2-charts/fesm5/ng2-charts.js");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! chart.js */ "./node_modules/chart.js/src/chart.js");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(chart_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var chartjs_plugin_annotation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! chartjs-plugin-annotation */ "./node_modules/chartjs-plugin-annotation/src/index.js");
/* harmony import */ var chartjs_plugin_annotation__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(chartjs_plugin_annotation__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _models_data_series__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../models/data-series */ "./src/app/models/data-series.ts");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../http.service */ "./src/app/http.service.ts");







var DashboardComponent = /** @class */ (function () {
    function DashboardComponent(httpService) {
        this.httpService = httpService;
        this.dataSeries = [
            {
                index: 0,
                axisId: 'Registrations',
                colorName: 'green',
                label: 'Registrations',
                units: 'Users',
                activeInBypassMode: true,
            }
        ];
        this.barChartOptions = {
            scaleShowVerticalLines: false,
            responsive: true,
            scales: {
                yAxes: [{
                        id: 'Registrations',
                        type: 'linear',
                        ticks: {
                            beginAtZero: true
                        },
                        scaleLabel: {
                            display: true,
                            labelString: 'Registrations',
                        },
                    }]
            },
            tooltips: {
                mode: 'index',
                position: 'nearest',
                intersect: false,
            },
            animation: {
                duration: 0,
            },
            hover: {
                intersect: false,
            },
            maintainAspectRatio: false
            /*,
            annotation: {
              annotations: [
                {
                  type: 'box',
                  yScaleID: 'Registrations',
                  yMin: 104,
                  yMax: 120.2,
                  backgroundColor: 'rgba(0,255,0,0.15)',
                  borderColor: 'rgba(0,255,0,0.05)',
                  borderWidth: 0,
                }
              ]
            }*/
        };
        this.barChartLabels = [];
        this.barChartData = [];
        this.barChartDataTemp = [];
        this.barChartType = 'line';
        this.barChartLegend = true;
        chart_js__WEBPACK_IMPORTED_MODULE_3__["Chart"].pluginService.register(chartjs_plugin_annotation__WEBPACK_IMPORTED_MODULE_4__);
        this.refreshDataSeries();
    }
    DashboardComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.httpService.getCustomersForUser().subscribe(function (data) {
            _this.customers = data;
            if (_this.customers && _this.customers.length == 1)
                _this.customer = _this.customers[0];
        });
        this.loadDashboardInfo();
    };
    DashboardComponent.prototype.loadDashboardInfo = function () {
        var _this = this;
        this.httpService.getAdminDashboardSummary(this.customer ? this.customer.GUID : null).subscribe(function (result) {
            _this.barChartLabels = [];
            _this.barChartData = [];
            for (var _i = 0, _a = result.Registrations; _i < _a.length; _i++) {
                var value = _a[_i];
                _this.barChartLabels.push(value.Month + "/" + value.Year);
                _this.barChartData.push(value.RegistrationCount);
            }
            _this.dashboardSummary = result;
        });
    };
    DashboardComponent.prototype.selected = function (value) {
        console.log('Selected value is: ', value);
    };
    DashboardComponent.prototype.removed = function (value) {
        console.log('Removed value is: ', value);
    };
    DashboardComponent.prototype.refreshDataSeries = function () {
        // This is an ugly hack in ng2-charts, line colors will not work without this:
        this.barChartColors = this.dataSeries.map(function (r) { return ({
            backgroundColor: _models_data_series__WEBPACK_IMPORTED_MODULE_5__["chartColors"][r.colorName]
        }); });
        this.barChartData = this.dataSeries.map(function (r) { return ({
            data: [],
            label: r.label,
            yAxisID: r.axisId,
            pointRadius: 3,
            pointBorderWidth: 1,
            pointHoverRadius: 4,
            pointHoverBorderWidth: 2,
            pointHitRadius: 1,
            borderWidth: 1,
            fill: false,
            borderColor: _models_data_series__WEBPACK_IMPORTED_MODULE_5__["chartColors"][r.colorName],
        }); });
        this.barChartDataTemp = this.dataSeries.map(function (r) { return ({
            data: [],
            label: r.label,
        }); });
        /*this.barChartLabels = [
          '10:00',
          '10:30',
          '11:00',
          '11:30',
          '12:00',
          '12:30',
          '13:00',
          '13:30',
          '14:00'
        ];
    
        this.barChartData[0].data = [
          50, 65, 68, 89, 92, 99, 108, 122, 130
        ];*/
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(ng2_charts__WEBPACK_IMPORTED_MODULE_2__["BaseChartDirective"]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", ng2_charts__WEBPACK_IMPORTED_MODULE_2__["BaseChartDirective"])
    ], DashboardComponent.prototype, "ch", void 0);
    DashboardComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-dashboard',
            template: __webpack_require__(/*! ./dashboard.component.html */ "./src/app/dashboard/dashboard.component.html"),
            styles: [__webpack_require__(/*! ./dashboard.component.css */ "./src/app/dashboard/dashboard.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_http_service__WEBPACK_IMPORTED_MODULE_6__["HttpService"]])
    ], DashboardComponent);
    return DashboardComponent;
}());



/***/ }),

/***/ "./src/app/edit-role/edit-role.component.css":
/*!***************************************************!*\
  !*** ./src/app/edit-role/edit-role.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2VkaXQtcm9sZS9lZGl0LXJvbGUuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/edit-role/edit-role.component.html":
/*!****************************************************!*\
  !*** ./src/app/edit-role/edit-role.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<h1>Edit Role</h1>\r\n\r\n<form name=\"editRoleForm\" #editRoleForm=\"ngForm\" (ngSubmit)=\"editRoleForm.form.valid && saveRole()\" novalidate class=\"mb-2\" *ngIf=\"editRoleVM\">\r\n  <div class=\"form-group row\">\r\n    <label class=\"col-lg-2 col-form-label\">Role: </label>\r\n    <div class=\"col-lg-5\">\r\n      <input #roleName=\"ngModel\" name=\"roleName\" type=\"text\" [(ngModel)]=\"editRoleVM.Role.Role\" class=\"form-control mr-sm-2\" [ngClass]=\"{ 'is-invalid': editRoleForm.submitted && roleName?.invalid }\" required placeholder=\"Role\">\r\n      <div *ngIf=\"editRoleForm.submitted && roleName?.invalid\" class=\"invalid-feedback\">\r\n        <div *ngIf=\"roleName.errors.required\">Role is required</div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"form-group row\">\r\n    <div class=\"col-lg-2\"> All Customer Access?</div>\r\n    <div class=\"col-lg-5\">\r\n      <div class=\"form-check\">\r\n        <input class=\"form-check-input\" type=\"checkbox\" [(ngModel)]=\"editRoleVM.Role.AllCustomerAccess\" name=\"allCustomerAccess\" value=\"true\" id=\"allCustomerAccessCheck\">\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"form-group row\" *ngIf=\"!editRoleVM.Role.AllCustomerAccess\">\r\n    <div class=\"col-lg-2 col-form-label\"> Select Customers for Access</div>\r\n    <div class=\"col-lg-5 \">\r\n      <ng-select [items]=\"editRoleVM.AvailableCustomers\"                 \r\n                 bindLabel=\"NameForDisplay\"\r\n                 bindValue=\"GUID\"\r\n                 name=\"customers\"\r\n                 [multiple]=\"true\"\r\n                 placeholder=\"Select Customers for Access\"\r\n                 [(ngModel)]=\"selectedCustomerIds\"\r\n                 (add)=\"customerAdded($event)\"\r\n                 (remove)=\"customerRemoved($event)\"\r\n                 (clear)=\"customerCleared()\">\r\n      </ng-select>      \r\n    </div>\r\n  </div>\r\n  <h3>Permissions</h3>\r\n  <ul class=\"list-unstyled\" *ngIf=\"editRoleVM && editRoleVM.Permissions\">\r\n    <li *ngFor=\"let permission of editRoleVM.Permissions;let i=index\">\r\n      <label><input type=\"checkbox\" [(ngModel)]=\"permission.Selected\" name=\"permission{{i}}\" value=\"true\" (change)=\"permissionSelectionChanged(permission)\" /> {{permission.Permission}}</label>\r\n      <div *ngIf=\"permission.Id == 3 && permission.Selected\" class=\"ml-3\">\r\n        Select roles the user will be allowed to add/remove from other users:\r\n        <ul class=\"list-unstyled ml-3\">\r\n          <li *ngFor=\"let role of editRoleVM.AvailableRoles;let j=index\">\r\n            <label><input type=\"checkbox\" [(ngModel)]=\"role.Selected\" name=\"role{{j}}\" value=\"true\" (change)=\"canManageRoleRoleSelectionChanged(role)\" /> {{role.Role}}</label>\r\n          </li>\r\n        </ul>\r\n      </div>\r\n    </li>\r\n  </ul>\r\n  <div class=\"form-group row\">\r\n    <div class=\"col-sm-10\">\r\n      <button type=\"submit\" class=\"btn btn-primary\">Save</button>\r\n    </div>\r\n  </div>\r\n</form>\r\n"

/***/ }),

/***/ "./src/app/edit-role/edit-role.component.ts":
/*!**************************************************!*\
  !*** ./src/app/edit-role/edit-role.component.ts ***!
  \**************************************************/
/*! exports provided: EditRoleComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditRoleComponent", function() { return EditRoleComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../http.service */ "./src/app/http.service.ts");
/* harmony import */ var _models_NKodRolePermission__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../models/NKodRolePermission */ "./src/app/models/NKodRolePermission.ts");
/* harmony import */ var _models_NKodRoleClaim__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../models/NKodRoleClaim */ "./src/app/models/NKodRoleClaim.ts");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../utils */ "./src/app/utils.ts");







var EditRoleComponent = /** @class */ (function () {
    function EditRoleComponent(route, httpService) {
        this.route = route;
        this.httpService = httpService;
    }
    EditRoleComponent.prototype.ngOnInit = function () {
        this.getRole();
    };
    EditRoleComponent.prototype.getRole = function () {
        var _this = this;
        var id = +this.route.snapshot.paramMap.get('id');
        this.httpService.getRole(id).subscribe(function (data) {
            _this.editRoleVM = data;
            if (_this.editRoleVM.Permissions) {
                for (var _i = 0, _a = _this.editRoleVM.Permissions; _i < _a.length; _i++) {
                    var permission = _a[_i];
                    permission.Selected = _this.roleHasPermission(permission.Id);
                }
            }
            if (_this.editRoleVM.AvailableRoles) {
                for (var _b = 0, _c = _this.editRoleVM.AvailableRoles; _b < _c.length; _b++) {
                    var availableRole = _c[_b];
                    availableRole.Selected = _this.roleHasClaim(_models_NKodRoleClaim__WEBPACK_IMPORTED_MODULE_5__["NKodRoleClaim"].CanAddRemoveRoleIdClaimType, String(availableRole.Id));
                }
            }
            _this.editRoleVM.AvailableCustomers = _this.editRoleVM.AvailableCustomers.map(function (x) {
                _utils__WEBPACK_IMPORTED_MODULE_6__["Utils"].setCustomerNameForDisplay(x);
                return x;
            });
            _this.selectedCustomerIds = _this.editRoleVM.Role.Claims.filter(function (x) { return x.ClaimType === _models_NKodRoleClaim__WEBPACK_IMPORTED_MODULE_5__["NKodRoleClaim"].CanAccessCustomerClaimType; }).map(function (x) { return x.ClaimValue; });
        });
    };
    EditRoleComponent.prototype.customerAdded = function (customer) {
        var newClaim = new _models_NKodRoleClaim__WEBPACK_IMPORTED_MODULE_5__["NKodRoleClaim"]();
        newClaim.ClaimType = _models_NKodRoleClaim__WEBPACK_IMPORTED_MODULE_5__["NKodRoleClaim"].CanAccessCustomerClaimType;
        newClaim.ClaimValue = customer.GUID;
        this.editRoleVM.Role.Claims.push(newClaim);
    };
    EditRoleComponent.prototype.customerRemoved = function (customer) {
        this.editRoleVM.Role.Claims.splice(this.editRoleVM.Role.Claims.findIndex(function (x) { return x.ClaimType === _models_NKodRoleClaim__WEBPACK_IMPORTED_MODULE_5__["NKodRoleClaim"].CanAccessCustomerClaimType && x.ClaimValue == customer.value.GUID; }), 1);
    };
    EditRoleComponent.prototype.customerCleared = function () {
        var claimsToRemove = this.editRoleVM.Role.Claims.filter(function (x) { return x.ClaimType === _models_NKodRoleClaim__WEBPACK_IMPORTED_MODULE_5__["NKodRoleClaim"].CanAccessCustomerClaimType; });
        for (var _i = 0, claimsToRemove_1 = claimsToRemove; _i < claimsToRemove_1.length; _i++) {
            var claim = claimsToRemove_1[_i];
            this.editRoleVM.Role.Claims.splice(this.editRoleVM.Role.Claims.indexOf(claim), 1);
        }
    };
    EditRoleComponent.prototype.roleHasPermission = function (permissionId) {
        return this.editRoleVM.Role.Permissions && this.editRoleVM.Role.Permissions.filter(function (e) { return e.Permission.Id === permissionId; }).length > 0;
    };
    EditRoleComponent.prototype.roleHasClaim = function (claimType, claimValue) {
        return this.editRoleVM.Role.Claims && this.editRoleVM.Role.Claims.filter(function (e) { return e.ClaimType === claimType && e.ClaimValue === claimValue; }).length > 0;
    };
    EditRoleComponent.prototype.saveRole = function () {
        this.httpService.saveRole(this.editRoleVM.Role).subscribe();
    };
    EditRoleComponent.prototype.canManageRoleRoleSelectionChanged = function (role) {
        if (role.Selected) {
            var newRoleClaim = new _models_NKodRoleClaim__WEBPACK_IMPORTED_MODULE_5__["NKodRoleClaim"]();
            newRoleClaim.ClaimType = _models_NKodRoleClaim__WEBPACK_IMPORTED_MODULE_5__["NKodRoleClaim"].CanAddRemoveRoleIdClaimType;
            newRoleClaim.ClaimValue = String(role.Id);
            newRoleClaim.RoleId = this.editRoleVM.Role.Id;
            this.editRoleVM.Role.Claims.push(newRoleClaim);
        }
        else
            this.editRoleVM.Role.Claims.splice(this.editRoleVM.Role.Claims.findIndex(function (x) { return x.ClaimType === _models_NKodRoleClaim__WEBPACK_IMPORTED_MODULE_5__["NKodRoleClaim"].CanAddRemoveRoleIdClaimType && x.ClaimValue == String(role.Id); }), 1);
    };
    EditRoleComponent.prototype.permissionSelectionChanged = function (permission) {
        if (permission.Selected) {
            var newRolePermission = new _models_NKodRolePermission__WEBPACK_IMPORTED_MODULE_4__["NKodRolePermission"]();
            newRolePermission.Permission = permission;
            this.editRoleVM.Role.Permissions.push(newRolePermission);
        }
        else
            this.editRoleVM.Role.Permissions.splice(this.editRoleVM.Role.Permissions.findIndex(function (x) { return x.Permission.Id === permission.Id; }), 1);
    };
    EditRoleComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-edit-role',
            template: __webpack_require__(/*! ./edit-role.component.html */ "./src/app/edit-role/edit-role.component.html"),
            styles: [__webpack_require__(/*! ./edit-role.component.css */ "./src/app/edit-role/edit-role.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _http_service__WEBPACK_IMPORTED_MODULE_3__["HttpService"]])
    ], EditRoleComponent);
    return EditRoleComponent;
}());



/***/ }),

/***/ "./src/app/error.service.ts":
/*!**********************************!*\
  !*** ./src/app/error.service.ts ***!
  \**********************************/
/*! exports provided: ErrorService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ErrorService", function() { return ErrorService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ErrorService = /** @class */ (function () {
    function ErrorService() {
    }
    ErrorService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ErrorService);
    return ErrorService;
}());



/***/ }),

/***/ "./src/app/error/error.component.css":
/*!*******************************************!*\
  !*** ./src/app/error/error.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Vycm9yL2Vycm9yLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/error/error.component.html":
/*!********************************************!*\
  !*** ./src/app/error/error.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"alert alert-danger\" [hidden]=\"!errorService.errorMessage\">\r\n  {{errorService.errorMessage}}\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/error/error.component.ts":
/*!******************************************!*\
  !*** ./src/app/error/error.component.ts ***!
  \******************************************/
/*! exports provided: ErrorComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ErrorComponent", function() { return ErrorComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../error.service */ "./src/app/error.service.ts");



var ErrorComponent = /** @class */ (function () {
    function ErrorComponent(errorService) {
        this.errorService = errorService;
    }
    ErrorComponent.prototype.ngOnInit = function () {
    };
    ErrorComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-error',
            template: __webpack_require__(/*! ./error.component.html */ "./src/app/error/error.component.html"),
            styles: [__webpack_require__(/*! ./error.component.css */ "./src/app/error/error.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_error_service__WEBPACK_IMPORTED_MODULE_2__["ErrorService"]])
    ], ErrorComponent);
    return ErrorComponent;
}());



/***/ }),

/***/ "./src/app/forbidden/forbidden.component.css":
/*!***************************************************!*\
  !*** ./src/app/forbidden/forbidden.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2ZvcmJpZGRlbi9mb3JiaWRkZW4uY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/forbidden/forbidden.component.html":
/*!****************************************************!*\
  !*** ./src/app/forbidden/forbidden.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\" style=\"overflow: hidden; min-height: 500px\">\r\n  <div class=\"text-center\">\r\n    <img src=\"assets/images/nKodeLogoLg.png\" />\r\n  </div>\r\n  <div class=\"alert alert-warning text-center\">\r\n    You have tried to access a page you do not have access to.\r\n  </div>\r\n  <div class=\"text-center\">\r\n    <button class=\"btn btn-primary\" (click)=\"authService.signOut()\">Sign Out</button>\r\n  </div>\r\n  \r\n</div>\r\n\r\n"

/***/ }),

/***/ "./src/app/forbidden/forbidden.component.ts":
/*!**************************************************!*\
  !*** ./src/app/forbidden/forbidden.component.ts ***!
  \**************************************************/
/*! exports provided: ForbiddenComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForbiddenComponent", function() { return ForbiddenComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _authorization_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! .././authorization.service */ "./src/app/authorization.service.ts");



var ForbiddenComponent = /** @class */ (function () {
    function ForbiddenComponent(authService) {
        this.authService = authService;
    }
    ForbiddenComponent.prototype.ngOnInit = function () {
    };
    ForbiddenComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-forbidden',
            template: __webpack_require__(/*! ./forbidden.component.html */ "./src/app/forbidden/forbidden.component.html"),
            styles: [__webpack_require__(/*! ./forbidden.component.css */ "./src/app/forbidden/forbidden.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_authorization_service__WEBPACK_IMPORTED_MODULE_2__["AuthorizationService"]])
    ], ForbiddenComponent);
    return ForbiddenComponent;
}());



/***/ }),

/***/ "./src/app/http.service.ts":
/*!*********************************!*\
  !*** ./src/app/http.service.ts ***!
  \*********************************/
/*! exports provided: HttpService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HttpService", function() { return HttpService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _authorization_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./authorization.service */ "./src/app/authorization.service.ts");
/* harmony import */ var _assets_config_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../assets/config.js */ "./src/assets/config.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./utils */ "./src/app/utils.ts");








var HttpService = /** @class */ (function () {
    function HttpService(http, _router, _authorizationService) {
        this.http = http;
        this._router = _router;
        this._authorizationService = _authorizationService;
        this.apiBaseUrl = _assets_config_js__WEBPACK_IMPORTED_MODULE_6__["default"].ADMIN_API_BASE_URL.replace(/\/$/, ''); //remove trailing slash if there
    }
    HttpService.prototype.getAdminDashboardSummary = function (customerId) {
        return this.http.get(this.apiBaseUrl + "/getDashboardSummary?customerGuid=" + (customerId || ""));
    };
    //getUser(username: string, customerId: string):Observable<User> {
    //  if (!this._authorizationService.checkForAndHandleUnauthorizedUser())
    //    return;
    //  return this.http.get<User>(`${this.apiBaseUrl}/getUser?username=${username}&customerId=${customerId}`);
    //}
    HttpService.prototype.editUser = function (username, customerId) {
        if (!this._authorizationService.checkForAndHandleUnauthorizedUser())
            return;
        return this.http.get(this.apiBaseUrl + "/editUser?username=" + username + "&customerId=" + customerId);
    };
    HttpService.prototype.saveUser = function (user) {
        this.http.post(this.apiBaseUrl + "/saveUser", user).subscribe();
    };
    HttpService.prototype.getCustomer = function (guid) {
        return this.http.get(this.apiBaseUrl + "/getCustomer?customerGuid=" + guid).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (x) {
            _utils__WEBPACK_IMPORTED_MODULE_7__["Utils"].setCustomerNameForDisplay(x);
            return x;
        }));
    };
    HttpService.prototype.createCustomerFromExisting = function (customer, customerToCopyFrom) {
        return this.http.post(this.apiBaseUrl + "/createCustomerFromExisting", { Customer: customer, CustomerToCopyFrom: customerToCopyFrom });
    };
    HttpService.prototype.createCustomer = function (customer) {
        return this.http.post(this.apiBaseUrl + "/createCustomer", customer);
    };
    HttpService.prototype.saveCustomer = function (customer) {
        this.http.post(this.apiBaseUrl + "/saveCustomer", customer).subscribe();
    };
    HttpService.prototype.getCustomersForUser = function () {
        if (!this._authorizationService.checkForAndHandleUnauthorizedUser())
            return;
        return this.http.get(this.apiBaseUrl + "/getCustomersForUser").pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (x) {
            return x.map(function (y) {
                _utils__WEBPACK_IMPORTED_MODULE_7__["Utils"].setCustomerNameForDisplay(y);
                return y;
            });
        }));
    };
    HttpService.prototype.setUserActive = function (userId, active) {
        this.http.post(this.apiBaseUrl + "/SetUserActive", { GUID: userId, Active: active }).subscribe();
    };
    //unlockUser(userId: string): void {
    //  this.http.post(`${this.apiBaseUrl}/UnlockUser/${userId}`, null).subscribe();
    //}
    HttpService.prototype.getRoles = function () {
        if (!this._authorizationService.checkForAndHandleUnauthorizedUser())
            return;
        return this.http.get(this.apiBaseUrl + "/getRoles");
    };
    HttpService.prototype.saveRole = function (role) {
        if (!this._authorizationService.checkForAndHandleUnauthorizedUser())
            return;
        return this.http.post(this.apiBaseUrl + "/SaveRole", role);
    };
    HttpService.prototype.deleteRole = function (id) {
        return this.http.post(this.apiBaseUrl + "/deleteRole/" + id, null);
    };
    HttpService.prototype.getRole = function (id) {
        return this.http.get(this.apiBaseUrl + "/editRole?id=" + id);
    };
    HttpService.prototype.refreshToken = function (refreshToken) {
        var _this = this;
        var options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('Content-Type', 'application/x-www-form-urlencoded')
        };
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]()
            .set('refresh_token', refreshToken)
            .set('grant_type', "refresh_token");
        return this.http.post(_assets_config_js__WEBPACK_IMPORTED_MODULE_6__["default"].API_URL + "/token", body, options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (data) {
            if (data) {
                _this._authorizationService.storeBearerTokenInformation(data);
            }
            return data;
        }));
    };
    HttpService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"], _authorization_service__WEBPACK_IMPORTED_MODULE_5__["AuthorizationService"]])
    ], HttpService);
    return HttpService;
}());



/***/ }),

/***/ "./src/app/models/NKodPolicy.ts":
/*!**************************************!*\
  !*** ./src/app/models/NKodPolicy.ts ***!
  \**************************************/
/*! exports provided: NKodPolicy */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NKodPolicy", function() { return NKodPolicy; });
var NKodPolicy = /** @class */ (function () {
    function NKodPolicy() {
    }
    return NKodPolicy;
}());



/***/ }),

/***/ "./src/app/models/NKodRoleClaim.ts":
/*!*****************************************!*\
  !*** ./src/app/models/NKodRoleClaim.ts ***!
  \*****************************************/
/*! exports provided: NKodRoleClaim */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NKodRoleClaim", function() { return NKodRoleClaim; });
var NKodRoleClaim = /** @class */ (function () {
    function NKodRoleClaim() {
    }
    NKodRoleClaim.AllCustomerAccessClaimType = "allCustomerAccess";
    NKodRoleClaim.CanAddRemoveRoleIdClaimType = "canAddRemoveRoleId";
    NKodRoleClaim.CanAccessCustomerClaimType = "canAccessCustomerGUID";
    NKodRoleClaim.PermissionIdClaimType = "permissionId";
    return NKodRoleClaim;
}());



/***/ }),

/***/ "./src/app/models/NKodRolePermission.ts":
/*!**********************************************!*\
  !*** ./src/app/models/NKodRolePermission.ts ***!
  \**********************************************/
/*! exports provided: NKodRolePermission */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NKodRolePermission", function() { return NKodRolePermission; });
var NKodRolePermission = /** @class */ (function () {
    function NKodRolePermission() {
    }
    return NKodRolePermission;
}());



/***/ }),

/***/ "./src/app/models/customer.ts":
/*!************************************!*\
  !*** ./src/app/models/customer.ts ***!
  \************************************/
/*! exports provided: Customer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Customer", function() { return Customer; });
var Customer = /** @class */ (function () {
    function Customer() {
    }
    return Customer;
}());



/***/ }),

/***/ "./src/app/models/data-series.ts":
/*!***************************************!*\
  !*** ./src/app/models/data-series.ts ***!
  \***************************************/
/*! exports provided: chartColors */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "chartColors", function() { return chartColors; });
var chartColors = {
    red: 'rgb(255, 99, 132)',
    orange: 'rgb(255, 159, 64)',
    yellow: 'rgb(255, 205, 86)',
    green: 'rgb(45, 192, 45)',
    blue: 'rgb(54, 162, 235)',
    darkblue: 'rgb(24, 42, 75)',
    purple: 'rgb(153, 102, 255)',
    grey: 'rgb(231,238,235)',
    darkgrey: 'rgb(81,88,85)',
    black: 'rgb(20,20,20)',
    white: 'rgb(255,255,255)',
};


/***/ }),

/***/ "./src/app/n-kode/emojis.css":
/*!***********************************!*\
  !*** ./src/app/n-kode/emojis.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".nkod_icon {\r\n    margin-top: 0.15em;\r\n    margin-bottom: 0.15em;\r\n}\r\n\r\n\r\ndiv[class*='_Emoji'] {\r\n    width: 1.4em;\r\n    height: 1.4em;\r\n}\r\n\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbi1rb2RlL2Vtb2ppcy5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxrQkFBa0I7SUFDbEIscUJBQXFCO0FBQ3pCOzs7QUFHQTtJQUNJLFlBQVk7SUFDWixhQUFhO0FBQ2pCIiwiZmlsZSI6InNyYy9hcHAvbi1rb2RlL2Vtb2ppcy5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubmtvZF9pY29uIHtcclxuICAgIG1hcmdpbi10b3A6IDAuMTVlbTtcclxuICAgIG1hcmdpbi1ib3R0b206IDAuMTVlbTtcclxufVxyXG5cclxuXHJcbmRpdltjbGFzcyo9J19FbW9qaSddIHtcclxuICAgIHdpZHRoOiAxLjRlbTtcclxuICAgIGhlaWdodDogMS40ZW07XHJcbn1cclxuXHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/n-kode/n-kode.component.css":
/*!*********************************************!*\
  !*** ./src/app/n-kode/n-kode.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/*#nkodBackspace {\r\n  position: absolute;\r\n  right: 6px;\r\n  top: -6px;\r\n  cursor: pointer;\r\n  color: #5b5b5b;\r\n}*/\r\n\r\n#passwordContainer {\r\n  position: relative;\r\n}\r\n\r\n#passwordContainer svg {\r\n    position: absolute;\r\n    right: 6px;\r\n    top: 1px;\r\n    cursor: pointer;\r\n    color: #5b5b5b;\r\n  }\r\n\r\n#nKodInterfaceSelectionButtonGroup .btn-primary:not(.active) {\r\n  background-color: white;\r\n  color: #0062cc\r\n}\r\n\r\n.error {\r\n  color: red;\r\n  border: red solid 1px;\r\n}\r\n\r\n.error::-webkit-input-placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */\r\n    color: red;\r\n    opacity: 1; /* Firefox */\r\n  }\r\n\r\n.error::-ms-input-placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */\r\n    color: red;\r\n    opacity: 1; /* Firefox */\r\n  }\r\n\r\n.error::placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */\r\n    color: red;\r\n    opacity: 1; /* Firefox */\r\n  }\r\n\r\n.error:-ms-input-placeholder { /* Internet Explorer 10-11 */\r\n    color: red;\r\n  }\r\n\r\n.error::-ms-input-placeholder { /* Microsoft Edge */\r\n    color: red;\r\n  }\r\n\r\n#passwordNKodeLogo { width:85px;height:23px;}\r\n\r\n.instruct {\r\n  border: 1px solid #ccc;\r\n  border-radius: 5px;\r\n  padding: 0;\r\n  background: #f7f7f7;\r\n}\r\n\r\n.instruct-box {\r\n  margin: 0;\r\n  border: 0;\r\n  border-top: 1px solid #ccc;\r\n  border-top-left-radius: 0;\r\n  border-top-right-radius: 0;\r\n  outline: 0px !important;\r\n  -webkit-appearance: none;\r\n}\r\n\r\n.interface-selection {\r\n  font-size: 1.25em;\r\n}\r\n\r\n#interfaceSelectionContainer img {\r\n  max-height: 25px;\r\n  max-width: 25px;\r\n  vertical-align: middle\r\n}\r\n\r\n#interfaceSelectionContainer label {\r\n  white-space: nowrap\r\n}\r\n\r\n@media (max-width: 575.98px) {\r\n  #nkodLogo {\r\n    max-height: 40px\r\n  }\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbi1rb2RlL24ta29kZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7RUFNRTs7QUFFRjtFQUNFLGtCQUFrQjtBQUNwQjs7QUFFRTtJQUNFLGtCQUFrQjtJQUNsQixVQUFVO0lBQ1YsUUFBUTtJQUNSLGVBQWU7SUFDZixjQUFjO0VBQ2hCOztBQUVGO0VBQ0UsdUJBQXVCO0VBQ3ZCO0FBQ0Y7O0FBRUE7RUFDRSxVQUFVO0VBQ1YscUJBQXFCO0FBQ3ZCOztBQUVFLG9DQUFzQix5Q0FBeUM7SUFDN0QsVUFBVTtJQUNWLFVBQVUsRUFBRSxZQUFZO0VBQzFCOztBQUhBLGdDQUFzQix5Q0FBeUM7SUFDN0QsVUFBVTtJQUNWLFVBQVUsRUFBRSxZQUFZO0VBQzFCOztBQUhBLHNCQUFzQix5Q0FBeUM7SUFDN0QsVUFBVTtJQUNWLFVBQVUsRUFBRSxZQUFZO0VBQzFCOztBQUVBLCtCQUErQiw0QkFBNEI7SUFDekQsVUFBVTtFQUNaOztBQUVBLGdDQUFnQyxtQkFBbUI7SUFDakQsVUFBVTtFQUNaOztBQUVGLHFCQUFxQixVQUFVLENBQUMsV0FBVyxDQUFDOztBQUU1QztFQUNFLHNCQUFzQjtFQUN0QixrQkFBa0I7RUFDbEIsVUFBVTtFQUNWLG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLFNBQVM7RUFDVCxTQUFTO0VBQ1QsMEJBQTBCO0VBQzFCLHlCQUF5QjtFQUN6QiwwQkFBMEI7RUFDMUIsdUJBQXVCO0VBQ3ZCLHdCQUF3QjtBQUMxQjs7QUFFQTtFQUNFLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixlQUFlO0VBQ2Y7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtJQUNFO0VBQ0Y7QUFDRiIsImZpbGUiOiJzcmMvYXBwL24ta29kZS9uLWtvZGUuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi8qI25rb2RCYWNrc3BhY2Uge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICByaWdodDogNnB4O1xyXG4gIHRvcDogLTZweDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgY29sb3I6ICM1YjViNWI7XHJcbn0qL1xyXG5cclxuI3Bhc3N3b3JkQ29udGFpbmVyIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbiAgI3Bhc3N3b3JkQ29udGFpbmVyIHN2ZyB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICByaWdodDogNnB4O1xyXG4gICAgdG9wOiAxcHg7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBjb2xvcjogIzViNWI1YjtcclxuICB9XHJcblxyXG4jbktvZEludGVyZmFjZVNlbGVjdGlvbkJ1dHRvbkdyb3VwIC5idG4tcHJpbWFyeTpub3QoLmFjdGl2ZSkge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gIGNvbG9yOiAjMDA2MmNjXHJcbn1cclxuXHJcbi5lcnJvciB7XHJcbiAgY29sb3I6IHJlZDtcclxuICBib3JkZXI6IHJlZCBzb2xpZCAxcHg7XHJcbn1cclxuXHJcbiAgLmVycm9yOjpwbGFjZWhvbGRlciB7IC8qIENocm9tZSwgRmlyZWZveCwgT3BlcmEsIFNhZmFyaSAxMC4xKyAqL1xyXG4gICAgY29sb3I6IHJlZDtcclxuICAgIG9wYWNpdHk6IDE7IC8qIEZpcmVmb3ggKi9cclxuICB9XHJcblxyXG4gIC5lcnJvcjotbXMtaW5wdXQtcGxhY2Vob2xkZXIgeyAvKiBJbnRlcm5ldCBFeHBsb3JlciAxMC0xMSAqL1xyXG4gICAgY29sb3I6IHJlZDtcclxuICB9XHJcblxyXG4gIC5lcnJvcjo6LW1zLWlucHV0LXBsYWNlaG9sZGVyIHsgLyogTWljcm9zb2Z0IEVkZ2UgKi9cclxuICAgIGNvbG9yOiByZWQ7XHJcbiAgfVxyXG5cclxuI3Bhc3N3b3JkTktvZGVMb2dvIHsgd2lkdGg6ODVweDtoZWlnaHQ6MjNweDt9XHJcblxyXG4uaW5zdHJ1Y3Qge1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgYmFja2dyb3VuZDogI2Y3ZjdmNztcclxufVxyXG5cclxuLmluc3RydWN0LWJveCB7XHJcbiAgbWFyZ2luOiAwO1xyXG4gIGJvcmRlcjogMDtcclxuICBib3JkZXItdG9wOiAxcHggc29saWQgI2NjYztcclxuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAwO1xyXG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAwO1xyXG4gIG91dGxpbmU6IDBweCAhaW1wb3J0YW50O1xyXG4gIC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTtcclxufVxyXG5cclxuLmludGVyZmFjZS1zZWxlY3Rpb24ge1xyXG4gIGZvbnQtc2l6ZTogMS4yNWVtO1xyXG59XHJcblxyXG4jaW50ZXJmYWNlU2VsZWN0aW9uQ29udGFpbmVyIGltZyB7XHJcbiAgbWF4LWhlaWdodDogMjVweDtcclxuICBtYXgtd2lkdGg6IDI1cHg7XHJcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZVxyXG59XHJcblxyXG4jaW50ZXJmYWNlU2VsZWN0aW9uQ29udGFpbmVyIGxhYmVsIHtcclxuICB3aGl0ZS1zcGFjZTogbm93cmFwXHJcbn1cclxuXHJcbkBtZWRpYSAobWF4LXdpZHRoOiA1NzUuOThweCkge1xyXG4gICNua29kTG9nbyB7XHJcbiAgICBtYXgtaGVpZ2h0OiA0MHB4XHJcbiAgfVxyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/n-kode/n-kode.component.html":
/*!**********************************************!*\
  !*** ./src/app/n-kode/n-kode.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\" style=\"overflow: hidden; min-height: 500px\">\r\n  <div class=\"text-center\">\r\n    <img id=\"nkodLogo\" src=\"assets/images/nKodeLogoLg.png\" />\r\n  </div>\r\n  <div [hidden]=\"!loginFailed\" class=\"alert alert-warning text-center\">\r\n    <h3><fa-icon icon=\"frown\"></fa-icon> {{loginFailedMessage}}</h3>\r\n  </div>\r\n  <div class=\"alert alert-info text-center\" [hidden]=\"!isNewRegistrant || keypadLoaded\">\r\n    Your nKode was created successfully.  Please login to continue.\r\n  </div>\r\n  <div [hidden]=\"!minLengthError && !maxLengthError && !complexityError && !disparityError\" class=\"alert alert-danger text-center\">\r\n    You have attempted to create an invalid nKode.  The reason(s) why it failed are below. Please try again.\r\n    <ul>\r\n      <li [hidden]=\"!minLengthError\">Your nKode is too short--the minimum length is {{minNKodeLength}}</li>\r\n      <li [hidden]=\"!maxLengthError\">Your nKode is too long--the maximum length is {{maxNKodeLength}}</li>\r\n      <li [hidden]=\"!complexityError\">You must select at least 2 different nKode image sets.</li>\r\n      <li [hidden]=\"!disparityError\">You must have at least 2 unique nKode values.</li>\r\n    </ul>\r\n  </div>\r\n\r\n  <div [hidden]=\"!nKodeLengthsDoNotMatch && !nKodeValuesDoNotMatch\" class=\"alert alert-danger text-center\">\r\n    <h3 [hidden]=\"!nKodeLengthsDoNotMatch\">nKode Lengths Don't Match.</h3>\r\n    <h3 [hidden]=\"!nKodeValuesDoNotMatch\">The two nKode values you entered do not match.  Please try again.</h3>\r\n  </div>\r\n  <app-error></app-error>\r\n\r\n  <div [hidden]=\"showSpinner\">\r\n    <div class=\"d-flex justify-content-center row\">\r\n      <div class=\"col-lg-5 col-12 p-0\">\r\n        <div *ngIf=\"keypadLoaded && !showSpinner && !isChange && !isSignUp\">\r\n          <strong>Logging in as:</strong> {{username}} <button (click)=\"changeLoginUsername()\" class=\"btn btn-danger btn-sm ml-2\"><fa-icon icon=\"times\"></fa-icon></button>\r\n        </div>\r\n        <div *ngIf=\"keypadLoaded && !showSpinner && isSignUp && isConfirmPasscodeStep\">\r\n          <strong>Registering as:</strong> {{username}} <button (click)=\"changeRegisterUsername()\" class=\"btn btn-danger btn-sm ml-2\"><fa-icon icon=\"times\"></fa-icon></button>\r\n        </div>\r\n        <div id=\"emailContainer\" [hidden]=\"(keypadLoaded && !isSignUp) || isChange || (isSignUp && isConfirmPasscodeStep)\">\r\n          <input type=\"text\" id=\"login-username\" [(ngModel)]=\"username\" class=\"form-control text-center\" [class.error]=\"usernameInputError\" placeholder=\"Enter your email\" required>\r\n          <button type=\"button\" class=\"btn btn-primary btn-block\" [hidden]=\"isSignUp\" (click)=\"generateLoginInterface()\">Login to Your Account</button>\r\n        </div>\r\n        <div class=\"instruct\" *ngIf=\"keypadLoaded && !showSpinner\">\r\n          <ul class=\"pl-4 pr-2 mb-2 mt-1\" id=\"signUpStep1Message\" *ngIf=\"isSignUp && !isConfirmPasscodeStep\">\r\n            <li class=\"mb-0 small\">Pick at least 4 characters </li>\r\n            <li class=\"mb-0 small\">Pick at least 2 different types (number, letter, shape, color, key position)</li>\r\n            <li class=\"mb-0 small\">Click <strong>anywhere</strong> on a key to select a character</li>\r\n            <li class=\"mb-0 small\">Click Next. The keypad will shuffle and you will re-enter your nKode so that the system knows what you have selected. </li>\r\n          </ul>\r\n          <ul class=\"pl-4 pr-2 mb-2 mt-1\" id=\"signUpStep2Message\" *ngIf=\"isSignUp && isConfirmPasscodeStep\">\r\n            <li class=\"mb-0 small\">Re-enter your nKode in the same order to confirm </li>\r\n            <li class=\"mb-0 small\">The keypad will shuffle every time you login</li>\r\n            <li class=\"mb-0 small\">Click anywhere on a key to select a character</li>\r\n          </ul>\r\n          <div [hidden]=\"!keypadLoaded\" id=\"passwordContainer\">\r\n            <!--<img src=\"assets/images/nKodeLogoLg.png\" class=\"mt-2 float-left mr-2\" id=\"passwordNKodeLogo\">-->\r\n            <input id=\"login-password\" readonly type=\"password\" class=\"form-control text-center\" [(ngModel)]=\"password\" placeholder=\"{{nKodePlaceholderText}}\" [class.error]=\"nkodeEmptyError\">\r\n            <span id=\"nkodBackspace\" (click)=\"backspace()\">\r\n              <fa-icon icon=\"backspace\" style=\"font-size:36px\"></fa-icon>\r\n            </span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div [hidden]=\"(isSignUp || isChange)\" class=\"text-center\">Not registered? <a [routerLink]=\"['/signup']\">Sign Up</a></div>\r\n    <div *ngIf=\"(isSignUp && !isChange)\" class=\"text-center\"><a [routerLink]=\"['/login']\">Return to Login</a></div>\r\n  </div>\r\n\r\n  <div class=\"text-center mt-2\" id=\"interfaceSelectionContainer\" *ngIf=\"!showSpinner && isSignUp && !isConfirmPasscodeStep\">\r\n    <div>\r\n      <span>Choose Interface Type:</span>\r\n    </div>\r\n    <div class=\"form-check form-check-inline\">\r\n      <input type=\"radio\" name=\"rdoInterface\" id=\"shapesRadio\" class=\"interfaceSelection\" autocomplete=\"off\" value=\"shapes\" checked [(ngModel)]=\"template\" (change)=\"interfaceTemplateChanged()\">\r\n      <label class=\"form-check-label ml-1\" for=\"shapesRadio\">Symbols <img src=\"/assets/images/nKode/gray/63.svg\" alt=\"\" role=\"img\"></label>\r\n    </div>\r\n    <div class=\"form-check form-check-inline\">\r\n      <input type=\"radio\" name=\"rdoInterface\" id=\"emojisRadio\" class=\"interfaceSelection\" autocomplete=\"off\" value=\"emojis\" [(ngModel)]=\"template\" (change)=\"interfaceTemplateChanged()\">\r\n      <label class=\"form-check-label ml-1\" for=\"emojisRadio\">Emoticons <img src=\"/assets/images/nKode/flaticon/251.svg\"></label>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"pb-6\">\r\n    <div class=\"fa-3x container col-12 py-5 my-5 text-center\" id=\"spinnerContainer\" [hidden]=\"!showSpinner\">\r\n      <fa-icon icon=\"spinner\" [spin]=\"true\"></fa-icon>\r\n    </div>\r\n    <div class=\"d-flex justify-content-center\">\r\n      <div id=\"nkod\" class=\"col-lg-5 col-xs-12\" [hidden]=\"!keypadLoaded || showSpinner\"></div>\r\n    </div>\r\n    <div class=\"d-flex justify-content-center\">\r\n      <div class=\"col-lg-9 col-xs-12 m-3 text-center\" [hidden]=\"!keypadLoaded || showSpinner\" id=\"loginContainer\">\r\n        <button type=\"button\" class=\"btn btn-secondary mr-2\" id=\"clearNKod\" (click)=\"clear()\">Clear</button>\r\n        <button type=\"button\" class=\"btn btn-primary\" (click)=\"enter()\">{{ enterButtonText }}</button>\r\n        <a *ngIf=\"isChange\" [routerLink]=\"['/admin']\"  class=\"btn btn-primary ml-2\">Cancel</a>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/n-kode/n-kode.component.ts":
/*!********************************************!*\
  !*** ./src/app/n-kode/n-kode.component.ts ***!
  \********************************************/
/*! exports provided: NKodeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NKodeComponent", function() { return NKodeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _assets_nKode_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../assets/nKode.js */ "./src/assets/nKode.js");
/* harmony import */ var _assets_nKode_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_assets_nKode_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_config_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../assets/config.js */ "./src/assets/config.js");
/* harmony import */ var _node_modules_fingerprintjs2_dist_fingerprint2_min_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/fingerprintjs2/dist/fingerprint2.min.js */ "./node_modules/fingerprintjs2/dist/fingerprint2.min.js");
/* harmony import */ var _node_modules_fingerprintjs2_dist_fingerprint2_min_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_fingerprintjs2_dist_fingerprint2_min_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _authorization_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../authorization.service */ "./src/app/authorization.service.ts");
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../error.service */ "./src/app/error.service.ts");









var NKodeComponent = /** @class */ (function () {
    function NKodeComponent(route, router, _authorizationService, errorService) {
        this.route = route;
        this.router = router;
        this._authorizationService = _authorizationService;
        this.errorService = errorService;
        this._fingerprint = "";
        this.usernameInputError = false;
        this.nkodeEmptyError = false;
        this.username = "";
        this.isConfirmPasscodeStep = false;
        this.keypadLoaded = false;
        this.showSpinner = false;
        this.password = "";
        this.loginFailed = false;
        this.loginFailedMessage = "";
        this.template = "shapes";
        this.minLengthError = false;
        this.maxLengthError = false;
        this.complexityError = false;
        this.disparityError = false;
        this.nKodeLengthsDoNotMatch = false;
        this.nKodeValuesDoNotMatch = false;
        this.isSignUp = this.route.snapshot.routeConfig.path.toLowerCase() === "signup";
        this.isChange = this.route.snapshot.routeConfig.path.toLowerCase() === "changenkode";
        this.minNKodeLength = _assets_config_js__WEBPACK_IMPORTED_MODULE_3__["default"].MIN_NKOD_LENGTH;
        this.maxNKodeLength = _assets_config_js__WEBPACK_IMPORTED_MODULE_3__["default"].MAX_NKOD_LENGTH;
    }
    NKodeComponent_1 = NKodeComponent;
    Object.defineProperty(NKodeComponent.prototype, "enterButtonText", {
        get: function () {
            if (!this.isSignUp)
                return this.isChange ? "Confim Login" : "Login";
            return this.isConfirmPasscodeStep ? "Finish" : "Next";
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(NKodeComponent.prototype, "nKodePlaceholderText", {
        get: function () {
            if (!this.isSignUp)
                return "Enter your nKode";
            return this.isConfirmPasscodeStep ? "Re-enter nKode to confirm" : "Select keys to create your nKode";
        },
        enumerable: true,
        configurable: true
    });
    NKodeComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (window['requestIdleCallback'])
            window['requestIdleCallback'](function () { _this.setFingerprint(); }); //Note: must call like this to keep scope so that this is accessible.    
        else
            setTimeout(function () { _this.setFingerprint(); }, 400);
        this.isNewRegistrant = this.route.snapshot.queryParams.registered;
        _assets_nKode_js__WEBPACK_IMPORTED_MODULE_2___default.a.setConfig(_assets_config_js__WEBPACK_IMPORTED_MODULE_3__["default"]);
        _assets_nKode_js__WEBPACK_IMPORTED_MODULE_2___default.a.setKodChangedCallback(function () {
            _this.password = "";
            var keyLength = _assets_nKode_js__WEBPACK_IMPORTED_MODULE_2___default.a.currentNKodLength();
            for (var i = 1; i <= keyLength; i++) {
                _this.password += "*";
            }
            _this.nkodeEmptyError = false;
        });
        if (this.isSignUp)
            this.loadCreateInterface();
        else if (this.isChange)
            this.generateLoginInterface();
    };
    NKodeComponent.prototype.interfaceTemplateChanged = function () {
        this.loadCreateInterface();
    };
    NKodeComponent.prototype.resetRegisterVariables = function () {
        this.isConfirmPasscodeStep = false;
        this.minLengthError = false;
        this.maxLengthError = false;
        this.complexityError = false;
        this.disparityError = false;
        this.nKodeLengthsDoNotMatch = false;
        this.nKodeValuesDoNotMatch = false;
    };
    NKodeComponent.prototype.setFingerprint = function () {
        var _this = this;
        _node_modules_fingerprintjs2_dist_fingerprint2_min_js__WEBPACK_IMPORTED_MODULE_4___default.a.getPromise().then(function (components) {
            _this._fingerprint = _node_modules_fingerprintjs2_dist_fingerprint2_min_js__WEBPACK_IMPORTED_MODULE_4___default.a.x64hash128(components.map(function (pair) { return pair.value; }).join(), 31);
        });
    };
    NKodeComponent.prototype.ensureFingerprintIsSet = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var tryCount;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        tryCount = 1;
                        _a.label = 1;
                    case 1:
                        if (!(this._fingerprint === "" && tryCount < 3)) return [3 /*break*/, 3];
                        return [4 /*yield*/, new Promise(function (res) { return setTimeout(res, 250); })];
                    case 2:
                        _a.sent();
                        return [3 /*break*/, 1];
                    case 3:
                        if (this._fingerprint === "")
                            this._fingerprint = NKodeComponent_1.fingerprintUnavailableValue;
                        return [2 /*return*/];
                }
            });
        });
    };
    NKodeComponent.prototype.loadCreateInterface = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var ex_1;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.showSpinner = true;
                        this.errorService.errorMessage = "";
                        this.resetRegisterVariables();
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, , 6, 7]);
                        _a.label = 2;
                    case 2:
                        _a.trys.push([2, 4, , 5]);
                        return [4 /*yield*/, _assets_nKode_js__WEBPACK_IMPORTED_MODULE_2___default.a.generateRegisterInterface(this.template)];
                    case 3:
                        _a.sent();
                        this.keypadLoaded = true;
                        return [3 /*break*/, 5];
                    case 4:
                        ex_1 = _a.sent();
                        this.keypadLoaded = false;
                        this.errorService.errorMessage = "An unexpected error occurred";
                        this.logError(ex_1);
                        return [3 /*break*/, 5];
                    case 5: return [3 /*break*/, 7];
                    case 6:
                        this.showSpinner = false;
                        return [7 /*endfinally*/];
                    case 7: return [2 /*return*/];
                }
            });
        });
    };
    NKodeComponent.prototype.generateLoginInterface = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var username, ex_2;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.showSpinner = true;
                        this.loginFailed = false;
                        this.errorService.errorMessage = "";
                        this.usernameInputError = false;
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 4, 5, 6]);
                        return [4 /*yield*/, this.ensureFingerprintIsSet()];
                    case 2:
                        _a.sent();
                        username = void 0;
                        if (!this.isChange) {
                            if (!this.username) {
                                this.usernameInputError = true;
                                return [2 /*return*/];
                            }
                            username = this.username;
                        }
                        else {
                            username = this._authorizationService.getLoggedInUser();
                            if (!username) {
                                this._authorizationService.signOut();
                                return [2 /*return*/];
                            }
                        }
                        return [4 /*yield*/, _assets_nKode_js__WEBPACK_IMPORTED_MODULE_2___default.a.generateLoginInterface(username, 'shapes', this._fingerprint)];
                    case 3:
                        _a.sent();
                        this.keypadLoaded = true;
                        return [3 /*break*/, 6];
                    case 4:
                        ex_2 = _a.sent();
                        this.keypadLoaded = false;
                        this.errorService.errorMessage = "An unexpected error occurred";
                        this.logError(ex_2);
                        return [3 /*break*/, 6];
                    case 5:
                        this.showSpinner = false;
                        return [7 /*endfinally*/];
                    case 6: return [2 /*return*/];
                }
            });
        });
    };
    NKodeComponent.prototype.enter = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, , 7, 8]);
                        this.showSpinner = true;
                        this.errorService.errorMessage = "";
                        this.loginFailed = false;
                        if (!!this.isSignUp) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.login()];
                    case 1:
                        _a.sent();
                        return [3 /*break*/, 6];
                    case 2:
                        if (!this.isConfirmPasscodeStep) return [3 /*break*/, 4];
                        return [4 /*yield*/, this.createNKodeStep2()];
                    case 3:
                        _a.sent();
                        return [3 /*break*/, 6];
                    case 4: return [4 /*yield*/, this.createNKodeStep1()];
                    case 5:
                        _a.sent();
                        _a.label = 6;
                    case 6: return [3 /*break*/, 8];
                    case 7:
                        this.showSpinner = false;
                        return [7 /*endfinally*/];
                    case 8: return [2 /*return*/];
                }
            });
        });
    };
    NKodeComponent.prototype.createNKodeStep2 = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var bearerToken, username, bearerTokenInfo, data, ex_3;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.ensureFingerprintIsSet()];
                    case 1:
                        _a.sent();
                        if (!this.isChange)
                            username = this.username;
                        else {
                            bearerTokenInfo = this._authorizationService.getBearerTokenInformation();
                            if (bearerTokenInfo) {
                                username = bearerTokenInfo.userName;
                                bearerToken = bearerTokenInfo.access_token;
                            }
                            if (!username) {
                                this._authorizationService.signOut();
                                return [2 /*return*/];
                            }
                        }
                        _a.label = 2;
                    case 2:
                        _a.trys.push([2, 4, , 5]);
                        return [4 /*yield*/, _assets_nKode_js__WEBPACK_IMPORTED_MODULE_2___default.a.createNKodeStep2(username, this._fingerprint, this.template, { isChange: this.isChange, bearerToken: bearerToken })];
                    case 3:
                        data = _a.sent();
                        if (data.Success) {
                            if (this.isChange) {
                                this.router.navigateByUrl("/");
                            }
                            else
                                this.router.navigateByUrl("/login?registered=true");
                        }
                        else {
                            if (data.NKodLengthUnequal) //Client side check of two lengths failed       
                                this.nKodeLengthsDoNotMatch = true;
                            else if (data.NKodCompareFailed) //Server side compare of entered nKod failed
                                this.nKodeValuesDoNotMatch = true;
                            else if (data.PolicyCompareResult) //Server side policy validation results
                             {
                                this.minLengthError = !data.PolicyCompareResult.MinLengthIsValid;
                                this.maxLengthError = !data.PolicyCompareResult.MaxLengthIsValid;
                                this.complexityError = !data.PolicyCompareResult.ComplexityIsValid;
                                this.disparityError = !data.PolicyCompareResult.DisparityIsValid;
                            }
                        }
                        return [3 /*break*/, 5];
                    case 4:
                        ex_3 = _a.sent();
                        switch (ex_3.status) {
                            case 401:
                                if (this.isChange) {
                                    this.errorService.errorMessage = "You are either not authenticated or the allowed password change time has elapsed.  Please try again.";
                                    this.resetNKodeDisplay();
                                    this.generateLoginInterface();
                                }
                                else
                                    this.errorService.errorMessage = "Unauthorized"; //This shouldn't happen, but just in case
                                break;
                            default:
                                this.errorService.errorMessage = "An unexpected error occurred";
                                this.logError(ex_3);
                                break;
                        }
                        return [3 /*break*/, 5];
                    case 5: return [2 /*return*/];
                }
            });
        });
    };
    NKodeComponent.prototype.createNKodeStep1 = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var username, data;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.isChange)
                            username = this.username;
                        else {
                            username = this._authorizationService.getLoggedInUser();
                            if (!username) {
                                this._authorizationService.signOut();
                                return [2 /*return*/];
                            }
                        }
                        return [4 /*yield*/, _assets_nKode_js__WEBPACK_IMPORTED_MODULE_2___default.a.createNKodeStep1(username, { isChange: this.isChange })];
                    case 1:
                        data = _a.sent();
                        if (!data.userExists) return [3 /*break*/, 3];
                        this.loginFailed = true;
                        this.loginFailedMessage = "Username already exists";
                        return [4 /*yield*/, this.loadCreateInterface()];
                    case 2:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        this.isConfirmPasscodeStep = true;
                        _a.label = 4;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    NKodeComponent.prototype.login = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var username, bearerToken, accessToken, success, ex_4, responseText;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 5]);
                        username = void 0;
                        this.usernameInputError = false;
                        if (_assets_nKode_js__WEBPACK_IMPORTED_MODULE_2___default.a.currentNKodLength() == 0) {
                            this.nkodeEmptyError = true;
                            return [2 /*return*/];
                        }
                        if (!this.isChange) {
                            if (!this.username) {
                                this.usernameInputError = true;
                                return [2 /*return*/];
                            }
                            username = this.username;
                        }
                        else {
                            username = this._authorizationService.getLoggedInUser();
                            if (!username) {
                                this._authorizationService.signOut();
                                return [2 /*return*/];
                            }
                        }
                        bearerToken = this._authorizationService.getBearerTokenInformation();
                        accessToken = null;
                        if (bearerToken)
                            accessToken = bearerToken.access_token;
                        return [4 /*yield*/, _assets_nKode_js__WEBPACK_IMPORTED_MODULE_2___default.a.login(username, { isVerifyLoginForNKodeChange: this.isChange, bearerToken: accessToken })];
                    case 1:
                        success = _a.sent();
                        if (success && success.bearerToken) {
                            this._authorizationService.storeBearerTokenInformation(success.bearerToken);
                            if (this.isChange) {
                                this.isSignUp = true;
                                this.loadCreateInterface();
                            }
                            else
                                this.router.navigateByUrl("/admin");
                        }
                        else {
                            this.loginFailed = true;
                            this.loginFailedMessage = NKodeComponent_1.defaultLoginFailedMessage;
                            this.resetNKodeDisplay();
                            if (this.isChange)
                                this.generateLoginInterface();
                        }
                        return [3 /*break*/, 5];
                    case 2:
                        ex_4 = _a.sent();
                        this.resetNKodeDisplay();
                        if (!this.isChange) return [3 /*break*/, 4];
                        return [4 /*yield*/, this.generateLoginInterface()];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4:
                        responseText = (ex_4.responseText || "").replace(/^"+|"+$/g, '');
                        switch (ex_4.status) {
                            case 401:
                                this.loginFailed = true;
                                if (responseText === "Account Inactive")
                                    this.loginFailedMessage = "Login failed -- this account is inactive";
                                else if (responseText === "Account Locked")
                                    this.loginFailedMessage = "Login failed -- this account is currently locked out";
                                else
                                    this.loginFailedMessage = "Login failed";
                                break;
                            default:
                                this.errorService.errorMessage = "An unexpected error occurred";
                                this.logError(ex_4);
                                break;
                        }
                        return [3 /*break*/, 5];
                    case 5: return [2 /*return*/];
                }
            });
        });
    };
    NKodeComponent.prototype.changeLoginUsername = function () {
        document.getElementById("nkod").innerHTML = "";
        this.username = "";
        this.keypadLoaded = false;
        _assets_nKode_js__WEBPACK_IMPORTED_MODULE_2___default.a.clear();
    };
    NKodeComponent.prototype.changeRegisterUsername = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.username = "";
                        this.isConfirmPasscodeStep = false;
                        this.keypadLoaded = false;
                        _assets_nKode_js__WEBPACK_IMPORTED_MODULE_2___default.a.clear();
                        return [4 /*yield*/, this.loadCreateInterface()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    NKodeComponent.prototype.resetNKodeDisplay = function () {
        _assets_nKode_js__WEBPACK_IMPORTED_MODULE_2___default.a.clear();
        document.getElementById(_assets_config_js__WEBPACK_IMPORTED_MODULE_3__["default"].INTERFACE_HTML_PLACEHOLDER_ID).innerHTML = "";
        this.keypadLoaded = false;
        this.isConfirmPasscodeStep = false;
    };
    NKodeComponent.prototype.clear = function () {
        _assets_nKode_js__WEBPACK_IMPORTED_MODULE_2___default.a.clear();
    };
    NKodeComponent.prototype.backspace = function () {
        _assets_nKode_js__WEBPACK_IMPORTED_MODULE_2___default.a.removeLastEntry();
    };
    NKodeComponent.prototype.logError = function (ex) {
        if (ex.nKodeMethodIdentifierStack)
            console.error("nKode method identifier stack: " + ex.nKodeMethodIdentifierStack);
        console.error(ex);
    };
    var NKodeComponent_1;
    NKodeComponent.fingerprintUnavailableValue = "unavailable";
    NKodeComponent.defaultLoginFailedMessage = "Login failed.  Please try again.";
    NKodeComponent = NKodeComponent_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-n-kode',
            template: __webpack_require__(/*! ./n-kode.component.html */ "./src/app/n-kode/n-kode.component.html"),
            encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewEncapsulation"].None,
            styles: [__webpack_require__(/*! ./n-kode.component.css */ "./src/app/n-kode/n-kode.component.css"), __webpack_require__(/*! ./sharedTemplate.css */ "./src/app/n-kode/sharedTemplate.css"), __webpack_require__(/*! ./emojis.css */ "./src/app/n-kode/emojis.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"], _authorization_service__WEBPACK_IMPORTED_MODULE_6__["AuthorizationService"], _error_service__WEBPACK_IMPORTED_MODULE_7__["ErrorService"]])
    ], NKodeComponent);
    return NKodeComponent;
}());



/***/ }),

/***/ "./src/app/n-kode/sharedTemplate.css":
/*!*******************************************!*\
  !*** ./src/app/n-kode/sharedTemplate.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".hvr-outline-in:before {\r\n  pointer-events: none;\r\n  content: '';\r\n  position: absolute;\r\n  border: #FF00FF solid 4px;\r\n  border-radius: 6px;\r\n  top: -16px;\r\n  right: -16px;\r\n  bottom: -16px;\r\n  left: -16px;\r\n  opacity: 0;\r\n  transition-duration: 0.3s;\r\n  transition-property: top, right, bottom, left;\r\n}\r\n\r\n.hvr-outline-in:hover:before, .hvr-outline-in:focus:before, .hvr-outline-in:active:before {\r\n  top: -7px;\r\n  right: -7px;\r\n  bottom: -7px;\r\n  left: -7px;\r\n  opacity: 1;\r\n}\r\n\r\n.click-shrink:active {\r\n  -webkit-transform: scale(0.95);\r\n  transform: scale(0.95);\r\n}\r\n\r\n.click-shrink {\r\n  transition-property: -webkit-transform;\r\n  transition-property: transform;\r\n  transition-property: transform, -webkit-transform;\r\n}\r\n\r\n/*[class^=\"hvr-\"] {\r\n    margin: .4em;\r\n    padding: 1em;\r\n    cursor: pointer;\r\n    background: #e1e1e1;\r\n    text-decoration: none;\r\n    color: #666;\r\n    -webkit-tap-highlight-color: rgba(0,0,0,0);\r\n    -webkit-font-smoothing: antialiased;\r\n    -moz-osx-font-smoothing: grayscale;\r\n}*/\r\n\r\n.hvr-outline-in {\r\n  -webkit-transform: perspective(1px) translateZ(0);\r\n  transform: perspective(1px) translateZ(0);\r\n  position: relative;\r\n}\r\n\r\n.square {\r\n    font-family: 'Open Sans';\r\n    border-radius: 6px;\r\n    border: 1px solid Gray;\r\n    cursor: pointer;\r\n    box-shadow: 1px 1px 1px #888888;\r\n    background-repeat: no-repeat;\r\n    background-size: 100% 100%;\r\n    padding: 15px 15px;\r\n}\r\n\r\n.square.col-4 {\r\n    flex: 0 0 31.333333%;\r\n    max-width: 31.33333333%;\r\n}\r\n\r\n.square .row {\r\n    line-height: 38px;\r\n}\r\n\r\n.template_105 {\r\n    /* yellow */\r\n    background-image: url('105.png')\r\n}\r\n\r\n.template_182 {\r\n    /* green */\r\n    background-image: url('182.png')\r\n}\r\n\r\n.template_186 {\r\n    /* blue */\r\n    background-image: url('186.png')\r\n}\r\n\r\n.template_96 {\r\n    /* orange */\r\n    background-image: url('96.png')\r\n}\r\n\r\n.template_193 {\r\n    /* black */\r\n    background-image: url('193.png')\r\n}\r\n\r\n.template_113 {\r\n    /* purple */\r\n    background-image: url('113.png')\r\n}\r\n\r\n.template_143 {\r\n    /* brown */\r\n    background-image: url('143.png')\r\n}\r\n\r\n.template_16 {\r\n    /* grey */\r\n    background-image: url('16.png')\r\n}\r\n\r\n.template_2 {\r\n    /* red */\r\n    background-image: url('2.png')\r\n}\r\n\r\n.template_151 {\r\n    /* white */\r\n    background-image: url('151.png')\r\n}\r\n\r\n.nkod-number {\r\n    font-size: 2em;\r\n    line-height: 0.75em;\r\n}\r\n\r\n.full_template {\r\n    font-size: 1.4em;\r\n    color: #5b5b5b;\r\n}\r\n\r\n.full_template img {\r\n        width: 1em;\r\n        height: 1em;\r\n    }\r\n\r\n@media only screen and (min-width: 576px) {\r\n    .full_template {\r\n        font-size: 2em;\r\n    }\r\n\r\n        .full_template img {\r\n            width: 1.25em;\r\n            height: 1.25em;\r\n        }\r\n\r\n    .nkod-number {\r\n        font-size: 2em;\r\n        line-height: 0.75em;\r\n    }\r\n}\r\n\r\n@media only screen and (max-width: 1199px) {\r\n    .square {\r\n        padding: 10px 15px;\r\n    }\r\n\r\n        .square .row {\r\n            line-height: 26px;\r\n        }\r\n}\r\n\r\n@media only screen and (max-width: 991px) {\r\n    .square {\r\n        padding: 21px 15px;\r\n    }\r\n\r\n       \r\n}\r\n\r\n@media only screen and (max-width: 767px) {\r\n    .square {\r\n        padding: 10px 15px;\r\n    }\r\n\r\n        .square .row {\r\n            line-height: 26px;\r\n        }\r\n}\r\n\r\n@media only screen and (min-width: 768px) {\r\n    .full_template {\r\n        font-size: 2.5em;\r\n    }\r\n    .modal-body .full_template{ font-size:2em}\r\n\r\n        .full_template img {\r\n            width: 1.25em;\r\n            height: 1.25em;\r\n        }\r\n\r\n   \r\n}\r\n\r\n@media only screen and (min-width: 992px) {\r\n    .full_template {\r\n        font-size: 2em;\r\n    }\r\n\r\n        .full_template img {\r\n            width: 1em;\r\n            height: 1em;\r\n        }\r\n\r\n    .nkod-number {\r\n        font-size: 2em;\r\n        line-height: 1em;\r\n    }\r\n}\r\n\r\n@media only screen and (min-width: 1140px) {\r\n    .full_template {\r\n        font-size: 2em;\r\n    }\r\n\r\n        .full_template img {\r\n            width: 1em;\r\n            height: 1em;\r\n        }\r\n\r\n    \r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbi1rb2RlL3NoYXJlZFRlbXBsYXRlLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG9CQUFvQjtFQUNwQixXQUFXO0VBQ1gsa0JBQWtCO0VBQ2xCLHlCQUF5QjtFQUN6QixrQkFBa0I7RUFDbEIsVUFBVTtFQUNWLFlBQVk7RUFDWixhQUFhO0VBQ2IsV0FBVztFQUNYLFVBQVU7RUFFVix5QkFBeUI7RUFFekIsNkNBQTZDO0FBQy9DOztBQUVBO0VBQ0UsU0FBUztFQUNULFdBQVc7RUFDWCxZQUFZO0VBQ1osVUFBVTtFQUNWLFVBQVU7QUFDWjs7QUFFQTtFQUNFLDhCQUE4QjtFQUM5QixzQkFBc0I7QUFDeEI7O0FBRUE7RUFDRSxzQ0FBOEI7RUFBOUIsOEJBQThCO0VBQTlCLGlEQUE4QjtBQUNoQzs7QUFFQTs7Ozs7Ozs7OztFQVVFOztBQUVGO0VBQ0UsaURBQWlEO0VBQ2pELHlDQUF5QztFQUN6QyxrQkFBa0I7QUFDcEI7O0FBRUE7SUFDSSx3QkFBd0I7SUFDeEIsa0JBQWtCO0lBQ2xCLHNCQUFzQjtJQUN0QixlQUFlO0lBQ2YsK0JBQStCO0lBQy9CLDRCQUE0QjtJQUM1QiwwQkFBMEI7SUFDMUIsa0JBQWtCO0FBQ3RCOztBQUVBO0lBRUksb0JBQW9CO0lBQ3BCLHVCQUF1QjtBQUMzQjs7QUFFQTtJQUNJLGlCQUFpQjtBQUNyQjs7QUFFQTtJQUNJLFdBQVc7SUFDWDtBQUNKOztBQUVBO0lBQ0ksVUFBVTtJQUNWO0FBQ0o7O0FBRUE7SUFDSSxTQUFTO0lBQ1Q7QUFDSjs7QUFFQTtJQUNJLFdBQVc7SUFDWDtBQUNKOztBQUVBO0lBQ0ksVUFBVTtJQUNWO0FBQ0o7O0FBRUE7SUFDSSxXQUFXO0lBQ1g7QUFDSjs7QUFFQTtJQUNJLFVBQVU7SUFDVjtBQUNKOztBQUVBO0lBQ0ksU0FBUztJQUNUO0FBQ0o7O0FBRUE7SUFDSSxRQUFRO0lBQ1I7QUFDSjs7QUFFQTtJQUNJLFVBQVU7SUFDVjtBQUNKOztBQUVBO0lBQ0ksY0FBYztJQUNkLG1CQUFtQjtBQUN2Qjs7QUFFQTtJQUNJLGdCQUFnQjtJQUNoQixjQUFjO0FBQ2xCOztBQUVJO1FBQ0ksVUFBVTtRQUNWLFdBQVc7SUFDZjs7QUFLSjtJQUNJO1FBQ0ksY0FBYztJQUNsQjs7UUFFSTtZQUNJLGFBQWE7WUFDYixjQUFjO1FBQ2xCOztJQUVKO1FBQ0ksY0FBYztRQUNkLG1CQUFtQjtJQUN2QjtBQUNKOztBQU1BO0lBQ0k7UUFDSSxrQkFBa0I7SUFDdEI7O1FBRUk7WUFDSSxpQkFBaUI7UUFDckI7QUFDUjs7QUFFQTtJQUNJO1FBQ0ksa0JBQWtCO0lBQ3RCOzs7QUFHSjs7QUFFQTtJQUNJO1FBQ0ksa0JBQWtCO0lBQ3RCOztRQUVJO1lBQ0ksaUJBQWlCO1FBQ3JCO0FBQ1I7O0FBR0E7SUFDSTtRQUNJLGdCQUFnQjtJQUNwQjtJQUNBLDRCQUE0QixhQUFhOztRQUVyQztZQUNJLGFBQWE7WUFDYixjQUFjO1FBQ2xCOzs7QUFHUjs7QUFHQTtJQUNJO1FBQ0ksY0FBYztJQUNsQjs7UUFFSTtZQUNJLFVBQVU7WUFDVixXQUFXO1FBQ2Y7O0lBRUo7UUFDSSxjQUFjO1FBQ2QsZ0JBQWdCO0lBQ3BCO0FBQ0o7O0FBRUE7SUFDSTtRQUNJLGNBQWM7SUFDbEI7O1FBRUk7WUFDSSxVQUFVO1lBQ1YsV0FBVztRQUNmOzs7QUFHUiIsImZpbGUiOiJzcmMvYXBwL24ta29kZS9zaGFyZWRUZW1wbGF0ZS5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaHZyLW91dGxpbmUtaW46YmVmb3JlIHtcclxuICBwb2ludGVyLWV2ZW50czogbm9uZTtcclxuICBjb250ZW50OiAnJztcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgYm9yZGVyOiAjRkYwMEZGIHNvbGlkIDRweDtcclxuICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgdG9wOiAtMTZweDtcclxuICByaWdodDogLTE2cHg7XHJcbiAgYm90dG9tOiAtMTZweDtcclxuICBsZWZ0OiAtMTZweDtcclxuICBvcGFjaXR5OiAwO1xyXG4gIC13ZWJraXQtdHJhbnNpdGlvbi1kdXJhdGlvbjogMC4zcztcclxuICB0cmFuc2l0aW9uLWR1cmF0aW9uOiAwLjNzO1xyXG4gIC13ZWJraXQtdHJhbnNpdGlvbi1wcm9wZXJ0eTogdG9wLCByaWdodCwgYm90dG9tLCBsZWZ0O1xyXG4gIHRyYW5zaXRpb24tcHJvcGVydHk6IHRvcCwgcmlnaHQsIGJvdHRvbSwgbGVmdDtcclxufVxyXG5cclxuLmh2ci1vdXRsaW5lLWluOmhvdmVyOmJlZm9yZSwgLmh2ci1vdXRsaW5lLWluOmZvY3VzOmJlZm9yZSwgLmh2ci1vdXRsaW5lLWluOmFjdGl2ZTpiZWZvcmUge1xyXG4gIHRvcDogLTdweDtcclxuICByaWdodDogLTdweDtcclxuICBib3R0b206IC03cHg7XHJcbiAgbGVmdDogLTdweDtcclxuICBvcGFjaXR5OiAxO1xyXG59XHJcblxyXG4uY2xpY2stc2hyaW5rOmFjdGl2ZSB7XHJcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlKDAuOTUpO1xyXG4gIHRyYW5zZm9ybTogc2NhbGUoMC45NSk7XHJcbn1cclxuXHJcbi5jbGljay1zaHJpbmsge1xyXG4gIHRyYW5zaXRpb24tcHJvcGVydHk6IHRyYW5zZm9ybTtcclxufVxyXG5cclxuLypbY2xhc3NePVwiaHZyLVwiXSB7XHJcbiAgICBtYXJnaW46IC40ZW07XHJcbiAgICBwYWRkaW5nOiAxZW07XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZTFlMWUxO1xyXG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gICAgY29sb3I6ICM2NjY7XHJcbiAgICAtd2Via2l0LXRhcC1oaWdobGlnaHQtY29sb3I6IHJnYmEoMCwwLDAsMCk7XHJcbiAgICAtd2Via2l0LWZvbnQtc21vb3RoaW5nOiBhbnRpYWxpYXNlZDtcclxuICAgIC1tb3otb3N4LWZvbnQtc21vb3RoaW5nOiBncmF5c2NhbGU7XHJcbn0qL1xyXG5cclxuLmh2ci1vdXRsaW5lLWluIHtcclxuICAtd2Via2l0LXRyYW5zZm9ybTogcGVyc3BlY3RpdmUoMXB4KSB0cmFuc2xhdGVaKDApO1xyXG4gIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoMXB4KSB0cmFuc2xhdGVaKDApO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLnNxdWFyZSB7XHJcbiAgICBmb250LWZhbWlseTogJ09wZW4gU2Fucyc7XHJcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCBHcmF5O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgYm94LXNoYWRvdzogMXB4IDFweCAxcHggIzg4ODg4ODtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IDEwMCUgMTAwJTtcclxuICAgIHBhZGRpbmc6IDE1cHggMTVweDtcclxufVxyXG5cclxuLnNxdWFyZS5jb2wtNCB7XHJcbiAgICAtbXMtZmxleDogMCAwIDMzLjMzMzMzMyU7XHJcbiAgICBmbGV4OiAwIDAgMzEuMzMzMzMzJTtcclxuICAgIG1heC13aWR0aDogMzEuMzMzMzMzMzMlO1xyXG59XHJcblxyXG4uc3F1YXJlIC5yb3cge1xyXG4gICAgbGluZS1oZWlnaHQ6IDM4cHg7XHJcbn1cclxuXHJcbi50ZW1wbGF0ZV8xMDUge1xyXG4gICAgLyogeWVsbG93ICovXHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uL2Fzc2V0cy9pbWFnZXMvbktvZGUvYnV0dG9ucy8xMDUucG5nJylcclxufVxyXG5cclxuLnRlbXBsYXRlXzE4MiB7XHJcbiAgICAvKiBncmVlbiAqL1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvaW1hZ2VzL25Lb2RlL2J1dHRvbnMvMTgyLnBuZycpXHJcbn1cclxuXHJcbi50ZW1wbGF0ZV8xODYge1xyXG4gICAgLyogYmx1ZSAqL1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvaW1hZ2VzL25Lb2RlL2J1dHRvbnMvMTg2LnBuZycpXHJcbn1cclxuXHJcbi50ZW1wbGF0ZV85NiB7XHJcbiAgICAvKiBvcmFuZ2UgKi9cclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnLi4vLi4vYXNzZXRzL2ltYWdlcy9uS29kZS9idXR0b25zLzk2LnBuZycpXHJcbn1cclxuXHJcbi50ZW1wbGF0ZV8xOTMge1xyXG4gICAgLyogYmxhY2sgKi9cclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnLi4vLi4vYXNzZXRzL2ltYWdlcy9uS29kZS9idXR0b25zLzE5My5wbmcnKVxyXG59XHJcblxyXG4udGVtcGxhdGVfMTEzIHtcclxuICAgIC8qIHB1cnBsZSAqL1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvaW1hZ2VzL25Lb2RlL2J1dHRvbnMvMTEzLnBuZycpXHJcbn1cclxuXHJcbi50ZW1wbGF0ZV8xNDMge1xyXG4gICAgLyogYnJvd24gKi9cclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnLi4vLi4vYXNzZXRzL2ltYWdlcy9uS29kZS9idXR0b25zLzE0My5wbmcnKVxyXG59XHJcblxyXG4udGVtcGxhdGVfMTYge1xyXG4gICAgLyogZ3JleSAqL1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvaW1hZ2VzL25Lb2RlL2J1dHRvbnMvMTYucG5nJylcclxufVxyXG5cclxuLnRlbXBsYXRlXzIge1xyXG4gICAgLyogcmVkICovXHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uL2Fzc2V0cy9pbWFnZXMvbktvZGUvYnV0dG9ucy8yLnBuZycpXHJcbn1cclxuXHJcbi50ZW1wbGF0ZV8xNTEge1xyXG4gICAgLyogd2hpdGUgKi9cclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnLi4vLi4vYXNzZXRzL2ltYWdlcy9uS29kZS9idXR0b25zLzE1MS5wbmcnKVxyXG59XHJcblxyXG4ubmtvZC1udW1iZXIge1xyXG4gICAgZm9udC1zaXplOiAyZW07XHJcbiAgICBsaW5lLWhlaWdodDogMC43NWVtO1xyXG59XHJcblxyXG4uZnVsbF90ZW1wbGF0ZSB7XHJcbiAgICBmb250LXNpemU6IDEuNGVtO1xyXG4gICAgY29sb3I6ICM1YjViNWI7XHJcbn1cclxuXHJcbiAgICAuZnVsbF90ZW1wbGF0ZSBpbWcge1xyXG4gICAgICAgIHdpZHRoOiAxZW07XHJcbiAgICAgICAgaGVpZ2h0OiAxZW07XHJcbiAgICB9XHJcblxyXG5cclxuXHJcblxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDU3NnB4KSB7XHJcbiAgICAuZnVsbF90ZW1wbGF0ZSB7XHJcbiAgICAgICAgZm9udC1zaXplOiAyZW07XHJcbiAgICB9XHJcblxyXG4gICAgICAgIC5mdWxsX3RlbXBsYXRlIGltZyB7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxLjI1ZW07XHJcbiAgICAgICAgICAgIGhlaWdodDogMS4yNWVtO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAubmtvZC1udW1iZXIge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMmVtO1xyXG4gICAgICAgIGxpbmUtaGVpZ2h0OiAwLjc1ZW07XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG5cclxuXHJcblxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDExOTlweCkge1xyXG4gICAgLnNxdWFyZSB7XHJcbiAgICAgICAgcGFkZGluZzogMTBweCAxNXB4O1xyXG4gICAgfVxyXG5cclxuICAgICAgICAuc3F1YXJlIC5yb3cge1xyXG4gICAgICAgICAgICBsaW5lLWhlaWdodDogMjZweDtcclxuICAgICAgICB9XHJcbn1cclxuXHJcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogOTkxcHgpIHtcclxuICAgIC5zcXVhcmUge1xyXG4gICAgICAgIHBhZGRpbmc6IDIxcHggMTVweDtcclxuICAgIH1cclxuXHJcbiAgICAgICBcclxufVxyXG5cclxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3NjdweCkge1xyXG4gICAgLnNxdWFyZSB7XHJcbiAgICAgICAgcGFkZGluZzogMTBweCAxNXB4O1xyXG4gICAgfVxyXG5cclxuICAgICAgICAuc3F1YXJlIC5yb3cge1xyXG4gICAgICAgICAgICBsaW5lLWhlaWdodDogMjZweDtcclxuICAgICAgICB9XHJcbn1cclxuXHJcblxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDc2OHB4KSB7XHJcbiAgICAuZnVsbF90ZW1wbGF0ZSB7XHJcbiAgICAgICAgZm9udC1zaXplOiAyLjVlbTtcclxuICAgIH1cclxuICAgIC5tb2RhbC1ib2R5IC5mdWxsX3RlbXBsYXRleyBmb250LXNpemU6MmVtfVxyXG5cclxuICAgICAgICAuZnVsbF90ZW1wbGF0ZSBpbWcge1xyXG4gICAgICAgICAgICB3aWR0aDogMS4yNWVtO1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDEuMjVlbTtcclxuICAgICAgICB9XHJcblxyXG4gICBcclxufVxyXG5cclxuXHJcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1pbi13aWR0aDogOTkycHgpIHtcclxuICAgIC5mdWxsX3RlbXBsYXRlIHtcclxuICAgICAgICBmb250LXNpemU6IDJlbTtcclxuICAgIH1cclxuXHJcbiAgICAgICAgLmZ1bGxfdGVtcGxhdGUgaW1nIHtcclxuICAgICAgICAgICAgd2lkdGg6IDFlbTtcclxuICAgICAgICAgICAgaGVpZ2h0OiAxZW07XHJcbiAgICAgICAgfVxyXG5cclxuICAgIC5ua29kLW51bWJlciB7XHJcbiAgICAgICAgZm9udC1zaXplOiAyZW07XHJcbiAgICAgICAgbGluZS1oZWlnaHQ6IDFlbTtcclxuICAgIH1cclxufVxyXG5cclxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWluLXdpZHRoOiAxMTQwcHgpIHtcclxuICAgIC5mdWxsX3RlbXBsYXRlIHtcclxuICAgICAgICBmb250LXNpemU6IDJlbTtcclxuICAgIH1cclxuXHJcbiAgICAgICAgLmZ1bGxfdGVtcGxhdGUgaW1nIHtcclxuICAgICAgICAgICAgd2lkdGg6IDFlbTtcclxuICAgICAgICAgICAgaGVpZ2h0OiAxZW07XHJcbiAgICAgICAgfVxyXG5cclxuICAgIFxyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/permissions-enum.ts":
/*!*************************************!*\
  !*** ./src/app/permissions-enum.ts ***!
  \*************************************/
/*! exports provided: Permissions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Permissions", function() { return Permissions; });
var Permissions;
(function (Permissions) {
    Permissions[Permissions["All"] = 0] = "All";
    Permissions[Permissions["Dashboard"] = 1] = "Dashboard";
    Permissions[Permissions["ManageUsers"] = 2] = "ManageUsers";
    Permissions[Permissions["ManageUserRoles"] = 3] = "ManageUserRoles";
})(Permissions || (Permissions = {}));


/***/ }),

/***/ "./src/app/roles/roles.component.css":
/*!*******************************************!*\
  !*** ./src/app/roles/roles.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JvbGVzL3JvbGVzLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/roles/roles.component.html":
/*!********************************************!*\
  !*** ./src/app/roles/roles.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<form name=\"addRoleForm\" #addRoleForm=\"ngForm\" (ngSubmit)=\"addRoleForm.form.valid && addRole()\" novalidate class=\"form-inline mb-2\">\r\n  <div class=\"form-group\">\r\n    <label class=\"mr-sm-2\">New Role: </label>\r\n    <input #role=\"ngModel\" name=\"role\" type=\"text\" [(ngModel)]=\"newRole\" class=\"form-control mr-sm-2\" [ngClass]=\"{ 'is-invalid': addRoleForm.submitted && role?.invalid }\" required placeholder=\"New Role\">\r\n    <button type=\"submit\" class=\"btn btn-primary\">Add</button>\r\n    <div *ngIf=\"addRoleForm.submitted && role?.invalid\" class=\"invalid-feedback\">\r\n      <div *ngIf=\"role.errors.required\">New role is required</div>\r\n    </div>\r\n  </div>\r\n  \r\n</form>\r\n\r\n<div class=\"row\">\r\n  <div class=\"col-12 col-lg-4\">\r\n    <h3>Roles:</h3>\r\n    <ul class=\"list-group\">\r\n      <li class=\"list-group-item\" *ngFor=\"let role of roles\">\r\n        {{role.Role}} <span *ngIf=\"role.Id != 1\" class=\"float-right\"> <button class=\"btn btn-sm btn-primary mr-sm-2\" type=\"button\" routerLink=\"/admin/editRole/{{role.Id}}\"><fa-icon icon=\"edit\"></fa-icon></button> <button type=\"button\" class=\"btn btn-sm btn-danger\" (click)=\"deleteRole(role,confirmDeleteModal)\"><fa-icon icon=\"trash\"></fa-icon></button></span>\r\n\r\n      </li>\r\n    </ul>\r\n  </div>\r\n</div>\r\n\r\n"

/***/ }),

/***/ "./src/app/roles/roles.component.ts":
/*!******************************************!*\
  !*** ./src/app/roles/roles.component.ts ***!
  \******************************************/
/*! exports provided: RolesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RolesComponent", function() { return RolesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../http.service */ "./src/app/http.service.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _confirm_delete_modal_confirm_delete_modal_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../confirm-delete-modal/confirm-delete-modal.component */ "./src/app/confirm-delete-modal/confirm-delete-modal.component.ts");





var RolesComponent = /** @class */ (function () {
    function RolesComponent(httpService, modalService) {
        this.httpService = httpService;
        this.modalService = modalService;
    }
    RolesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.httpService.getRoles().subscribe(function (data) { return _this.roles = data; });
    };
    RolesComponent.prototype.addRole = function () {
        var _this = this;
        this.httpService.saveRole({ Role: this.newRole, AllCustomerAccess: false }).subscribe(function (result) {
            _this.roles.push(result);
            _this.newRole = "";
            _this.formValues.resetForm(); // Added this
        });
    };
    RolesComponent.prototype.deleteRole = function (role) {
        var _this = this;
        var modal = this.modalService.open(_confirm_delete_modal_confirm_delete_modal_component__WEBPACK_IMPORTED_MODULE_4__["ConfirmDeleteModalComponent"]);
        modal.componentInstance.deleteMessage = "Are you sure you wish to delete role: " + role.Role + "?";
        modal.result.then(function (value) {
            _this.httpService.deleteRole(role.Id).subscribe(function (data) {
                _this.roles.splice(_this.roles.indexOf(role), 1);
            });
        }, function (reason) {
        });
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('addRoleForm'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], RolesComponent.prototype, "formValues", void 0);
    RolesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-roles',
            template: __webpack_require__(/*! ./roles.component.html */ "./src/app/roles/roles.component.html"),
            styles: [__webpack_require__(/*! ./roles.component.css */ "./src/app/roles/roles.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_3__["NgbModal"]])
    ], RolesComponent);
    return RolesComponent;
}());



/***/ }),

/***/ "./src/app/select-interface/select-interface.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/select-interface/select-interface.component.css ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NlbGVjdC1pbnRlcmZhY2Uvc2VsZWN0LWludGVyZmFjZS5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/select-interface/select-interface.component.html":
/*!******************************************************************!*\
  !*** ./src/app/select-interface/select-interface.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\r\n  select-interface works!\r\n</p>\r\n"

/***/ }),

/***/ "./src/app/select-interface/select-interface.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/select-interface/select-interface.component.ts ***!
  \****************************************************************/
/*! exports provided: SelectInterfaceComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectInterfaceComponent", function() { return SelectInterfaceComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var SelectInterfaceComponent = /** @class */ (function () {
    function SelectInterfaceComponent() {
    }
    SelectInterfaceComponent.prototype.ngOnInit = function () {
    };
    SelectInterfaceComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-select-interface',
            template: __webpack_require__(/*! ./select-interface.component.html */ "./src/app/select-interface/select-interface.component.html"),
            styles: [__webpack_require__(/*! ./select-interface.component.css */ "./src/app/select-interface/select-interface.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], SelectInterfaceComponent);
    return SelectInterfaceComponent;
}());



/***/ }),

/***/ "./src/app/users/users.component.css":
/*!*******************************************!*\
  !*** ./src/app/users/users.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3VzZXJzL3VzZXJzLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/users/users.component.html":
/*!********************************************!*\
  !*** ./src/app/users/users.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row mb-2\">\r\n  <div class=\"col-12 col-lg-4\">\r\n    <span class=\"form-control-static mr-3\">Find User Associated With Customer: </span>\r\n    <!--see https://stackblitz.com/edit/ng-select for demo-->\r\n    <ng-select [items]=\"customers\"\r\n               bindLabel=\"NameForDisplay\"\r\n               placeholder=\"Select Customer\"\r\n               [(ngModel)]=\"customer\"\r\n               (change)=\"selectedCustomerChanged()\"\r\n               *ngIf=\"customers && customers.length > 1\">\r\n    </ng-select>\r\n   <span *ngIf=\"customers && customers.length == 1\">{{customers[0].NameForDisplay}}</span>\r\n  </div>\r\n</div>\r\n\r\n\r\n<form name=\"form\" (ngSubmit)=\"f.form.valid && findUser(username.value)\" #f=\"ngForm\" novalidate class=\"form-inline mb-2\" [hidden]=\"!customer\">\r\n  <div class=\"form-group mb-2\">\r\n    <label for=\"staticEmail2\" class=\"sr-only\">Username</label>\r\n    <input type=\"text\" #username=\"ngModel\" class=\"form-control\" [(ngModel)]=\"usernameSearchEntry\" name=\"username\" [ngClass]=\"{ 'is-invalid': f.submitted && username?.invalid }\" required placeholder=\"Username\">\r\n    <button type=\"submit\" class=\"btn btn-primary\">Search</button>\r\n    <div *ngIf=\"f.submitted && username?.invalid\" class=\"invalid-feedback\">\r\n      <div *ngIf=\"username.errors.required\">Username is required</div>\r\n    </div>\r\n  </div>\r\n</form>\r\n\r\n<div class=\"row col-12 col-lg-4\">\r\n  <div class=\"alert alert-warning text-center\" [hidden]=\"!userNotFound\">\r\n    User not found.\r\n  </div>\r\n</div>\r\n\r\n\r\n<div *ngIf=\"editUserVM && editUserVM.User\" class=\"row\">\r\n  <div class=\"col-lg-4\">\r\n    <div class=\"row\">\r\n      <div class=\"col-6\"><strong>Username:</strong></div>\r\n      <div class=\"col-6\"> {{ editUserVM.User.UserName }}</div>\r\n    </div>\r\n    <div class=\"row\">\r\n      <div class=\"col-6\"><strong>Last Login:</strong></div>\r\n      <div class=\"col-6\"> {{ editUserVM.User.LastLogin | date:\"MM/dd/yyyy h:mma\" }}</div>\r\n    </div>\r\n    <div class=\"row\">\r\n      <div class=\"col-6\"><strong>Active?</strong></div>\r\n      <div class=\"col-6\"> <input type=\"checkbox\" [(ngModel)]=\"editUserVM.User.Active\" /></div>\r\n    </div>\r\n    <div class=\"row\">\r\n      <div class=\"col-6\"><strong>Selected Template:</strong></div>\r\n      <div class=\"col-6\"> {{ editUserVM.User.TemplateIdentifier }}</div>\r\n    </div>\r\n    <div class=\"row\">\r\n      <div class=\"col-6\"><strong>Login Count:</strong></div>\r\n      <div class=\"col-6\"> {{ editUserVM.User.Pass }}</div>\r\n    </div>\r\n    <div class=\"row\">\r\n      <div class=\"col-6\"><strong>Fail Count:</strong></div>\r\n      <div class=\"col-6\"> {{ editUserVM.User.Fail }}</div>\r\n    </div>\r\n    <div class=\"row\">\r\n      <div class=\"col-6\"><strong>Lockout end date:</strong></div>\r\n      <div class=\"col-6\"> {{ editUserVM.User.LockoutEndDateUtc | date:\"MM/dd/yyyy h:mma\" }} <button [hidden]=\"editUserVM.User.LockoutEndDateUtc == null\" class=\"btn btn-primary btn-sm\" (click)=\"unlockUser()\">Unlock Account</button></div>\r\n    </div>\r\n    <div class=\"row\">\r\n      <div class=\"col-6\"><strong>Locked Out Count:</strong></div>\r\n      <div class=\"col-6\"> {{ editUserVM.User.LockoutCount }} </div>\r\n    </div>\r\n    <div class=\"row\">\r\n      <div class=\"col-6\"><strong>User Created:</strong></div>\r\n      <div class=\"col-6\"> {{ editUserVM.User.Created | date:\"MM/dd/yyyy h:mma\" }}</div>\r\n    </div>\r\n    <div class=\"row\">\r\n      <div class=\"col-6\"><strong>User Updated:</strong></div>\r\n      <div class=\"col-6\"> {{ editUserVM.User.Updated | date:\"MM/dd/yyyy h:mma\" }}</div>\r\n    </div>\r\n    <div class=\"row\">\r\n      <div class=\"col-6\"><strong>nKode Last Changed:</strong></div>\r\n      <div class=\"col-6\"> {{ editUserVM.User.Changed | date:\"MM/dd/yyyy h:mma\" }}</div>\r\n    </div>\r\n    <div class=\"row\">\r\n      <div class=\"col-6\"><strong>nKode Last Reset:</strong></div>\r\n      <div class=\"col-6\"> {{ editUserVM.User.Reset | date:\"MM/dd/yyyy h:mma\" }}</div>\r\n    </div>\r\n    <div class=\"row\" *ngIf=\"editUserVM && editUserVM.AvailableRoles && editUserVM.AvailableRoles.length > 0\">\r\n      <div class=\"col-6\"><strong>Role(s):</strong></div>\r\n      <div class=\"col-6\">\r\n        <ng-select [items]=\"editUserVM.AvailableRoles\"\r\n                   bindLabel=\"Role\"\r\n                   bindValue=\"Id\"\r\n                   name=\"roles\"\r\n                   [multiple]=\"true\"\r\n                   placeholder=\"Select User Role(s)\"\r\n                   [(ngModel)]=\"selectedRoleIds\"\r\n                   (add)=\"roleAdded($event)\"\r\n                   (remove)=\"roleRemoved($event)\"\r\n                   (clear)=\"rolesCleared()\">\r\n        </ng-select>\r\n      </div>\r\n    </div>\r\n    <div class=\"row\">\r\n      <div class=\"col-6\"><button class=\"btn btn-primary\" (click)=\"saveUser()\">Save</button></div>\r\n    </div>\r\n  </div>\r\n  \r\n    \r\n  </div>\r\n\r\n"

/***/ }),

/***/ "./src/app/users/users.component.ts":
/*!******************************************!*\
  !*** ./src/app/users/users.component.ts ***!
  \******************************************/
/*! exports provided: UsersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersComponent", function() { return UsersComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../http.service */ "./src/app/http.service.ts");



var UsersComponent = /** @class */ (function () {
    function UsersComponent(httpService) {
        this.httpService = httpService;
        this.userNotFound = false;
    }
    UsersComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.httpService.getCustomersForUser().subscribe(function (data) {
            _this.customers = data;
            if (_this.customers && _this.customers.length == 1)
                _this.customer = _this.customers[0];
        });
    };
    UsersComponent.prototype.findUser = function (username) {
        var _this = this;
        this.userNotFound = false;
        this.httpService.editUser(username, this.customer.GUID).subscribe(function (data) {
            _this.editUserVM = data;
            if (!data)
                _this.userNotFound = true;
            else
                _this.selectedRoleIds = _this.editUserVM.User.Roles.map(function (x) { return x.Id; });
        });
    };
    UsersComponent.prototype.selectedCustomerChanged = function () {
        this.editUserVM = null;
        this.userNotFound = false;
    };
    UsersComponent.prototype.unlockUser = function () {
        this.editUserVM.User.LockoutEndDateUtc = null;
    };
    UsersComponent.prototype.roleAdded = function (role) {
        this.editUserVM.User.Roles.push(role);
    };
    UsersComponent.prototype.roleRemoved = function (role) {
        this.editUserVM.User.Roles.splice(this.editUserVM.User.Roles.findIndex(function (x) { return x.Id == role.value.Id; }), 1);
    };
    UsersComponent.prototype.rolesCleared = function () {
        this.editUserVM.User.Roles = [];
    };
    UsersComponent.prototype.saveUser = function () {
        this.httpService.saveUser(this.editUserVM.User);
    };
    UsersComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-users',
            template: __webpack_require__(/*! ./users.component.html */ "./src/app/users/users.component.html"),
            styles: [__webpack_require__(/*! ./users.component.css */ "./src/app/users/users.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"]])
    ], UsersComponent);
    return UsersComponent;
}());



/***/ }),

/***/ "./src/app/utils.ts":
/*!**************************!*\
  !*** ./src/app/utils.ts ***!
  \**************************/
/*! exports provided: Utils */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Utils", function() { return Utils; });
var Utils = /** @class */ (function () {
    function Utils() {
    }
    Utils.setCustomerNameForDisplay = function (customer) {
        if (customer.Branch)
            customer.NameForDisplay = customer.Name + " [" + customer.Branch + "]";
        else
            customer.NameForDisplay = customer.Name;
    };
    return Utils;
}());



/***/ }),

/***/ "./src/app/validators/customerInfoValidators.ts":
/*!******************************************************!*\
  !*** ./src/app/validators/customerInfoValidators.ts ***!
  \******************************************************/
/*! exports provided: MinNKodeLengthExceedsMaxNKodeLength, DisparityExceedsMinNKodeLength, ComplexityExceedsDisparity */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MinNKodeLengthExceedsMaxNKodeLength", function() { return MinNKodeLengthExceedsMaxNKodeLength; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DisparityExceedsMinNKodeLength", function() { return DisparityExceedsMinNKodeLength; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComplexityExceedsDisparity", function() { return ComplexityExceedsDisparity; });
var MinNKodeLengthExceedsMaxNKodeLength = function (control) {
    return control.controls.MinLength.value > control.controls.MaxLength.value ? { 'minNKodeLengthExceedsMaxNKodeLength': true } : null;
};
var DisparityExceedsMinNKodeLength = function (control) {
    return control.controls.Disparity.value > control.controls.MinLength.value ? { 'disparityExceedsMinNKodeLength': true } : null;
};
var ComplexityExceedsDisparity = function (control) {
    return control.controls.Complexity.value > control.controls.Disparity.value ? { 'complexityExceedsDisparity': true } : null;
};


/***/ }),

/***/ "./src/app/wait-display.service.ts":
/*!*****************************************!*\
  !*** ./src/app/wait-display.service.ts ***!
  \*****************************************/
/*! exports provided: WaitDisplayService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WaitDisplayService", function() { return WaitDisplayService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var WaitDisplayService = /** @class */ (function () {
    function WaitDisplayService() {
        this.showWait = false;
    }
    WaitDisplayService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], WaitDisplayService);
    return WaitDisplayService;
}());



/***/ }),

/***/ "./src/app/wait-display/wait-display.component.css":
/*!*********************************************************!*\
  !*** ./src/app/wait-display/wait-display.component.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "div.AJAXWait {\r\n  width: 100%;\r\n  height: 100%;\r\n  position: fixed;\r\n  left: 0;\r\n  top: 0;\r\n  margin: 0;\r\n  filter: alpha(opacity=20);\r\n  -moz-opacity: 0.2;\r\n  -khtml-opacity: 0.2;\r\n  opacity: 0.2;\r\n  background-color: #000;\r\n  z-index: 10000;\r\n}\r\n\r\n.AJAXWaitImageContainer {\r\n  width: 80px;\r\n  height: 80px;\r\n  position: fixed;\r\n  left: 50%;\r\n  top: 50%;\r\n  margin: -40px 0 0 -40px;\r\n  z-index: 10001;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvd2FpdC1kaXNwbGF5L3dhaXQtZGlzcGxheS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixlQUFlO0VBQ2YsT0FBTztFQUNQLE1BQU07RUFDTixTQUFTO0VBQ1QseUJBQXlCO0VBQ3pCLGlCQUFpQjtFQUNqQixtQkFBbUI7RUFDbkIsWUFBWTtFQUNaLHNCQUFzQjtFQUN0QixjQUFjO0FBQ2hCOztBQUVBO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixlQUFlO0VBQ2YsU0FBUztFQUNULFFBQVE7RUFDUix1QkFBdUI7RUFDdkIsY0FBYztBQUNoQiIsImZpbGUiOiJzcmMvYXBwL3dhaXQtZGlzcGxheS93YWl0LWRpc3BsYXkuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbImRpdi5BSkFYV2FpdCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICBsZWZ0OiAwO1xyXG4gIHRvcDogMDtcclxuICBtYXJnaW46IDA7XHJcbiAgZmlsdGVyOiBhbHBoYShvcGFjaXR5PTIwKTtcclxuICAtbW96LW9wYWNpdHk6IDAuMjtcclxuICAta2h0bWwtb3BhY2l0eTogMC4yO1xyXG4gIG9wYWNpdHk6IDAuMjtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAwO1xyXG4gIHotaW5kZXg6IDEwMDAwO1xyXG59XHJcblxyXG4uQUpBWFdhaXRJbWFnZUNvbnRhaW5lciB7XHJcbiAgd2lkdGg6IDgwcHg7XHJcbiAgaGVpZ2h0OiA4MHB4O1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICBsZWZ0OiA1MCU7XHJcbiAgdG9wOiA1MCU7XHJcbiAgbWFyZ2luOiAtNDBweCAwIDAgLTQwcHg7XHJcbiAgei1pbmRleDogMTAwMDE7XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/wait-display/wait-display.component.html":
/*!**********************************************************!*\
  !*** ./src/app/wait-display/wait-display.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"AJAXWaitContainer\" [hidden]=\"!waitDisplayService.showWait\">\r\n  <div class=\"AJAXWait\">\r\n  </div>\r\n  <div class=\"AJAXWaitImageContainer\">\r\n    <fa-icon icon=\"spinner\" [spin]=\"true\" class=\"fa-3x\"></fa-icon>\r\n  </div>\r\n  \r\n</div>\r\n"

/***/ }),

/***/ "./src/app/wait-display/wait-display.component.ts":
/*!********************************************************!*\
  !*** ./src/app/wait-display/wait-display.component.ts ***!
  \********************************************************/
/*! exports provided: WaitDisplayComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WaitDisplayComponent", function() { return WaitDisplayComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _wait_display_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../wait-display.service */ "./src/app/wait-display.service.ts");



var WaitDisplayComponent = /** @class */ (function () {
    function WaitDisplayComponent(waitDisplayService) {
        this.waitDisplayService = waitDisplayService;
    }
    WaitDisplayComponent.prototype.ngOnInit = function () {
    };
    WaitDisplayComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-wait-display',
            template: __webpack_require__(/*! ./wait-display.component.html */ "./src/app/wait-display/wait-display.component.html"),
            styles: [__webpack_require__(/*! ./wait-display.component.css */ "./src/app/wait-display/wait-display.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_wait_display_service__WEBPACK_IMPORTED_MODULE_2__["WaitDisplayService"]])
    ], WaitDisplayComponent);
    return WaitDisplayComponent;
}());



/***/ }),

/***/ "./src/assets/config.js":
/*!******************************!*\
  !*** ./src/assets/config.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//  ---------------------------------
//  ENVIRONMENT VARIABLES
//  ---------------------------------

var config = {
  API_URL: "http://localhost:58717",
  ADMIN_API_BASE_URL:"http://localhost:58717/api/NKodeAdminAPI",
    HTML_TEMPLATE_PATH: "assets/nKodeTemplates/${templateIdentifier}.html",    
  CLIENT_ID: "7ee607425af741dabc12e416afa02a47",//"498D12A91F604F8A82095AFA31FBE8CD", //"61db4bce45914bae9f6d364c67945e48",
    INTERFACE_HTML_PLACEHOLDER_ID: "nkod",   
    MAX_NKOD_LENGTH: 10,
    MIN_NKOD_LENGTH: 4
};

/* harmony default export */ __webpack_exports__["default"] = (config);


/***/ }),

/***/ "./src/assets/nKode.js":
/*!*****************************!*\
  !*** ./src/assets/nKode.js ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

(function webpackUniversalModuleDefinition(root, factory) {
	if(true)
		module.exports = factory();
	else {}
})(window, function() {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/nKode.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/clientMerge.js":
/*!****************************!*\
  !*** ./src/clientMerge.js ***!
  \****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _transform_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transform.js */ "./src/transform.js");
/* harmony import */ var _darcCommon_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./darcCommon.js */ "./src/darcCommon.js");
/* harmony import */ var _common_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./common.js */ "./src/common.js");



var clientMerge = {
  mergeMessage: function mergeMessage(persistentKeys, ephemeralKeys, DARCdata, inputSequence) {
    try {
      var appliedOuterClientShuffleAlphabetKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterClientShuffleKey, ephemeralKeys.OuterClientShuffleEphemeralKey);
      var appliedOuterClientShuffleFunctionAlphabetKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterClientShuffleFunctionKey, ephemeralKeys.OuterClientShuffleFunctionEphemeralKey);
      appliedOuterClientShuffleAlphabetKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].transformationCompliment(_transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterClientShuffleAlphabetKey, appliedOuterClientShuffleFunctionAlphabetKey)); //Determine Medium dimensions

      var height = persistentKeys.ClientMediumKey.length;
      var width = persistentKeys.ClientMediumKey[0].length;
      var msgLen = inputSequence.length; //Generate random input sequence for message padding

      inputSequence = _darcCommon_js__WEBPACK_IMPORTED_MODULE_1__["default"].randNewInts(inputSequence, height, 0, height);
      var appliedInputSequence = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterClientShuffleAlphabetKey, [inputSequence]);
      var appliedOuterClientShuffleMediumKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterClientShuffleMediumKey, ephemeralKeys.OuterClientShuffleMediumEphemeralKey);
      var appliedOuterClientShuffleFunctionMediumKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterClientShuffleFunctionMediumKey, ephemeralKeys.OuterClientShuffleFunctionMediumEphemeralKey);
      appliedOuterClientShuffleMediumKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterClientShuffleMediumKey, appliedOuterClientShuffleFunctionMediumKey);
      appliedInputSequence = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedInputSequence, appliedOuterClientShuffleMediumKey);
      var message = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(DARCdata.AlphabetData, appliedInputSequence); //*****  Generate random input data to trigger end-of-message (EOM) during decryption by server  *****\\
      //NOTE: The random series of bytes acts as an EOM indicator during decryption because a matching set of values in the DARC alphabet will not exist. 
      //      DARC is designed to interpret an unresolvable set of bytes as EOM. 
      //      If the full DARC alphabet key space (every possible combination of byte values) is used, 
      //        RandUniqueNewBytes() will not return a new distinct series of bytes, 
      //        but rather a random set of bytes that already exists somewhere in the DARC alphabet. 
      //      Such cases will occur when the key.height >= 256^key.width. 
      //      The most realistic example is full-byte support for the transfer of digital files/documents or streaming data (e.g. audio/video).
      //      To be able to successfully encipher and decipher this type of data, 
      //        every possible byte value must be represented in the DARC alphabet (key.height = 256).
      //      When this data is encoded on a single-byte-per-byte implementation (key.width = 1), 
      //        it is impossible to define a byte value that is not a valid member of the DARC alphabet (key.height{256} >= 256^key.width{1} = TRUE).
      //      However, this will not prevent DARC decryption from completing successfully. 
      //      Files have a built-in end-of-file (EOF) designator, 
      //        so DARC will append the RandUniqueNewBytes() generated values and pad the remainder of the final message block,
      //        but the random data will be ignored because the receiving system will stop reading the file at EOF.
      //      Streaming data is processed in real-time, 
      //        so any random data appended to the end of the stream will be interpreted as background noise,
      //        and be ignored by the stream player.
      //      If any unspeculated issues arise from this process for key.height >= 256^key.width scenarios, 
      //        an initial step can be added to convert the file or stream into a number base that fits within the byte - 1 space.
      //      A final step would also be required to convert the decrypted data back into it's original number base.
      //      These additional step would obviously require significantly more processing, 
      //        and thus should be avoided if possible.
      //****************************************************************************************************\\

      var inputEOM = _darcCommon_js__WEBPACK_IMPORTED_MODULE_1__["default"].randUniqueNewBytes(DARCdata.AlphabetData, width, 0, 256); //Calculate medium max ordinal to be used in the else branch below so that the if and else branches will have identical execution time and memory profile 

      var mediumMaxOrd = height - 1; //Generate lookup array to map padding to message

      var messagePadKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].transformationCompliment(appliedOuterClientShuffleMediumKey); //Get data for last input in message

      var lastInput = message[messagePadKey[0][mediumMaxOrd]];
      if (msgLen < height) message[messagePadKey[0][msgLen]] = inputEOM; //Interject inputEOM into the message
      else //Required to maintain constant execution time and memory profile regardless of branch
        message[messagePadKey[0][mediumMaxOrd]] = lastInput; //Interject lastInput into the message

      var appliedPositionFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.PositionFunctionMediumKey, ephemeralKeys.PositionFunctionMediumEphemeralKey);
      var appliedOuterPositionFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterPositionFunctionMediumKey, ephemeralKeys.OuterPositionFunctionMediumEphemeralKey);
      var appliedOuterPositionShuffleKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterPositionShuffleMediumKey, ephemeralKeys.OuterPositionShuffleMediumEphemeralKey);
      appliedOuterPositionFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterPositionShuffleKey, appliedOuterPositionFunctionKey);
      appliedOuterClientShuffleMediumKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].transformationCompliment(appliedOuterClientShuffleMediumKey);
      appliedOuterPositionFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].transformationCompliment(_transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterClientShuffleMediumKey, appliedOuterPositionFunctionKey));
      var identityOuterFunction = _darcCommon_js__WEBPACK_IMPORTED_MODULE_1__["default"].initializeNewArray(persistentKeys.OuterPositionFunctionMediumKey[0].length, persistentKeys.OuterPositionFunctionMediumKey.length);
      message = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].substituteFunctionOperands(appliedOuterPositionFunctionKey, appliedPositionFunctionKey, identityOuterFunction, DARCdata.MediumData, message);
      var appliedOuterPositionShuffleFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterPositionShuffleFunctionMediumKey, ephemeralKeys.OuterPositionShuffleFunctionMediumEphemeralKey);
      var appliedPositionShuffleKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.PositionShuffleMediumKey, ephemeralKeys.PositionShuffleMediumEphemeralKey);
      appliedOuterPositionShuffleKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterClientShuffleMediumKey, appliedOuterPositionShuffleKey);
      appliedOuterPositionShuffleFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterPositionShuffleFunctionKey, appliedOuterPositionFunctionKey);
      message = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(_transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteFunctionMap(appliedOuterPositionShuffleFunctionKey, message, appliedPositionShuffleKey), appliedOuterPositionShuffleKey);
      return message;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_2__["default"].addNKodeMethodIdentifierStackInfo(ex, "ea9bab84-2fcf-4248-9434-2909cb1d048a");
      throw ex;
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (clientMerge);

/***/ }),

/***/ "./src/clientRx.js":
/*!*************************!*\
  !*** ./src/clientRx.js ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _transform_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transform.js */ "./src/transform.js");
/* harmony import */ var _common_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./common.js */ "./src/common.js");


var clientRx = {
  receive: function receive(persistentKeys, ephemeralKeys, DARCdata) {
    try {
      DARCdata.AlphabetData = receiveAlphabet(persistentKeys, ephemeralKeys, DARCdata.AlphabetData);
      DARCdata.MediumData = receiveMedium(persistentKeys, ephemeralKeys, DARCdata.MediumData);
      return DARCdata;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "9bb61b4f-16aa-4a28-8787-db1accbd358c");
      throw ex;
    }
  }
}; //1) Key; 2) Substitutions; 3) Inner Permutations; 4) Outer Permutations

function receiveAlphabet(persistentKeys, ephemeralKeys, alphabet) {
  try {
    var appliedOuterServerShuffleFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterServerShuffleFunctionKey, ephemeralKeys.OuterServerShuffleFunctionEphemeralKey);
    var appliedFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.FunctionKey, ephemeralKeys.FunctionEphemeralKey);
    var appliedClientShuffleKeyA = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.ClientShuffleKeyA, ephemeralKeys.ClientShuffleEphemeralKeyA);
    var appliedOuterFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionKey, ephemeralKeys.OuterFunctionEphemeralKey);
    var appliedOuterFunctionFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionFunctionKey, ephemeralKeys.OuterFunctionFunctionEphemeralKey);
    var result = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].substituteFunctionOperands(appliedOuterFunctionFunctionKey, appliedFunctionKey, appliedOuterFunctionKey, alphabet, ephemeralKeys.ClientEphemeralKey, persistentKeys.ClientKey, persistentKeys.MutualKey);
    alphabet = result; //rename TransposeX to InnerTranspose?

    alphabet = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteFunctionMap(appliedOuterServerShuffleFunctionKey, alphabet, appliedClientShuffleKeyA);
    var appliedOuterClientShuffleKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterClientShuffleKey, ephemeralKeys.OuterClientShuffleEphemeralKey);
    var appliedOuterClientShuffleFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterClientShuffleFunctionKey, ephemeralKeys.OuterClientShuffleFunctionEphemeralKey);
    appliedOuterClientShuffleKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterClientShuffleKey, appliedOuterClientShuffleFunctionKey);
    alphabet = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(alphabet, appliedOuterClientShuffleKey);
    return alphabet;
  } catch (ex) {
    _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "d2cb1b4e-e110-41cf-a6e6-9f4e718d93a9");
    throw ex;
  }
}

function receiveMedium(persistentKeys, ephemeralKeys, medium) {
  try {
    var appliedOuterServerShuffleFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterServerShuffleFunctionMediumKey, ephemeralKeys.OuterServerShuffleFunctionMediumEphemeralKey);
    var appliedFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.FunctionMediumKey, ephemeralKeys.FunctionMediumEphemeralKey);
    var appliedClientShuffleKeyA = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.ClientShuffleMediumKeyA, ephemeralKeys.ClientShuffleMediumEphemeralKeyA);
    var appliedOuterFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionMediumKey, ephemeralKeys.OuterFunctionMediumEphemeralKey);
    var appliedOuterFunctionFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionFunctionMediumKey, ephemeralKeys.OuterFunctionFunctionMediumEphemeralKey);
    var result = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].substituteFunctionOperands(appliedOuterFunctionFunctionKey, appliedFunctionKey, appliedOuterFunctionKey, medium, ephemeralKeys.ClientMediumEphemeralKey, persistentKeys.ClientMediumKey, persistentKeys.MutualMediumKey);
    medium = result;
    medium = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteFunctionMap(appliedOuterServerShuffleFunctionKey, medium, appliedClientShuffleKeyA);
    var appliedOuterClientShuffleKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterClientShuffleMediumKey, ephemeralKeys.OuterClientShuffleMediumEphemeralKey);
    var appliedOuterClientShuffleFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterClientShuffleFunctionMediumKey, ephemeralKeys.OuterClientShuffleFunctionMediumEphemeralKey);
    appliedOuterClientShuffleKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterClientShuffleKey, appliedOuterClientShuffleFunctionKey);
    medium = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(medium, appliedOuterClientShuffleKey);
    return medium;
  } catch (ex) {
    _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "73cbfbea-2b96-4270-936e-4ce387fb4a27");
    throw ex;
  }
}

/* harmony default export */ __webpack_exports__["default"] = (clientRx);

/***/ }),

/***/ "./src/clientTx.js":
/*!*************************!*\
  !*** ./src/clientTx.js ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _transform_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transform.js */ "./src/transform.js");
/* harmony import */ var _darcCommon_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./darcCommon.js */ "./src/darcCommon.js");
/* harmony import */ var _common_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./common.js */ "./src/common.js");



var clientTx = {
  transmit: function transmit(persistentKeys, ephemeralKeys, DARCdata) {
    try {
      DARCdata.AlphabetData = transmitAlphabet(persistentKeys, ephemeralKeys, DARCdata.AlphabetData);
      DARCdata.MediumData = transmitMedium(persistentKeys, ephemeralKeys, DARCdata.MediumData);
      return DARCdata;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_2__["default"].addNKodeMethodIdentifierStackInfo(ex, "778c6b6e-a2e7-460e-aa33-556362ccc12f");
      throw ex;
    }
  }
};

function transmitAlphabet(persistentKeys, ephemeralKeys, alphabet) {
  try {
    var clientShufflEphemeralKeyB = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].transformationCompliment(ephemeralKeys.ClientShuffleEphemeralKeyA);
    var appliedOuterServerShuffleFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterServerShuffleFunctionKey, ephemeralKeys.OuterServerShuffleFunctionEphemeralKey);
    var appliedOuterClientShuffleKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterClientShuffleKey, ephemeralKeys.OuterClientShuffleEphemeralKey);
    var appliedOuterClientShuffleFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterClientShuffleFunctionKey, ephemeralKeys.OuterClientShuffleFunctionEphemeralKey);
    var inputOuterClientShuffleKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterClientShuffleKey, appliedOuterClientShuffleFunctionKey);
    var inputOuterServerShuffleFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterServerShuffleFunctionKey, inputOuterClientShuffleKey);
    var appliedOuterFunctionFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionFunctionKey, ephemeralKeys.OuterFunctionFunctionEphemeralKey);
    appliedOuterFunctionFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterFunctionFunctionKey, inputOuterClientShuffleKey);
    var appliedFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.FunctionKey, ephemeralKeys.FunctionEphemeralKey);
    appliedFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(appliedFunctionKey, appliedOuterFunctionFunctionKey);
    var reorderedShuffleKeyX = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(persistentKeys.ClientShuffleKeyX, inputOuterServerShuffleFunctionKey);
    var functionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedFunctionKey, reorderedShuffleKeyX); //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\
    //vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\\  

    var clientShufflKeyB = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(_transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].transformationCompliment(persistentKeys.ClientShuffleKeyA), persistentKeys.ClientShuffleKeyX); //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\

    var inputClientShuffleKeyB = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(clientShufflEphemeralKeyB, clientShufflKeyB); //Note the reversed sequence of the arguments.

    var shuffledItems = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteFunctionMap(inputOuterServerShuffleFunctionKey, alphabet, inputClientShuffleKeyB);
    var appliedOuterFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionKey, ephemeralKeys.OuterFunctionEphemeralKey);
    var inputOuterFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterFunctionKey, inputOuterClientShuffleKey);
    var identityOuterFunction = _darcCommon_js__WEBPACK_IMPORTED_MODULE_1__["default"].initializeNewArray(persistentKeys.OuterFunctionFunctionKey[0].length, persistentKeys.OuterFunctionFunctionKey.length);
    var txAlphabet = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].substituteFunctionOperands(identityOuterFunction, functionEphemeralKeyApplied, inputOuterFunctionKey, shuffledItems, ephemeralKeys.ClientEphemeralKey, persistentKeys.ClientKey, ephemeralKeys.MutualEphemeralKey);
    return txAlphabet;
  } catch (ex) {
    _common_js__WEBPACK_IMPORTED_MODULE_2__["default"].addNKodeMethodIdentifierStackInfo(ex, "72819ce2-692e-40b3-b498-9de3bf31016c");
    throw ex;
  }
}

function transmitMedium(persistentKeys, ephemeralKeys, medium) {
  try {
    //vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\\        
    var clientShufflEphemeralKeyB = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].transformationCompliment(ephemeralKeys.ClientShuffleMediumEphemeralKeyA); //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\

    var appliedOuterServerShuffleFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterServerShuffleFunctionMediumKey, ephemeralKeys.OuterServerShuffleFunctionMediumEphemeralKey);
    var appliedOuterClientShuffleKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterClientShuffleMediumKey, ephemeralKeys.OuterClientShuffleMediumEphemeralKey);
    var appliedOuterClientShuffleFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterClientShuffleFunctionMediumKey, ephemeralKeys.OuterClientShuffleFunctionMediumEphemeralKey);
    var inputOuterClientShuffleKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterClientShuffleKey, appliedOuterClientShuffleFunctionKey);
    var inputOuterServerShuffleFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterServerShuffleFunctionKey, inputOuterClientShuffleKey);
    var appliedOuterFunctionFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionFunctionMediumKey, ephemeralKeys.OuterFunctionFunctionMediumEphemeralKey);
    appliedOuterFunctionFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterFunctionFunctionKey, inputOuterClientShuffleKey);
    var appliedFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.FunctionMediumKey, ephemeralKeys.FunctionMediumEphemeralKey);
    appliedFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(appliedFunctionKey, appliedOuterFunctionFunctionKey);
    var reorderedShuffleKeyX = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(persistentKeys.ClientShuffleMediumKeyX, inputOuterServerShuffleFunctionKey);
    var functionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedFunctionKey, reorderedShuffleKeyX); //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\
    //vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\\

    var clientShufflKeyB = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(_transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].transformationCompliment(persistentKeys.ClientShuffleMediumKeyA), persistentKeys.ClientShuffleMediumKeyX); //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\

    var inputClientShuffleKeyB = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(clientShufflEphemeralKeyB, clientShufflKeyB); //Note the reversed sequence of the arguments.

    var shuffledItems = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteFunctionMap(inputOuterServerShuffleFunctionKey, medium, inputClientShuffleKeyB);
    var appliedOuterFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionMediumKey, ephemeralKeys.OuterFunctionMediumEphemeralKey);
    var inputOuterFunctionKey = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(appliedOuterFunctionKey, inputOuterClientShuffleKey);
    var identityOuterFunction = _darcCommon_js__WEBPACK_IMPORTED_MODULE_1__["default"].initializeNewArray(persistentKeys.OuterFunctionFunctionMediumKey[0].length, persistentKeys.OuterFunctionFunctionMediumKey.length);
    var txMedium = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].substituteFunctionOperands(identityOuterFunction, functionEphemeralKeyApplied, inputOuterFunctionKey, shuffledItems, ephemeralKeys.ClientMediumEphemeralKey, persistentKeys.ClientMediumKey, ephemeralKeys.MutualMediumEphemeralKey);
    return txMedium;
  } catch (ex) {
    _common_js__WEBPACK_IMPORTED_MODULE_2__["default"].addNKodeMethodIdentifierStackInfo(ex, "0a779d9c-02a7-4109-8b2d-a29de7ce97c3");
    throw ex;
  }
}

/* harmony default export */ __webpack_exports__["default"] = (clientTx);

/***/ }),

/***/ "./src/common.js":
/*!***********************!*\
  !*** ./src/common.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var common = {
  createErrorWithNkodeMethodIdentifier: function createErrorWithNkodeMethodIdentifier(message, nKodeMethodIdentifier) {
    var error = new Error(message);
    common.addNKodeMethodIdentifierStackInfo(error, nKodeMethodIdentifier);
    return error;
  },
  addNKodeMethodIdentifierStackInfo: function addNKodeMethodIdentifierStackInfo(error, nKodeMethodIdentifier) {
    if (!error.nKodeMethodIdentifierStack) error.nKodeMethodIdentifierStack = new Array();
    error.nKodeMethodIdentifierStack.push(nKodeMethodIdentifier);
  },
  checkForValue: function checkForValue(array, arrayName) {
    if (array === null || array === [] || array === 0) throw new Error("".concat(arrayName, " is null or empty"));
    return true;
  },
  get: function get(url) {
    var returnJson = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    return new Promise(function (resolve, reject) {
      // do the usual Http request
      var request = new XMLHttpRequest();
      var cacheBuster = Math.floor(Math.random() * 99999999) + 10000000;
      request.open('GET', url + '?_=' + cacheBuster, true);

      request.onload = function () {
        if (request.status === 200) {
          if (returnJson) {
            resolve(JSON.parse(request.response));
          } else {
            resolve(request.response);
          }
        } else if (request.status > 0) {
          reject(request);
        }
      };

      request.onerror = function () {
        reject(common.createErrorWithNkodeMethodIdentifier("HTTP GET Network error", "7e5f1fc4-e091-40cc-bc4a-dc6d9f739ca3"));
      };

      request.send();
    });
  },
  post: function post(url, payload) {
    return new Promise(function (resolve, reject) {
      var request = new XMLHttpRequest();
      request.open('POST', url, true);
      request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');

      request.onreadystatechange = function () {
        if (request.readyState === 4) {
          if (request.status === 200) {
            var result = request.response;

            if (result) {
              try {
                result = JSON.parse(result);
              } catch (_unused) {}
            }

            resolve(result);
          } else if (request.status > 0) {
            //reject(new error('49FAE9BD-ACC5-4F64-8E05-CBF0A421FD0C', request));
            reject(request);
          }
        }
      };

      var encoded = Object.keys(payload).map(function (key) {
        if (_typeof(payload[key]) === "object") {
          //return Object.keys(payload[key]).map((array, index) => {
          //    return array.map(value => {
          //        return "Keys[" + index + "][]=" + encodeURIComponent(value);
          //    }).join('&');
          //}).join('&');
          return encodeURIComponent(key) + '=' + JSON.stringify(payload[key]);
        } else {
          return encodeURIComponent(key) + '=' + encodeURIComponent(payload[key]);
        }
      }).join('&');

      request.onerror = function () {
        reject(common.createErrorWithNkodeMethodIdentifier("HTTP POST Network error", "1379eab4-e15e-4e7c-830e-b374f73bdb77")); //new error('A761FFE3-3C37-4894-9F9F-420A9AC5E3B6'));
      };

      request.send(encoded);
    });
  }
};
/* harmony default export */ __webpack_exports__["default"] = (common);

/***/ }),

/***/ "./src/darcCommon.js":
/*!***************************!*\
  !*** ./src/darcCommon.js ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _common_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./common.js */ "./src/common.js");

var darcCommon = {
  getDarcKeyLength: function getDarcKeyLength(array) {
    try {
      var count = 0;
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = array[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var value = _step.value;
          count += Array.isArray(value) ? value.length : 1;
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return != null) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return count;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(ex, "87dcd299-79a3-4a24-8f81-beb7b1827402");
      throw ex;
    }
  },
  flattenTwoDimArray: function flattenTwoDimArray(twoDimArray) {
    try {
      var result = new Array();
      var _iteratorNormalCompletion2 = true;
      var _didIteratorError2 = false;
      var _iteratorError2 = undefined;

      try {
        for (var _iterator2 = twoDimArray[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
          var value = _step2.value;
          var _iteratorNormalCompletion3 = true;
          var _didIteratorError3 = false;
          var _iteratorError3 = undefined;

          try {
            for (var _iterator3 = value[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              var subValue = _step3.value;
              result.push(subValue);
            }
          } catch (err) {
            _didIteratorError3 = true;
            _iteratorError3 = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion3 && _iterator3.return != null) {
                _iterator3.return();
              }
            } finally {
              if (_didIteratorError3) {
                throw _iteratorError3;
              }
            }
          }
        }
      } catch (err) {
        _didIteratorError2 = true;
        _iteratorError2 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion2 && _iterator2.return != null) {
            _iterator2.return();
          }
        } finally {
          if (_didIteratorError2) {
            throw _iteratorError2;
          }
        }
      }

      return result;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(ex, "a91b1ae8-7e3f-4531-b8a2-49587a4d2047");
      throw ex;
    }
  },
  initializeNewArray: function initializeNewArray(width, height, value) {
    try {
      var empty = new Array();
      var element = new Array();

      for (var w = 0; w < width; w++) {
        element.push(value === undefined || value === null ? w : value);
      }

      for (var h = 0; h < height; h++) {
        empty.push(element);
      }

      return empty;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(ex, "792f75b4-2bb6-4afd-95ab-aefaaa4b269a");
      throw ex;
    }
  },
  arrayElementsMatch: function arrayElementsMatch(array1, array2) {
    try {
      if (array1.length !== array2.length) return false;
      var result = true;

      for (var x = 0; x < array1.length; x++) {
        if (array1[x] !== array2[x]) {
          result = false;
          break;
        }
      }

      return result;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(ex, "0a578e81-f6a1-41da-b047-b9a3e45313be");
      throw ex;
    }
  },
  //byte[][] bytes, int count, int min, int max
  randUniqueNewBytes: function randUniqueNewBytes(bytes, count, min, max) {
    try {
      var byteMax = 256;
      var byteMin = 0; //Verify that all parameters are valid for byte data

      if (count < 0 || count > byteMax || min < byteMin || min > byteMax || max < byteMin || max > byteMax || min > max) throw _common_js__WEBPACK_IMPORTED_MODULE_0__["default"].createErrorWithNkodeMethodIdentifier("Argument(s) out of range", "b8935b4c-ef28-49b7-a9e1-ac7258933292"); //Determine array dimensions

      var height = bytes.length;
      var width = bytes[0].length; //Verify that all bytes sub-arrays are uniform in size

      var contra = new Array();

      for (var i = 1; i < height; i++) {
        if (bytes[i].length !== width) contra.push(i);
      }

      if (contra.length > 0) throw _common_js__WEBPACK_IMPORTED_MODULE_0__["default"].createErrorWithNkodeMethodIdentifier("Size of bytes sub-arrays must be uniform", "b8935b4c-ef28-49b7-a9e1-ac7258933292");
      contra = null; //Begin process

      var success = new Array(width);
      var chosen = new Array();
      var pass = 0;
      var fail = 0;
      var randNum = 0;
      var hit = 0;
      var miss = 0;
      var ord = 0;
      var scrap = 0; //Random permutation

      var ordinal = darcCommon.randUniqueInt(width, 0, width); //RandUniqueInt max is EXclusive
      //Random byte block

      var set = darcCommon.randUniqueInt(width, 0, byteMax); //RandUniqueByte max is EXclusive
      //Build possible valid values

      var possible = new Array();

      for (var _i = min; _i < max; _i++) {
        possible.push(_i);
      } //Identify possible ordinal and value combinations which are distinct across all bytes[]


      for (var x = 0; x < width; x++) {
        var avail = possible.slice(0); //ConvertAll to byte to ensure that avail is a COPY of possible, and because byte is more memory efficient than int.
        //Remove each element value in bytes[y][ordinal[x]] from avail[]

        for (var y = 0; y < height; y++) {
          var z = avail.Count - 1;

          do {
            if (avail[z] === bytes[y][ordinal[x]]) {
              avail.splice(z, 1);
              z--;
            }

            z--;
          } while (z >= 0);
        }

        success[x] = avail.length > 0;
        randNum = darcCommon.randNum(0, avail.length);
        chosen.push(avail[randNum]);
      } //Consolidate identified ordinal and value combinations to a single pair.


      for (var _x = 0; _x < width; _x++) {
        if (success[_x]) {
          pass = chosen[_x];
          hit = _x;
          ord = ordinal[_x];
        } else //Assign array element and variable to maintain constant execution time and memory profile regardless of branch.
          {
            fail = chosen[_x];
            miss = _x;
            scrap = ordinal[_x];
          }
      }

      set[ord] = pass; //If the full bytes[][] space (every possible combination of byte values) is used, set will not be a new distinct series of bytes, but rather a random series of bytes that already exists somewhere in bytes[][].  

      return set;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(ex, "b8935b4c-ef28-49b7-a9e1-ac7258933292");
      throw ex;
    }
  },
  randNewInts: function randNewInts(ints, count, min, max) {
    try {
      var msgLen = ints.length; //Generate random values for padding

      var setPad = darcCommon.randInt(count, min, max);
      var set = new Array(); //Pad set with random values

      for (var i = 0; i < max; i++) {
        if (msgLen > i) set.push(ints[i]);else set.push(setPad[i]);
      }

      return set;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(ex, "bcaebc49-37dc-45fb-b93f-78c46fb65a9b");
      throw ex;
    }
  },
  randInt: function randInt(count, min, max) {
    try {
      var array = new Array(count);

      for (var b = 0; b < count; b++) {
        array[b] = darcCommon.randNum(min, max);
      }

      return array;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(ex, "33abf500-e02d-4cb6-8349-12e5e9b0fd2c");
      throw ex;
    }
  },
  //Inclusive min exclusive max
  randUniqueInt: function randUniqueInt(count, min, max) {
    try {
      if (max <= min || count < 0 || // max - min > 0 required to avoid overflow
      count > max - min && max - min > 0) {} //throw new ArgumentOutOfRangeException("Range " + min + " to " + max + " (" + (max - min) + " values), or count " + count + " is illegal");
      // generate count random values.


      var candidates = {}; // start count values before max, and end at max

      for (var top = max - count; top < max; top++) {
        var randNumResult = darcCommon.randNum(min, top + 1);
        if (candidates[randNumResult] === true) // collision, add inclusive max.
          // which could not possibly have been added before.
          candidates[top] = true;else candidates[randNumResult] = true;
      } // load them in to an array, to sort


      var result = Object.keys(candidates);

      for (var x = 0; x < count; x++) {
        result[x] = parseInt(result[x], 10);
      } // shuffle the results because HashSet has messed
      // with the order, and the algorithm does not produce
      // random-ordered results (e.g. max-1 will never be the first value)


      for (var i = count - 1; i > 0; i--) {
        var k = darcCommon.randNum(0, i); //TODO: check 0 is lowest

        var tmp = result[k];
        result[k] = result[i];
        result[i] = tmp;
      }

      return result;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(ex, "095ee311-05b4-4e25-8e89-cf63bb1b5fcb");
      throw ex;
    }
  },
  //Inclusive min, exclusive max
  randNum: function randNum(min, max) {
    try {
      min = Math.ceil(min);
      max = Math.floor(max); //return Math.floor(Math.random() * (max - 1 - min + 1)) + min;

      return secure_rand(min, max);
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(ex, "e25bad2d-0db4-4f3f-9e2a-fe2121ff43fc");
      throw ex;
    }
  },
  structureFlattenedTwoDimensionalArray: function structureFlattenedTwoDimensionalArray(height, width, data) {
    try {
      if (height * width !== data.length) throw _common_js__WEBPACK_IMPORTED_MODULE_0__["default"].createErrorWithNkodeMethodIdentifier("Arguments out of range", "9743e48a-9b3a-4221-acca-9fbc1830c1df");
      var outerArray = new Array();

      for (var x = 0; x < height; x++) {
        var innerArray = new Array();

        for (var y = 0; y < width; y++) {
          innerArray.push(data[width * x + y]);
        }

        outerArray.push(innerArray);
      }

      return outerArray;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(ex, "9743e48a-9b3a-4221-acca-9fbc1830c1df");
      throw ex;
    }
  }
};
/**
 * Javascript CSPRNG for Integers.  Taken from https://gist.github.com/paragonie-scott/c7a73fd0f759e451cf07
 * @param {int} min Inclusive minimum value
 * @param {int} max Exclusive maximum value
 * @returns {int} Random value
 */

function secure_rand(min, max) {
  var rval = 0;
  var range = max - min;

  if (range < 2) {
    return min;
  }

  var bits_needed = Math.ceil(Math.log2(range));

  if (bits_needed > 53) {
    throw new Exception("We cannot generate numbers larger than 53 bits.");
  }

  var bytes_needed = Math.ceil(bits_needed / 8);
  var mask = Math.pow(2, bits_needed) - 1; // 7776 -> (2^13 = 8192) -1 == 8191 or 0x00001111 11111111
  // Create byte array and fill with N random numbers

  var byteArray = new Uint8Array(bytes_needed);
  window.crypto.getRandomValues(byteArray);
  var p = (bytes_needed - 1) * 8;

  for (var i = 0; i < bytes_needed; i++) {
    rval += byteArray[i] * Math.pow(2, p);
    p -= 8;
  } // Use & to apply the mask and reduce the number of recursive lookups


  rval = rval & mask;

  if (rval >= range) {
    // Integer out of acceptable range
    return secure_rand(min, max);
  } // Return an integer that falls within the range


  return min + rval;
}

/* harmony default export */ __webpack_exports__["default"] = (darcCommon);

/***/ }),

/***/ "./src/darcConfig.js":
/*!***************************!*\
  !*** ./src/darcConfig.js ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var darcConfig = // @jscrambler enable numberToString, stringConcealing, identifiersRenaming
{
  ATTRIBUTE_VALUES: [37, 251, 55, 253, 76, 146, 252, 212, 138, 63, 67, 179, 187, 36, 216, 11, 70, 125, 199, 156, 66, 100, 92, 24, 46, 209, 29, 174, 86, 104, 128, 204, 112, 167, 110, 158, 8, 183, 235, 176, 244, 64, 91, 163, 200, 153, 0, 141, 18, 201, 105, 182, 186, 113, 2, 96, 143, 193, 16, 151, 14, 101, 221, 119, 241, 118, 10, 21, 80, 207],
  POSITION_ATTRIBUTE_ORDINAL_POSITION: 6,
  CLIENT_KEYS: {
    OuterFunctionKey: [[3, 7, 9, 0, 1, 4, 5, 2, 8, 6]],
    OuterFunctionFunctionKey: [[3, 4, 9, 5, 7, 1, 0, 6, 2, 8]],
    OuterServerShuffleFunctionKey: [[8, 5, 7, 0, 9, 2, 6, 3, 4, 1]],
    MutualKey: [[210, 97, 245, 13, 137, 45, 135], [80, 186, 150, 223, 252, 158, 216], [233, 106, 179, 93, 228, 202, 162], [162, 18, 68, 128, 72, 1, 88], [64, 117, 72, 66, 17, 6, 247], [23, 149, 88, 91, 140, 184, 23], [166, 172, 53, 226, 183, 98, 6], [14, 123, 100, 227, 244, 141, 165], [112, 81, 238, 17, 11, 57, 14], [36, 166, 11, 102, 120, 51, 107]],
    FunctionKey: [[0, 5, 3, 4, 1, 2, 6], [4, 1, 3, 6, 5, 2, 0], [2, 4, 3, 5, 6, 1, 0], [5, 3, 2, 6, 1, 0, 4], [3, 2, 4, 1, 5, 0, 6], [6, 0, 2, 1, 4, 5, 3], [1, 5, 2, 0, 6, 3, 4], [0, 2, 5, 4, 1, 6, 3], [2, 1, 5, 0, 4, 3, 6], [4, 3, 6, 5, 0, 1, 2]],
    ClientShuffleKeyX: [[1, 3, 2, 0, 6, 5, 4], [5, 4, 3, 6, 1, 0, 2], [3, 5, 1, 6, 0, 4, 2], [5, 0, 3, 6, 4, 1, 2], [0, 6, 5, 4, 1, 2, 3], [6, 1, 5, 3, 0, 2, 4], [6, 1, 5, 0, 2, 3, 4], [6, 2, 0, 1, 3, 5, 4], [2, 6, 4, 0, 3, 5, 1], [3, 1, 2, 4, 5, 0, 6]],
    MutualMediumKey: [[155, 172, 102, 11, 72, 33, 88], [65, 78, 66, 25, 245, 97, 8], [202, 75, 128, 89, 175, 12, 228], [118, 177, 237, 65, 40, 15, 65], [93, 28, 176, 115, 13, 205, 248], [193, 254, 126, 60, 225, 222, 217], [33, 122, 169, 117, 4, 231, 141], [36, 246, 211, 52, 192, 201, 157], [249, 115, 8, 117, 221, 139, 205], [214, 153, 127, 169, 209, 165, 6]],
    OuterFunctionMediumKey: [[7, 2, 4, 3, 1, 8, 0, 6, 9, 5]],
    OuterFunctionFunctionMediumKey: [[5, 4, 2, 7, 8, 6, 1, 9, 0, 3]],
    OuterServerShuffleFunctionMediumKey: [[9, 2, 4, 0, 8, 3, 1, 6, 5, 7]],
    FunctionMediumKey: [[2, 5, 4, 0, 1, 3, 6], [0, 3, 2, 6, 4, 1, 5], [4, 3, 2, 6, 5, 0, 1], [2, 1, 5, 3, 4, 6, 0], [4, 5, 6, 2, 3, 0, 1], [0, 1, 4, 5, 3, 2, 6], [3, 6, 0, 2, 4, 5, 1], [2, 0, 3, 5, 6, 1, 4], [5, 0, 3, 6, 4, 2, 1], [6, 3, 5, 4, 2, 1, 0]],
    ClientShuffleMediumKeyX: [[0, 4, 6, 1, 3, 2, 5], [5, 2, 1, 0, 4, 6, 3], [0, 3, 6, 4, 5, 2, 1], [3, 4, 0, 1, 2, 6, 5], [5, 6, 1, 3, 2, 0, 4], [3, 6, 0, 1, 5, 2, 4], [6, 3, 4, 1, 2, 5, 0], [0, 2, 6, 4, 3, 1, 5], [3, 5, 2, 4, 6, 0, 1], [4, 0, 2, 5, 1, 3, 6]],
    OuterPositionShuffleMediumKey: [[1, 9, 4, 3, 0, 8, 5, 7, 6, 2]],
    OuterPositionShuffleFunctionMediumKey: [[2, 1, 9, 6, 0, 8, 3, 7, 5, 4]],
    OuterPositionFunctionMediumKey: [[9, 1, 5, 3, 8, 4, 0, 6, 7, 2]],
    PositionFunctionMediumKey: [[3, 4, 0, 1, 6, 2, 5], [3, 1, 5, 0, 6, 2, 4], [3, 1, 5, 4, 6, 2, 0], [0, 1, 3, 4, 6, 5, 2], [4, 1, 3, 2, 0, 6, 5], [5, 2, 4, 0, 6, 1, 3], [0, 5, 4, 2, 1, 6, 3], [6, 2, 4, 1, 5, 0, 3], [3, 0, 4, 2, 5, 6, 1], [3, 5, 0, 4, 6, 2, 1]],
    PositionShuffleMediumKey: [[1, 0, 2, 3, 5, 6, 4], [1, 4, 2, 6, 3, 5, 0], [2, 5, 3, 6, 0, 4, 1], [1, 4, 0, 5, 3, 2, 6], [2, 1, 0, 5, 3, 6, 4], [1, 5, 6, 4, 0, 2, 3], [1, 3, 6, 0, 5, 2, 4], [3, 0, 2, 5, 1, 6, 4], [3, 4, 0, 6, 2, 5, 1], [2, 1, 0, 4, 3, 5, 6]],
    ClientKey: [[142, 8, 155, 162, 199, 29, 154], [14, 227, 140, 50, 8, 26, 135], [18, 26, 73, 224, 77, 104, 198], [5, 204, 137, 194, 193, 186, 143], [149, 245, 194, 177, 217, 111, 85], [39, 164, 86, 244, 140, 9, 242], [90, 215, 86, 151, 228, 35, 109], [254, 168, 170, 201, 198, 197, 72], [155, 177, 87, 163, 84, 248, 97], [115, 20, 225, 193, 15, 59, 50]],
    ClientShuffleKeyA: [[4, 6, 5, 1, 2, 0, 3], [1, 3, 6, 4, 2, 5, 0], [1, 5, 0, 4, 3, 2, 6], [2, 6, 4, 0, 3, 5, 1], [2, 4, 3, 0, 5, 1, 6], [6, 5, 3, 1, 4, 0, 2], [4, 5, 3, 0, 6, 1, 2], [1, 6, 2, 5, 4, 3, 0], [0, 1, 5, 2, 3, 6, 4], [5, 0, 4, 2, 6, 1, 3]],
    OuterClientShuffleKey: [[0, 6, 5, 7, 9, 2, 3, 8, 1, 4]],
    OuterClientShuffleFunctionKey: [[2, 7, 6, 9, 3, 5, 8, 4, 0, 1]],
    OuterClientShuffleMediumKey: [[7, 6, 5, 4, 0, 8, 1, 2, 9, 3]],
    OuterClientShuffleFunctionMediumKey: [[6, 7, 1, 5, 4, 9, 0, 3, 8, 2]],
    ClientShuffleMediumKeyA: [[1, 6, 5, 2, 4, 3, 0], [6, 0, 4, 3, 2, 1, 5], [1, 0, 2, 6, 3, 4, 5], [6, 4, 5, 2, 1, 0, 3], [6, 1, 2, 4, 3, 5, 0], [6, 4, 0, 2, 3, 1, 5], [4, 2, 0, 3, 1, 6, 5], [1, 2, 4, 6, 5, 0, 3], [5, 0, 3, 1, 2, 6, 4], [6, 3, 2, 5, 1, 0, 4]],
    ClientMediumKey: [[180, 86, 206, 210, 10, 156, 185], [72, 240, 170, 185, 152, 57, 158], [166, 120, 103, 40, 159, 205, 15], [105, 70, 224, 208, 157, 26, 67], [72, 193, 40, 177, 96, 159, 160], [44, 133, 39, 216, 162, 212, 4], [34, 114, 81, 174, 218, 141, 1], [171, 234, 33, 245, 14, 153, 38], [61, 198, 53, 58, 210, 178, 39], [67, 207, 199, 240, 159, 226, 182]]
  },
  SERVER_DARC_ATTRIBUTE_KEYS: {
    OuterFunctionKey: [[35, 52, 19, 24, 3, 26, 42, 67, 13, 17, 37, 7, 39, 60, 61, 15, 34, 18, 36, 29, 23, 11, 41, 6, 58, 9, 1, 48, 49, 45, 51, 40, 55, 20, 44, 31, 28, 5, 68, 22, 50, 54, 21, 12, 56, 8, 27, 10, 64, 32, 59, 33, 38, 43, 47, 14, 0, 16, 46, 30, 2, 66, 62, 63, 25, 53, 57, 69, 4, 65]],
    OuterFunctionFunctionKey: [[29, 27, 37, 8, 17, 30, 54, 58, 2, 23, 47, 57, 50, 13, 21, 7, 53, 32, 24, 44, 20, 68, 42, 49, 65, 62, 39, 63, 46, 61, 18, 10, 5, 38, 52, 0, 19, 60, 28, 33, 22, 67, 15, 59, 55, 41, 9, 14, 6, 40, 3, 45, 51, 31, 11, 12, 36, 69, 1, 34, 66, 35, 16, 43, 56, 26, 48, 4, 25, 64]],
    OuterServerShuffleFunctionKey: [[68, 66, 33, 64, 10, 12, 9, 2, 5, 59, 4, 14, 29, 49, 15, 38, 34, 8, 48, 60, 26, 30, 63, 50, 61, 6, 13, 46, 39, 55, 52, 43, 32, 11, 27, 51, 53, 25, 41, 22, 1, 37, 21, 69, 7, 40, 62, 20, 45, 31, 18, 17, 65, 3, 35, 54, 56, 47, 67, 19, 23, 44, 57, 58, 16, 36, 0, 42, 24, 28]],
    MutualKey: [[26, 63, 234], [48, 30, 185], [87, 70, 124], [144, 172, 13], [110, 144, 7], [9, 49, 127], [128, 225, 84], [240, 132, 186], [219, 187, 6], [186, 156, 137], [62, 53, 191], [207, 125, 136], [72, 188, 252], [173, 200, 41], [201, 163, 127], [84, 251, 226], [119, 121, 91], [166, 245, 143], [79, 22, 90], [202, 202, 33], [212, 67, 28], [123, 158, 54], [18, 171, 72], [164, 163, 245], [176, 169, 82], [5, 227, 95], [91, 97, 51], [72, 47, 122], [25, 174, 191], [180, 203, 75], [63, 56, 142], [183, 138, 68], [63, 31, 231], [117, 4, 140], [208, 17, 226], [244, 90, 102], [157, 111, 70], [239, 242, 65], [202, 157, 76], [157, 176, 15], [168, 95, 216], [216, 170, 219], [217, 199, 246], [41, 60, 42], [209, 224, 107], [156, 184, 157], [14, 150, 71], [30, 83, 189], [161, 118, 178], [88, 25, 127], [54, 204, 255], [233, 246, 88], [223, 233, 51], [7, 97, 91], [234, 75, 2], [86, 25, 152], [74, 214, 20], [149, 62, 218], [217, 12, 6], [21, 248, 143], [193, 28, 132], [189, 54, 161], [168, 25, 144], [195, 58, 130], [198, 93, 200], [107, 36, 170], [106, 50, 104], [189, 244, 41], [45, 129, 10], [232, 239, 201]],
    FunctionKey: [[2, 0, 1], [2, 0, 1], [1, 0, 2], [0, 1, 2], [1, 0, 2], [0, 2, 1], [0, 2, 1], [1, 2, 0], [0, 2, 1], [0, 2, 1], [1, 2, 0], [0, 2, 1], [2, 1, 0], [1, 2, 0], [0, 2, 1], [0, 2, 1], [1, 2, 0], [1, 0, 2], [1, 0, 2], [0, 2, 1], [1, 2, 0], [1, 0, 2], [0, 1, 2], [0, 2, 1], [2, 1, 0], [2, 0, 1], [1, 2, 0], [1, 0, 2], [2, 0, 1], [2, 1, 0], [1, 2, 0], [2, 1, 0], [2, 0, 1], [0, 1, 2], [0, 1, 2], [0, 2, 1], [0, 1, 2], [2, 1, 0], [2, 1, 0], [1, 2, 0], [2, 1, 0], [2, 1, 0], [0, 2, 1], [1, 2, 0], [2, 1, 0], [1, 0, 2], [2, 1, 0], [1, 2, 0], [2, 0, 1], [2, 0, 1], [1, 2, 0], [2, 0, 1], [2, 1, 0], [2, 0, 1], [2, 1, 0], [2, 1, 0], [2, 0, 1], [1, 0, 2], [1, 2, 0], [1, 2, 0], [1, 0, 2], [0, 2, 1], [0, 1, 2], [2, 1, 0], [0, 1, 2], [1, 2, 0], [1, 2, 0], [1, 0, 2], [2, 1, 0], [2, 1, 0]],
    ClientShuffleKeyX: [[1, 0, 2], [0, 2, 1], [2, 0, 1], [0, 2, 1], [1, 2, 0], [0, 2, 1], [1, 2, 0], [2, 0, 1], [0, 1, 2], [1, 0, 2], [0, 1, 2], [0, 2, 1], [0, 1, 2], [0, 2, 1], [0, 1, 2], [1, 2, 0], [1, 0, 2], [2, 1, 0], [0, 2, 1], [1, 0, 2], [1, 2, 0], [0, 2, 1], [1, 0, 2], [1, 2, 0], [0, 1, 2], [1, 2, 0], [0, 2, 1], [2, 0, 1], [2, 0, 1], [2, 1, 0], [1, 0, 2], [2, 0, 1], [1, 0, 2], [0, 1, 2], [0, 1, 2], [0, 2, 1], [0, 2, 1], [1, 0, 2], [0, 1, 2], [2, 0, 1], [1, 0, 2], [0, 2, 1], [2, 0, 1], [2, 1, 0], [2, 1, 0], [0, 1, 2], [0, 2, 1], [0, 2, 1], [0, 2, 1], [2, 1, 0], [0, 1, 2], [0, 2, 1], [0, 2, 1], [2, 1, 0], [2, 0, 1], [0, 1, 2], [0, 2, 1], [1, 2, 0], [2, 1, 0], [1, 0, 2], [1, 0, 2], [0, 1, 2], [0, 1, 2], [0, 1, 2], [1, 0, 2], [1, 0, 2], [1, 0, 2], [1, 2, 0], [0, 2, 1], [0, 2, 1]],
    MutualMediumKey: [[210, 209, 238], [94, 138, 251], [244, 57, 131], [72, 129, 51], [138, 239, 90], [70, 207, 124], [51, 224, 78], [13, 250, 225], [210, 216, 103], [33, 168, 203], [85, 40, 188], [58, 247, 162], [142, 217, 71], [128, 185, 86], [11, 83, 224], [250, 190, 26], [30, 224, 58], [36, 166, 36], [143, 226, 107], [67, 179, 7], [120, 244, 243], [115, 152, 112], [53, 3, 13], [230, 220, 217], [142, 63, 69], [255, 141, 208], [164, 2, 118], [158, 192, 236], [92, 52, 74], [111, 53, 143], [116, 221, 131], [21, 62, 58], [250, 78, 87], [35, 212, 254], [218, 114, 255], [122, 169, 134], [226, 118, 188], [3, 113, 2], [82, 166, 216], [197, 28, 197], [184, 57, 97], [188, 91, 103], [171, 163, 164], [211, 26, 209], [140, 175, 71], [103, 142, 52], [129, 248, 155], [124, 211, 3], [32, 41, 180], [124, 111, 174], [136, 253, 130], [179, 165, 51], [129, 135, 183], [42, 64, 190], [245, 54, 196], [141, 189, 24], [43, 16, 14], [76, 18, 186], [13, 34, 182], [72, 2, 3], [41, 183, 144], [228, 65, 238], [6, 232, 102], [20, 87, 187], [15, 98, 56], [171, 174, 20], [220, 115, 22], [64, 154, 121], [141, 108, 111], [35, 239, 76]],
    OuterFunctionMediumKey: [[30, 63, 65, 43, 49, 18, 39, 4, 15, 12, 20, 29, 69, 64, 36, 53, 41, 42, 61, 62, 13, 55, 2, 58, 44, 66, 0, 50, 10, 51, 48, 32, 52, 9, 33, 54, 31, 3, 68, 25, 19, 46, 59, 23, 57, 16, 56, 6, 47, 67, 7, 21, 35, 45, 8, 37, 14, 22, 17, 24, 26, 28, 11, 34, 60, 5, 38, 1, 40, 27]],
    OuterFunctionFunctionMediumKey: [[12, 19, 54, 30, 15, 9, 44, 49, 3, 28, 20, 14, 36, 69, 25, 61, 63, 6, 62, 21, 1, 2, 35, 47, 39, 22, 4, 29, 68, 24, 27, 46, 26, 60, 37, 11, 50, 31, 66, 67, 43, 38, 48, 16, 33, 8, 52, 7, 41, 51, 0, 56, 32, 57, 58, 42, 64, 53, 18, 13, 5, 59, 45, 34, 17, 23, 10, 40, 65, 55]],
    OuterServerShuffleFunctionMediumKey: [[4, 35, 25, 58, 63, 69, 42, 44, 60, 28, 59, 61, 49, 27, 31, 68, 43, 51, 21, 6, 32, 15, 2, 14, 55, 50, 30, 37, 38, 45, 23, 47, 0, 16, 57, 62, 8, 10, 46, 65, 1, 3, 11, 48, 36, 26, 17, 40, 52, 64, 53, 33, 39, 5, 56, 67, 13, 9, 34, 54, 19, 18, 20, 24, 29, 66, 22, 7, 41, 12]],
    FunctionMediumKey: [[0, 2, 1], [2, 0, 1], [2, 1, 0], [1, 0, 2], [2, 1, 0], [2, 0, 1], [2, 0, 1], [0, 1, 2], [1, 2, 0], [2, 1, 0], [2, 0, 1], [0, 2, 1], [1, 0, 2], [0, 1, 2], [0, 2, 1], [1, 0, 2], [2, 1, 0], [2, 0, 1], [2, 0, 1], [1, 2, 0], [1, 2, 0], [2, 0, 1], [1, 2, 0], [1, 0, 2], [0, 2, 1], [1, 0, 2], [0, 1, 2], [2, 0, 1], [2, 0, 1], [2, 0, 1], [2, 1, 0], [2, 1, 0], [0, 1, 2], [0, 2, 1], [2, 1, 0], [2, 1, 0], [2, 1, 0], [1, 0, 2], [2, 1, 0], [2, 0, 1], [1, 2, 0], [0, 2, 1], [0, 1, 2], [0, 1, 2], [2, 1, 0], [2, 0, 1], [0, 1, 2], [2, 0, 1], [0, 1, 2], [0, 2, 1], [0, 1, 2], [0, 1, 2], [1, 0, 2], [0, 2, 1], [0, 1, 2], [1, 2, 0], [1, 0, 2], [1, 0, 2], [2, 0, 1], [0, 1, 2], [2, 1, 0], [0, 2, 1], [2, 1, 0], [2, 0, 1], [0, 2, 1], [2, 0, 1], [2, 0, 1], [2, 1, 0], [2, 0, 1], [0, 1, 2]],
    ClientShuffleMediumKeyX: [[2, 0, 1], [2, 0, 1], [0, 1, 2], [2, 1, 0], [1, 2, 0], [0, 2, 1], [2, 1, 0], [1, 0, 2], [1, 0, 2], [1, 2, 0], [1, 0, 2], [0, 1, 2], [0, 1, 2], [1, 2, 0], [0, 1, 2], [0, 1, 2], [2, 1, 0], [2, 0, 1], [2, 1, 0], [1, 0, 2], [2, 0, 1], [2, 0, 1], [1, 2, 0], [2, 0, 1], [1, 2, 0], [2, 1, 0], [2, 1, 0], [1, 0, 2], [2, 0, 1], [2, 1, 0], [1, 0, 2], [2, 0, 1], [2, 1, 0], [2, 0, 1], [2, 0, 1], [0, 1, 2], [2, 0, 1], [1, 2, 0], [1, 2, 0], [2, 0, 1], [1, 2, 0], [0, 2, 1], [2, 1, 0], [0, 1, 2], [2, 1, 0], [0, 2, 1], [0, 1, 2], [1, 0, 2], [1, 2, 0], [0, 2, 1], [0, 1, 2], [0, 2, 1], [0, 1, 2], [2, 1, 0], [0, 1, 2], [2, 1, 0], [0, 1, 2], [1, 2, 0], [1, 2, 0], [2, 1, 0], [0, 1, 2], [0, 2, 1], [2, 1, 0], [1, 2, 0], [1, 0, 2], [2, 0, 1], [0, 1, 2], [2, 0, 1], [0, 1, 2], [1, 0, 2]],
    OuterPositionShuffleMediumKey: [[42, 56, 45, 13, 61, 46, 39, 31, 16, 63, 35, 22, 25, 32, 49, 9, 5, 0, 58, 55, 40, 19, 23, 62, 65, 51, 1, 59, 18, 30, 48, 69, 64, 24, 17, 34, 6, 50, 66, 57, 38, 60, 4, 21, 27, 68, 43, 28, 36, 37, 7, 44, 11, 3, 52, 2, 20, 12, 54, 41, 26, 33, 53, 8, 10, 14, 47, 29, 15, 67]],
    OuterPositionShuffleFunctionMediumKey: [[6, 36, 15, 54, 45, 9, 69, 8, 13, 41, 12, 2, 30, 31, 57, 50, 28, 40, 26, 37, 64, 48, 19, 47, 24, 58, 63, 32, 18, 59, 11, 55, 35, 53, 46, 68, 38, 44, 0, 7, 1, 39, 10, 14, 29, 20, 66, 16, 49, 5, 56, 4, 33, 21, 61, 17, 67, 62, 60, 27, 65, 23, 25, 52, 3, 22, 34, 42, 51, 43]],
    OuterPositionFunctionMediumKey: [[24, 46, 53, 21, 2, 41, 43, 0, 20, 16, 3, 51, 47, 13, 19, 63, 39, 62, 17, 64, 52, 61, 36, 37, 29, 34, 32, 55, 48, 25, 67, 14, 7, 15, 54, 23, 42, 65, 6, 45, 57, 28, 35, 44, 68, 12, 69, 50, 66, 26, 18, 22, 30, 56, 27, 59, 31, 11, 4, 40, 33, 10, 9, 8, 60, 1, 5, 58, 49, 38]],
    PositionFunctionMediumKey: [[2, 0, 1], [1, 2, 0], [0, 1, 2], [1, 0, 2], [1, 2, 0], [0, 1, 2], [2, 1, 0], [1, 0, 2], [1, 0, 2], [0, 1, 2], [1, 0, 2], [2, 1, 0], [2, 0, 1], [0, 2, 1], [2, 1, 0], [0, 1, 2], [1, 2, 0], [2, 1, 0], [0, 1, 2], [2, 1, 0], [1, 0, 2], [0, 1, 2], [2, 1, 0], [0, 1, 2], [2, 1, 0], [2, 1, 0], [1, 0, 2], [1, 2, 0], [2, 0, 1], [1, 2, 0], [0, 1, 2], [1, 0, 2], [1, 0, 2], [0, 2, 1], [0, 2, 1], [2, 0, 1], [0, 1, 2], [2, 0, 1], [0, 1, 2], [2, 0, 1], [0, 2, 1], [1, 2, 0], [0, 2, 1], [0, 2, 1], [1, 0, 2], [1, 0, 2], [1, 2, 0], [1, 0, 2], [0, 2, 1], [1, 0, 2], [2, 0, 1], [1, 0, 2], [2, 0, 1], [1, 0, 2], [1, 2, 0], [2, 0, 1], [2, 1, 0], [0, 1, 2], [0, 1, 2], [1, 0, 2], [1, 2, 0], [0, 2, 1], [0, 1, 2], [1, 0, 2], [1, 0, 2], [1, 0, 2], [2, 1, 0], [0, 2, 1], [2, 0, 1], [2, 0, 1]],
    PositionShuffleMediumKey: [[0, 1, 2], [2, 0, 1], [2, 1, 0], [2, 0, 1], [0, 2, 1], [2, 1, 0], [0, 1, 2], [1, 2, 0], [0, 1, 2], [0, 2, 1], [0, 1, 2], [0, 2, 1], [2, 1, 0], [2, 0, 1], [2, 1, 0], [2, 1, 0], [0, 2, 1], [0, 1, 2], [2, 0, 1], [0, 2, 1], [0, 2, 1], [2, 1, 0], [1, 2, 0], [2, 1, 0], [2, 1, 0], [0, 1, 2], [2, 0, 1], [2, 0, 1], [2, 0, 1], [2, 1, 0], [2, 0, 1], [0, 2, 1], [0, 1, 2], [2, 0, 1], [2, 0, 1], [1, 2, 0], [1, 0, 2], [0, 1, 2], [0, 1, 2], [2, 1, 0], [2, 1, 0], [0, 2, 1], [0, 2, 1], [2, 1, 0], [2, 1, 0], [2, 1, 0], [2, 0, 1], [2, 1, 0], [2, 1, 0], [1, 2, 0], [0, 2, 1], [1, 0, 2], [0, 1, 2], [2, 0, 1], [2, 0, 1], [1, 2, 0], [1, 0, 2], [1, 0, 2], [1, 0, 2], [2, 1, 0], [0, 1, 2], [2, 0, 1], [2, 1, 0], [2, 0, 1], [1, 0, 2], [0, 1, 2], [1, 2, 0], [1, 0, 2], [2, 1, 0], [0, 2, 1]],
    OuterServerShuffleKey: [[26, 52, 58, 27, 33, 36, 38, 51, 67, 43, 35, 42, 64, 62, 3, 37, 10, 19, 65, 18, 63, 53, 39, 57, 8, 5, 7, 40, 12, 24, 34, 68, 66, 9, 11, 47, 59, 46, 41, 29, 60, 6, 28, 13, 0, 22, 16, 14, 15, 2, 23, 49, 17, 4, 56, 50, 21, 25, 30, 48, 1, 69, 20, 61, 55, 31, 54, 45, 44, 32]],
    ServerKey: [[6, 17, 71], [145, 66, 84], [115, 209, 177], [20, 14, 189], [74, 223, 48], [186, 80, 241], [228, 157, 78], [91, 50, 242], [98, 152, 135], [145, 124, 130], [232, 108, 159], [0, 111, 157], [3, 12, 39], [143, 44, 155], [226, 139, 51], [213, 217, 56], [95, 23, 249], [153, 3, 223], [142, 62, 12], [172, 55, 107], [110, 254, 243], [30, 78, 72], [63, 235, 128], [56, 176, 25], [0, 164, 84], [31, 113, 240], [123, 90, 158], [154, 42, 254], [127, 46, 16], [121, 190, 190], [222, 130, 234], [216, 84, 36], [229, 57, 189], [152, 59, 167], [195, 20, 52], [168, 49, 26], [145, 7, 204], [18, 115, 128], [34, 32, 196], [146, 253, 253], [134, 31, 46], [55, 11, 223], [122, 189, 199], [138, 213, 144], [112, 49, 145], [191, 104, 117], [12, 136, 54], [202, 248, 81], [50, 181, 60], [165, 130, 124], [139, 16, 53], [35, 173, 3], [88, 202, 44], [43, 167, 164], [229, 194, 29], [239, 10, 26], [219, 243, 199], [140, 107, 107], [138, 251, 28], [39, 84, 195], [220, 16, 57], [243, 218, 211], [32, 94, 74], [174, 193, 6], [31, 85, 216], [159, 23, 144], [19, 124, 224], [45, 93, 11], [199, 243, 165], [250, 160, 251]],
    ServerShuffleKey: [[1, 2, 0], [2, 0, 1], [0, 1, 2], [1, 2, 0], [2, 0, 1], [1, 0, 2], [0, 1, 2], [2, 1, 0], [0, 1, 2], [2, 0, 1], [0, 1, 2], [0, 1, 2], [1, 2, 0], [2, 1, 0], [0, 1, 2], [0, 1, 2], [2, 0, 1], [0, 2, 1], [2, 0, 1], [2, 1, 0], [1, 0, 2], [0, 1, 2], [1, 0, 2], [0, 2, 1], [0, 1, 2], [1, 2, 0], [2, 1, 0], [2, 0, 1], [0, 1, 2], [0, 1, 2], [0, 1, 2], [0, 1, 2], [2, 1, 0], [2, 1, 0], [1, 2, 0], [0, 2, 1], [2, 0, 1], [1, 2, 0], [2, 1, 0], [0, 1, 2], [2, 1, 0], [2, 1, 0], [1, 2, 0], [1, 0, 2], [1, 0, 2], [2, 0, 1], [0, 2, 1], [1, 2, 0], [2, 0, 1], [0, 1, 2], [2, 0, 1], [0, 1, 2], [1, 0, 2], [0, 2, 1], [0, 1, 2], [0, 2, 1], [0, 2, 1], [1, 2, 0], [2, 1, 0], [0, 1, 2], [2, 1, 0], [1, 2, 0], [0, 2, 1], [2, 1, 0], [0, 1, 2], [0, 1, 2], [0, 1, 2], [1, 2, 0], [0, 2, 1], [1, 0, 2]],
    ServerMediumKey: [[9, 84, 203], [230, 12, 94], [164, 32, 233], [34, 168, 57], [223, 185, 26], [47, 159, 106], [235, 93, 19], [58, 90, 118], [184, 20, 249], [139, 84, 250], [218, 44, 79], [201, 105, 221], [238, 75, 228], [13, 107, 220], [202, 217, 46], [48, 161, 85], [5, 105, 198], [12, 176, 35], [186, 202, 205], [222, 119, 133], [139, 121, 124], [123, 134, 245], [165, 105, 142], [134, 61, 38], [244, 45, 115], [184, 55, 138], [79, 117, 153], [196, 86, 42], [74, 29, 237], [192, 69, 207], [194, 186, 43], [11, 92, 45], [139, 228, 4], [108, 29, 7], [130, 148, 241], [75, 96, 162], [170, 203, 69], [202, 202, 84], [61, 55, 35], [53, 104, 142], [72, 224, 163], [73, 207, 3], [147, 133, 65], [147, 111, 24], [85, 206, 30], [59, 8, 44], [189, 126, 48], [65, 155, 30], [50, 7, 81], [250, 93, 161], [237, 130, 102], [63, 2, 243], [223, 149, 53], [15, 214, 212], [244, 92, 83], [249, 96, 19], [211, 2, 140], [23, 121, 57], [85, 175, 69], [212, 2, 75], [54, 168, 10], [32, 104, 136], [119, 142, 208], [207, 78, 68], [111, 111, 18], [148, 191, 198], [25, 53, 190], [153, 65, 18], [3, 197, 133], [32, 210, 226]]
  }
};
/* harmony default export */ __webpack_exports__["default"] = (darcConfig);

/***/ }),

/***/ "./src/ephemeralKeys.js":
/*!******************************!*\
  !*** ./src/ephemeralKeys.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./darcCommon.js */ "./src/darcCommon.js");
/* harmony import */ var _common_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./common.js */ "./src/common.js");


var randMin = 0;
var randMax = 255;
var ephemeralKeys = {
  generateSharedInstanceTranslations: function generateSharedInstanceTranslations(width, height, inputBlockLength, update) {
    try {
      var sharedEphemeralKeysObj = {
        MutualEphemeralKey: getNewDataTranslationKey(width, height),
        //Adds Mutual translation; prevents differential cryptanalysis between Tx and Rx
        FunctionEphemeralKey: getNewShuffleOrFunctionTranslationKey(width, height),
        //Session-Specific Translation Function; Insulates Sessions from on another in the event of Obfuscated Java Script compromise
        OuterFunctionEphemeralKey: getNewShuffleOrFunctionTranslationKey(height, 1),
        OuterFunctionFunctionEphemeralKey: getNewShuffleOrFunctionTranslationKey(height, 1),
        OuterServerShuffleFunctionEphemeralKey: getNewShuffleOrFunctionTranslationKey(height, 1),
        MutualMediumEphemeralKey: getNewDataTranslationKey(width, inputBlockLength),
        //Adds Mutual translation; prevents differential cryptanalysis between Tx and Rx            
        FunctionMediumEphemeralKey: getNewShuffleOrFunctionTranslationKey(width, inputBlockLength),
        //Session-Specific Translation Function; Insulates Sessions from on another in the event of Obfuscated Java Script compromise
        PositionFunctionMediumEphemeralKey: getNewShuffleOrFunctionTranslationKey(width, inputBlockLength),
        OuterFunctionMediumEphemeralKey: getNewShuffleOrFunctionTranslationKey(inputBlockLength, 1),
        OuterFunctionFunctionMediumEphemeralKey: getNewShuffleOrFunctionTranslationKey(inputBlockLength, 1),
        OuterPositionFunctionMediumEphemeralKey: getNewShuffleOrFunctionTranslationKey(inputBlockLength, 1),
        OuterServerShuffleFunctionMediumEphemeralKey: getNewShuffleOrFunctionTranslationKey(inputBlockLength, 1),
        OuterPositionShuffleFunctionMediumEphemeralKey: getNewShuffleOrFunctionTranslationKey(inputBlockLength, 1),
        PositionShuffleMediumEphemeralKey: getNewShuffleOrFunctionTranslationKey(width, height),
        OuterPositionShuffleMediumEphemeralKey: getNewShuffleOrFunctionTranslationKey(inputBlockLength, 1),
        TokenUpdateFunctionEphemeralKey: null //Update-Specific Update Translation Function; Insulates Updates from on another in the event of Obfuscated Java Script compromise                                    

      };
      if (update) sharedEphemeralKeysObj.TokenUpdateFunctionEphemeralKey = getNewShuffleOrFunctionTranslationKey(width, height);
      return sharedEphemeralKeysObj;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "7ac7c545-13cc-44a7-835b-33b5385af4ca");
      throw ex;
    }
  },
  generateServerInstanceTranslations: function generateServerInstanceTranslations(width, height, inputBlockLength) {
    try {
      var serverEphemeralKeysObj = {
        OuterServerShuffleEphemeralKey: getNewShuffleOrFunctionTranslationKey(height, 1),
        ServerEphemeralKey: getNewDataTranslationKey(width, height),
        ServerShuffleEphemeralKey: getNewShuffleOrFunctionTranslationKey(width, height),
        ServerMediumEphemeralKey: getNewDataTranslationKey(width, inputBlockLength) //Adds Server-Side translation exclusive to the Server-Side

      };
      return serverEphemeralKeysObj;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "a937be14-8f26-4a03-8caf-03b54ad904e6");
      throw ex;
    }
  },
  generateClientInstanceTranslations: function generateClientInstanceTranslations(width, height, inputBlockLength) {
    try {
      var clientEphemeralKeysObj = {
        OuterClientShuffleEphemeralKey: getNewShuffleOrFunctionTranslationKey(height, 1),
        OuterClientShuffleFunctionEphemeralKey: getNewShuffleOrFunctionTranslationKey(height, 1),
        ClientEphemeralKey: getNewDataTranslationKey(width, height),
        ClientShuffleEphemeralKeyA: getNewShuffleOrFunctionTranslationKey(width, height),
        OuterClientShuffleMediumEphemeralKey: getNewShuffleOrFunctionTranslationKey(height, 1),
        OuterClientShuffleFunctionMediumEphemeralKey: getNewShuffleOrFunctionTranslationKey(height, 1),
        ClientShuffleMediumEphemeralKeyA: getNewShuffleOrFunctionTranslationKey(width, height),
        ClientMediumEphemeralKey: getNewDataTranslationKey(width, inputBlockLength) //Adds Client-Side translation exclusive to the Client-Side

      };
      return clientEphemeralKeysObj;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "6438bdea-26bd-41cf-8a00-fd5d727f4b00");
      throw ex;
    }
  }
};

function getNewShuffleOrFunctionTranslationKey(width, height) {
  try {
    var data = new Array(height);

    for (var h = 0; h < height; h++) {
      data[h] = _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].randUniqueInt(width, randMin, width);
    }

    return data;
  } catch (ex) {
    _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "2d06263b-bc2b-491b-88ba-ef969c13cb2f");
    throw ex;
  }
}

function getNewDataTranslationKey(width, height) {
  try {
    var data = new Array(height);

    for (var h = 0; h < height; h++) {
      data[h] = _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].randUniqueInt(width, randMin, randMax + 1);
    }

    return data;
  } catch (ex) {
    _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "bf246bc6-78ab-4618-a832-46adc89a0f84");
    throw ex;
  }
}

/* harmony default export */ __webpack_exports__["default"] = (ephemeralKeys);

/***/ }),

/***/ "./src/keypad.js":
/*!***********************!*\
  !*** ./src/keypad.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./common */ "./src/common.js");
/* harmony import */ var _darcConfig__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./darcConfig */ "./src/darcConfig.js");
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }



var _config = null;
var keypad = {
  removeLastEntry: function removeLastEntry() {
    keypad.selectedKeyOrdinal.pop();
    fireChangedEvent();
  },
  setConfig: function setConfig(config) {
    _config = config;
  },
  nKodChanged: null,
  selectedKeyOrdinal: [],
  currentNKodLength: function currentNKodLength() {
    return keypad.selectedKeyOrdinal.length;
  },
  //  RETURN HTML KEYPAD
  getKeypad: function () {
    var _getKeypad = _asyncToGenerator(
    /*#__PURE__*/
    regeneratorRuntime.mark(function _callee(attributeDarcData, templateIdentifier, attributeMap) {
      var keys, copy, attributePositionData, positionIndex, width, height, positionArrayStartIndex, x, currentAlphabetPosition, _x4, i, html, htmlTemplate, attributeSetOne, attributeSetTwo, attributeSetThree, attributeSetFour, attributeSetFive, attributeSetSix, attributeSetSeven, _i, j, attribute, interfacePlaceholderElement, clickableKeys, _i2;

      return regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.prev = 0;
              keys = [];
              copy = attributeDarcData;
              attributePositionData = new Array();

              if (!(copy.length > 0)) {
                _context.next = 18;
                break;
              }

              positionIndex = _darcConfig__WEBPACK_IMPORTED_MODULE_1__["default"].ATTRIBUTE_VALUES.indexOf(attributeMap[copy[0][_darcConfig__WEBPACK_IMPORTED_MODULE_1__["default"].POSITION_ATTRIBUTE_ORDINAL_POSITION]]);
              width = copy[0].length;
              height = copy.length;
              x = 0;

            case 9:
              if (!(x < width)) {
                _context.next = 17;
                break;
              }

              currentAlphabetPosition = height * x;

              if (!(currentAlphabetPosition <= positionIndex && positionIndex < currentAlphabetPosition + height)) {
                _context.next = 14;
                break;
              }

              positionArrayStartIndex = currentAlphabetPosition;
              return _context.abrupt("break", 17);

            case 14:
              x++;
              _context.next = 9;
              break;

            case 17:
              attributePositionData = _darcConfig__WEBPACK_IMPORTED_MODULE_1__["default"].ATTRIBUTE_VALUES.slice(positionArrayStartIndex, positionArrayStartIndex + height);

            case 18:
              for (_x4 = 0; _x4 < copy.length; _x4++) //loop through number of keys
              {
                for (i = 0; i < copy.length; i++) //Use index of outer loop to add correct key by matching to the corresponding attribute position
                {
                  copy[i].oldIndex = i;

                  if (attributeMap[copy[i][_darcConfig__WEBPACK_IMPORTED_MODULE_1__["default"].POSITION_ATTRIBUTE_ORDINAL_POSITION]] === attributePositionData[_x4]) {
                    keys.push(copy[i]);
                  }
                }
              }

              html = "";
              _context.next = 22;
              return _common__WEBPACK_IMPORTED_MODULE_0__["default"].get(_config.HTML_TEMPLATE_PATH.replace(/(\${templateIdentifier})+/g, templateIdentifier));

            case 22:
              htmlTemplate = _context.sent;
              //  PREP POSITION REPLACEMENTS
              attributeSetOne = "";
              attributeSetTwo = "";
              attributeSetThree = "";
              attributeSetFour = "";
              attributeSetFive = "";
              attributeSetSix = "";
              attributeSetSeven = "";
              _i = 0;

            case 31:
              if (!(_i < keys.length)) {
                _context.next = 61;
                break;
              }

              j = 0;

            case 33:
              if (!(j < keys[_i].length)) {
                _context.next = 55;
                break;
              }

              attribute = keys[_i][j];
              _context.t0 = j;
              _context.next = _context.t0 === 0 ? 38 : _context.t0 === 1 ? 40 : _context.t0 === 2 ? 42 : _context.t0 === 3 ? 44 : _context.t0 === 4 ? 46 : _context.t0 === 5 ? 48 : _context.t0 === 6 ? 50 : 52;
              break;

            case 38:
              attributeSetOne = attributeMap[attribute];
              return _context.abrupt("break", 52);

            case 40:
              attributeSetTwo = attributeMap[attribute];
              return _context.abrupt("break", 52);

            case 42:
              attributeSetThree = attributeMap[attribute];
              return _context.abrupt("break", 52);

            case 44:
              attributeSetFour = attributeMap[attribute];
              return _context.abrupt("break", 52);

            case 46:
              attributeSetFive = attributeMap[attribute];
              return _context.abrupt("break", 52);

            case 48:
              attributeSetSix = attributeMap[attribute];
              return _context.abrupt("break", 52);

            case 50:
              attributeSetSeven = attributeMap[attribute];
              return _context.abrupt("break", 52);

            case 52:
              j++;
              _context.next = 33;
              break;

            case 55:
              if (_i === 0 || _i === 3 || _i === 6) {
                html += '<div class="row justify-content-between mt-2">';
              } else if (_i === 9) {
                html += '<div class="row justify-content-around mt-2">';
              }

              html += htmlTemplate.replace(/(\${indexer})+/g, keys[_i].oldIndex).replace(/(\${attributeSetOne})+/g, attributeSetOne).replace(/(\${attributeSetTwo})+/g, attributeSetTwo).replace(/(\${attributeSetThree})+/g, attributeSetThree).replace(/(\${attributeSetFour})+/g, attributeSetFour).replace(/(\${attributeSetFive})+/g, attributeSetFive).replace(/(\${attributeSetSix})+/g, attributeSetSix).replace(/(\${attributeSetSeven})+/g, attributeSetSeven);

              if (_i === 2 || _i === 5 || _i === 8 || _i === 9) {
                html += "</div>";
              }

            case 58:
              _i++;
              _context.next = 31;
              break;

            case 61:
              interfacePlaceholderElement = document.getElementById(_config.INTERFACE_HTML_PLACEHOLDER_ID);

              if (interfacePlaceholderElement) {
                interfacePlaceholderElement.innerHTML = html;
                clickableKeys = document.querySelectorAll(".square");

                for (_i2 = 0; _i2 < clickableKeys.length; _i2++) {
                  //clickableKeys[i].removeEventListener('click', clickKey);
                  clickableKeys[_i2].addEventListener("click", clickKey); //clickableKeys[i].removeEventListener('mousedown', keyDown);


                  clickableKeys[_i2].addEventListener("mousedown", mousedown);
                }
              }

              _context.next = 69;
              break;

            case 65:
              _context.prev = 65;
              _context.t1 = _context["catch"](0);
              _common__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(_context.t1, "b58d62d1-7ebf-4eb6-be07-32d34564eb9d");
              throw _context.t1;

            case 69:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, this, [[0, 65]]);
    }));

    function getKeypad(_x, _x2, _x3) {
      return _getKeypad.apply(this, arguments);
    }

    return getKeypad;
  }(),
  clear: function () {
    var _clear = _asyncToGenerator(
    /*#__PURE__*/
    regeneratorRuntime.mark(function _callee2() {
      return regeneratorRuntime.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              keypad.selectedKeyOrdinal = [];
              fireChangedEvent();

            case 2:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, this);
    }));

    function clear() {
      return _clear.apply(this, arguments);
    }

    return clear;
  }()
};

function fireChangedEvent() {
  if (keypad.nKodChanged) {
    try {
      keypad.nKodChanged();
    } catch (_unused) {} //swallow error

  }
}

function mousedown(e) {
  //  THE KEY CLICKS. WE DON'T LET IMPLEMENTATION HAVE ACCES TO KEY CLICK BECAUSE OF SENSITIVITY.
  e.preventDefault();
  return false;
}

function clickKey(e) {
  //  THE KEY CLICKS. WE DON'T LET IMPLEMENTATION HAVE ACCES TO KEY CLICK BECAUSE OF SENSITIVITY.
  try {
    if (keypad.selectedKeyOrdinal.length < _config.MAX_NKOD_LENGTH) {
      var indexer = e.currentTarget.dataset.indexer;
      keypad.selectedKeyOrdinal.push(indexer);
      fireChangedEvent();
    }
  } catch (ex) {
    _common__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(ex, "9cdc6284-a739-4fcc-91dd-8ba5c90e7ba5");
    throw ex;
  }
}

/* harmony default export */ __webpack_exports__["default"] = (keypad);

/***/ }),

/***/ "./src/nKode.js":
/*!**********************!*\
  !*** ./src/nKode.js ***!
  \**********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./common */ "./src/common.js");
/* harmony import */ var _darcConfig__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./darcConfig */ "./src/darcConfig.js");
/* harmony import */ var _keypad__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./keypad */ "./src/keypad.js");
/* harmony import */ var _ephemeralKeys__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ephemeralKeys */ "./src/ephemeralKeys.js");
/* harmony import */ var _clientMerge__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./clientMerge */ "./src/clientMerge.js");
/* harmony import */ var _clientTx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./clientTx */ "./src/clientTx.js");
/* harmony import */ var _clientRx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./clientRx */ "./src/clientRx.js");
/* harmony import */ var _serverTx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./serverTx */ "./src/serverTx.js");
/* harmony import */ var _serverRx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./serverRx */ "./src/serverRx.js");
/* harmony import */ var _darcCommon_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./darcCommon.js */ "./src/darcCommon.js");
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/**
 * The nKode API
 * @module nKode
 */










var ATTRIBUTE_WIDTH = 3;
var ATTRIBUTE_HEIGHT = 70;
var _keypad = _keypad__WEBPACK_IMPORTED_MODULE_2__["default"];
var _interfaceData = {};
var _createNKodData = {};
var _config = null;

function createInterface() {
  return _createInterface.apply(this, arguments);
}
/**
 * The nKode JavaScript API
 *  @public
 * */


function _createInterface() {
  _createInterface = _asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee6() {
    var userName,
        templateIdentifier,
        fingerprint,
        additionalData,
        url,
        dARCPhase1AttributeData,
        response,
        _args6 = arguments;
    return regeneratorRuntime.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            userName = _args6.length > 0 && _args6[0] !== undefined ? _args6[0] : null;
            templateIdentifier = _args6.length > 1 ? _args6[1] : undefined;
            fingerprint = _args6.length > 2 ? _args6[2] : undefined;
            additionalData = _args6.length > 3 ? _args6[3] : undefined;
            _context6.prev = 4;

            _keypad.clear();

            url = userName !== null ? "".concat(_config.API_URL, "/api/nkod/getLoginInterface") : "".concat(_config.API_URL, "/api/nkod/generateInterface");
            dARCPhase1AttributeData = getAttributeDataForTransmission(); //_interfaceData = await common.get(url, true);

            _context6.next = 10;
            return _common__WEBPACK_IMPORTED_MODULE_0__["default"].post(url, {
              "ClientId": _config.CLIENT_ID,
              "UserName": userName,
              "Fingerprint": fingerprint,
              "AttributeP1DARCData": dARCPhase1AttributeData,
              "AttributeMutualEphemeralKeys": _interfaceData.attributeMutualEphemeralKeys,
              "AdditionalData": additionalData || ""
            });

          case 10:
            response = _context6.sent;
            processReceivedData(response);
            _context6.next = 14;
            return _keypad.getKeypad(_interfaceData.attributeDarcData, _interfaceData.UserTemplateIdentifier || templateIdentifier, _interfaceData.mappedAttributeValues);

          case 14:
            _interfaceData.attributeDarcData = null;
            _interfaceData.attributeLookupValues = null;
            _context6.next = 22;
            break;

          case 18:
            _context6.prev = 18;
            _context6.t0 = _context6["catch"](4);
            _common__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(_context6.t0, "02fd32e5-9489-4f7b-a8cb-807702761a11");
            throw _context6.t0;

          case 22:
          case "end":
            return _context6.stop();
        }
      }
    }, _callee6, this, [[4, 18]]);
  }));
  return _createInterface.apply(this, arguments);
}

var nKode = {
  /**
   * Set the configuration values needed for nKode to function correctly.  This must be called before any other functions.     
   * @memberOf module:nKode#
   * @param  {Object} config An object containing the required config values
   * @param  {string} config.API_URL The base URL for the REST service containing the nKode server API calls
   * @param  {string} config.HTML_TEMPLATE_PATH The path to the templates for the various nKode interfaces.  
   * ${templateIdentifier} in the path will be replaced with the templateIdentifier value for the interface that should be loaded.
   * For ex: assets/nKodeTemplates/${templateIdentifier}.html
   * @param {string} config.CLIENT_ID The GUID identifier for the client/customer the website is for.  The GUID may be defined with or without hypens
   * @param {string} config.INTERFACE_HTML_PLACEHOLDER_ID The id of the HTML element that should contain the rendered nKode interface
   * @param {number} config.MAX_NKOD_LENGTH A number indicating the maximum nKode length that should be allowed.  Note that the system allowed limit is currently 10
   * @param {number} config.MIN_NKOD_LENGTH A number indicating the minimum nKode length that should be allowed. 
   * */
  setConfig: function setConfig(config) {
    _config = config;

    _keypad.setConfig(config);
  },

  /**
   * Removes the last value the user has entered.  Calls @see setKodChangedCallback if it has been set
   * @memberOf module:nKode#
   * */
  removeLastEntry: function removeLastEntry() {
    _keypad.removeLastEntry();
  },

  /**
   * Sets the function to be called when the entered nKode has been changed (cleared, another key selected, etc)
   * @memberOf module:nKode#
   * @param {requestCallback} callback A parameterless function to be called 
   * */
  setKodChangedCallback: function setKodChangedCallback(callback) {
    _keypad.nKodChanged = callback;
  },

  /**
   * Gets the current enterd nKode length
   * @memberOf module:nKode#
   * @returns {number} The current enterd nKode length
   * */
  currentNKodLength: function currentNKodLength() {
    return _keypad.currentNKodLength();
  },

  /**     
   * Generates the interface for a user to login
   * @memberOf module:nKode#
   * @param {string} userName The username for which the login interface should be generated for
   * @param {string} defaultTemplateIdentifier The default template identifier to be used in case the username doesn't exist
   * @param {string} fingerprint The browser fingerprint of the user.  
   * @param {any} additionalData Any additional data you wish to be sent to the server
   */
  generateLoginInterface: function () {
    var _generateLoginInterface = _asyncToGenerator(
    /*#__PURE__*/
    regeneratorRuntime.mark(function _callee(userName, defaultTemplateIdentifier, fingerprint, additionalData) {
      return regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.prev = 0;
              _createNKodData = {};
              _context.next = 4;
              return createInterface(userName, defaultTemplateIdentifier, fingerprint, additionalData);

            case 4:
              _context.next = 10;
              break;

            case 6:
              _context.prev = 6;
              _context.t0 = _context["catch"](0);
              _common__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(_context.t0, "17f65148-ca31-4dea-ac5c-e184f0ff8cef");
              throw _context.t0;

            case 10:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, this, [[0, 6]]);
    }));

    function generateLoginInterface(_x, _x2, _x3, _x4) {
      return _generateLoginInterface.apply(this, arguments);
    }

    return generateLoginInterface;
  }(),

  /**
   * Generates the interface used for the first step of creating or changing a nKode
   * @memberOf module:nKode#
   * @param {string} templateIdentifier The interface template to use
   * @param {any} additionalData Any additional data you wish to be sent to the server
   */
  // @jscrambler define selfDefending {threshold: 1, options: [tolerateMinification,tolerateBenignPoisoning]} as sd
  // @jscrambler enable sd
  generateRegisterInterface: function () {
    var _generateRegisterInterface = _asyncToGenerator(
    /*#__PURE__*/
    regeneratorRuntime.mark(function _callee2(templateIdentifier, additionalData) {
      return regeneratorRuntime.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.prev = 0;
              _createNKodData.setupNkodTemplateSelector = templateIdentifier;
              _context2.next = 4;
              return createInterface(null, templateIdentifier, null, additionalData);

            case 4:
              _context2.next = 10;
              break;

            case 6:
              _context2.prev = 6;
              _context2.t0 = _context2["catch"](0);
              _common__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(_context2.t0, "94f375a6-e07c-4813-8c34-046ddca3b2f2");
              throw _context2.t0;

            case 10:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, this, [[0, 6]]);
    }));

    function generateRegisterInterface(_x5, _x6) {
      return _generateRegisterInterface.apply(this, arguments);
    }

    return generateRegisterInterface;
  }(),

  /**
   * Sends the user's entered nKode to confirm if the user can login correctly
   * @memberOf module:nKode#
   * @param {string} username The username of the user
   * @param {any} additionalData Any additional data you wish to be sent to the server
   * @returns {any} Data from the server containing information aobut the login attempt.  This can vary depending upon the implementation
   **/
  login: function () {
    var _login = _asyncToGenerator(
    /*#__PURE__*/
    regeneratorRuntime.mark(function _callee3(username, additionalData) {
      var newKeyValues, response;
      return regeneratorRuntime.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              _context3.prev = 0;
              newKeyValues = prepareKeyInputForTransmission(_keypad.selectedKeyOrdinal);
              _context3.next = 4;
              return _common__WEBPACK_IMPORTED_MODULE_0__["default"].post(_config.API_URL + "/api/nkod/", {
                "ClientId": _config.CLIENT_ID,
                "SessionId": _interfaceData.SessionId,
                "UserName": username,
                "Keys": newKeyValues,
                "AdditionalData": additionalData || ""
              });

            case 4:
              response = _context3.sent;
              return _context3.abrupt("return", response);

            case 8:
              _context3.prev = 8;
              _context3.t0 = _context3["catch"](0);
              _common__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(_context3.t0, "1a25e365-60e1-4c41-8c6f-868a63808bb3");
              throw _context3.t0;

            case 12:
              _context3.prev = 12;
              final();
              return _context3.finish(12);

            case 15:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3, this, [[0, 8, 12, 15]]);
    }));

    function login(_x7, _x8) {
      return _login.apply(this, arguments);
    }

    return login;
  }(),

  /**
   * Sets the user's nKode for the first step in creating/changing a nKode. Performs a special shuffle on the interface for the user to confirm the entered nKode in the second step.
   * @memberOf module:nKode#
   * @param {string} username The username of the user
   * @param {any} additionalData Any additional data you wish to be sent to the server
   * @returns {any} The response data if the user exists, true otherwise
   * */
  createNKodeStep1: function () {
    var _createNKodeStep = _asyncToGenerator(
    /*#__PURE__*/
    regeneratorRuntime.mark(function _callee4(username, additionalData) {
      var dARCPhase1AttributeData, newKeyValues, response;
      return regeneratorRuntime.wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              _context4.prev = 0;
              _createNKodData.firstNKodLength = _keypad.selectedKeyOrdinal.length;
              _common__WEBPACK_IMPORTED_MODULE_0__["default"].checkForValue(_keypad.selectedKeyOrdinal, 'Selected key ordinal');
              _common__WEBPACK_IMPORTED_MODULE_0__["default"].checkForValue(_keypad.userName, 'Username');
              dARCPhase1AttributeData = getAttributeDataForTransmission();
              newKeyValues = prepareKeyInputForTransmission(_keypad.selectedKeyOrdinal);
              _common__WEBPACK_IMPORTED_MODULE_0__["default"].checkForValue(newKeyValues, 'New key values');
              _context4.next = 9;
              return _common__WEBPACK_IMPORTED_MODULE_0__["default"].post("".concat(_config.API_URL, "/api/nkod/set"), {
                "ClientId": _config.CLIENT_ID,
                "SessionId": _interfaceData.SessionId,
                "UserName": username,
                "Keys": newKeyValues,
                "AttributeP1DARCData": dARCPhase1AttributeData,
                "AttributeMutualEphemeralKeys": _interfaceData.attributeMutualEphemeralKeys,
                "AdditionalData": additionalData || ""
              });

            case 9:
              response = _context4.sent;

              if (!response.userExists) {
                _context4.next = 12;
                break;
              }

              return _context4.abrupt("return", response);

            case 12:
              _keypad.clear();

              processReceivedData(response);
              _context4.next = 16;
              return _keypad.getKeypad(_interfaceData.attributeDarcData, _createNKodData.setupNkodTemplateSelector, _interfaceData.mappedAttributeValues);

            case 16:
              _interfaceData.attributeDarcData = null;
              return _context4.abrupt("return", true);

            case 20:
              _context4.prev = 20;
              _context4.t0 = _context4["catch"](0);
              _common__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(_context4.t0, "041b17bb-ccfe-4463-a606-402d04124257");
              throw _context4.t0;

            case 24:
            case "end":
              return _context4.stop();
          }
        }
      }, _callee4, this, [[0, 20]]);
    }));

    function createNKodeStep1(_x9, _x10) {
      return _createNKodeStep.apply(this, arguments);
    }

    return createNKodeStep1;
  }(),

  /**
   * The second (confirmation) step of creating/changing a user's nKode.
   * @memberOf module:nKode#
   * @param {string} username The username of the user
   * @param {string} fingerprint The browser fingerprint of the user.
   * @param {string} templateIdentifier The identifier for the nKode interface the user has selected
   * @param {any} additionalData Any additional data you wish to be sent to the server
   * @returns {any} An object containing the result of attempting to create/change a user's nKode.  This can vary depending upon the implementation.
   * */
  createNKodeStep2: function () {
    var _createNKodeStep2 = _asyncToGenerator(
    /*#__PURE__*/
    regeneratorRuntime.mark(function _callee5(username, fingerprint, templateIdentifier, additionalData) {
      var newKeyValues, result;
      return regeneratorRuntime.wrap(function _callee5$(_context5) {
        while (1) {
          switch (_context5.prev = _context5.next) {
            case 0:
              _context5.prev = 0;

              if (!(_createNKodData.firstNKodLength !== _keypad.selectedKeyOrdinal.length)) {
                _context5.next = 3;
                break;
              }

              return _context5.abrupt("return", {
                NKodLengthUnequal: true
              });

            case 3:
              newKeyValues = prepareKeyInputForTransmission(_keypad.selectedKeyOrdinal);
              _context5.next = 6;
              return _common__WEBPACK_IMPORTED_MODULE_0__["default"].post("".concat(_config.API_URL, "/api/nkod/confirm"), {
                "ClientId": _config.CLIENT_ID,
                "SessionId": _interfaceData.SessionId,
                "UserName": username,
                "Keys": newKeyValues,
                "Fingerprint": fingerprint,
                "TemplateIdentifier": templateIdentifier,
                "AdditionalData": additionalData || ""
              });

            case 6:
              result = _context5.sent;
              return _context5.abrupt("return", result);

            case 10:
              _context5.prev = 10;
              _context5.t0 = _context5["catch"](0);
              _common__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(_context5.t0, "6f6c648d-363b-4a52-81a4-e7d50380d9f8");
              throw _context5.t0;

            case 14:
              _context5.prev = 14;
              final();
              return _context5.finish(14);

            case 17:
            case "end":
              return _context5.stop();
          }
        }
      }, _callee5, this, [[0, 10, 14, 17]]);
    }));

    function createNKodeStep2(_x11, _x12, _x13, _x14) {
      return _createNKodeStep2.apply(this, arguments);
    }

    return createNKodeStep2;
  }(),

  /**
   * Gets the attribute sets and values used for the client
   * @memberOf module:nKode#
   * @returns {Array.<Array.<number>>} A 2 dimensional array containing attribute sets and values.  The first dimension is the attribute set and the second dimension
   * is the attribute values used for that attribute set.
   * */
  getClientAttributeSetsAndValues: function getClientAttributeSetsAndValues() {
    return _darcCommon_js__WEBPACK_IMPORTED_MODULE_9__["default"].structureFlattenedTwoDimensionalArray(7, 10, _darcConfig__WEBPACK_IMPORTED_MODULE_1__["default"].ATTRIBUTE_VALUES);
  },

  /**
   * Clears any input values.  Calls @see nKode.setKodChangedCallback if it has been set
   * @memberOf module:nKode#
   * */
  clear: function clear() {
    _keypad.clear();
  }
};

function final() {
  //  RESET THE BROWSER MEMORY TO WIPE ALL VALUES       
  _keypad.clear();

  _interfaceData = {};
  _createNKodData = {};
}

function getAttributeDataForTransmission() {
  try {
    var numberOfAttributeValues = _darcConfig__WEBPACK_IMPORTED_MODULE_1__["default"].ATTRIBUTE_VALUES.length;
    _interfaceData.serverEphemeralKeys = _ephemeralKeys__WEBPACK_IMPORTED_MODULE_3__["default"].generateServerInstanceTranslations(ATTRIBUTE_WIDTH, ATTRIBUTE_HEIGHT, ATTRIBUTE_HEIGHT);
    _interfaceData.attributeMutualEphemeralKeys = _ephemeralKeys__WEBPACK_IMPORTED_MODULE_3__["default"].generateSharedInstanceTranslations(ATTRIBUTE_WIDTH, ATTRIBUTE_HEIGHT, ATTRIBUTE_HEIGHT);
    _interfaceData.serverEphemeralKeys = Object.assign(_interfaceData.serverEphemeralKeys, _interfaceData.attributeMutualEphemeralKeys);
    var attributeLookupValues = _darcCommon_js__WEBPACK_IMPORTED_MODULE_9__["default"].randUniqueInt(numberOfAttributeValues, 0, 256); //Generate random values to send to server

    _interfaceData.mappedAttributeValues = {};
    _interfaceData.attributeAlphabet = new Array();

    for (var x = 0; x < numberOfAttributeValues; x++) {
      //Add additional random values to values
      _interfaceData.attributeAlphabet.push([attributeLookupValues[x]].concat(_darcCommon_js__WEBPACK_IMPORTED_MODULE_9__["default"].randUniqueInt(ATTRIBUTE_WIDTH - 1, 0, 256)));

      _interfaceData.mappedAttributeValues[attributeLookupValues[x].toString()] = _darcConfig__WEBPACK_IMPORTED_MODULE_1__["default"].ATTRIBUTE_VALUES[x]; //Build lookup
    }

    var dARCPhase1 = _serverTx__WEBPACK_IMPORTED_MODULE_7__["default"].transmit(_darcConfig__WEBPACK_IMPORTED_MODULE_1__["default"].SERVER_DARC_ATTRIBUTE_KEYS, _interfaceData.serverEphemeralKeys, _interfaceData.attributeAlphabet);
    return dARCPhase1;
  } catch (ex) {
    _common__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(ex, "d9f7a441-ddce-4456-bd38-78f18f1eb66d");
    throw ex;
  }
}

function prepareKeyInputForTransmission(inputSequence) {
  try {
    var dARCPhase3 = _clientTx__WEBPACK_IMPORTED_MODULE_5__["default"].transmit(_darcConfig__WEBPACK_IMPORTED_MODULE_1__["default"].CLIENT_KEYS, _interfaceData.clientEphemeralKeys, _interfaceData.KeypadDarcData);
    var dARCMessage = _clientMerge__WEBPACK_IMPORTED_MODULE_4__["default"].mergeMessage(_darcConfig__WEBPACK_IMPORTED_MODULE_1__["default"].CLIENT_KEYS, _interfaceData.clientEphemeralKeys, dARCPhase3, inputSequence);
    return dARCMessage;
  } catch (ex) {
    _common__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(ex, "2de6f376-07f3-4344-be3b-1a5ff5488531");
    throw ex;
  }
}

function processReceivedData(response) {
  try {
    _interfaceData = Object.assign(_interfaceData, response); //Merge response with existing data

    _interfaceData.clientEphemeralKeys = _ephemeralKeys__WEBPACK_IMPORTED_MODULE_3__["default"].generateClientInstanceTranslations(7, 10, 10);
    _interfaceData.clientEphemeralKeys = Object.assign(_interfaceData.clientEphemeralKeys, _interfaceData.KeypadMutualEphemeralKeys); //Merge mutual keys into generated client only keys

    _interfaceData.keypadDarcData = _clientRx__WEBPACK_IMPORTED_MODULE_6__["default"].receive(_darcConfig__WEBPACK_IMPORTED_MODULE_1__["default"].CLIENT_KEYS, _interfaceData.clientEphemeralKeys, response.KeypadDarcData); //Transform DARC phase 1 data into phase 2

    var attributeData = _serverRx__WEBPACK_IMPORTED_MODULE_8__["default"].translate(_darcConfig__WEBPACK_IMPORTED_MODULE_1__["default"].SERVER_DARC_ATTRIBUTE_KEYS, _interfaceData.serverEphemeralKeys, response.AttributeDarcData, _interfaceData.attributeAlphabet); //Get just first position of data

    attributeData = attributeData.map(function (value) {
      return value[0];
    });
    _interfaceData.attributeDarcData = _darcCommon_js__WEBPACK_IMPORTED_MODULE_9__["default"].structureFlattenedTwoDimensionalArray(10, 7, attributeData);
  } catch (ex) {
    _common__WEBPACK_IMPORTED_MODULE_0__["default"].addNKodeMethodIdentifierStackInfo(ex, "6fec73da-2a96-4178-bedf-2bf6394cba3f");
    throw ex;
  }
}

/* harmony default export */ __webpack_exports__["default"] = (nKode);

/***/ }),

/***/ "./src/serverRx.js":
/*!*************************!*\
  !*** ./src/serverRx.js ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _transform_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transform.js */ "./src/transform.js");
/* harmony import */ var _darcCommon_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./darcCommon.js */ "./src/darcCommon.js");
/* harmony import */ var _common_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./common.js */ "./src/common.js");



var serverRx = {
  //1) Key Preparations; 2) Outer Medium Permutations 3) Medium Substitutions; 4) Outer/Inner Message Permutations;
  translate: function translate(persistentKeys, ephemeralKeys, rxData, alphabet) {
    try {
      var outerPositionFunctionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterPositionFunctionMediumKey, ephemeralKeys.OuterPositionFunctionMediumEphemeralKey);
      var outerPositionShuffleEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterPositionShuffleMediumKey, ephemeralKeys.OuterPositionShuffleMediumEphemeralKey);
      outerPositionFunctionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].transformationCompliment(_transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(outerPositionShuffleEphemeralKeyApplied, outerPositionFunctionEphemeralKeyApplied));
      outerPositionShuffleEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].transformationCompliment(outerPositionShuffleEphemeralKeyApplied);
      var outerPositionShuffleFunctionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterPositionShuffleFunctionMediumKey, ephemeralKeys.OuterPositionShuffleFunctionMediumEphemeralKey);
      outerPositionShuffleFunctionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(outerPositionShuffleFunctionEphemeralKeyApplied, outerPositionFunctionEphemeralKeyApplied);
      var outerFunctionFunctionMediumEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionFunctionMediumKey, ephemeralKeys.OuterFunctionFunctionMediumEphemeralKey);
      var outerServerShuffleFunctionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterServerShuffleFunctionKey, ephemeralKeys.OuterServerShuffleFunctionEphemeralKey);
      var outerServerShuffleFunctionMediumEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterServerShuffleFunctionMediumKey, ephemeralKeys.OuterServerShuffleFunctionMediumEphemeralKey);
      var functionMediumEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.FunctionMediumKey, ephemeralKeys.FunctionMediumEphemeralKey); //Customer-Specific Translation Function defining how translation is applied to data; Insulates Customers from one another; Imbedded in Obfuscated Java Script (Widget)

      var clientShuffleMediumKeyX = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(persistentKeys.ClientShuffleMediumKeyX, outerServerShuffleFunctionMediumEphemeralKeyApplied);
      clientShuffleMediumKeyX = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteFunctionOperand(outerFunctionFunctionMediumEphemeralKeyApplied, functionMediumEphemeralKeyApplied, clientShuffleMediumKeyX);
      var positionShuffleEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.PositionShuffleMediumKey, ephemeralKeys.PositionShuffleMediumEphemeralKey);
      positionShuffleEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(positionShuffleEphemeralKeyApplied, outerPositionShuffleFunctionEphemeralKeyApplied);
      clientShuffleMediumKeyX = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(clientShuffleMediumKeyX, positionShuffleEphemeralKeyApplied);
      var clientShuffleKeyX = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(persistentKeys.ClientShuffleKeyX, outerServerShuffleFunctionEphemeralKeyApplied);
      var outerFunctionFunctionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionFunctionKey, ephemeralKeys.OuterFunctionFunctionEphemeralKey);
      var outerFunctionMediumEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionMediumKey, ephemeralKeys.OuterFunctionMediumEphemeralKey);
      rxData = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(rxData, outerPositionShuffleEphemeralKeyApplied);
      var identityOuterFunction = _darcCommon_js__WEBPACK_IMPORTED_MODULE_1__["default"].initializeNewArray(persistentKeys.OuterFunctionFunctionKey[0].length, persistentKeys.OuterFunctionFunctionKey.length);
      rxData = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].substituteFunctionOperands(identityOuterFunction, clientShuffleMediumKeyX, outerFunctionMediumEphemeralKeyApplied, rxData, persistentKeys.ServerMediumKey, ephemeralKeys.ServerMediumEphemeralKey, persistentKeys.MutualMediumKey, ephemeralKeys.MutualMediumEphemeralKey);
      var positionFunctionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].transformationCompliment(_transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.PositionFunctionMediumKey, ephemeralKeys.PositionFunctionMediumEphemeralKey));
      rxData = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(rxData, _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(_transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].transformationCompliment(positionShuffleEphemeralKeyApplied), _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(positionFunctionEphemeralKeyApplied, outerPositionFunctionEphemeralKeyApplied)));
      var functionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.FunctionKey, ephemeralKeys.FunctionEphemeralKey); //Customer-Specific Translation Function defining how translation is applied to data; Insulates Customers from one another; Imbedded in Obfuscated Java Script (Widget)

      functionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteFunctionOperand(outerFunctionFunctionEphemeralKeyApplied, functionEphemeralKeyApplied, clientShuffleKeyX);
      var serverShuffleEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(_transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].transformationCompliment(_transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.ServerShuffleKey, persistentKeys.ClientShuffleKeyX)), _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].transformationCompliment(ephemeralKeys.ServerShuffleEphemeralKey));
      serverShuffleEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].transformationCompliment(_transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(serverShuffleEphemeralKeyApplied, outerServerShuffleFunctionEphemeralKeyApplied));
      var outerServerShuffleEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterServerShuffleKey, ephemeralKeys.OuterServerShuffleEphemeralKey);
      var alphaPrep = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(_transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(alphabet, outerServerShuffleEphemeralKeyApplied), serverShuffleEphemeralKeyApplied);
      var outerFunctionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionKey, ephemeralKeys.OuterFunctionEphemeralKey);
      alphaPrep = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].substituteFunctionOperands(identityOuterFunction, functionEphemeralKeyApplied, outerFunctionEphemeralKeyApplied, alphaPrep, persistentKeys.ServerKey, ephemeralKeys.ServerEphemeralKey, persistentKeys.MutualKey, ephemeralKeys.MutualEphemeralKey);
      var serverData = serverRx.resolveRxData(rxData, alphaPrep, alphabet); //Revert Rx data back into original Attribute Values 
      //#if CLIENT_TOKEN
      //                                , TokenKey.Data
      //#endif
      //                                )
      //            }; //Revert Rx data back into original Attribute Values 

      return serverData;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_2__["default"].addNKodeMethodIdentifierStackInfo(ex, "802d9cb7-969a-4a97-9d33-1b87b60c7059");
      throw ex;
    }
  },
  resolveRxData: function resolveRxData(rxData, alphaPrep, alphabet) {
    try {
      var result = new Array();

      for (var x = 0; x < rxData.length; x++) {
        var findArray = rxData[x];
        var match = false;

        for (var a = 0; a < alphaPrep.length; a++) {
          //if (ArcanumCommon.Common.GetString(alphaPrep[a].ToArray(), ",") == ArcanumCommon.Common.GetString(findArray, ","))
          if (_darcCommon_js__WEBPACK_IMPORTED_MODULE_1__["default"].arrayElementsMatch(alphaPrep[a], findArray)) {
            match = true;
            result.push(alphabet[a]);
            break;
          }
        }

        if (!match) //    return null;  //Failure at any point is a complete failure; Do not continue, as it will only provide insight for hackers to determine which keys might match, return null.
          //    FailMatch = true;  //Added because, if some inputs do not match, it will skip them and continue, then give a false positive if the correct inputs appear in sequence later in the stream.
          break;
      }

      return result;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_2__["default"].addNKodeMethodIdentifierStackInfo(ex, "82d41f5c-5507-454f-b46d-80260f849e78");
      throw ex;
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (serverRx);

/***/ }),

/***/ "./src/serverTx.js":
/*!*************************!*\
  !*** ./src/serverTx.js ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _transform_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transform.js */ "./src/transform.js");
/* harmony import */ var _darcCommon_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./darcCommon.js */ "./src/darcCommon.js");
/* harmony import */ var _common_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./common.js */ "./src/common.js");



var serverTx = {
  transmit: function transmit(persistentKeys, ephemeralKeys, alphabet) {
    try {
      var darcData = {};
      darcData.AlphabetData = translateData(persistentKeys, ephemeralKeys, alphabet, false);
      darcData.MediumData = translateMedium(persistentKeys, ephemeralKeys, false);
      return darcData;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_2__["default"].addNKodeMethodIdentifierStackInfo(ex, "66bc6254-f85c-447d-be16-c92f4d7bd3b3");
      throw ex;
    }
  }
};

function translateMedium(persistentKeys, ephemeralKeys) {
  try {
    var functionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.FunctionMediumKey, ephemeralKeys.FunctionMediumEphemeralKey); //Customer-Specific Translation Function defining how translation is applied to data; Insulates Customers from one another; Imbedded in Obfuscated Java Script (Widget)

    var inputData = _darcCommon_js__WEBPACK_IMPORTED_MODULE_1__["default"].initializeNewArray(persistentKeys.FunctionMediumKey[0].length, persistentKeys.FunctionMediumKey.length, 0);
    var outerFunctionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionMediumKey, ephemeralKeys.OuterFunctionMediumEphemeralKey); //Customer-Specific Translation Function defining how translation is applied to data; Insulates Customers from one another; Imbedded in Obfuscated Java Script (Widget)

    var outerFunctionFunctionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionFunctionMediumKey, ephemeralKeys.OuterFunctionFunctionMediumEphemeralKey); //Customer-Specific Translation Function defining how translation is applied to data; Insulates Customers from one another; Imbedded in Obfuscated Java Script (Widget)

    var txMedium = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].substituteFunctionOperands(outerFunctionFunctionEphemeralKeyApplied, functionEphemeralKeyApplied, outerFunctionEphemeralKeyApplied, inputData, persistentKeys.ServerMediumKey, ephemeralKeys.ServerMediumEphemeralKey); //Build data for Tx       

    return txMedium;
  } catch (ex) {
    _common_js__WEBPACK_IMPORTED_MODULE_2__["default"].addNKodeMethodIdentifierStackInfo(ex, "42728833-f381-426c-bab8-57aecb5da579");
    throw ex;
  }
} //1) Key Preparations; 2) Outer Permutations; 3) Inner Permutations; 4) Substitutions


function translateData(persistentKeys, ephemeralKeys, alphabet) {
  try {
    var functionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.FunctionKey, ephemeralKeys.FunctionEphemeralKey); //Customer-Specific Translation Function defining how translation is applied to data; Insulates Customers from one another; Imbedded in Obfuscated Java Script (Widget)

    var outerFunctionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionKey, ephemeralKeys.OuterFunctionEphemeralKey); //Customer-Specific Translation Function defining how translation is applied to data; Insulates Customers from one another; Imbedded in Obfuscated Java Script (Widget)

    var outerFunctionFunctionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterFunctionFunctionKey, ephemeralKeys.OuterFunctionFunctionEphemeralKey); //Customer-Specific Translation Function defining how translation is applied to data; Insulates Customers from one another; Imbedded in Obfuscated Java Script (Widget)

    var outerServerShuffleEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterServerShuffleKey, ephemeralKeys.OuterServerShuffleEphemeralKey);
    var outerServerShuffleFunctionEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(persistentKeys.OuterServerShuffleFunctionKey, ephemeralKeys.OuterServerShuffleFunctionEphemeralKey); //Customer-Specific Translation Function defining how translation is applied to data; Insulates Customers from one another; Imbedded in Obfuscated Java Script (Widget)
    //#if CLIENT_TOKEN
    //            //In Client
    //            //DataTranslation TokenKey = ((DataTranslationClientToken)interActor.GetActor(DataTranslationIndex.Translation.ClientTranslation)).TokenKey;
    //           DataTranslation TokenKey = Client.TokenKey;
    //#endif

    var inputData = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(alphabet, outerServerShuffleEphemeralKeyApplied);
    var serverShuffleEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(ephemeralKeys.ServerShuffleEphemeralKey, persistentKeys.ServerShuffleKey);
    serverShuffleEphemeralKeyApplied = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteOuterTransformation(serverShuffleEphemeralKeyApplied, outerServerShuffleFunctionEphemeralKeyApplied);
    inputData = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].permuteInnerTransformation(inputData, serverShuffleEphemeralKeyApplied);
    var txAlphabet = _transform_js__WEBPACK_IMPORTED_MODULE_0__["default"].substituteFunctionOperands(outerFunctionFunctionEphemeralKeyApplied, functionEphemeralKeyApplied, outerFunctionEphemeralKeyApplied, inputData, persistentKeys.ServerKey, ephemeralKeys.ServerEphemeralKey //    #if CLIENT_TOKEN
    //        //_TODO-8: Rename to ClientTranslation
    //        , TokenKey.Data
    //#endif
    ); //Build data for Tx      

    return txAlphabet;
  } catch (ex) {
    _common_js__WEBPACK_IMPORTED_MODULE_2__["default"].addNKodeMethodIdentifierStackInfo(ex, "966954a6-794e-46d1-8816-a072922c00cf");
    throw ex;
  }
}

/* harmony default export */ __webpack_exports__["default"] = (serverTx);

/***/ }),

/***/ "./src/transform.js":
/*!**************************!*\
  !*** ./src/transform.js ***!
  \**************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./darcCommon.js */ "./src/darcCommon.js");
/* harmony import */ var _common_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./common.js */ "./src/common.js");


var transform = {
  permute: function permute(operand, map) {
    try {
      if (!operand) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operand is null or empty", "7613a59a-6b58-4478-95dd-483dcddff79e");
      if (!map) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("map is null or empty", "7613a59a-6b58-4478-95dd-483dcddff79e");
      if (operand.length !== map.length) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("Arguments are not equal in length", "7613a59a-6b58-4478-95dd-483dcddff79e");
      var result = new Array(operand.length);

      for (var x = 0; x < map.length; x++) {
        result[x] = operand[map[x]];
      }

      return result;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "7613a59a-6b58-4478-95dd-483dcddff79e");
      throw ex;
    }
  },
  //operand and map should both be two dimensional arrays here
  permuteInnerTransformation: function permuteInnerTransformation(operand, map) {
    try {
      if (!operand) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operand is null or empty", "22590837-0dbf-4d5e-9a2f-82fd8aaad311");
      if (!map) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("map is null or empty", "22590837-0dbf-4d5e-9a2f-82fd8aaad311"); //NOTE: length corresponds to height property in C# class

      if (operand.length !== map.length || _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(operand) !== _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(map)
      /*|| !operand.ValidData || !map.ValidData*/
      ) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("Arguments are not equal in length", "22590837-0dbf-4d5e-9a2f-82fd8aaad311");
      var result = new Array();

      for (var x = 0; x < map.length; x++) {
        result.push(transform.permute(operand[x], map[x]));
      }

      return result;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "22590837-0dbf-4d5e-9a2f-82fd8aaad311");
      throw ex;
    }
  },
  permuteOuterTransformation: function permuteOuterTransformation(operand, map) {
    try {
      if (!operand) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operand is null or empty", "2f61d7e9-8bb2-41c5-8225-cee6527e58d1");
      if (!map) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("map is null or empty", "2f61d7e9-8bb2-41c5-8225-cee6527e58d1"); //NOTE: length corresponds to height property in C# class

      if (_darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(map) !== operand.length
      /*|| !operand.ValidData || !map.ValidData*/
      ) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("Arguments are not equal in length", "2f61d7e9-8bb2-41c5-8225-cee6527e58d1");
      var result = transform.permute(operand, _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].flattenTwoDimArray(map));
      return result;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "2f61d7e9-8bb2-41c5-8225-cee6527e58d1");
      throw ex;
    }
  },
  permuteFunctionMap: function permuteFunctionMap(outerPermutationFunction, operand, map) {
    try {
      if (!outerPermutationFunction) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("outerPermutationFunction is null or empty", "2ed02e67-f741-45b2-9c58-2f29d5b72b02");
      if (!operand) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operand is null or empty", "2ed02e67-f741-45b2-9c58-2f29d5b72b02");
      if (!map) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("map is null or empty", "2ed02e67-f741-45b2-9c58-2f29d5b72b02");
      if (_darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(outerPermutationFunction) !== map.length || operand.length !== map.length || _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(operand) != _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(map)
      /*|| !outerPermutationFunction.ValidData || !operand.ValidData || !map.ValidData*/
      ) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("Arguments are not equal in length", "2ed02e67-f741-45b2-9c58-2f29d5b72b02");
      var outerShufFunc = _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].flattenTwoDimArray(outerPermutationFunction);
      var result = new Array();

      for (var x = 0; x < map.length; x++) {
        result.push(transform.permute(operand[x], map[outerShufFunc[x]]));
      }

      return result;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "2ed02e67-f741-45b2-9c58-2f29d5b72b02");
      throw ex;
    }
  },
  permuteFunctionOperand: function permuteFunctionOperand(outerPermutationFunction, operand, map) {
    try {
      if (!outerPermutationFunction) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("outerPermutationFunction is null or empty", "410cfb93-cd19-4ef4-b227-f358baee4a95");
      if (!operand) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operand is null or empty", "410cfb93-cd19-4ef4-b227-f358baee4a95");
      if (!map) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("map is null or empty", "410cfb93-cd19-4ef4-b227-f358baee4a95");
      if (_darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(outerPermutationFunction) !== map.length || operand.length !== map.length || _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(operand) != _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(map)
      /*|| !outerPermutationFunction.ValidData || !operand.ValidData || !map.ValidData*/
      ) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("Arguments are not equal in length", "410cfb93-cd19-4ef4-b227-f358baee4a95");
      var outerShufFunc = _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].flattenTwoDimArray(outerPermutationFunction);
      var result = new Array();

      for (var x = 0; x < map.length; x++) {
        result.push(transform.permute(operand[outerShufFunc[x]], map[x]));
      }

      return result;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "410cfb93-cd19-4ef4-b227-f358baee4a95");
      throw ex;
    }
  },
  transformationCompliment: function transformationCompliment(map) {
    try {
      if (!map) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("map is null or empty", "6ee77563-0e9c-4e05-a5d1-a40b175b31b9");

      if (Array.isArray(map[0])) {
        var result = new Array();

        for (var h = 0; h < map.length; h++) {
          result.push(transform.transformationCompliment(map[h]));
        }

        return result;
      } else {
        var _result = new Array(map.length);

        for (var x = 0; x < map.length; x++) {
          _result[map[x]] = x;
        }

        return _result;
      }
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "6ee77563-0e9c-4e05-a5d1-a40b175b31b9");
      throw ex;
    }
  },
  substitute: function substitute(operand_A, operand_B) {
    try {
      if (!operand_A) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operand_A is null or empty", "d29b2851-5b6a-4260-b4a2-910ee957d16e");
      if (!operand_B) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operand_B is null or empty", "d29b2851-5b6a-4260-b4a2-910ee957d16e");
      if (operandADarcKeyLength !== _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(operand_B)) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("Arguments are not equal in length", "d29b2851-5b6a-4260-b4a2-910ee957d16e");
      var operandADarcKeyLength = _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(operand_A);
      var result = new Array(operandADarcKeyLength);

      for (var x = 0; x < operandADarcKeyLength; x++) {
        result[x] = operand_A[x] ^ operand_B[x];
      }

      return result;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "d29b2851-5b6a-4260-b4a2-910ee957d16e");
      throw ex;
    }
  },
  substituteOperands: function substituteOperands(operand) {
    for (var _len = arguments.length, operands = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      operands[_key - 1] = arguments[_key];
    }

    try {
      if (!operand) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operand is null or empty", "7f759a15-5569-40c8-963b-dc29547cd635");
      if (!operands) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operands is null or empty", "7f759a15-5569-40c8-963b-dc29547cd635");

      for (var x = 0; x < operands.length; x++) {
        operand = substituteOperand(operand, operands[x]);
      }

      return operand;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "7f759a15-5569-40c8-963b-dc29547cd635");
      throw ex;
    }
  },
  substituteOperand: function substituteOperand(operand_A, operand_B) {
    try {
      if (!operand_A) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operand_A is null or empty", "da40df80-e895-4750-9bc5-8d1ea13b0cf8");
      if (!operand_B) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operand_B is null or empty", "da40df80-e895-4750-9bc5-8d1ea13b0cf8");
      var result = new Array();
      if (operand_A.length !== operand_B.length || _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(operand_A) !== _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(operand_B)
      /*|| !operand_A.ValidData || !operand_B.ValidData*/
      ) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("Arguments are not equal in length", "da40df80-e895-4750-9bc5-8d1ea13b0cf8");

      for (var x = 0; x < operand_A.length; x++) {
        result.Values.Add(substitute(operand_A[x], operand_B[x]));
      }

      return result;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "da40df80-e895-4750-9bc5-8d1ea13b0cf8");
      throw ex;
    }
  },
  substituteFunction: function substituteFunction(functionKeys, operand_A, operand_B) {
    try {
      if (!functionKeys) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("functionKeys is null or empty", "0f857e2d-e750-4da5-9fef-11ccf47d229c");
      if (!operand_A) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operand_A is null or empty", "0f857e2d-e750-4da5-9fef-11ccf47d229c");
      if (!operand_B) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operand_B is null or empty", "0f857e2d-e750-4da5-9fef-11ccf47d229c");
      var operandADarcKeyLength = _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(operand_A);
      var result = new Array(operandADarcKeyLength);
      if (operandADarcKeyLength !== _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(functionKeys) || _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(operand_B) !== _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(functionKeys)) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("Arguments are not equal in length", "0f857e2d-e750-4da5-9fef-11ccf47d229c");

      for (var x = 0; x < operandADarcKeyLength; x++) {
        var newVal = operand_A[x] ^ operand_B[functionKeys[x]];
        result[x] = newVal;
      }

      return result;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "0f857e2d-e750-4da5-9fef-11ccf47d229c");
      throw ex;
    }
  },
  substituteFunctionOperands: function substituteFunctionOperands(outerFunctionFunction, innerFunction, outerFunction, operand) {
    for (var _len2 = arguments.length, operands = new Array(_len2 > 4 ? _len2 - 4 : 0), _key2 = 4; _key2 < _len2; _key2++) {
      operands[_key2 - 4] = arguments[_key2];
    }

    try {
      if (!outerFunctionFunction) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("outerFunctionFunction is null or empty", "9f8d0522-3ed5-4d71-a1c4-35ba36334335");
      if (!innerFunction) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("innerFunction is null or empty", "9f8d0522-3ed5-4d71-a1c4-35ba36334335");
      if (!outerFunction) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("outerFunction is null or empty", "9f8d0522-3ed5-4d71-a1c4-35ba36334335");
      if (!operand) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operand is null or empty", "9f8d0522-3ed5-4d71-a1c4-35ba36334335");
      if (!operands) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operands is null or empty", "9f8d0522-3ed5-4d71-a1c4-35ba36334335");
      if (_darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(outerFunctionFunction) !== innerFunction.length || _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(outerFunction) !== operand.length
      /*|| !outerFunctionFunction.ValidData || !outerFunction.ValidData*/
      ) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("Arguments are not equal in length", "9f8d0522-3ed5-4d71-a1c4-35ba36334335");
      var outerFuncFunc = _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].flattenTwoDimArray(outerFunctionFunction);
      var outerFunc = _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].flattenTwoDimArray(outerFunction);

      for (var x = 0; x < operands.length; x++) {
        operand = transform.substituteFunctionOperand(outerFuncFunc, innerFunction, outerFunc, operand, operands[x]);
      }

      return operand;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "9f8d0522-3ed5-4d71-a1c4-35ba36334335");
      throw ex;
    }
  },
  substituteFunctionOperand: function substituteFunctionOperand(outerFunctionFunction, innerFunction, outerFunction, operand_A, operand_B) {
    try {
      if (!outerFunctionFunction) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("outerFunctionFunction is null or empty", "a919163c-c5e2-4b97-9fc3-673b93315ecc");
      if (!innerFunction) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("innerFunction is null or empty", "a919163c-c5e2-4b97-9fc3-673b93315ecc");
      if (!outerFunction) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("outerFunction is null or empty", "a919163c-c5e2-4b97-9fc3-673b93315ecc");
      if (!operand_A) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operand_A is null or empty", "a919163c-c5e2-4b97-9fc3-673b93315ecc");
      if (!operand_B) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("operand_B is null or empty", "a919163c-c5e2-4b97-9fc3-673b93315ecc");
      var result = new Array();
      if (operand_A.length !== innerFunction.length || operand_B.length !== innerFunction.length || _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(operand_A) !== _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(innerFunction) || _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(operand_B) !== _darcCommon_js__WEBPACK_IMPORTED_MODULE_0__["default"].getDarcKeyLength(innerFunction)
      /*|| !operand_A.ValidData || !operand_B.ValidData || !innerFunction.ValidData*/
      ) throw _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].createErrorWithNkodeMethodIdentifier("Arguments are not equal in length", "a919163c-c5e2-4b97-9fc3-673b93315ecc");

      for (var x = 0; x < operand_A.length; x++) {
        result.push(transform.substituteFunction(innerFunction[outerFunctionFunction[x]], operand_A[x], operand_B[outerFunction[x]]));
      }

      return result;
    } catch (ex) {
      _common_js__WEBPACK_IMPORTED_MODULE_1__["default"].addNKodeMethodIdentifierStackInfo(ex, "a919163c-c5e2-4b97-9fc3-673b93315ecc");
      throw ex;
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (transform);

/***/ })

/******/ })["default"];
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uS29kZS93ZWJwYWNrL3VuaXZlcnNhbE1vZHVsZURlZmluaXRpb24iLCJ3ZWJwYWNrOi8vbktvZGUvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vbktvZGUvLi9zcmMvY2xpZW50TWVyZ2UuanMiLCJ3ZWJwYWNrOi8vbktvZGUvLi9zcmMvY2xpZW50UnguanMiLCJ3ZWJwYWNrOi8vbktvZGUvLi9zcmMvY2xpZW50VHguanMiLCJ3ZWJwYWNrOi8vbktvZGUvLi9zcmMvY29tbW9uLmpzIiwid2VicGFjazovL25Lb2RlLy4vc3JjL2RhcmNDb21tb24uanMiLCJ3ZWJwYWNrOi8vbktvZGUvLi9zcmMvZGFyY0NvbmZpZy5qcyIsIndlYnBhY2s6Ly9uS29kZS8uL3NyYy9lcGhlbWVyYWxLZXlzLmpzIiwid2VicGFjazovL25Lb2RlLy4vc3JjL2tleXBhZC5qcyIsIndlYnBhY2s6Ly9uS29kZS8uL3NyYy9uS29kZS5qcyIsIndlYnBhY2s6Ly9uS29kZS8uL3NyYy9zZXJ2ZXJSeC5qcyIsIndlYnBhY2s6Ly9uS29kZS8uL3NyYy9zZXJ2ZXJUeC5qcyIsIndlYnBhY2s6Ly9uS29kZS8uL3NyYy90cmFuc2Zvcm0uanMiXSwibmFtZXMiOlsiY2xpZW50TWVyZ2UiLCJtZXJnZU1lc3NhZ2UiLCJwZXJzaXN0ZW50S2V5cyIsImVwaGVtZXJhbEtleXMiLCJEQVJDZGF0YSIsImlucHV0U2VxdWVuY2UiLCJhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlQWxwaGFiZXRLZXkiLCJ0cmFuc2Zvcm0iLCJwZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbiIsIk91dGVyQ2xpZW50U2h1ZmZsZUtleSIsIk91dGVyQ2xpZW50U2h1ZmZsZUVwaGVtZXJhbEtleSIsImFwcGxpZWRPdXRlckNsaWVudFNodWZmbGVGdW5jdGlvbkFscGhhYmV0S2V5IiwiT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25LZXkiLCJPdXRlckNsaWVudFNodWZmbGVGdW5jdGlvbkVwaGVtZXJhbEtleSIsInRyYW5zZm9ybWF0aW9uQ29tcGxpbWVudCIsImhlaWdodCIsIkNsaWVudE1lZGl1bUtleSIsImxlbmd0aCIsIndpZHRoIiwibXNnTGVuIiwiZGFyY0NvbW1vbiIsInJhbmROZXdJbnRzIiwiYXBwbGllZElucHV0U2VxdWVuY2UiLCJhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlTWVkaXVtS2V5IiwiT3V0ZXJDbGllbnRTaHVmZmxlTWVkaXVtS2V5IiwiT3V0ZXJDbGllbnRTaHVmZmxlTWVkaXVtRXBoZW1lcmFsS2V5IiwiYXBwbGllZE91dGVyQ2xpZW50U2h1ZmZsZUZ1bmN0aW9uTWVkaXVtS2V5IiwiT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25NZWRpdW1LZXkiLCJPdXRlckNsaWVudFNodWZmbGVGdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleSIsIm1lc3NhZ2UiLCJwZXJtdXRlT3V0ZXJUcmFuc2Zvcm1hdGlvbiIsIkFscGhhYmV0RGF0YSIsImlucHV0RU9NIiwicmFuZFVuaXF1ZU5ld0J5dGVzIiwibWVkaXVtTWF4T3JkIiwibWVzc2FnZVBhZEtleSIsImxhc3RJbnB1dCIsImFwcGxpZWRQb3NpdGlvbkZ1bmN0aW9uS2V5IiwiUG9zaXRpb25GdW5jdGlvbk1lZGl1bUtleSIsIlBvc2l0aW9uRnVuY3Rpb25NZWRpdW1FcGhlbWVyYWxLZXkiLCJhcHBsaWVkT3V0ZXJQb3NpdGlvbkZ1bmN0aW9uS2V5IiwiT3V0ZXJQb3NpdGlvbkZ1bmN0aW9uTWVkaXVtS2V5IiwiT3V0ZXJQb3NpdGlvbkZ1bmN0aW9uTWVkaXVtRXBoZW1lcmFsS2V5IiwiYXBwbGllZE91dGVyUG9zaXRpb25TaHVmZmxlS2V5IiwiT3V0ZXJQb3NpdGlvblNodWZmbGVNZWRpdW1LZXkiLCJPdXRlclBvc2l0aW9uU2h1ZmZsZU1lZGl1bUVwaGVtZXJhbEtleSIsImlkZW50aXR5T3V0ZXJGdW5jdGlvbiIsImluaXRpYWxpemVOZXdBcnJheSIsInN1YnN0aXR1dGVGdW5jdGlvbk9wZXJhbmRzIiwiTWVkaXVtRGF0YSIsImFwcGxpZWRPdXRlclBvc2l0aW9uU2h1ZmZsZUZ1bmN0aW9uS2V5IiwiT3V0ZXJQb3NpdGlvblNodWZmbGVGdW5jdGlvbk1lZGl1bUtleSIsIk91dGVyUG9zaXRpb25TaHVmZmxlRnVuY3Rpb25NZWRpdW1FcGhlbWVyYWxLZXkiLCJhcHBsaWVkUG9zaXRpb25TaHVmZmxlS2V5IiwiUG9zaXRpb25TaHVmZmxlTWVkaXVtS2V5IiwiUG9zaXRpb25TaHVmZmxlTWVkaXVtRXBoZW1lcmFsS2V5IiwicGVybXV0ZUZ1bmN0aW9uTWFwIiwiZXgiLCJjb21tb24iLCJhZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8iLCJjbGllbnRSeCIsInJlY2VpdmUiLCJyZWNlaXZlQWxwaGFiZXQiLCJyZWNlaXZlTWVkaXVtIiwiYWxwaGFiZXQiLCJhcHBsaWVkT3V0ZXJTZXJ2ZXJTaHVmZmxlRnVuY3Rpb25LZXkiLCJPdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbktleSIsIk91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uRXBoZW1lcmFsS2V5IiwiYXBwbGllZEZ1bmN0aW9uS2V5IiwiRnVuY3Rpb25LZXkiLCJGdW5jdGlvbkVwaGVtZXJhbEtleSIsImFwcGxpZWRDbGllbnRTaHVmZmxlS2V5QSIsIkNsaWVudFNodWZmbGVLZXlBIiwiQ2xpZW50U2h1ZmZsZUVwaGVtZXJhbEtleUEiLCJhcHBsaWVkT3V0ZXJGdW5jdGlvbktleSIsIk91dGVyRnVuY3Rpb25LZXkiLCJPdXRlckZ1bmN0aW9uRXBoZW1lcmFsS2V5IiwiYXBwbGllZE91dGVyRnVuY3Rpb25GdW5jdGlvbktleSIsIk91dGVyRnVuY3Rpb25GdW5jdGlvbktleSIsIk91dGVyRnVuY3Rpb25GdW5jdGlvbkVwaGVtZXJhbEtleSIsInJlc3VsdCIsIkNsaWVudEVwaGVtZXJhbEtleSIsIkNsaWVudEtleSIsIk11dHVhbEtleSIsImFwcGxpZWRPdXRlckNsaWVudFNodWZmbGVLZXkiLCJhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25LZXkiLCJtZWRpdW0iLCJPdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbk1lZGl1bUtleSIsIk91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uTWVkaXVtRXBoZW1lcmFsS2V5IiwiRnVuY3Rpb25NZWRpdW1LZXkiLCJGdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleSIsIkNsaWVudFNodWZmbGVNZWRpdW1LZXlBIiwiQ2xpZW50U2h1ZmZsZU1lZGl1bUVwaGVtZXJhbEtleUEiLCJPdXRlckZ1bmN0aW9uTWVkaXVtS2V5IiwiT3V0ZXJGdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleSIsIk91dGVyRnVuY3Rpb25GdW5jdGlvbk1lZGl1bUtleSIsIk91dGVyRnVuY3Rpb25GdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleSIsIkNsaWVudE1lZGl1bUVwaGVtZXJhbEtleSIsIk11dHVhbE1lZGl1bUtleSIsImNsaWVudFR4IiwidHJhbnNtaXQiLCJ0cmFuc21pdEFscGhhYmV0IiwidHJhbnNtaXRNZWRpdW0iLCJjbGllbnRTaHVmZmxFcGhlbWVyYWxLZXlCIiwiaW5wdXRPdXRlckNsaWVudFNodWZmbGVLZXkiLCJpbnB1dE91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uS2V5IiwicmVvcmRlcmVkU2h1ZmZsZUtleVgiLCJDbGllbnRTaHVmZmxlS2V5WCIsImZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCIsImNsaWVudFNodWZmbEtleUIiLCJpbnB1dENsaWVudFNodWZmbGVLZXlCIiwic2h1ZmZsZWRJdGVtcyIsImlucHV0T3V0ZXJGdW5jdGlvbktleSIsInR4QWxwaGFiZXQiLCJNdXR1YWxFcGhlbWVyYWxLZXkiLCJDbGllbnRTaHVmZmxlTWVkaXVtS2V5WCIsInR4TWVkaXVtIiwiTXV0dWFsTWVkaXVtRXBoZW1lcmFsS2V5IiwiY3JlYXRlRXJyb3JXaXRoTmtvZGVNZXRob2RJZGVudGlmaWVyIiwibktvZGVNZXRob2RJZGVudGlmaWVyIiwiZXJyb3IiLCJFcnJvciIsIm5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrIiwiQXJyYXkiLCJwdXNoIiwiY2hlY2tGb3JWYWx1ZSIsImFycmF5IiwiYXJyYXlOYW1lIiwiZ2V0IiwidXJsIiwicmV0dXJuSnNvbiIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0IiwicmVxdWVzdCIsIlhNTEh0dHBSZXF1ZXN0IiwiY2FjaGVCdXN0ZXIiLCJNYXRoIiwiZmxvb3IiLCJyYW5kb20iLCJvcGVuIiwib25sb2FkIiwic3RhdHVzIiwiSlNPTiIsInBhcnNlIiwicmVzcG9uc2UiLCJvbmVycm9yIiwic2VuZCIsInBvc3QiLCJwYXlsb2FkIiwic2V0UmVxdWVzdEhlYWRlciIsIm9ucmVhZHlzdGF0ZWNoYW5nZSIsInJlYWR5U3RhdGUiLCJlbmNvZGVkIiwiT2JqZWN0Iiwia2V5cyIsIm1hcCIsImtleSIsImVuY29kZVVSSUNvbXBvbmVudCIsInN0cmluZ2lmeSIsImpvaW4iLCJnZXREYXJjS2V5TGVuZ3RoIiwiY291bnQiLCJ2YWx1ZSIsImlzQXJyYXkiLCJmbGF0dGVuVHdvRGltQXJyYXkiLCJ0d29EaW1BcnJheSIsInN1YlZhbHVlIiwiZW1wdHkiLCJlbGVtZW50IiwidyIsInVuZGVmaW5lZCIsImgiLCJhcnJheUVsZW1lbnRzTWF0Y2giLCJhcnJheTEiLCJhcnJheTIiLCJ4IiwiYnl0ZXMiLCJtaW4iLCJtYXgiLCJieXRlTWF4IiwiYnl0ZU1pbiIsImNvbnRyYSIsImkiLCJzdWNjZXNzIiwiY2hvc2VuIiwicGFzcyIsImZhaWwiLCJyYW5kTnVtIiwiaGl0IiwibWlzcyIsIm9yZCIsInNjcmFwIiwib3JkaW5hbCIsInJhbmRVbmlxdWVJbnQiLCJzZXQiLCJwb3NzaWJsZSIsImF2YWlsIiwic2xpY2UiLCJ5IiwieiIsIkNvdW50Iiwic3BsaWNlIiwiaW50cyIsInNldFBhZCIsInJhbmRJbnQiLCJiIiwiY2FuZGlkYXRlcyIsInRvcCIsInJhbmROdW1SZXN1bHQiLCJwYXJzZUludCIsImsiLCJ0bXAiLCJjZWlsIiwic2VjdXJlX3JhbmQiLCJzdHJ1Y3R1cmVGbGF0dGVuZWRUd29EaW1lbnNpb25hbEFycmF5IiwiZGF0YSIsIm91dGVyQXJyYXkiLCJpbm5lckFycmF5IiwicnZhbCIsInJhbmdlIiwiYml0c19uZWVkZWQiLCJsb2cyIiwiRXhjZXB0aW9uIiwiYnl0ZXNfbmVlZGVkIiwibWFzayIsInBvdyIsImJ5dGVBcnJheSIsIlVpbnQ4QXJyYXkiLCJ3aW5kb3ciLCJjcnlwdG8iLCJnZXRSYW5kb21WYWx1ZXMiLCJwIiwiZGFyY0NvbmZpZyIsIkFUVFJJQlVURV9WQUxVRVMiLCJQT1NJVElPTl9BVFRSSUJVVEVfT1JESU5BTF9QT1NJVElPTiIsIkNMSUVOVF9LRVlTIiwiU0VSVkVSX0RBUkNfQVRUUklCVVRFX0tFWVMiLCJPdXRlclNlcnZlclNodWZmbGVLZXkiLCJTZXJ2ZXJLZXkiLCJTZXJ2ZXJTaHVmZmxlS2V5IiwiU2VydmVyTWVkaXVtS2V5IiwicmFuZE1pbiIsInJhbmRNYXgiLCJnZW5lcmF0ZVNoYXJlZEluc3RhbmNlVHJhbnNsYXRpb25zIiwiaW5wdXRCbG9ja0xlbmd0aCIsInVwZGF0ZSIsInNoYXJlZEVwaGVtZXJhbEtleXNPYmoiLCJnZXROZXdEYXRhVHJhbnNsYXRpb25LZXkiLCJnZXROZXdTaHVmZmxlT3JGdW5jdGlvblRyYW5zbGF0aW9uS2V5IiwiVG9rZW5VcGRhdGVGdW5jdGlvbkVwaGVtZXJhbEtleSIsImdlbmVyYXRlU2VydmVySW5zdGFuY2VUcmFuc2xhdGlvbnMiLCJzZXJ2ZXJFcGhlbWVyYWxLZXlzT2JqIiwiT3V0ZXJTZXJ2ZXJTaHVmZmxlRXBoZW1lcmFsS2V5IiwiU2VydmVyRXBoZW1lcmFsS2V5IiwiU2VydmVyU2h1ZmZsZUVwaGVtZXJhbEtleSIsIlNlcnZlck1lZGl1bUVwaGVtZXJhbEtleSIsImdlbmVyYXRlQ2xpZW50SW5zdGFuY2VUcmFuc2xhdGlvbnMiLCJjbGllbnRFcGhlbWVyYWxLZXlzT2JqIiwiX2NvbmZpZyIsImtleXBhZCIsInJlbW92ZUxhc3RFbnRyeSIsInNlbGVjdGVkS2V5T3JkaW5hbCIsInBvcCIsImZpcmVDaGFuZ2VkRXZlbnQiLCJzZXRDb25maWciLCJjb25maWciLCJuS29kQ2hhbmdlZCIsImN1cnJlbnROS29kTGVuZ3RoIiwiZ2V0S2V5cGFkIiwiYXR0cmlidXRlRGFyY0RhdGEiLCJ0ZW1wbGF0ZUlkZW50aWZpZXIiLCJhdHRyaWJ1dGVNYXAiLCJjb3B5IiwiYXR0cmlidXRlUG9zaXRpb25EYXRhIiwicG9zaXRpb25JbmRleCIsImluZGV4T2YiLCJjdXJyZW50QWxwaGFiZXRQb3NpdGlvbiIsInBvc2l0aW9uQXJyYXlTdGFydEluZGV4Iiwib2xkSW5kZXgiLCJodG1sIiwiSFRNTF9URU1QTEFURV9QQVRIIiwicmVwbGFjZSIsImh0bWxUZW1wbGF0ZSIsImF0dHJpYnV0ZVNldE9uZSIsImF0dHJpYnV0ZVNldFR3byIsImF0dHJpYnV0ZVNldFRocmVlIiwiYXR0cmlidXRlU2V0Rm91ciIsImF0dHJpYnV0ZVNldEZpdmUiLCJhdHRyaWJ1dGVTZXRTaXgiLCJhdHRyaWJ1dGVTZXRTZXZlbiIsImoiLCJhdHRyaWJ1dGUiLCJpbnRlcmZhY2VQbGFjZWhvbGRlckVsZW1lbnQiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiSU5URVJGQUNFX0hUTUxfUExBQ0VIT0xERVJfSUQiLCJpbm5lckhUTUwiLCJjbGlja2FibGVLZXlzIiwicXVlcnlTZWxlY3RvckFsbCIsImFkZEV2ZW50TGlzdGVuZXIiLCJjbGlja0tleSIsIm1vdXNlZG93biIsImNsZWFyIiwiZSIsInByZXZlbnREZWZhdWx0IiwiTUFYX05LT0RfTEVOR1RIIiwiaW5kZXhlciIsImN1cnJlbnRUYXJnZXQiLCJkYXRhc2V0IiwiQVRUUklCVVRFX1dJRFRIIiwiQVRUUklCVVRFX0hFSUdIVCIsIl9rZXlwYWQiLCJLZXlwYWQiLCJfaW50ZXJmYWNlRGF0YSIsIl9jcmVhdGVOS29kRGF0YSIsImNyZWF0ZUludGVyZmFjZSIsInVzZXJOYW1lIiwiZmluZ2VycHJpbnQiLCJhZGRpdGlvbmFsRGF0YSIsIkFQSV9VUkwiLCJkQVJDUGhhc2UxQXR0cmlidXRlRGF0YSIsImdldEF0dHJpYnV0ZURhdGFGb3JUcmFuc21pc3Npb24iLCJDTElFTlRfSUQiLCJhdHRyaWJ1dGVNdXR1YWxFcGhlbWVyYWxLZXlzIiwicHJvY2Vzc1JlY2VpdmVkRGF0YSIsIlVzZXJUZW1wbGF0ZUlkZW50aWZpZXIiLCJtYXBwZWRBdHRyaWJ1dGVWYWx1ZXMiLCJhdHRyaWJ1dGVMb29rdXBWYWx1ZXMiLCJuS29kZSIsInNldEtvZENoYW5nZWRDYWxsYmFjayIsImNhbGxiYWNrIiwiZ2VuZXJhdGVMb2dpbkludGVyZmFjZSIsImRlZmF1bHRUZW1wbGF0ZUlkZW50aWZpZXIiLCJnZW5lcmF0ZVJlZ2lzdGVySW50ZXJmYWNlIiwic2V0dXBOa29kVGVtcGxhdGVTZWxlY3RvciIsImxvZ2luIiwidXNlcm5hbWUiLCJuZXdLZXlWYWx1ZXMiLCJwcmVwYXJlS2V5SW5wdXRGb3JUcmFuc21pc3Npb24iLCJTZXNzaW9uSWQiLCJmaW5hbCIsImNyZWF0ZU5Lb2RlU3RlcDEiLCJmaXJzdE5Lb2RMZW5ndGgiLCJ1c2VyRXhpc3RzIiwiY3JlYXRlTktvZGVTdGVwMiIsIk5Lb2RMZW5ndGhVbmVxdWFsIiwiZ2V0Q2xpZW50QXR0cmlidXRlU2V0c0FuZFZhbHVlcyIsIm51bWJlck9mQXR0cmlidXRlVmFsdWVzIiwic2VydmVyRXBoZW1lcmFsS2V5cyIsImFzc2lnbiIsImF0dHJpYnV0ZUFscGhhYmV0IiwiY29uY2F0IiwidG9TdHJpbmciLCJkQVJDUGhhc2UxIiwic2VydmVyVHgiLCJkQVJDUGhhc2UzIiwiY2xpZW50RXBoZW1lcmFsS2V5cyIsIktleXBhZERhcmNEYXRhIiwiZEFSQ01lc3NhZ2UiLCJLZXlwYWRNdXR1YWxFcGhlbWVyYWxLZXlzIiwia2V5cGFkRGFyY0RhdGEiLCJhdHRyaWJ1dGVEYXRhIiwic2VydmVyUngiLCJ0cmFuc2xhdGUiLCJBdHRyaWJ1dGVEYXJjRGF0YSIsInJ4RGF0YSIsIm91dGVyUG9zaXRpb25GdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWQiLCJvdXRlclBvc2l0aW9uU2h1ZmZsZUVwaGVtZXJhbEtleUFwcGxpZWQiLCJvdXRlclBvc2l0aW9uU2h1ZmZsZUZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCIsIm91dGVyRnVuY3Rpb25GdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleUFwcGxpZWQiLCJvdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWQiLCJvdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleUFwcGxpZWQiLCJmdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleUFwcGxpZWQiLCJjbGllbnRTaHVmZmxlTWVkaXVtS2V5WCIsInBlcm11dGVGdW5jdGlvbk9wZXJhbmQiLCJwb3NpdGlvblNodWZmbGVFcGhlbWVyYWxLZXlBcHBsaWVkIiwiY2xpZW50U2h1ZmZsZUtleVgiLCJvdXRlckZ1bmN0aW9uRnVuY3Rpb25FcGhlbWVyYWxLZXlBcHBsaWVkIiwib3V0ZXJGdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleUFwcGxpZWQiLCJwb3NpdGlvbkZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCIsInNlcnZlclNodWZmbGVFcGhlbWVyYWxLZXlBcHBsaWVkIiwib3V0ZXJTZXJ2ZXJTaHVmZmxlRXBoZW1lcmFsS2V5QXBwbGllZCIsImFscGhhUHJlcCIsIm91dGVyRnVuY3Rpb25FcGhlbWVyYWxLZXlBcHBsaWVkIiwic2VydmVyRGF0YSIsInJlc29sdmVSeERhdGEiLCJmaW5kQXJyYXkiLCJtYXRjaCIsImEiLCJkYXJjRGF0YSIsInRyYW5zbGF0ZURhdGEiLCJ0cmFuc2xhdGVNZWRpdW0iLCJpbnB1dERhdGEiLCJwZXJtdXRlIiwib3BlcmFuZCIsIm91dGVyUGVybXV0YXRpb25GdW5jdGlvbiIsIm91dGVyU2h1ZkZ1bmMiLCJzdWJzdGl0dXRlIiwib3BlcmFuZF9BIiwib3BlcmFuZF9CIiwib3BlcmFuZEFEYXJjS2V5TGVuZ3RoIiwic3Vic3RpdHV0ZU9wZXJhbmRzIiwib3BlcmFuZHMiLCJzdWJzdGl0dXRlT3BlcmFuZCIsIlZhbHVlcyIsIkFkZCIsInN1YnN0aXR1dGVGdW5jdGlvbiIsImZ1bmN0aW9uS2V5cyIsIm5ld1ZhbCIsIm91dGVyRnVuY3Rpb25GdW5jdGlvbiIsImlubmVyRnVuY3Rpb24iLCJvdXRlckZ1bmN0aW9uIiwib3V0ZXJGdW5jRnVuYyIsIm91dGVyRnVuYyIsInN1YnN0aXR1dGVGdW5jdGlvbk9wZXJhbmQiXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRCxPO0FDVkE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxrREFBMEMsZ0NBQWdDO0FBQzFFO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsZ0VBQXdELGtCQUFrQjtBQUMxRTtBQUNBLHlEQUFpRCxjQUFjO0FBQy9EOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpREFBeUMsaUNBQWlDO0FBQzFFLHdIQUFnSCxtQkFBbUIsRUFBRTtBQUNySTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLG1DQUEyQiwwQkFBMEIsRUFBRTtBQUN2RCx5Q0FBaUMsZUFBZTtBQUNoRDtBQUNBO0FBQ0E7O0FBRUE7QUFDQSw4REFBc0QsK0RBQStEOztBQUVySDtBQUNBOzs7QUFHQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDbEZBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBRUEsSUFBSUEsV0FBVyxHQUFHO0FBQ2RDLGNBQVksRUFBRSxzQkFBQ0MsY0FBRCxFQUFpQkMsYUFBakIsRUFBZ0NDLFFBQWhDLEVBQTBDQyxhQUExQyxFQUE0RDtBQUV0RSxRQUFJO0FBQ0EsVUFBSUMsb0NBQW9DLEdBQUdDLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUNPLHFCQUFwRCxFQUEyRU4sYUFBYSxDQUFDTyw4QkFBekYsQ0FBM0M7QUFDQSxVQUFJQyw0Q0FBNEMsR0FBR0oscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNOLGNBQWMsQ0FBQ1UsNkJBQXBELEVBQW1GVCxhQUFhLENBQUNVLHNDQUFqRyxDQUFuRDtBQUVBUCwwQ0FBb0MsR0FBR0MscURBQVMsQ0FBQ08sd0JBQVYsQ0FBbUNQLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDRixvQ0FBckMsRUFBMkVLLDRDQUEzRSxDQUFuQyxDQUF2QyxDQUpBLENBTUE7O0FBQ0EsVUFBSUksTUFBTSxHQUFHYixjQUFjLENBQUNjLGVBQWYsQ0FBK0JDLE1BQTVDO0FBQ0EsVUFBSUMsS0FBSyxHQUFHaEIsY0FBYyxDQUFDYyxlQUFmLENBQStCLENBQS9CLEVBQWtDQyxNQUE5QztBQUNBLFVBQUlFLE1BQU0sR0FBR2QsYUFBYSxDQUFDWSxNQUEzQixDQVRBLENBV0E7O0FBQ0FaLG1CQUFhLEdBQUdlLHNEQUFVLENBQUNDLFdBQVgsQ0FBdUJoQixhQUF2QixFQUFzQ1UsTUFBdEMsRUFBOEMsQ0FBOUMsRUFBaURBLE1BQWpELENBQWhCO0FBR0EsVUFBSU8sb0JBQW9CLEdBQUdmLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDRixvQ0FBckMsRUFBMkUsQ0FBQ0QsYUFBRCxDQUEzRSxDQUEzQjtBQUNBLFVBQUlrQixrQ0FBa0MsR0FBR2hCLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUNzQiwyQkFBcEQsRUFBaUZyQixhQUFhLENBQUNzQixvQ0FBL0YsQ0FBekM7QUFDQSxVQUFJQywwQ0FBMEMsR0FBR25CLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUN5QixtQ0FBcEQsRUFBeUZ4QixhQUFhLENBQUN5Qiw0Q0FBdkcsQ0FBakQ7QUFFQUwsd0NBQWtDLEdBQUdoQixxREFBUyxDQUFDQywwQkFBVixDQUFxQ2Usa0NBQXJDLEVBQXlFRywwQ0FBekUsQ0FBckM7QUFFQUosMEJBQW9CLEdBQUdmLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDYyxvQkFBckMsRUFBMkRDLGtDQUEzRCxDQUF2QjtBQUVBLFVBQUlNLE9BQU8sR0FBR3RCLHFEQUFTLENBQUN1QiwwQkFBVixDQUFxQzFCLFFBQVEsQ0FBQzJCLFlBQTlDLEVBQTREVCxvQkFBNUQsQ0FBZCxDQXZCQSxDQXlCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxVQUFJVSxRQUFRLEdBQUdaLHNEQUFVLENBQUNhLGtCQUFYLENBQThCN0IsUUFBUSxDQUFDMkIsWUFBdkMsRUFBcURiLEtBQXJELEVBQTRELENBQTVELEVBQStELEdBQS9ELENBQWYsQ0FsREEsQ0FvREE7O0FBQ0EsVUFBSWdCLFlBQVksR0FBR25CLE1BQU0sR0FBRyxDQUE1QixDQXJEQSxDQXVEQTs7QUFDQSxVQUFJb0IsYUFBYSxHQUFHNUIscURBQVMsQ0FBQ08sd0JBQVYsQ0FBbUNTLGtDQUFuQyxDQUFwQixDQXhEQSxDQTBEQTs7QUFDQSxVQUFJYSxTQUFTLEdBQUdQLE9BQU8sQ0FBQ00sYUFBYSxDQUFDLENBQUQsQ0FBYixDQUFpQkQsWUFBakIsQ0FBRCxDQUF2QjtBQUVBLFVBQUlmLE1BQU0sR0FBR0osTUFBYixFQUNJYyxPQUFPLENBQUNNLGFBQWEsQ0FBQyxDQUFELENBQWIsQ0FBaUJoQixNQUFqQixDQUFELENBQVAsR0FBb0NhLFFBQXBDLENBREosQ0FDa0Q7QUFEbEQsV0FFSztBQUNESCxlQUFPLENBQUNNLGFBQWEsQ0FBQyxDQUFELENBQWIsQ0FBaUJELFlBQWpCLENBQUQsQ0FBUCxHQUEwQ0UsU0FBMUMsQ0FoRUosQ0FnRXlEOztBQUV6RCxVQUFJQywwQkFBMEIsR0FBRzlCLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUNvQyx5QkFBcEQsRUFBK0VuQyxhQUFhLENBQUNvQyxrQ0FBN0YsQ0FBakM7QUFDQSxVQUFJQywrQkFBK0IsR0FBR2pDLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUN1Qyw4QkFBcEQsRUFBb0Z0QyxhQUFhLENBQUN1Qyx1Q0FBbEcsQ0FBdEM7QUFFQSxVQUFJQyw4QkFBOEIsR0FBR3BDLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUMwQyw2QkFBcEQsRUFBbUZ6QyxhQUFhLENBQUMwQyxzQ0FBakcsQ0FBckM7QUFFQUwscUNBQStCLEdBQUdqQyxxREFBUyxDQUFDQywwQkFBVixDQUFxQ21DLDhCQUFyQyxFQUFxRUgsK0JBQXJFLENBQWxDO0FBRUFqQix3Q0FBa0MsR0FBR2hCLHFEQUFTLENBQUNPLHdCQUFWLENBQW1DUyxrQ0FBbkMsQ0FBckM7QUFDQWlCLHFDQUErQixHQUFHakMscURBQVMsQ0FBQ08sd0JBQVYsQ0FBbUNQLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDZSxrQ0FBckMsRUFBeUVpQiwrQkFBekUsQ0FBbkMsQ0FBbEM7QUFFQSxVQUFJTSxxQkFBcUIsR0FBRzFCLHNEQUFVLENBQUMyQixrQkFBWCxDQUE4QjdDLGNBQWMsQ0FBQ3VDLDhCQUFmLENBQThDLENBQTlDLEVBQWlEeEIsTUFBL0UsRUFBdUZmLGNBQWMsQ0FBQ3VDLDhCQUFmLENBQThDeEIsTUFBckksQ0FBNUI7QUFFQVksYUFBTyxHQUFHdEIscURBQVMsQ0FBQ3lDLDBCQUFWLENBQ05SLCtCQURNLEVBRUpILDBCQUZJLEVBR0pTLHFCQUhJLEVBSUoxQyxRQUFRLENBQUM2QyxVQUpMLEVBS0pwQixPQUxJLENBQVY7QUFRQSxVQUFJcUIsc0NBQXNDLEdBQUczQyxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDaUQscUNBQXBELEVBQTJGaEQsYUFBYSxDQUFDaUQsOENBQXpHLENBQTdDO0FBRUEsVUFBSUMseUJBQXlCLEdBQUc5QyxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDb0Qsd0JBQXBELEVBQThFbkQsYUFBYSxDQUFDb0QsaUNBQTVGLENBQWhDO0FBRUFaLG9DQUE4QixHQUFHcEMscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNlLGtDQUFyQyxFQUF5RW9CLDhCQUF6RSxDQUFqQztBQUNBTyw0Q0FBc0MsR0FBRzNDLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDMEMsc0NBQXJDLEVBQTZFViwrQkFBN0UsQ0FBekM7QUFFQVgsYUFBTyxHQUFHdEIscURBQVMsQ0FBQ3VCLDBCQUFWLENBQXFDdkIscURBQVMsQ0FBQ2lELGtCQUFWLENBQTZCTixzQ0FBN0IsRUFBcUVyQixPQUFyRSxFQUE4RXdCLHlCQUE5RSxDQUFyQyxFQUErSVYsOEJBQS9JLENBQVY7QUFFQSxhQUFPZCxPQUFQO0FBQ0gsS0FoR0QsQ0FnR0UsT0FBTzRCLEVBQVAsRUFDRjtBQUNJQyx3REFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsWUFBTUEsRUFBTjtBQUNIO0FBQ0o7QUF4R2EsQ0FBbEI7QUEyR2V6RCwwRUFBZixFOzs7Ozs7Ozs7Ozs7QUMvR0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUVBLElBQUk0RCxRQUFRLEdBQUc7QUFDWEMsU0FBTyxFQUFDLGlCQUFDM0QsY0FBRCxFQUFpQkMsYUFBakIsRUFBZ0NDLFFBQWhDLEVBQ1I7QUFDSSxRQUFJO0FBQ0FBLGNBQVEsQ0FBQzJCLFlBQVQsR0FBd0IrQixlQUFlLENBQUM1RCxjQUFELEVBQWlCQyxhQUFqQixFQUFnQ0MsUUFBUSxDQUFDMkIsWUFBekMsQ0FBdkM7QUFDQTNCLGNBQVEsQ0FBQzZDLFVBQVQsR0FBc0JjLGFBQWEsQ0FBQzdELGNBQUQsRUFBaUJDLGFBQWpCLEVBQWdDQyxRQUFRLENBQUM2QyxVQUF6QyxDQUFuQztBQUNBLGFBQU83QyxRQUFQO0FBQ0gsS0FKRCxDQUlFLE9BQU9xRCxFQUFQLEVBQVc7QUFDVEMsd0RBQU0sQ0FBQ0MsaUNBQVAsQ0FBeUNGLEVBQXpDLEVBQTZDLHNDQUE3QztBQUNBLFlBQU1BLEVBQU47QUFDSDtBQUNKO0FBWFUsQ0FBZixDLENBY0E7O0FBQ0EsU0FBU0ssZUFBVCxDQUF5QjVELGNBQXpCLEVBQXlDQyxhQUF6QyxFQUF3RDZELFFBQXhELEVBQ0E7QUFDSSxNQUFJO0FBQ0EsUUFBSUMsb0NBQW9DLEdBQUcxRCxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDZ0UsNkJBQXBELEVBQW1GL0QsYUFBYSxDQUFDZ0Usc0NBQWpHLENBQTNDO0FBQ0EsUUFBSUMsa0JBQWtCLEdBQUc3RCxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDbUUsV0FBcEQsRUFBaUVsRSxhQUFhLENBQUNtRSxvQkFBL0UsQ0FBekI7QUFDQSxRQUFJQyx3QkFBd0IsR0FBR2hFLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUNzRSxpQkFBcEQsRUFBdUVyRSxhQUFhLENBQUNzRSwwQkFBckYsQ0FBL0I7QUFDQSxRQUFJQyx1QkFBdUIsR0FBR25FLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUN5RSxnQkFBcEQsRUFBc0V4RSxhQUFhLENBQUN5RSx5QkFBcEYsQ0FBOUI7QUFDQSxRQUFJQywrQkFBK0IsR0FBR3RFLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUM0RSx3QkFBcEQsRUFBOEUzRSxhQUFhLENBQUM0RSxpQ0FBNUYsQ0FBdEM7QUFFQSxRQUFJQyxNQUFNLEdBQUd6RSxxREFBUyxDQUFDeUMsMEJBQVYsQ0FDVDZCLCtCQURTLEVBRVRULGtCQUZTLEVBR1RNLHVCQUhTLEVBSVRWLFFBSlMsRUFLVDdELGFBQWEsQ0FBQzhFLGtCQUxMLEVBTVQvRSxjQUFjLENBQUNnRixTQU5OLEVBT1RoRixjQUFjLENBQUNpRixTQVBOLENBQWI7QUFVQW5CLFlBQVEsR0FBR2dCLE1BQVgsQ0FqQkEsQ0FtQkE7O0FBQ0FoQixZQUFRLEdBQUd6RCxxREFBUyxDQUFDaUQsa0JBQVYsQ0FBNkJTLG9DQUE3QixFQUFtRUQsUUFBbkUsRUFBNkVPLHdCQUE3RSxDQUFYO0FBQ0EsUUFBSWEsNEJBQTRCLEdBQUc3RSxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDTyxxQkFBcEQsRUFBMkVOLGFBQWEsQ0FBQ08sOEJBQXpGLENBQW5DO0FBQ0EsUUFBSTJFLG9DQUFvQyxHQUFHOUUscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNOLGNBQWMsQ0FBQ1UsNkJBQXBELEVBQW1GVCxhQUFhLENBQUNVLHNDQUFqRyxDQUEzQztBQUNBdUUsZ0NBQTRCLEdBQUc3RSxxREFBUyxDQUFDQywwQkFBVixDQUFxQzRFLDRCQUFyQyxFQUFtRUMsb0NBQW5FLENBQS9CO0FBQ0FyQixZQUFRLEdBQUd6RCxxREFBUyxDQUFDdUIsMEJBQVYsQ0FBcUNrQyxRQUFyQyxFQUErQ29CLDRCQUEvQyxDQUFYO0FBRUEsV0FBT3BCLFFBQVA7QUFDSCxHQTNCRCxDQTJCRSxPQUFPUCxFQUFQLEVBQVc7QUFDVEMsc0RBQU0sQ0FBQ0MsaUNBQVAsQ0FBeUNGLEVBQXpDLEVBQTZDLHNDQUE3QztBQUNBLFVBQU1BLEVBQU47QUFDSDtBQUNKOztBQUVELFNBQVNNLGFBQVQsQ0FBdUI3RCxjQUF2QixFQUF1Q0MsYUFBdkMsRUFBc0RtRixNQUF0RCxFQUE4RDtBQUUxRCxNQUFJO0FBQ0EsUUFBSXJCLG9DQUFvQyxHQUFHMUQscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNOLGNBQWMsQ0FBQ3FGLG1DQUFwRCxFQUF5RnBGLGFBQWEsQ0FBQ3FGLDRDQUF2RyxDQUEzQztBQUNBLFFBQUlwQixrQkFBa0IsR0FBRzdELHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUN1RixpQkFBcEQsRUFBdUV0RixhQUFhLENBQUN1RiwwQkFBckYsQ0FBekI7QUFDQSxRQUFJbkIsd0JBQXdCLEdBQUdoRSxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDeUYsdUJBQXBELEVBQTZFeEYsYUFBYSxDQUFDeUYsZ0NBQTNGLENBQS9CO0FBQ0EsUUFBSWxCLHVCQUF1QixHQUFHbkUscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNOLGNBQWMsQ0FBQzJGLHNCQUFwRCxFQUE0RTFGLGFBQWEsQ0FBQzJGLCtCQUExRixDQUE5QjtBQUNBLFFBQUlqQiwrQkFBK0IsR0FBR3RFLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUM2Riw4QkFBcEQsRUFBb0Y1RixhQUFhLENBQUM2Rix1Q0FBbEcsQ0FBdEM7QUFFQSxRQUFJaEIsTUFBTSxHQUFHekUscURBQVMsQ0FBQ3lDLDBCQUFWLENBQ1Q2QiwrQkFEUyxFQUVUVCxrQkFGUyxFQUdUTSx1QkFIUyxFQUlUWSxNQUpTLEVBS1RuRixhQUFhLENBQUM4Rix3QkFMTCxFQU1UL0YsY0FBYyxDQUFDYyxlQU5OLEVBT1RkLGNBQWMsQ0FBQ2dHLGVBUE4sQ0FBYjtBQVVBWixVQUFNLEdBQUdOLE1BQVQ7QUFFQU0sVUFBTSxHQUFHL0UscURBQVMsQ0FBQ2lELGtCQUFWLENBQTZCUyxvQ0FBN0IsRUFBbUVxQixNQUFuRSxFQUEyRWYsd0JBQTNFLENBQVQ7QUFDQSxRQUFJYSw0QkFBNEIsR0FBRzdFLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUNzQiwyQkFBcEQsRUFBaUZyQixhQUFhLENBQUNzQixvQ0FBL0YsQ0FBbkM7QUFDQSxRQUFJNEQsb0NBQW9DLEdBQUc5RSxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDeUIsbUNBQXBELEVBQXlGeEIsYUFBYSxDQUFDeUIsNENBQXZHLENBQTNDO0FBQ0F3RCxnQ0FBNEIsR0FBRzdFLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDNEUsNEJBQXJDLEVBQW1FQyxvQ0FBbkUsQ0FBL0I7QUFDQUMsVUFBTSxHQUFHL0UscURBQVMsQ0FBQ3VCLDBCQUFWLENBQXFDd0QsTUFBckMsRUFBNkNGLDRCQUE3QyxDQUFUO0FBRUEsV0FBT0UsTUFBUDtBQUNILEdBMUJELENBMEJFLE9BQU83QixFQUFQLEVBQVc7QUFDVEMsc0RBQU0sQ0FBQ0MsaUNBQVAsQ0FBeUNGLEVBQXpDLEVBQTZDLHNDQUE3QztBQUNBLFVBQU1BLEVBQU47QUFDSDtBQUNKOztBQUVjRyx1RUFBZixFOzs7Ozs7Ozs7Ozs7QUN2RkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQSxJQUFJdUMsUUFBUSxHQUFHO0FBQ1hDLFVBQVEsRUFBQyxrQkFBQ2xHLGNBQUQsRUFBaUJDLGFBQWpCLEVBQWdDQyxRQUFoQyxFQUNUO0FBQ0ksUUFBSTtBQUNBQSxjQUFRLENBQUMyQixZQUFULEdBQXdCc0UsZ0JBQWdCLENBQUNuRyxjQUFELEVBQWlCQyxhQUFqQixFQUFnQ0MsUUFBUSxDQUFDMkIsWUFBekMsQ0FBeEM7QUFDQTNCLGNBQVEsQ0FBQzZDLFVBQVQsR0FBc0JxRCxjQUFjLENBQUNwRyxjQUFELEVBQWlCQyxhQUFqQixFQUFnQ0MsUUFBUSxDQUFDNkMsVUFBekMsQ0FBcEM7QUFFQSxhQUFPN0MsUUFBUDtBQUNILEtBTEQsQ0FLRSxPQUFPcUQsRUFBUCxFQUFXO0FBQ1RDLHdEQUFNLENBQUNDLGlDQUFQLENBQXlDRixFQUF6QyxFQUE2QyxzQ0FBN0M7QUFDQSxZQUFNQSxFQUFOO0FBQ0g7QUFDSjtBQVpVLENBQWY7O0FBZUEsU0FBUzRDLGdCQUFULENBQTBCbkcsY0FBMUIsRUFBMENDLGFBQTFDLEVBQXlENkQsUUFBekQsRUFDQTtBQUVJLE1BQUk7QUFDQSxRQUFJdUMseUJBQXlCLEdBQUdoRyxxREFBUyxDQUFDTyx3QkFBVixDQUFtQ1gsYUFBYSxDQUFDc0UsMEJBQWpELENBQWhDO0FBQ0EsUUFBSVIsb0NBQW9DLEdBQUcxRCxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDZ0UsNkJBQXBELEVBQW1GL0QsYUFBYSxDQUFDZ0Usc0NBQWpHLENBQTNDO0FBQ0EsUUFBSWlCLDRCQUE0QixHQUFHN0UscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNOLGNBQWMsQ0FBQ08scUJBQXBELEVBQTJFTixhQUFhLENBQUNPLDhCQUF6RixDQUFuQztBQUNBLFFBQUkyRSxvQ0FBb0MsR0FBRzlFLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUNVLDZCQUFwRCxFQUFtRlQsYUFBYSxDQUFDVSxzQ0FBakcsQ0FBM0M7QUFDQSxRQUFJMkYsMEJBQTBCLEdBQUdqRyxxREFBUyxDQUFDQywwQkFBVixDQUFxQzRFLDRCQUFyQyxFQUFtRUMsb0NBQW5FLENBQWpDO0FBQ0EsUUFBSW9CLGtDQUFrQyxHQUFHbEcscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUN5RCxvQ0FBckMsRUFBMkV1QywwQkFBM0UsQ0FBekM7QUFDQSxRQUFJM0IsK0JBQStCLEdBQUd0RSxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDNEUsd0JBQXBELEVBQThFM0UsYUFBYSxDQUFDNEUsaUNBQTVGLENBQXRDO0FBQ0FGLG1DQUErQixHQUFHdEUscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNxRSwrQkFBckMsRUFBc0UyQiwwQkFBdEUsQ0FBbEM7QUFDQSxRQUFJcEMsa0JBQWtCLEdBQUc3RCxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDbUUsV0FBcEQsRUFBaUVsRSxhQUFhLENBQUNtRSxvQkFBL0UsQ0FBekI7QUFDQUYsc0JBQWtCLEdBQUc3RCxxREFBUyxDQUFDdUIsMEJBQVYsQ0FBcUNzQyxrQkFBckMsRUFBeURTLCtCQUF6RCxDQUFyQjtBQUNBLFFBQUk2QixvQkFBb0IsR0FBR25HLHFEQUFTLENBQUN1QiwwQkFBVixDQUFxQzVCLGNBQWMsQ0FBQ3lHLGlCQUFwRCxFQUF1RUYsa0NBQXZFLENBQTNCO0FBQ0EsUUFBSUcsMkJBQTJCLEdBQUdyRyxxREFBUyxDQUFDQywwQkFBVixDQUFxQzRELGtCQUFyQyxFQUF5RHNDLG9CQUF6RCxDQUFsQyxDQVpBLENBYUE7QUFFQTs7QUFDQSxRQUFJRyxnQkFBZ0IsR0FBR3RHLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDRCxxREFBUyxDQUFDTyx3QkFBVixDQUFtQ1osY0FBYyxDQUFDc0UsaUJBQWxELENBQXJDLEVBQTJHdEUsY0FBYyxDQUFDeUcsaUJBQTFILENBQXZCLENBaEJBLENBaUJBOztBQUVBLFFBQUlHLHNCQUFzQixHQUFHdkcscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUMrRix5QkFBckMsRUFBZ0VNLGdCQUFoRSxDQUE3QixDQW5CQSxDQW1CZ0g7O0FBQ2hILFFBQUlFLGFBQWEsR0FBR3hHLHFEQUFTLENBQUNpRCxrQkFBVixDQUE2QmlELGtDQUE3QixFQUFpRXpDLFFBQWpFLEVBQTJFOEMsc0JBQTNFLENBQXBCO0FBQ0EsUUFBSXBDLHVCQUF1QixHQUFHbkUscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNOLGNBQWMsQ0FBQ3lFLGdCQUFwRCxFQUFzRXhFLGFBQWEsQ0FBQ3lFLHlCQUFwRixDQUE5QjtBQUNBLFFBQUlvQyxxQkFBcUIsR0FBR3pHLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDa0UsdUJBQXJDLEVBQThEOEIsMEJBQTlELENBQTVCO0FBQ0EsUUFBSTFELHFCQUFxQixHQUFHMUIsc0RBQVUsQ0FBQzJCLGtCQUFYLENBQThCN0MsY0FBYyxDQUFDNEUsd0JBQWYsQ0FBd0MsQ0FBeEMsRUFBMkM3RCxNQUF6RSxFQUFpRmYsY0FBYyxDQUFDNEUsd0JBQWYsQ0FBd0M3RCxNQUF6SCxDQUE1QjtBQUVBLFFBQUlnRyxVQUFVLEdBQUcxRyxxREFBUyxDQUFDeUMsMEJBQVYsQ0FDYkYscUJBRGEsRUFFWDhELDJCQUZXLEVBR1hJLHFCQUhXLEVBSVhELGFBSlcsRUFLWDVHLGFBQWEsQ0FBQzhFLGtCQUxILEVBTVgvRSxjQUFjLENBQUNnRixTQU5KLEVBT1gvRSxhQUFhLENBQUMrRyxrQkFQSCxDQUFqQjtBQVVBLFdBQU9ELFVBQVA7QUFDSCxHQXBDRCxDQW9DRSxPQUFPeEQsRUFBUCxFQUFXO0FBQ1RDLHNEQUFNLENBQUNDLGlDQUFQLENBQXlDRixFQUF6QyxFQUE2QyxzQ0FBN0M7QUFDQSxVQUFNQSxFQUFOO0FBQ0g7QUFDSjs7QUFFRyxTQUFTNkMsY0FBVCxDQUF3QnBHLGNBQXhCLEVBQXdDQyxhQUF4QyxFQUF1RG1GLE1BQXZELEVBQ0E7QUFDSSxNQUFJO0FBQ0E7QUFDQSxRQUFJaUIseUJBQXlCLEdBQUdoRyxxREFBUyxDQUFDTyx3QkFBVixDQUFtQ1gsYUFBYSxDQUFDeUYsZ0NBQWpELENBQWhDLENBRkEsQ0FHQTs7QUFFQSxRQUFJM0Isb0NBQW9DLEdBQUcxRCxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDcUYsbUNBQXBELEVBQXlGcEYsYUFBYSxDQUFDcUYsNENBQXZHLENBQTNDO0FBQ0EsUUFBSUosNEJBQTRCLEdBQUc3RSxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDc0IsMkJBQXBELEVBQWlGckIsYUFBYSxDQUFDc0Isb0NBQS9GLENBQW5DO0FBQ0EsUUFBSTRELG9DQUFvQyxHQUFHOUUscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNOLGNBQWMsQ0FBQ3lCLG1DQUFwRCxFQUF5RnhCLGFBQWEsQ0FBQ3lCLDRDQUF2RyxDQUEzQztBQUNBLFFBQUk0RSwwQkFBMEIsR0FBR2pHLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDNEUsNEJBQXJDLEVBQW1FQyxvQ0FBbkUsQ0FBakM7QUFDQSxRQUFJb0Isa0NBQWtDLEdBQUdsRyxxREFBUyxDQUFDQywwQkFBVixDQUFxQ3lELG9DQUFyQyxFQUEyRXVDLDBCQUEzRSxDQUF6QztBQUNBLFFBQUkzQiwrQkFBK0IsR0FBR3RFLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUM2Riw4QkFBcEQsRUFBb0Y1RixhQUFhLENBQUM2Rix1Q0FBbEcsQ0FBdEM7QUFDQW5CLG1DQUErQixHQUFHdEUscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNxRSwrQkFBckMsRUFBc0UyQiwwQkFBdEUsQ0FBbEM7QUFDQSxRQUFJcEMsa0JBQWtCLEdBQUc3RCxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDdUYsaUJBQXBELEVBQXVFdEYsYUFBYSxDQUFDdUYsMEJBQXJGLENBQXpCO0FBQ0F0QixzQkFBa0IsR0FBRzdELHFEQUFTLENBQUN1QiwwQkFBVixDQUFxQ3NDLGtCQUFyQyxFQUF5RFMsK0JBQXpELENBQXJCO0FBQ0EsUUFBSTZCLG9CQUFvQixHQUFHbkcscURBQVMsQ0FBQ3VCLDBCQUFWLENBQXFDNUIsY0FBYyxDQUFDaUgsdUJBQXBELEVBQTZFVixrQ0FBN0UsQ0FBM0I7QUFDQSxRQUFJRywyQkFBMkIsR0FBR3JHLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDNEQsa0JBQXJDLEVBQXlEc0Msb0JBQXpELENBQWxDLENBZkEsQ0FnQkE7QUFHQTs7QUFDQSxRQUFJRyxnQkFBZ0IsR0FBR3RHLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDRCxxREFBUyxDQUFDTyx3QkFBVixDQUFtQ1osY0FBYyxDQUFDeUYsdUJBQWxELENBQXJDLEVBQWlIekYsY0FBYyxDQUFDaUgsdUJBQWhJLENBQXZCLENBcEJBLENBcUJBOztBQUVBLFFBQUlMLHNCQUFzQixHQUFHdkcscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUMrRix5QkFBckMsRUFBZ0VNLGdCQUFoRSxDQUE3QixDQXZCQSxDQXVCZ0g7O0FBQ2hILFFBQUlFLGFBQWEsR0FBR3hHLHFEQUFTLENBQUNpRCxrQkFBVixDQUE2QmlELGtDQUE3QixFQUFpRW5CLE1BQWpFLEVBQXlFd0Isc0JBQXpFLENBQXBCO0FBQ0EsUUFBSXBDLHVCQUF1QixHQUFHbkUscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNOLGNBQWMsQ0FBQzJGLHNCQUFwRCxFQUE0RTFGLGFBQWEsQ0FBQzJGLCtCQUExRixDQUE5QjtBQUNBLFFBQUlrQixxQkFBcUIsR0FBR3pHLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDa0UsdUJBQXJDLEVBQThEOEIsMEJBQTlELENBQTVCO0FBQ0EsUUFBSTFELHFCQUFxQixHQUFHMUIsc0RBQVUsQ0FBQzJCLGtCQUFYLENBQThCN0MsY0FBYyxDQUFDNkYsOEJBQWYsQ0FBOEMsQ0FBOUMsRUFBaUQ5RSxNQUEvRSxFQUF1RmYsY0FBYyxDQUFDNkYsOEJBQWYsQ0FBOEM5RSxNQUFySSxDQUE1QjtBQUVBLFFBQUltRyxRQUFRLEdBQUc3RyxxREFBUyxDQUFDeUMsMEJBQVYsQ0FDWEYscUJBRFcsRUFFVDhELDJCQUZTLEVBR1RJLHFCQUhTLEVBSVRELGFBSlMsRUFLVDVHLGFBQWEsQ0FBQzhGLHdCQUxMLEVBTVQvRixjQUFjLENBQUNjLGVBTk4sRUFPVGIsYUFBYSxDQUFDa0gsd0JBUEwsQ0FBZjtBQVVBLFdBQU9ELFFBQVA7QUFDSCxHQXhDRCxDQXdDRSxPQUFPM0QsRUFBUCxFQUFXO0FBQ1RDLHNEQUFNLENBQUNDLGlDQUFQLENBQXlDRixFQUF6QyxFQUE2QyxzQ0FBN0M7QUFDQSxVQUFNQSxFQUFOO0FBQ0g7QUFDSjs7QUFFVTBDLHVFQUFmLEU7Ozs7Ozs7Ozs7Ozs7OztBQ2hIQSxJQUFNekMsTUFBTSxHQUFHO0FBQ1g0RCxzQ0FBb0MsRUFBRSw4Q0FBQ3pGLE9BQUQsRUFBVTBGLHFCQUFWLEVBQW9DO0FBQ3RFLFFBQUlDLEtBQUssR0FBRyxJQUFJQyxLQUFKLENBQVU1RixPQUFWLENBQVo7QUFDQTZCLFVBQU0sQ0FBQ0MsaUNBQVAsQ0FBeUM2RCxLQUF6QyxFQUFnREQscUJBQWhEO0FBQ0EsV0FBT0MsS0FBUDtBQUNILEdBTFU7QUFNWDdELG1DQUFpQyxFQUFFLDJDQUFDNkQsS0FBRCxFQUFRRCxxQkFBUixFQUFrQztBQUNqRSxRQUFJLENBQUNDLEtBQUssQ0FBQ0UsMEJBQVgsRUFDSUYsS0FBSyxDQUFDRSwwQkFBTixHQUFtQyxJQUFJQyxLQUFKLEVBQW5DO0FBQ0pILFNBQUssQ0FBQ0UsMEJBQU4sQ0FBaUNFLElBQWpDLENBQXNDTCxxQkFBdEM7QUFDSCxHQVZVO0FBV1hNLGVBQWEsRUFBRSx1QkFBQ0MsS0FBRCxFQUFRQyxTQUFSLEVBQXNCO0FBQ2pDLFFBQUlELEtBQUssS0FBSyxJQUFWLElBQWtCQSxLQUFLLEtBQUssRUFBNUIsSUFBa0NBLEtBQUssS0FBSyxDQUFoRCxFQUNJLE1BQU0sSUFBSUwsS0FBSixXQUFhTSxTQUFiLHVCQUFOO0FBRUosV0FBTyxJQUFQO0FBQ0gsR0FoQlU7QUFrQlhDLEtBQUcsRUFBQyxhQUFDQyxHQUFELEVBQTZCO0FBQUEsUUFBdkJDLFVBQXVCLHVFQUFWLEtBQVU7QUFDN0IsV0FBTyxJQUFJQyxPQUFKLENBQVksVUFBVUMsT0FBVixFQUFtQkMsTUFBbkIsRUFBMkI7QUFDMUM7QUFDQSxVQUFJQyxPQUFPLEdBQUcsSUFBSUMsY0FBSixFQUFkO0FBRUEsVUFBTUMsV0FBVyxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLFFBQTNCLElBQXVDLFFBQTNEO0FBRUFMLGFBQU8sQ0FBQ00sSUFBUixDQUFhLEtBQWIsRUFBb0JYLEdBQUcsR0FBRyxLQUFOLEdBQWNPLFdBQWxDLEVBQStDLElBQS9DOztBQUVBRixhQUFPLENBQUNPLE1BQVIsR0FBaUIsWUFBWTtBQUN6QixZQUFJUCxPQUFPLENBQUNRLE1BQVIsS0FBbUIsR0FBdkIsRUFBNEI7QUFDeEIsY0FBSVosVUFBSixFQUFnQjtBQUNaRSxtQkFBTyxDQUFDVyxJQUFJLENBQUNDLEtBQUwsQ0FBV1YsT0FBTyxDQUFDVyxRQUFuQixDQUFELENBQVA7QUFDSCxXQUZELE1BRU87QUFDSGIsbUJBQU8sQ0FBQ0UsT0FBTyxDQUFDVyxRQUFULENBQVA7QUFDSDtBQUNKLFNBTkQsTUFNTyxJQUFHWCxPQUFPLENBQUNRLE1BQVIsR0FBaUIsQ0FBcEIsRUFBdUI7QUFDMUJULGdCQUFNLENBQUNDLE9BQUQsQ0FBTjtBQUNIO0FBQ0osT0FWRDs7QUFZQUEsYUFBTyxDQUFDWSxPQUFSLEdBQWtCLFlBQVk7QUFDMUJiLGNBQU0sQ0FBQzNFLE1BQU0sQ0FBQzRELG9DQUFQLENBQTRDLHdCQUE1QyxFQUFzRSxzQ0FBdEUsQ0FBRCxDQUFOO0FBQ0gsT0FGRDs7QUFJQWdCLGFBQU8sQ0FBQ2EsSUFBUjtBQUNILEtBekJNLENBQVA7QUEwQkgsR0E3Q1U7QUErQ1hDLE1BQUksRUFBQyxjQUFDbkIsR0FBRCxFQUFNb0IsT0FBTixFQUFrQjtBQUNuQixXQUFPLElBQUlsQixPQUFKLENBQVksVUFBVUMsT0FBVixFQUFtQkMsTUFBbkIsRUFBMkI7QUFDMUMsVUFBSUMsT0FBTyxHQUFHLElBQUlDLGNBQUosRUFBZDtBQUNBRCxhQUFPLENBQUNNLElBQVIsQ0FBYSxNQUFiLEVBQXFCWCxHQUFyQixFQUEwQixJQUExQjtBQUVESyxhQUFPLENBQUNnQixnQkFBUixDQUF5QixjQUF6QixFQUF5QyxrREFBekM7O0FBRUNoQixhQUFPLENBQUNpQixrQkFBUixHQUE2QixZQUFZO0FBQ3JDLFlBQUlqQixPQUFPLENBQUNrQixVQUFSLEtBQXVCLENBQTNCLEVBQThCO0FBQzFCLGNBQUlsQixPQUFPLENBQUNRLE1BQVIsS0FBbUIsR0FBdkIsRUFBNEI7QUFDeEIsZ0JBQUk5RCxNQUFNLEdBQUdzRCxPQUFPLENBQUNXLFFBQXJCOztBQUNBLGdCQUFJakUsTUFBSixFQUFZO0FBQ1Isa0JBQUk7QUFDQUEsc0JBQU0sR0FBRytELElBQUksQ0FBQ0MsS0FBTCxDQUFXaEUsTUFBWCxDQUFUO0FBQ0gsZUFGRCxDQUdBLGdCQUFNLENBQUc7QUFDWjs7QUFDRG9ELG1CQUFPLENBQUNwRCxNQUFELENBQVA7QUFDSCxXQVRELE1BU08sSUFBR3NELE9BQU8sQ0FBQ1EsTUFBUixHQUFpQixDQUFwQixFQUF1QjtBQUMxQjtBQUNBVCxrQkFBTSxDQUFDQyxPQUFELENBQU47QUFDSDtBQUNKO0FBQ0osT0FoQkQ7O0FBa0JBLFVBQU1tQixPQUFPLEdBQUdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZTixPQUFaLEVBQXFCTyxHQUFyQixDQUF5QixVQUFBQyxHQUFHLEVBQUk7QUFDNUMsWUFBSSxRQUFRUixPQUFPLENBQUNRLEdBQUQsQ0FBZixNQUEwQixRQUE5QixFQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFPQyxrQkFBa0IsQ0FBQ0QsR0FBRCxDQUFsQixHQUEwQixHQUExQixHQUFnQ2QsSUFBSSxDQUFDZ0IsU0FBTCxDQUFlVixPQUFPLENBQUNRLEdBQUQsQ0FBdEIsQ0FBdkM7QUFDSCxTQVJELE1BUU87QUFDSCxpQkFBT0Msa0JBQWtCLENBQUNELEdBQUQsQ0FBbEIsR0FBMEIsR0FBMUIsR0FBZ0NDLGtCQUFrQixDQUFDVCxPQUFPLENBQUNRLEdBQUQsQ0FBUixDQUF6RDtBQUNIO0FBQ0osT0FaZSxFQVliRyxJQVphLENBWVIsR0FaUSxDQUFoQjs7QUFjQTFCLGFBQU8sQ0FBQ1ksT0FBUixHQUFrQixZQUFZO0FBQzFCYixjQUFNLENBQUMzRSxNQUFNLENBQUM0RCxvQ0FBUCxDQUE0Qyx5QkFBNUMsRUFBc0Usc0NBQXRFLENBQUQsQ0FBTixDQUQwQixDQUM0RjtBQUN6SCxPQUZEOztBQUlBZ0IsYUFBTyxDQUFDYSxJQUFSLENBQWFNLE9BQWI7QUFDSCxLQTNDTSxDQUFQO0FBNENIO0FBNUZVLENBQWY7QUErRmUvRixxRUFBZixFOzs7Ozs7Ozs7Ozs7QUMvRkE7QUFBQTtBQUFBO0FBRUEsSUFBTXRDLFVBQVUsR0FBRztBQUNmNkksa0JBQWdCLEVBQUUsMEJBQUNuQyxLQUFELEVBQVc7QUFDekIsUUFBSTtBQUNBLFVBQUlvQyxLQUFLLEdBQUcsQ0FBWjtBQURBO0FBQUE7QUFBQTs7QUFBQTtBQUVBLDZCQUFrQnBDLEtBQWxCLDhIQUF5QjtBQUFBLGNBQWhCcUMsS0FBZ0I7QUFDckJELGVBQUssSUFBSXZDLEtBQUssQ0FBQ3lDLE9BQU4sQ0FBY0QsS0FBZCxJQUF1QkEsS0FBSyxDQUFDbEosTUFBN0IsR0FBc0MsQ0FBL0M7QUFDSDtBQUpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBTUEsYUFBT2lKLEtBQVA7QUFDSCxLQVBELENBT0UsT0FBT3pHLEVBQVAsRUFBVztBQUNUQyx3REFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsWUFBTUEsRUFBTjtBQUNIO0FBQ0osR0FiYztBQWVmNEcsb0JBQWtCLEVBQUUsNEJBQUNDLFdBQUQsRUFBaUI7QUFDakMsUUFBSTtBQUNBLFVBQUl0RixNQUFNLEdBQUcsSUFBSTJDLEtBQUosRUFBYjtBQURBO0FBQUE7QUFBQTs7QUFBQTtBQUdBLDhCQUFrQjJDLFdBQWxCO0FBQUEsY0FBU0gsS0FBVDtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUNJLGtDQUFxQkEsS0FBckI7QUFBQSxrQkFBU0ksUUFBVDtBQUNJdkYsb0JBQU0sQ0FBQzRDLElBQVAsQ0FBWTJDLFFBQVo7QUFESjtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBT0EsYUFBT3ZGLE1BQVA7QUFDSCxLQVJELENBUUUsT0FBT3ZCLEVBQVAsRUFBVztBQUNUQyx3REFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsWUFBTUEsRUFBTjtBQUNIO0FBQ0osR0E1QmM7QUE4QmZWLG9CQUFrQixFQUFFLDRCQUFDN0IsS0FBRCxFQUFRSCxNQUFSLEVBQWdCb0osS0FBaEIsRUFBMEI7QUFDMUMsUUFBSTtBQUNBLFVBQUlLLEtBQUssR0FBRyxJQUFJN0MsS0FBSixFQUFaO0FBQ0EsVUFBSThDLE9BQU8sR0FBRyxJQUFJOUMsS0FBSixFQUFkOztBQUVBLFdBQUssSUFBSStDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUd4SixLQUFwQixFQUEyQndKLENBQUMsRUFBNUI7QUFDSUQsZUFBTyxDQUFDN0MsSUFBUixDQUFhdUMsS0FBSyxLQUFLUSxTQUFWLElBQXVCUixLQUFLLEtBQUssSUFBakMsR0FBd0NPLENBQXhDLEdBQTRDUCxLQUF6RDtBQURKOztBQUdBLFdBQUssSUFBSVMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRzdKLE1BQXBCLEVBQTRCNkosQ0FBQyxFQUE3QjtBQUNJSixhQUFLLENBQUM1QyxJQUFOLENBQVc2QyxPQUFYO0FBREo7O0FBR0EsYUFBT0QsS0FBUDtBQUNILEtBWEQsQ0FXRSxPQUFPL0csRUFBUCxFQUFXO0FBQ1RDLHdEQUFNLENBQUNDLGlDQUFQLENBQXlDRixFQUF6QyxFQUE2QyxzQ0FBN0M7QUFDQSxZQUFNQSxFQUFOO0FBQ0g7QUFDSixHQTlDYztBQWdEZm9ILG9CQUFrQixFQUFFLDRCQUFDQyxNQUFELEVBQVNDLE1BQVQsRUFBb0I7QUFDcEMsUUFBSTtBQUNBLFVBQUlELE1BQU0sQ0FBQzdKLE1BQVAsS0FBa0I4SixNQUFNLENBQUM5SixNQUE3QixFQUNJLE9BQU8sS0FBUDtBQUVKLFVBQUkrRCxNQUFNLEdBQUcsSUFBYjs7QUFDQSxXQUFLLElBQUlnRyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHRixNQUFNLENBQUM3SixNQUEzQixFQUFtQytKLENBQUMsRUFBcEMsRUFBd0M7QUFDcEMsWUFBSUYsTUFBTSxDQUFDRSxDQUFELENBQU4sS0FBY0QsTUFBTSxDQUFDQyxDQUFELENBQXhCLEVBQTZCO0FBQ3pCaEcsZ0JBQU0sR0FBRyxLQUFUO0FBQ0E7QUFDSDtBQUNKOztBQUVELGFBQU9BLE1BQVA7QUFDSCxLQWJELENBYUUsT0FBT3ZCLEVBQVAsRUFBVztBQUNUQyx3REFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsWUFBTUEsRUFBTjtBQUNIO0FBQ0osR0FsRWM7QUFrRWI7QUFDRnhCLG9CQUFrQixFQUFFLDRCQUFDZ0osS0FBRCxFQUFRZixLQUFSLEVBQWVnQixHQUFmLEVBQW9CQyxHQUFwQixFQUNwQjtBQUNJLFFBQUk7QUFDQSxVQUFJQyxPQUFPLEdBQUcsR0FBZDtBQUNBLFVBQUlDLE9BQU8sR0FBRyxDQUFkLENBRkEsQ0FJQTs7QUFDQSxVQUFJbkIsS0FBSyxHQUFHLENBQVIsSUFBYUEsS0FBSyxHQUFHa0IsT0FBckIsSUFBZ0NGLEdBQUcsR0FBR0csT0FBdEMsSUFBaURILEdBQUcsR0FBR0UsT0FBdkQsSUFBa0VELEdBQUcsR0FBR0UsT0FBeEUsSUFBbUZGLEdBQUcsR0FBR0MsT0FBekYsSUFBb0dGLEdBQUcsR0FBR0MsR0FBOUcsRUFDSSxNQUFNekgsa0RBQU0sQ0FBQzRELG9DQUFQLENBQTRDLDBCQUE1QyxFQUF3RSxzQ0FBeEUsQ0FBTixDQU5KLENBUUE7O0FBQ0EsVUFBSXZHLE1BQU0sR0FBR2tLLEtBQUssQ0FBQ2hLLE1BQW5CO0FBQ0EsVUFBSUMsS0FBSyxHQUFHK0osS0FBSyxDQUFDLENBQUQsQ0FBTCxDQUFTaEssTUFBckIsQ0FWQSxDQVlBOztBQUNBLFVBQUlxSyxNQUFNLEdBQUcsSUFBSTNELEtBQUosRUFBYjs7QUFFQSxXQUFLLElBQUk0RCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHeEssTUFBcEIsRUFBNEJ3SyxDQUFDLEVBQTdCO0FBQ0ksWUFBSU4sS0FBSyxDQUFDTSxDQUFELENBQUwsQ0FBU3RLLE1BQVQsS0FBb0JDLEtBQXhCLEVBQ0lvSyxNQUFNLENBQUMxRCxJQUFQLENBQVkyRCxDQUFaO0FBRlI7O0FBSUEsVUFBSUQsTUFBTSxDQUFDckssTUFBUCxHQUFnQixDQUFwQixFQUNJLE1BQU15QyxrREFBTSxDQUFDNEQsb0NBQVAsQ0FBNEMsMENBQTVDLEVBQXdGLHNDQUF4RixDQUFOO0FBRUpnRSxZQUFNLEdBQUcsSUFBVCxDQXRCQSxDQXdCQTs7QUFDQSxVQUFJRSxPQUFPLEdBQUcsSUFBSTdELEtBQUosQ0FBVXpHLEtBQVYsQ0FBZDtBQUNBLFVBQUl1SyxNQUFNLEdBQUcsSUFBSTlELEtBQUosRUFBYjtBQUNBLFVBQUkrRCxJQUFJLEdBQUcsQ0FBWDtBQUNBLFVBQUlDLElBQUksR0FBRyxDQUFYO0FBQ0EsVUFBSUMsT0FBTyxHQUFHLENBQWQ7QUFDQSxVQUFJQyxHQUFHLEdBQUcsQ0FBVjtBQUNBLFVBQUlDLElBQUksR0FBRyxDQUFYO0FBQ0EsVUFBSUMsR0FBRyxHQUFHLENBQVY7QUFDQSxVQUFJQyxLQUFLLEdBQUcsQ0FBWixDQWpDQSxDQW1DQTs7QUFDQSxVQUFJQyxPQUFPLEdBQUc3SyxVQUFVLENBQUM4SyxhQUFYLENBQXlCaEwsS0FBekIsRUFBZ0MsQ0FBaEMsRUFBbUNBLEtBQW5DLENBQWQsQ0FwQ0EsQ0FvQ3dEO0FBRXhEOztBQUNBLFVBQUlpTCxHQUFHLEdBQUcvSyxVQUFVLENBQUM4SyxhQUFYLENBQXlCaEwsS0FBekIsRUFBZ0MsQ0FBaEMsRUFBbUNrSyxPQUFuQyxDQUFWLENBdkNBLENBdUNzRDtBQUV0RDs7QUFDQSxVQUFJZ0IsUUFBUSxHQUFHLElBQUl6RSxLQUFKLEVBQWY7O0FBRUEsV0FBSyxJQUFJNEQsRUFBQyxHQUFHTCxHQUFiLEVBQWtCSyxFQUFDLEdBQUdKLEdBQXRCLEVBQTJCSSxFQUFDLEVBQTVCO0FBQ0lhLGdCQUFRLENBQUN4RSxJQUFULENBQWMyRCxFQUFkO0FBREosT0E1Q0EsQ0ErQ0E7OztBQUNBLFdBQUssSUFBSVAsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRzlKLEtBQXBCLEVBQTJCOEosQ0FBQyxFQUE1QixFQUFnQztBQUM1QixZQUFJcUIsS0FBSyxHQUFHRCxRQUFRLENBQUNFLEtBQVQsQ0FBZSxDQUFmLENBQVosQ0FENEIsQ0FDRTtBQUU5Qjs7QUFDQSxhQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUd4TCxNQUFwQixFQUE0QndMLENBQUMsRUFBN0IsRUFBaUM7QUFDN0IsY0FBSUMsQ0FBQyxHQUFHSCxLQUFLLENBQUNJLEtBQU4sR0FBYyxDQUF0Qjs7QUFFQSxhQUFHO0FBQ0MsZ0JBQUlKLEtBQUssQ0FBQ0csQ0FBRCxDQUFMLEtBQWF2QixLQUFLLENBQUNzQixDQUFELENBQUwsQ0FBU04sT0FBTyxDQUFDakIsQ0FBRCxDQUFoQixDQUFqQixFQUF1QztBQUNuQ3FCLG1CQUFLLENBQUNLLE1BQU4sQ0FBYUYsQ0FBYixFQUFnQixDQUFoQjtBQUNBQSxlQUFDO0FBQ0o7O0FBRURBLGFBQUM7QUFFSixXQVJELFFBUVNBLENBQUMsSUFBSSxDQVJkO0FBU0g7O0FBRURoQixlQUFPLENBQUNSLENBQUQsQ0FBUCxHQUFhcUIsS0FBSyxDQUFDcEwsTUFBTixHQUFlLENBQTVCO0FBQ0EySyxlQUFPLEdBQUd4SyxVQUFVLENBQUN3SyxPQUFYLENBQW1CLENBQW5CLEVBQXNCUyxLQUFLLENBQUNwTCxNQUE1QixDQUFWO0FBQ0F3SyxjQUFNLENBQUM3RCxJQUFQLENBQVl5RSxLQUFLLENBQUNULE9BQUQsQ0FBakI7QUFDSCxPQXJFRCxDQXVFQTs7O0FBQ0EsV0FBSyxJQUFJWixFQUFDLEdBQUcsQ0FBYixFQUFnQkEsRUFBQyxHQUFHOUosS0FBcEIsRUFBMkI4SixFQUFDLEVBQTVCLEVBQWdDO0FBQzVCLFlBQUlRLE9BQU8sQ0FBQ1IsRUFBRCxDQUFYLEVBQWdCO0FBQ1pVLGNBQUksR0FBR0QsTUFBTSxDQUFDVCxFQUFELENBQWI7QUFDQWEsYUFBRyxHQUFHYixFQUFOO0FBQ0FlLGFBQUcsR0FBR0UsT0FBTyxDQUFDakIsRUFBRCxDQUFiO0FBQ0gsU0FKRCxNQUtLO0FBQ0w7QUFDSVcsZ0JBQUksR0FBR0YsTUFBTSxDQUFDVCxFQUFELENBQWI7QUFDQWMsZ0JBQUksR0FBR2QsRUFBUDtBQUNBZ0IsaUJBQUssR0FBR0MsT0FBTyxDQUFDakIsRUFBRCxDQUFmO0FBQ0g7QUFDSjs7QUFFRG1CLFNBQUcsQ0FBQ0osR0FBRCxDQUFILEdBQVdMLElBQVgsQ0F0RkEsQ0FzRmtCOztBQUVsQixhQUFPUyxHQUFQO0FBQ0gsS0F6RkQsQ0F5RkUsT0FBTzFJLEVBQVAsRUFBVztBQUNUQyx3REFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsWUFBTUEsRUFBTjtBQUNIO0FBQ0osR0FsS2M7QUFtS2ZwQyxhQUFXLEVBQUUscUJBQUNzTCxJQUFELEVBQU96QyxLQUFQLEVBQWNnQixHQUFkLEVBQW1CQyxHQUFuQixFQUEyQjtBQUNwQyxRQUFJO0FBQ0EsVUFBSWhLLE1BQU0sR0FBR3dMLElBQUksQ0FBQzFMLE1BQWxCLENBREEsQ0FHQTs7QUFDQSxVQUFJMkwsTUFBTSxHQUFHeEwsVUFBVSxDQUFDeUwsT0FBWCxDQUFtQjNDLEtBQW5CLEVBQTBCZ0IsR0FBMUIsRUFBK0JDLEdBQS9CLENBQWI7QUFFQSxVQUFJZ0IsR0FBRyxHQUFHLElBQUl4RSxLQUFKLEVBQVYsQ0FOQSxDQVFBOztBQUNBLFdBQUssSUFBSTRELENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdKLEdBQXBCLEVBQXlCSSxDQUFDLEVBQTFCLEVBQThCO0FBQzFCLFlBQUlwSyxNQUFNLEdBQUdvSyxDQUFiLEVBQ0lZLEdBQUcsQ0FBQ3ZFLElBQUosQ0FBUytFLElBQUksQ0FBQ3BCLENBQUQsQ0FBYixFQURKLEtBR0lZLEdBQUcsQ0FBQ3ZFLElBQUosQ0FBU2dGLE1BQU0sQ0FBQ3JCLENBQUQsQ0FBZjtBQUNQOztBQUVELGFBQU9ZLEdBQVA7QUFDSCxLQWpCRCxDQWlCRSxPQUFPMUksRUFBUCxFQUFXO0FBQ1RDLHdEQUFNLENBQUNDLGlDQUFQLENBQXlDRixFQUF6QyxFQUE2QyxzQ0FBN0M7QUFDQSxZQUFNQSxFQUFOO0FBQ0g7QUFDSixHQXpMYztBQTBMZm9KLFNBQU8sRUFBQyxpQkFBQzNDLEtBQUQsRUFBUWdCLEdBQVIsRUFBYUMsR0FBYixFQUFxQjtBQUN6QixRQUFJO0FBQ0EsVUFBSXJELEtBQUssR0FBRyxJQUFJSCxLQUFKLENBQVV1QyxLQUFWLENBQVo7O0FBRUEsV0FBSyxJQUFJNEMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRzVDLEtBQXBCLEVBQTJCNEMsQ0FBQyxFQUE1QjtBQUNJaEYsYUFBSyxDQUFDZ0YsQ0FBRCxDQUFMLEdBQVcxTCxVQUFVLENBQUN3SyxPQUFYLENBQW1CVixHQUFuQixFQUF3QkMsR0FBeEIsQ0FBWDtBQURKOztBQUdBLGFBQU9yRCxLQUFQO0FBQ0gsS0FQRCxDQU9FLE9BQU9yRSxFQUFQLEVBQVc7QUFDVEMsd0RBQU0sQ0FBQ0MsaUNBQVAsQ0FBeUNGLEVBQXpDLEVBQTZDLHNDQUE3QztBQUNBLFlBQU1BLEVBQU47QUFDSDtBQUNKLEdBdE1jO0FBdU1mO0FBQ0F5SSxlQUFhLEVBQUUsdUJBQUNoQyxLQUFELEVBQVFnQixHQUFSLEVBQWFDLEdBQWIsRUFBcUI7QUFDaEMsUUFBSTtBQUNBLFVBQUlBLEdBQUcsSUFBSUQsR0FBUCxJQUFjaEIsS0FBSyxHQUFHLENBQXRCLElBQ0E7QUFDQ0EsV0FBSyxHQUFHaUIsR0FBRyxHQUFHRCxHQUFkLElBQXFCQyxHQUFHLEdBQUdELEdBQU4sR0FBWSxDQUZ0QyxFQUUwQyxDQUd6QyxDQUxELENBSUk7QUFHSjs7O0FBQ0EsVUFBSTZCLFVBQVUsR0FBRyxFQUFqQixDQVRBLENBV0E7O0FBQ0EsV0FBSyxJQUFJQyxHQUFHLEdBQUc3QixHQUFHLEdBQUdqQixLQUFyQixFQUE0QjhDLEdBQUcsR0FBRzdCLEdBQWxDLEVBQXVDNkIsR0FBRyxFQUExQyxFQUE4QztBQUMxQyxZQUFJQyxhQUFhLEdBQUc3TCxVQUFVLENBQUN3SyxPQUFYLENBQW1CVixHQUFuQixFQUF3QjhCLEdBQUcsR0FBRyxDQUE5QixDQUFwQjtBQUVBLFlBQUlELFVBQVUsQ0FBQ0UsYUFBRCxDQUFWLEtBQThCLElBQWxDLEVBQ0k7QUFDQTtBQUNBRixvQkFBVSxDQUFDQyxHQUFELENBQVYsR0FBa0IsSUFBbEIsQ0FISixLQUtJRCxVQUFVLENBQUNFLGFBQUQsQ0FBVixHQUE0QixJQUE1QjtBQUNQLE9BckJELENBeUJBOzs7QUFDQSxVQUFJakksTUFBTSxHQUFHMEUsTUFBTSxDQUFDQyxJQUFQLENBQVlvRCxVQUFaLENBQWI7O0FBR0EsV0FBSyxJQUFJL0IsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR2QsS0FBcEIsRUFBMkJjLENBQUMsRUFBNUI7QUFDSWhHLGNBQU0sQ0FBQ2dHLENBQUQsQ0FBTixHQUFZa0MsUUFBUSxDQUFDbEksTUFBTSxDQUFDZ0csQ0FBRCxDQUFQLEVBQVksRUFBWixDQUFwQjtBQURKLE9BN0JBLENBZ0NBO0FBQ0E7QUFDQTs7O0FBQ0EsV0FBSyxJQUFJTyxDQUFDLEdBQUlyQixLQUFLLEdBQUcsQ0FBdEIsRUFBMEJxQixDQUFDLEdBQUcsQ0FBOUIsRUFBaUNBLENBQUMsRUFBbEMsRUFBc0M7QUFDbEMsWUFBSTRCLENBQUMsR0FBRy9MLFVBQVUsQ0FBQ3dLLE9BQVgsQ0FBbUIsQ0FBbkIsRUFBc0JMLENBQXRCLENBQVIsQ0FEa0MsQ0FDQTs7QUFDbEMsWUFBSTZCLEdBQUcsR0FBR3BJLE1BQU0sQ0FBQ21JLENBQUQsQ0FBaEI7QUFFQW5JLGNBQU0sQ0FBQ21JLENBQUQsQ0FBTixHQUFZbkksTUFBTSxDQUFDdUcsQ0FBRCxDQUFsQjtBQUNBdkcsY0FBTSxDQUFDdUcsQ0FBRCxDQUFOLEdBQVk2QixHQUFaO0FBQ0g7O0FBR0QsYUFBT3BJLE1BQVA7QUFDSCxLQTdDRCxDQTZDRSxPQUFPdkIsRUFBUCxFQUFXO0FBQ1RDLHdEQUFNLENBQUNDLGlDQUFQLENBQXlDRixFQUF6QyxFQUE2QyxzQ0FBN0M7QUFDQSxZQUFNQSxFQUFOO0FBQ0g7QUFDSixHQTFQYztBQTJQZjtBQUNBbUksU0FBTyxFQUFFLGlCQUFDVixHQUFELEVBQU1DLEdBQU4sRUFBYztBQUNuQixRQUFJO0FBQ0FELFNBQUcsR0FBR3pDLElBQUksQ0FBQzRFLElBQUwsQ0FBVW5DLEdBQVYsQ0FBTjtBQUNBQyxTQUFHLEdBQUcxQyxJQUFJLENBQUNDLEtBQUwsQ0FBV3lDLEdBQVgsQ0FBTixDQUZBLENBR0E7O0FBQ0EsYUFBT21DLFdBQVcsQ0FBQ3BDLEdBQUQsRUFBTUMsR0FBTixDQUFsQjtBQUNILEtBTEQsQ0FLRSxPQUFPMUgsRUFBUCxFQUFXO0FBQ1RDLHdEQUFNLENBQUNDLGlDQUFQLENBQXlDRixFQUF6QyxFQUE2QyxzQ0FBN0M7QUFDQSxZQUFNQSxFQUFOO0FBQ0g7QUFDSixHQXRRYztBQXVRZjhKLHVDQUFxQyxFQUFFLCtDQUFDeE0sTUFBRCxFQUFTRyxLQUFULEVBQWdCc00sSUFBaEIsRUFDdkM7QUFDSSxRQUFJO0FBQ0EsVUFBSXpNLE1BQU0sR0FBR0csS0FBVCxLQUFtQnNNLElBQUksQ0FBQ3ZNLE1BQTVCLEVBQ0ksTUFBTXlDLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0Qyx3QkFBNUMsRUFBc0Usc0NBQXRFLENBQU47QUFFSixVQUFJbUcsVUFBVSxHQUFHLElBQUk5RixLQUFKLEVBQWpCOztBQUNBLFdBQUssSUFBSXFELENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdqSyxNQUFwQixFQUE0QmlLLENBQUMsRUFBN0IsRUFBaUM7QUFDN0IsWUFBSTBDLFVBQVUsR0FBRyxJQUFJL0YsS0FBSixFQUFqQjs7QUFDQSxhQUFLLElBQUk0RSxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHckwsS0FBcEIsRUFBMkJxTCxDQUFDLEVBQTVCO0FBQ0ltQixvQkFBVSxDQUFDOUYsSUFBWCxDQUFnQjRGLElBQUksQ0FBQ3RNLEtBQUssR0FBRzhKLENBQVIsR0FBWXVCLENBQWIsQ0FBcEI7QUFESjs7QUFHQWtCLGtCQUFVLENBQUM3RixJQUFYLENBQWdCOEYsVUFBaEI7QUFDSDs7QUFFRCxhQUFPRCxVQUFQO0FBQ0gsS0FkRCxDQWNFLE9BQU9oSyxFQUFQLEVBQVc7QUFDVEMsd0RBQU0sQ0FBQ0MsaUNBQVAsQ0FBeUNGLEVBQXpDLEVBQTZDLHNDQUE3QztBQUNBLFlBQU1BLEVBQU47QUFDSDtBQUNKO0FBM1JjLENBQW5CO0FBOFJBOzs7Ozs7O0FBTUEsU0FBUzZKLFdBQVQsQ0FBcUJwQyxHQUFyQixFQUEwQkMsR0FBMUIsRUFBK0I7QUFDM0IsTUFBSXdDLElBQUksR0FBRyxDQUFYO0FBQ0EsTUFBSUMsS0FBSyxHQUFHekMsR0FBRyxHQUFHRCxHQUFsQjs7QUFDQSxNQUFJMEMsS0FBSyxHQUFHLENBQVosRUFBZTtBQUNYLFdBQU8xQyxHQUFQO0FBQ0g7O0FBRUQsTUFBSTJDLFdBQVcsR0FBR3BGLElBQUksQ0FBQzRFLElBQUwsQ0FBVTVFLElBQUksQ0FBQ3FGLElBQUwsQ0FBVUYsS0FBVixDQUFWLENBQWxCOztBQUNBLE1BQUlDLFdBQVcsR0FBRyxFQUFsQixFQUFzQjtBQUNsQixVQUFNLElBQUlFLFNBQUosQ0FBYyxpREFBZCxDQUFOO0FBQ0g7O0FBQ0QsTUFBSUMsWUFBWSxHQUFHdkYsSUFBSSxDQUFDNEUsSUFBTCxDQUFVUSxXQUFXLEdBQUcsQ0FBeEIsQ0FBbkI7QUFDQSxNQUFJSSxJQUFJLEdBQUd4RixJQUFJLENBQUN5RixHQUFMLENBQVMsQ0FBVCxFQUFZTCxXQUFaLElBQTJCLENBQXRDLENBWjJCLENBYTNCO0FBRUE7O0FBQ0EsTUFBSU0sU0FBUyxHQUFHLElBQUlDLFVBQUosQ0FBZUosWUFBZixDQUFoQjtBQUNBSyxRQUFNLENBQUNDLE1BQVAsQ0FBY0MsZUFBZCxDQUE4QkosU0FBOUI7QUFFQSxNQUFJSyxDQUFDLEdBQUcsQ0FBQ1IsWUFBWSxHQUFHLENBQWhCLElBQXFCLENBQTdCOztBQUNBLE9BQUssSUFBSXpDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUd5QyxZQUFwQixFQUFrQ3pDLENBQUMsRUFBbkMsRUFBdUM7QUFDbkNvQyxRQUFJLElBQUlRLFNBQVMsQ0FBQzVDLENBQUQsQ0FBVCxHQUFlOUMsSUFBSSxDQUFDeUYsR0FBTCxDQUFTLENBQVQsRUFBWU0sQ0FBWixDQUF2QjtBQUNBQSxLQUFDLElBQUksQ0FBTDtBQUNILEdBdkIwQixDQXlCM0I7OztBQUNBYixNQUFJLEdBQUdBLElBQUksR0FBR00sSUFBZDs7QUFFQSxNQUFJTixJQUFJLElBQUlDLEtBQVosRUFBbUI7QUFDZjtBQUNBLFdBQU9OLFdBQVcsQ0FBQ3BDLEdBQUQsRUFBTUMsR0FBTixDQUFsQjtBQUNILEdBL0IwQixDQWdDM0I7OztBQUNBLFNBQU9ELEdBQUcsR0FBR3lDLElBQWI7QUFDSDs7QUFFY3ZNLHlFQUFmLEU7Ozs7Ozs7Ozs7OztBQzFVQTtBQUFBLElBQUlxTixVQUFVLEdBQ2Q7QUFDQTtBQUU0QkMsa0JBQWdCLEVBQUUsQ0FBQyxFQUFELEVBQUssR0FBTCxFQUFVLEVBQVYsRUFBYyxHQUFkLEVBQW1CLEVBQW5CLEVBQXVCLEdBQXZCLEVBQTRCLEdBQTVCLEVBQWlDLEdBQWpDLEVBQXNDLEdBQXRDLEVBQTJDLEVBQTNDLEVBQStDLEVBQS9DLEVBQW1ELEdBQW5ELEVBQXdELEdBQXhELEVBQTZELEVBQTdELEVBQWlFLEdBQWpFLEVBQXNFLEVBQXRFLEVBQTBFLEVBQTFFLEVBQThFLEdBQTlFLEVBQW1GLEdBQW5GLEVBQXdGLEdBQXhGLEVBQTZGLEVBQTdGLEVBQWlHLEdBQWpHLEVBQXNHLEVBQXRHLEVBQTBHLEVBQTFHLEVBQThHLEVBQTlHLEVBQWtILEdBQWxILEVBQXVILEVBQXZILEVBQTJILEdBQTNILEVBQWdJLEVBQWhJLEVBQW9JLEdBQXBJLEVBQXlJLEdBQXpJLEVBQThJLEdBQTlJLEVBQW1KLEdBQW5KLEVBQXdKLEdBQXhKLEVBQTZKLEdBQTdKLEVBQWtLLEdBQWxLLEVBQXVLLENBQXZLLEVBQTBLLEdBQTFLLEVBQStLLEdBQS9LLEVBQW9MLEdBQXBMLEVBQXlMLEdBQXpMLEVBQThMLEVBQTlMLEVBQWtNLEVBQWxNLEVBQXNNLEdBQXRNLEVBQTJNLEdBQTNNLEVBQWdOLEdBQWhOLEVBQXFOLENBQXJOLEVBQXdOLEdBQXhOLEVBQTZOLEVBQTdOLEVBQWlPLEdBQWpPLEVBQXNPLEdBQXRPLEVBQTJPLEdBQTNPLEVBQWdQLEdBQWhQLEVBQXFQLEdBQXJQLEVBQTBQLENBQTFQLEVBQTZQLEVBQTdQLEVBQWlRLEdBQWpRLEVBQXNRLEdBQXRRLEVBQTJRLEVBQTNRLEVBQStRLEdBQS9RLEVBQW9SLEVBQXBSLEVBQXdSLEdBQXhSLEVBQTZSLEdBQTdSLEVBQWtTLEdBQWxTLEVBQXVTLEdBQXZTLEVBQTRTLEdBQTVTLEVBQWlULEVBQWpULEVBQXFULEVBQXJULEVBQXlULEVBQXpULEVBQTZULEdBQTdULENBRjlDO0FBRzRCQyxxQ0FBbUMsRUFBRSxDQUhqRTtBQUk0QkMsYUFBVyxFQUFFO0FBQ1RqSyxvQkFBZ0IsRUFBRSxDQUFDLENBQUMsQ0FBRCxFQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsQ0FBVixFQUFhLENBQWIsRUFBZ0IsQ0FBaEIsRUFBbUIsQ0FBbkIsRUFBc0IsQ0FBdEIsRUFBeUIsQ0FBekIsRUFBNEIsQ0FBNUIsQ0FBRCxDQURUO0FBRVRHLDRCQUF3QixFQUFFLENBQUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLEVBQWUsQ0FBZixFQUFpQixDQUFqQixFQUFtQixDQUFuQixDQUFELENBRmpCO0FBR1RaLGlDQUE2QixFQUFFLENBQUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLEVBQWUsQ0FBZixFQUFpQixDQUFqQixFQUFtQixDQUFuQixDQUFELENBSHRCO0FBSVRpQixhQUFTLEVBQUUsQ0FBQyxDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsR0FBUixFQUFZLEVBQVosRUFBZSxHQUFmLEVBQW1CLEVBQW5CLEVBQXNCLEdBQXRCLENBQUQsRUFBNEIsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEdBQVIsRUFBWSxHQUFaLEVBQWdCLEdBQWhCLEVBQW9CLEdBQXBCLEVBQXdCLEdBQXhCLENBQTVCLEVBQXlELENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULEVBQWEsRUFBYixFQUFnQixHQUFoQixFQUFvQixHQUFwQixFQUF3QixHQUF4QixDQUF6RCxFQUFzRixDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsRUFBUixFQUFXLEdBQVgsRUFBZSxFQUFmLEVBQWtCLENBQWxCLEVBQW9CLEVBQXBCLENBQXRGLEVBQThHLENBQUMsRUFBRCxFQUFJLEdBQUosRUFBUSxFQUFSLEVBQVcsRUFBWCxFQUFjLEVBQWQsRUFBaUIsQ0FBakIsRUFBbUIsR0FBbkIsQ0FBOUcsRUFBc0ksQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEVBQVIsRUFBVyxFQUFYLEVBQWMsR0FBZCxFQUFrQixHQUFsQixFQUFzQixFQUF0QixDQUF0SSxFQUFnSyxDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsRUFBVCxFQUFZLEdBQVosRUFBZ0IsR0FBaEIsRUFBb0IsRUFBcEIsRUFBdUIsQ0FBdkIsQ0FBaEssRUFBMEwsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEdBQVIsRUFBWSxHQUFaLEVBQWdCLEdBQWhCLEVBQW9CLEdBQXBCLEVBQXdCLEdBQXhCLENBQTFMLEVBQXVOLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxHQUFSLEVBQVksRUFBWixFQUFlLEVBQWYsRUFBa0IsRUFBbEIsRUFBcUIsRUFBckIsQ0FBdk4sRUFBZ1AsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEVBQVIsRUFBVyxHQUFYLEVBQWUsR0FBZixFQUFtQixFQUFuQixFQUFzQixHQUF0QixDQUFoUCxDQUpGO0FBS1RkLGVBQVcsRUFBRSxDQUFDLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFELEVBQWlCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqQixFQUFpQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakMsRUFBaUQsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpELEVBQWlFLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqRSxFQUFpRixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakYsRUFBaUcsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpHLEVBQWlILENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqSCxFQUFpSSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakksRUFBaUosQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpKLENBTEo7QUFNVHNDLHFCQUFpQixFQUFFLENBQUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQUQsRUFBaUIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpCLEVBQWlDLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqQyxFQUFpRCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakQsRUFBaUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpFLEVBQWlGLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqRixFQUFpRyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakcsRUFBaUgsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpILEVBQWlJLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqSSxFQUFpSixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakosQ0FOVjtBQVFUVCxtQkFBZSxFQUFFLENBQUMsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsRUFBYSxFQUFiLEVBQWdCLEVBQWhCLEVBQW1CLEVBQW5CLEVBQXNCLEVBQXRCLENBQUQsRUFBMkIsQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEVBQVAsRUFBVSxFQUFWLEVBQWEsR0FBYixFQUFpQixFQUFqQixFQUFvQixDQUFwQixDQUEzQixFQUFrRCxDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsR0FBUixFQUFZLEVBQVosRUFBZSxHQUFmLEVBQW1CLEVBQW5CLEVBQXNCLEdBQXRCLENBQWxELEVBQTZFLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULEVBQWEsRUFBYixFQUFnQixFQUFoQixFQUFtQixFQUFuQixFQUFzQixFQUF0QixDQUE3RSxFQUF1RyxDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sR0FBUCxFQUFXLEdBQVgsRUFBZSxFQUFmLEVBQWtCLEdBQWxCLEVBQXNCLEdBQXRCLENBQXZHLEVBQWtJLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULEVBQWEsRUFBYixFQUFnQixHQUFoQixFQUFvQixHQUFwQixFQUF3QixHQUF4QixDQUFsSSxFQUErSixDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsR0FBUixFQUFZLEdBQVosRUFBZ0IsQ0FBaEIsRUFBa0IsR0FBbEIsRUFBc0IsR0FBdEIsQ0FBL0osRUFBMEwsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEdBQVIsRUFBWSxFQUFaLEVBQWUsR0FBZixFQUFtQixHQUFuQixFQUF1QixHQUF2QixDQUExTCxFQUFzTixDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsQ0FBVCxFQUFXLEdBQVgsRUFBZSxHQUFmLEVBQW1CLEdBQW5CLEVBQXVCLEdBQXZCLENBQXROLEVBQWtQLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULEVBQWEsR0FBYixFQUFpQixHQUFqQixFQUFxQixHQUFyQixFQUF5QixDQUF6QixDQUFsUCxDQVJSO0FBU1RMLDBCQUFzQixFQUFFLENBQUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLEVBQWUsQ0FBZixFQUFpQixDQUFqQixFQUFtQixDQUFuQixDQUFELENBVGY7QUFVVEUsa0NBQThCLEVBQUUsQ0FBQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsRUFBZSxDQUFmLEVBQWlCLENBQWpCLEVBQW1CLENBQW5CLENBQUQsQ0FWdkI7QUFXVFIsdUNBQW1DLEVBQUUsQ0FBQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsRUFBZSxDQUFmLEVBQWlCLENBQWpCLEVBQW1CLENBQW5CLENBQUQsQ0FYNUI7QUFZVEUscUJBQWlCLEVBQUUsQ0FBQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBRCxFQUFpQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakIsRUFBaUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpDLEVBQWlELENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqRCxFQUFpRSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakUsRUFBaUYsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpGLEVBQWlHLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqRyxFQUFpSCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakgsRUFBaUksQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpJLEVBQWlKLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqSixDQVpWO0FBYVQwQiwyQkFBdUIsRUFBRSxDQUFDLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFELEVBQWlCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqQixFQUFpQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakMsRUFBaUQsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpELEVBQWlFLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqRSxFQUFpRixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakYsRUFBaUcsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpHLEVBQWlILENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqSCxFQUFpSSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakksRUFBaUosQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpKLENBYmhCO0FBY1R2RSxpQ0FBNkIsRUFBRSxDQUFDLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixFQUFlLENBQWYsRUFBaUIsQ0FBakIsRUFBbUIsQ0FBbkIsQ0FBRCxDQWR0QjtBQWVUTyx5Q0FBcUMsRUFBRSxDQUFDLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixFQUFlLENBQWYsRUFBaUIsQ0FBakIsRUFBbUIsQ0FBbkIsQ0FBRCxDQWY5QjtBQWdCVFYsa0NBQThCLEVBQUUsQ0FBQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsRUFBZSxDQUFmLEVBQWlCLENBQWpCLEVBQW1CLENBQW5CLENBQUQsQ0FoQnZCO0FBaUJUSCw2QkFBeUIsRUFBRSxDQUFDLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFELEVBQWlCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqQixFQUFpQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakMsRUFBaUQsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpELEVBQWlFLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqRSxFQUFpRixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakYsRUFBaUcsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpHLEVBQWlILENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqSCxFQUFpSSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakksRUFBaUosQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpKLENBakJsQjtBQWtCVGdCLDRCQUF3QixFQUFFLENBQUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQUQsRUFBaUIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpCLEVBQWlDLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqQyxFQUFpRCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakQsRUFBaUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpFLEVBQWlGLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqRixFQUFpRyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakcsRUFBaUgsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpILEVBQWlJLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqSSxFQUFpSixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakosQ0FsQmpCO0FBb0JUNEIsYUFBUyxFQUFFLENBQUMsQ0FBQyxHQUFELEVBQUssQ0FBTCxFQUFPLEdBQVAsRUFBVyxHQUFYLEVBQWUsR0FBZixFQUFtQixFQUFuQixFQUFzQixHQUF0QixDQUFELEVBQTRCLENBQUMsRUFBRCxFQUFJLEdBQUosRUFBUSxHQUFSLEVBQVksRUFBWixFQUFlLENBQWYsRUFBaUIsRUFBakIsRUFBb0IsR0FBcEIsQ0FBNUIsRUFBcUQsQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEVBQVAsRUFBVSxHQUFWLEVBQWMsRUFBZCxFQUFpQixHQUFqQixFQUFxQixHQUFyQixDQUFyRCxFQUErRSxDQUFDLENBQUQsRUFBRyxHQUFILEVBQU8sR0FBUCxFQUFXLEdBQVgsRUFBZSxHQUFmLEVBQW1CLEdBQW5CLEVBQXVCLEdBQXZCLENBQS9FLEVBQTJHLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULEVBQWEsR0FBYixFQUFpQixHQUFqQixFQUFxQixHQUFyQixFQUF5QixFQUF6QixDQUEzRyxFQUF3SSxDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsRUFBUixFQUFXLEdBQVgsRUFBZSxHQUFmLEVBQW1CLENBQW5CLEVBQXFCLEdBQXJCLENBQXhJLEVBQWtLLENBQUMsRUFBRCxFQUFJLEdBQUosRUFBUSxFQUFSLEVBQVcsR0FBWCxFQUFlLEdBQWYsRUFBbUIsRUFBbkIsRUFBc0IsR0FBdEIsQ0FBbEssRUFBNkwsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsRUFBYSxHQUFiLEVBQWlCLEdBQWpCLEVBQXFCLEdBQXJCLEVBQXlCLEVBQXpCLENBQTdMLEVBQTBOLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULEVBQVksR0FBWixFQUFnQixFQUFoQixFQUFtQixHQUFuQixFQUF1QixFQUF2QixDQUExTixFQUFxUCxDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsR0FBUixFQUFZLEdBQVosRUFBZ0IsRUFBaEIsRUFBbUIsRUFBbkIsRUFBc0IsRUFBdEIsQ0FBclAsQ0FwQkY7QUFxQlRWLHFCQUFpQixFQUFFLENBQUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQUQsRUFBaUIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpCLEVBQWlDLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqQyxFQUFpRCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakQsRUFBaUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpFLEVBQWlGLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqRixFQUFpRyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakcsRUFBaUgsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpILEVBQWlJLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqSSxFQUFpSixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakosQ0FyQlY7QUFzQlQvRCx5QkFBcUIsRUFBRSxDQUFDLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixFQUFlLENBQWYsRUFBaUIsQ0FBakIsRUFBbUIsQ0FBbkIsQ0FBRCxDQXRCZDtBQXVCVEcsaUNBQTZCLEVBQUUsQ0FBQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsRUFBZSxDQUFmLEVBQWlCLENBQWpCLEVBQW1CLENBQW5CLENBQUQsQ0F2QnRCO0FBeUJUWSwrQkFBMkIsRUFBRSxDQUFDLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixFQUFlLENBQWYsRUFBaUIsQ0FBakIsRUFBbUIsQ0FBbkIsQ0FBRCxDQXpCcEI7QUEwQlRHLHVDQUFtQyxFQUFFLENBQUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLEVBQWUsQ0FBZixFQUFpQixDQUFqQixFQUFtQixDQUFuQixDQUFELENBMUI1QjtBQTJCVGdFLDJCQUF1QixFQUFFLENBQUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQUQsRUFBaUIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpCLEVBQWlDLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqQyxFQUFpRCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakQsRUFBaUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpFLEVBQWlGLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqRixFQUFpRyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakcsRUFBaUgsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLENBQWpILEVBQWlJLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxFQUFTLENBQVQsRUFBVyxDQUFYLEVBQWEsQ0FBYixDQUFqSSxFQUFpSixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsQ0FBakosQ0EzQmhCO0FBNEJUM0UsbUJBQWUsRUFBRSxDQUFDLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxHQUFSLEVBQVksR0FBWixFQUFnQixFQUFoQixFQUFtQixHQUFuQixFQUF1QixHQUF2QixDQUFELEVBQTZCLENBQUMsRUFBRCxFQUFJLEdBQUosRUFBUSxHQUFSLEVBQVksR0FBWixFQUFnQixHQUFoQixFQUFvQixFQUFwQixFQUF1QixHQUF2QixDQUE3QixFQUF5RCxDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsR0FBVCxFQUFhLEVBQWIsRUFBZ0IsR0FBaEIsRUFBb0IsR0FBcEIsRUFBd0IsRUFBeEIsQ0FBekQsRUFBcUYsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEdBQVIsRUFBWSxHQUFaLEVBQWdCLEdBQWhCLEVBQW9CLEVBQXBCLEVBQXVCLEVBQXZCLENBQXJGLEVBQWdILENBQUMsRUFBRCxFQUFJLEdBQUosRUFBUSxFQUFSLEVBQVcsR0FBWCxFQUFlLEVBQWYsRUFBa0IsR0FBbEIsRUFBc0IsR0FBdEIsQ0FBaEgsRUFBMkksQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEVBQVIsRUFBVyxHQUFYLEVBQWUsR0FBZixFQUFtQixHQUFuQixFQUF1QixDQUF2QixDQUEzSSxFQUFxSyxDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsRUFBUixFQUFXLEdBQVgsRUFBZSxHQUFmLEVBQW1CLEdBQW5CLEVBQXVCLENBQXZCLENBQXJLLEVBQStMLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULEVBQVksR0FBWixFQUFnQixFQUFoQixFQUFtQixHQUFuQixFQUF1QixFQUF2QixDQUEvTCxFQUEwTixDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsRUFBUixFQUFXLEVBQVgsRUFBYyxHQUFkLEVBQWtCLEdBQWxCLEVBQXNCLEVBQXRCLENBQTFOLEVBQW9QLENBQUMsRUFBRCxFQUFJLEdBQUosRUFBUSxHQUFSLEVBQVksR0FBWixFQUFnQixHQUFoQixFQUFvQixHQUFwQixFQUF3QixHQUF4QixDQUFwUDtBQTVCUixHQUp6QztBQWtDNEI2Tiw0QkFBMEIsRUFBRTtBQUN4QmxLLG9CQUFnQixFQUFFLENBQUMsQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEVBQVAsRUFBVSxFQUFWLEVBQWEsQ0FBYixFQUFlLEVBQWYsRUFBa0IsRUFBbEIsRUFBcUIsRUFBckIsRUFBd0IsRUFBeEIsRUFBMkIsRUFBM0IsRUFBOEIsRUFBOUIsRUFBaUMsQ0FBakMsRUFBbUMsRUFBbkMsRUFBc0MsRUFBdEMsRUFBeUMsRUFBekMsRUFBNEMsRUFBNUMsRUFBK0MsRUFBL0MsRUFBa0QsRUFBbEQsRUFBcUQsRUFBckQsRUFBd0QsRUFBeEQsRUFBMkQsRUFBM0QsRUFBOEQsRUFBOUQsRUFBaUUsRUFBakUsRUFBb0UsQ0FBcEUsRUFBc0UsRUFBdEUsRUFBeUUsQ0FBekUsRUFBMkUsQ0FBM0UsRUFBNkUsRUFBN0UsRUFBZ0YsRUFBaEYsRUFBbUYsRUFBbkYsRUFBc0YsRUFBdEYsRUFBeUYsRUFBekYsRUFBNEYsRUFBNUYsRUFBK0YsRUFBL0YsRUFBa0csRUFBbEcsRUFBcUcsRUFBckcsRUFBd0csRUFBeEcsRUFBMkcsQ0FBM0csRUFBNkcsRUFBN0csRUFBZ0gsRUFBaEgsRUFBbUgsRUFBbkgsRUFBc0gsRUFBdEgsRUFBeUgsRUFBekgsRUFBNEgsRUFBNUgsRUFBK0gsRUFBL0gsRUFBa0ksQ0FBbEksRUFBb0ksRUFBcEksRUFBdUksRUFBdkksRUFBMEksRUFBMUksRUFBNkksRUFBN0ksRUFBZ0osRUFBaEosRUFBbUosRUFBbkosRUFBc0osRUFBdEosRUFBeUosRUFBekosRUFBNEosRUFBNUosRUFBK0osRUFBL0osRUFBa0ssQ0FBbEssRUFBb0ssRUFBcEssRUFBdUssRUFBdkssRUFBMEssRUFBMUssRUFBNkssQ0FBN0ssRUFBK0ssRUFBL0ssRUFBa0wsRUFBbEwsRUFBcUwsRUFBckwsRUFBd0wsRUFBeEwsRUFBMkwsRUFBM0wsRUFBOEwsRUFBOUwsRUFBaU0sRUFBak0sRUFBb00sQ0FBcE0sRUFBc00sRUFBdE0sQ0FBRCxDQURNO0FBRXhCRyw0QkFBd0IsRUFBRSxDQUFDLENBQUMsRUFBRCxFQUFJLEVBQUosRUFBTyxFQUFQLEVBQVUsQ0FBVixFQUFZLEVBQVosRUFBZSxFQUFmLEVBQWtCLEVBQWxCLEVBQXFCLEVBQXJCLEVBQXdCLENBQXhCLEVBQTBCLEVBQTFCLEVBQTZCLEVBQTdCLEVBQWdDLEVBQWhDLEVBQW1DLEVBQW5DLEVBQXNDLEVBQXRDLEVBQXlDLEVBQXpDLEVBQTRDLENBQTVDLEVBQThDLEVBQTlDLEVBQWlELEVBQWpELEVBQW9ELEVBQXBELEVBQXVELEVBQXZELEVBQTBELEVBQTFELEVBQTZELEVBQTdELEVBQWdFLEVBQWhFLEVBQW1FLEVBQW5FLEVBQXNFLEVBQXRFLEVBQXlFLEVBQXpFLEVBQTRFLEVBQTVFLEVBQStFLEVBQS9FLEVBQWtGLEVBQWxGLEVBQXFGLEVBQXJGLEVBQXdGLEVBQXhGLEVBQTJGLEVBQTNGLEVBQThGLENBQTlGLEVBQWdHLEVBQWhHLEVBQW1HLEVBQW5HLEVBQXNHLENBQXRHLEVBQXdHLEVBQXhHLEVBQTJHLEVBQTNHLEVBQThHLEVBQTlHLEVBQWlILEVBQWpILEVBQW9ILEVBQXBILEVBQXVILEVBQXZILEVBQTBILEVBQTFILEVBQTZILEVBQTdILEVBQWdJLEVBQWhJLEVBQW1JLEVBQW5JLEVBQXNJLENBQXRJLEVBQXdJLEVBQXhJLEVBQTJJLENBQTNJLEVBQTZJLEVBQTdJLEVBQWdKLENBQWhKLEVBQWtKLEVBQWxKLEVBQXFKLEVBQXJKLEVBQXdKLEVBQXhKLEVBQTJKLEVBQTNKLEVBQThKLEVBQTlKLEVBQWlLLEVBQWpLLEVBQW9LLEVBQXBLLEVBQXVLLENBQXZLLEVBQXlLLEVBQXpLLEVBQTRLLEVBQTVLLEVBQStLLEVBQS9LLEVBQWtMLEVBQWxMLEVBQXFMLEVBQXJMLEVBQXdMLEVBQXhMLEVBQTJMLEVBQTNMLEVBQThMLEVBQTlMLEVBQWlNLENBQWpNLEVBQW1NLEVBQW5NLEVBQXNNLEVBQXRNLENBQUQsQ0FGRjtBQUd4QlosaUNBQTZCLEVBQUUsQ0FBQyxDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sRUFBUCxFQUFVLEVBQVYsRUFBYSxFQUFiLEVBQWdCLEVBQWhCLEVBQW1CLENBQW5CLEVBQXFCLENBQXJCLEVBQXVCLENBQXZCLEVBQXlCLEVBQXpCLEVBQTRCLENBQTVCLEVBQThCLEVBQTlCLEVBQWlDLEVBQWpDLEVBQW9DLEVBQXBDLEVBQXVDLEVBQXZDLEVBQTBDLEVBQTFDLEVBQTZDLEVBQTdDLEVBQWdELENBQWhELEVBQWtELEVBQWxELEVBQXFELEVBQXJELEVBQXdELEVBQXhELEVBQTJELEVBQTNELEVBQThELEVBQTlELEVBQWlFLEVBQWpFLEVBQW9FLEVBQXBFLEVBQXVFLENBQXZFLEVBQXlFLEVBQXpFLEVBQTRFLEVBQTVFLEVBQStFLEVBQS9FLEVBQWtGLEVBQWxGLEVBQXFGLEVBQXJGLEVBQXdGLEVBQXhGLEVBQTJGLEVBQTNGLEVBQThGLEVBQTlGLEVBQWlHLEVBQWpHLEVBQW9HLEVBQXBHLEVBQXVHLEVBQXZHLEVBQTBHLEVBQTFHLEVBQTZHLEVBQTdHLEVBQWdILEVBQWhILEVBQW1ILENBQW5ILEVBQXFILEVBQXJILEVBQXdILEVBQXhILEVBQTJILEVBQTNILEVBQThILENBQTlILEVBQWdJLEVBQWhJLEVBQW1JLEVBQW5JLEVBQXNJLEVBQXRJLEVBQXlJLEVBQXpJLEVBQTRJLEVBQTVJLEVBQStJLEVBQS9JLEVBQWtKLEVBQWxKLEVBQXFKLEVBQXJKLEVBQXdKLENBQXhKLEVBQTBKLEVBQTFKLEVBQTZKLEVBQTdKLEVBQWdLLEVBQWhLLEVBQW1LLEVBQW5LLEVBQXNLLEVBQXRLLEVBQXlLLEVBQXpLLEVBQTRLLEVBQTVLLEVBQStLLEVBQS9LLEVBQWtMLEVBQWxMLEVBQXFMLEVBQXJMLEVBQXdMLEVBQXhMLEVBQTJMLEVBQTNMLEVBQThMLENBQTlMLEVBQWdNLEVBQWhNLEVBQW1NLEVBQW5NLEVBQXNNLEVBQXRNLENBQUQsQ0FIUDtBQUl4QmlCLGFBQVMsRUFBRSxDQUFDLENBQUMsRUFBRCxFQUFJLEVBQUosRUFBTyxHQUFQLENBQUQsRUFBYSxDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sR0FBUCxDQUFiLEVBQXlCLENBQUMsRUFBRCxFQUFJLEVBQUosRUFBTyxHQUFQLENBQXpCLEVBQXFDLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQXJDLEVBQWtELENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxDQUFULENBQWxELEVBQThELENBQUMsQ0FBRCxFQUFHLEVBQUgsRUFBTSxHQUFOLENBQTlELEVBQXlFLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQXpFLEVBQXNGLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULENBQXRGLEVBQW9HLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxDQUFULENBQXBHLEVBQWdILENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULENBQWhILEVBQThILENBQUMsRUFBRCxFQUFJLEVBQUosRUFBTyxHQUFQLENBQTlILEVBQTBJLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULENBQTFJLEVBQXdKLENBQUMsRUFBRCxFQUFJLEdBQUosRUFBUSxHQUFSLENBQXhKLEVBQXFLLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQXJLLEVBQWtMLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULENBQWxMLEVBQWdNLENBQUMsRUFBRCxFQUFJLEdBQUosRUFBUSxHQUFSLENBQWhNLEVBQTZNLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQTdNLEVBQTBOLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULENBQTFOLEVBQXdPLENBQUMsRUFBRCxFQUFJLEVBQUosRUFBTyxFQUFQLENBQXhPLEVBQW1QLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQW5QLEVBQWdRLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxFQUFSLENBQWhRLEVBQTRRLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQTVRLEVBQXlSLENBQUMsRUFBRCxFQUFJLEdBQUosRUFBUSxFQUFSLENBQXpSLEVBQXFTLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULENBQXJTLEVBQW1ULENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQW5ULEVBQWdVLENBQUMsQ0FBRCxFQUFHLEdBQUgsRUFBTyxFQUFQLENBQWhVLEVBQTJVLENBQUMsRUFBRCxFQUFJLEVBQUosRUFBTyxFQUFQLENBQTNVLEVBQXNWLENBQUMsRUFBRCxFQUFJLEVBQUosRUFBTyxHQUFQLENBQXRWLEVBQWtXLENBQUMsRUFBRCxFQUFJLEdBQUosRUFBUSxHQUFSLENBQWxXLEVBQStXLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQS9XLEVBQTRYLENBQUMsRUFBRCxFQUFJLEVBQUosRUFBTyxHQUFQLENBQTVYLEVBQXdZLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQXhZLEVBQXFaLENBQUMsRUFBRCxFQUFJLEVBQUosRUFBTyxHQUFQLENBQXJaLEVBQWlhLENBQUMsR0FBRCxFQUFLLENBQUwsRUFBTyxHQUFQLENBQWphLEVBQTZhLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxHQUFSLENBQTdhLEVBQTBiLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxHQUFSLENBQTFiLEVBQXVjLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQXZjLEVBQW9kLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQXBkLEVBQWllLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQWplLEVBQThlLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQTllLEVBQTJmLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxHQUFSLENBQTNmLEVBQXdnQixDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsR0FBVCxDQUF4Z0IsRUFBc2hCLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULENBQXRoQixFQUFvaUIsQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEVBQVAsQ0FBcGlCLEVBQStpQixDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsR0FBVCxDQUEvaUIsRUFBNmpCLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULENBQTdqQixFQUEya0IsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEVBQVIsQ0FBM2tCLEVBQXVsQixDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sR0FBUCxDQUF2bEIsRUFBbW1CLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULENBQW5tQixFQUFpbkIsQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEdBQVAsQ0FBam5CLEVBQTZuQixDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsR0FBUixDQUE3bkIsRUFBMG9CLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQTFvQixFQUF1cEIsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEVBQVQsQ0FBdnBCLEVBQW9xQixDQUFDLENBQUQsRUFBRyxFQUFILEVBQU0sRUFBTixDQUFwcUIsRUFBOHFCLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxDQUFSLENBQTlxQixFQUF5ckIsQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEdBQVAsQ0FBenJCLEVBQXFzQixDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsRUFBUixDQUFyc0IsRUFBaXRCLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxHQUFSLENBQWp0QixFQUE4dEIsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLENBQVIsQ0FBOXRCLEVBQXl1QixDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsR0FBUixDQUF6dUIsRUFBc3ZCLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxHQUFSLENBQXR2QixFQUFtd0IsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEdBQVIsQ0FBbndCLEVBQWd4QixDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsR0FBUixDQUFoeEIsRUFBNnhCLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxHQUFSLENBQTd4QixFQUEweUIsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEdBQVIsQ0FBMXlCLEVBQXV6QixDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsR0FBUixDQUF2ekIsRUFBbzBCLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxHQUFSLENBQXAwQixFQUFpMUIsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEVBQVQsQ0FBajFCLEVBQTgxQixDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsRUFBUixDQUE5MUIsRUFBMDJCLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULENBQTEyQixDQUphO0FBS3hCZCxlQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFELEVBQVMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBVCxFQUFpQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqQixFQUF5QixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6QixFQUFpQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqQyxFQUF5QyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6QyxFQUFpRCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRCxFQUF5RCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RCxFQUFpRSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRSxFQUF5RSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RSxFQUFpRixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRixFQUF5RixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RixFQUFpRyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRyxFQUF5RyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RyxFQUFpSCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSCxFQUF5SCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SCxFQUFpSSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSSxFQUF5SSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SSxFQUFpSixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSixFQUF5SixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SixFQUFpSyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSyxFQUF5SyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SyxFQUFpTCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTCxFQUF5TCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TCxFQUFpTSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTSxFQUF5TSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TSxFQUFpTixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTixFQUF5TixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TixFQUFpTyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTyxFQUF5TyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TyxFQUFpUCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUCxFQUF5UCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6UCxFQUFpUSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUSxFQUF5USxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6USxFQUFpUixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUixFQUF5UixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6UixFQUFpUyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUyxFQUF5UyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6UyxFQUFpVCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVCxFQUF5VCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VCxFQUFpVSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVSxFQUF5VSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VSxFQUFpVixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVixFQUF5VixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VixFQUFpVyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVyxFQUF5VyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VyxFQUFpWCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqWCxFQUF5WCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6WCxFQUFpWSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqWSxFQUF5WSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6WSxFQUFpWixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqWixFQUF5WixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6WixFQUFpYSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqYSxFQUF5YSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6YSxFQUFpYixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqYixFQUF5YixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6YixFQUFpYyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqYyxFQUF5YyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6YyxFQUFpZCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqZCxFQUF5ZCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6ZCxFQUFpZSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqZSxFQUF5ZSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6ZSxFQUFpZixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqZixFQUF5ZixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6ZixFQUFpZ0IsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamdCLEVBQXlnQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6Z0IsRUFBaWhCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpoQixFQUF5aEIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemhCLEVBQWlpQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqaUIsRUFBeWlCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXppQixDQUxXO0FBTXhCc0MscUJBQWlCLEVBQUUsQ0FBQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFELEVBQVMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBVCxFQUFpQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqQixFQUF5QixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6QixFQUFpQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqQyxFQUF5QyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6QyxFQUFpRCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRCxFQUF5RCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RCxFQUFpRSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRSxFQUF5RSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RSxFQUFpRixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRixFQUF5RixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RixFQUFpRyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRyxFQUF5RyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RyxFQUFpSCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSCxFQUF5SCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SCxFQUFpSSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSSxFQUF5SSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SSxFQUFpSixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSixFQUF5SixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SixFQUFpSyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSyxFQUF5SyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SyxFQUFpTCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTCxFQUF5TCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TCxFQUFpTSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTSxFQUF5TSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TSxFQUFpTixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTixFQUF5TixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TixFQUFpTyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTyxFQUF5TyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TyxFQUFpUCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUCxFQUF5UCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6UCxFQUFpUSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUSxFQUF5USxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6USxFQUFpUixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUixFQUF5UixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6UixFQUFpUyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUyxFQUF5UyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6UyxFQUFpVCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVCxFQUF5VCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VCxFQUFpVSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVSxFQUF5VSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VSxFQUFpVixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVixFQUF5VixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VixFQUFpVyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVyxFQUF5VyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VyxFQUFpWCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqWCxFQUF5WCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6WCxFQUFpWSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqWSxFQUF5WSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6WSxFQUFpWixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqWixFQUF5WixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6WixFQUFpYSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqYSxFQUF5YSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6YSxFQUFpYixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqYixFQUF5YixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6YixFQUFpYyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqYyxFQUF5YyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6YyxFQUFpZCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqZCxFQUF5ZCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6ZCxFQUFpZSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqZSxFQUF5ZSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6ZSxFQUFpZixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqZixFQUF5ZixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6ZixFQUFpZ0IsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamdCLEVBQXlnQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6Z0IsRUFBaWhCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpoQixFQUF5aEIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemhCLEVBQWlpQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqaUIsRUFBeWlCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXppQixDQU5LO0FBUXhCVCxtQkFBZSxFQUFFLENBQUMsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBRCxFQUFlLENBQUMsRUFBRCxFQUFJLEdBQUosRUFBUSxHQUFSLENBQWYsRUFBNEIsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEdBQVIsQ0FBNUIsRUFBeUMsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEVBQVIsQ0FBekMsRUFBcUQsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEVBQVQsQ0FBckQsRUFBa0UsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEdBQVIsQ0FBbEUsRUFBK0UsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEVBQVIsQ0FBL0UsRUFBMkYsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEdBQVIsQ0FBM0YsRUFBd0csQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBeEcsRUFBc0gsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEdBQVIsQ0FBdEgsRUFBbUksQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEdBQVAsQ0FBbkksRUFBK0ksQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEdBQVIsQ0FBL0ksRUFBNEosQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEVBQVQsQ0FBNUosRUFBeUssQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEVBQVQsQ0FBekssRUFBc0wsQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEdBQVAsQ0FBdEwsRUFBa00sQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEVBQVQsQ0FBbE0sRUFBK00sQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEVBQVIsQ0FBL00sRUFBMk4sQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEVBQVIsQ0FBM04sRUFBdU8sQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBdk8sRUFBcVAsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLENBQVIsQ0FBclAsRUFBZ1EsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBaFEsRUFBOFEsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBOVEsRUFBNFIsQ0FBQyxFQUFELEVBQUksQ0FBSixFQUFNLEVBQU4sQ0FBNVIsRUFBc1MsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBdFMsRUFBb1QsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEVBQVIsQ0FBcFQsRUFBZ1UsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBaFUsRUFBOFUsQ0FBQyxHQUFELEVBQUssQ0FBTCxFQUFPLEdBQVAsQ0FBOVUsRUFBMFYsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBMVYsRUFBd1csQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEVBQVAsQ0FBeFcsRUFBbVgsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEdBQVIsQ0FBblgsRUFBZ1ksQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBaFksRUFBOFksQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEVBQVAsQ0FBOVksRUFBeVosQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEVBQVIsQ0FBelosRUFBcWEsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEdBQVIsQ0FBcmEsRUFBa2IsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBbGIsRUFBZ2MsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBaGMsRUFBOGMsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBOWMsRUFBNGQsQ0FBQyxDQUFELEVBQUcsR0FBSCxFQUFPLENBQVAsQ0FBNWQsRUFBc2UsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEdBQVIsQ0FBdGUsRUFBbWYsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEdBQVIsQ0FBbmYsRUFBZ2dCLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxFQUFSLENBQWhnQixFQUE0Z0IsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEdBQVIsQ0FBNWdCLEVBQXloQixDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsR0FBVCxDQUF6aEIsRUFBdWlCLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxHQUFSLENBQXZpQixFQUFvakIsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEVBQVQsQ0FBcGpCLEVBQWlrQixDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsRUFBVCxDQUFqa0IsRUFBOGtCLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULENBQTlrQixFQUE0bEIsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLENBQVQsQ0FBNWxCLEVBQXdtQixDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sR0FBUCxDQUF4bUIsRUFBb25CLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULENBQXBuQixFQUFrb0IsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBbG9CLEVBQWdwQixDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsRUFBVCxDQUFocEIsRUFBNnBCLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULENBQTdwQixFQUEycUIsQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEdBQVAsQ0FBM3FCLEVBQXVyQixDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsR0FBUixDQUF2ckIsRUFBb3NCLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQXBzQixFQUFpdEIsQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEVBQVAsQ0FBanRCLEVBQTR0QixDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sR0FBUCxDQUE1dEIsRUFBd3VCLENBQUMsRUFBRCxFQUFJLEVBQUosRUFBTyxHQUFQLENBQXh1QixFQUFvdkIsQ0FBQyxFQUFELEVBQUksQ0FBSixFQUFNLENBQU4sQ0FBcHZCLEVBQTZ2QixDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsR0FBUixDQUE3dkIsRUFBMHdCLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxHQUFSLENBQTF3QixFQUF1eEIsQ0FBQyxDQUFELEVBQUcsR0FBSCxFQUFPLEdBQVAsQ0FBdnhCLEVBQW15QixDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sR0FBUCxDQUFueUIsRUFBK3lCLENBQUMsRUFBRCxFQUFJLEVBQUosRUFBTyxFQUFQLENBQS95QixFQUEwekIsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEVBQVQsQ0FBMXpCLEVBQXUwQixDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsRUFBVCxDQUF2MEIsRUFBbzFCLENBQUMsRUFBRCxFQUFJLEdBQUosRUFBUSxHQUFSLENBQXAxQixFQUFpMkIsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBajJCLEVBQSsyQixDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsRUFBUixDQUEvMkIsQ0FSTztBQVN4QkwsMEJBQXNCLEVBQUUsQ0FBQyxDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sRUFBUCxFQUFVLEVBQVYsRUFBYSxFQUFiLEVBQWdCLEVBQWhCLEVBQW1CLEVBQW5CLEVBQXNCLENBQXRCLEVBQXdCLEVBQXhCLEVBQTJCLEVBQTNCLEVBQThCLEVBQTlCLEVBQWlDLEVBQWpDLEVBQW9DLEVBQXBDLEVBQXVDLEVBQXZDLEVBQTBDLEVBQTFDLEVBQTZDLEVBQTdDLEVBQWdELEVBQWhELEVBQW1ELEVBQW5ELEVBQXNELEVBQXRELEVBQXlELEVBQXpELEVBQTRELEVBQTVELEVBQStELEVBQS9ELEVBQWtFLENBQWxFLEVBQW9FLEVBQXBFLEVBQXVFLEVBQXZFLEVBQTBFLEVBQTFFLEVBQTZFLENBQTdFLEVBQStFLEVBQS9FLEVBQWtGLEVBQWxGLEVBQXFGLEVBQXJGLEVBQXdGLEVBQXhGLEVBQTJGLEVBQTNGLEVBQThGLEVBQTlGLEVBQWlHLENBQWpHLEVBQW1HLEVBQW5HLEVBQXNHLEVBQXRHLEVBQXlHLEVBQXpHLEVBQTRHLENBQTVHLEVBQThHLEVBQTlHLEVBQWlILEVBQWpILEVBQW9ILEVBQXBILEVBQXVILEVBQXZILEVBQTBILEVBQTFILEVBQTZILEVBQTdILEVBQWdJLEVBQWhJLEVBQW1JLEVBQW5JLEVBQXNJLEVBQXRJLEVBQXlJLENBQXpJLEVBQTJJLEVBQTNJLEVBQThJLEVBQTlJLEVBQWlKLENBQWpKLEVBQW1KLEVBQW5KLEVBQXNKLEVBQXRKLEVBQXlKLEVBQXpKLEVBQTRKLENBQTVKLEVBQThKLEVBQTlKLEVBQWlLLEVBQWpLLEVBQW9LLEVBQXBLLEVBQXVLLEVBQXZLLEVBQTBLLEVBQTFLLEVBQTZLLEVBQTdLLEVBQWdMLEVBQWhMLEVBQW1MLEVBQW5MLEVBQXNMLEVBQXRMLEVBQXlMLEVBQXpMLEVBQTRMLENBQTVMLEVBQThMLEVBQTlMLEVBQWlNLENBQWpNLEVBQW1NLEVBQW5NLEVBQXNNLEVBQXRNLENBQUQsQ0FUQTtBQVV4QkUsa0NBQThCLEVBQUUsQ0FBQyxDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sRUFBUCxFQUFVLEVBQVYsRUFBYSxFQUFiLEVBQWdCLENBQWhCLEVBQWtCLEVBQWxCLEVBQXFCLEVBQXJCLEVBQXdCLENBQXhCLEVBQTBCLEVBQTFCLEVBQTZCLEVBQTdCLEVBQWdDLEVBQWhDLEVBQW1DLEVBQW5DLEVBQXNDLEVBQXRDLEVBQXlDLEVBQXpDLEVBQTRDLEVBQTVDLEVBQStDLEVBQS9DLEVBQWtELENBQWxELEVBQW9ELEVBQXBELEVBQXVELEVBQXZELEVBQTBELENBQTFELEVBQTRELENBQTVELEVBQThELEVBQTlELEVBQWlFLEVBQWpFLEVBQW9FLEVBQXBFLEVBQXVFLEVBQXZFLEVBQTBFLENBQTFFLEVBQTRFLEVBQTVFLEVBQStFLEVBQS9FLEVBQWtGLEVBQWxGLEVBQXFGLEVBQXJGLEVBQXdGLEVBQXhGLEVBQTJGLEVBQTNGLEVBQThGLEVBQTlGLEVBQWlHLEVBQWpHLEVBQW9HLEVBQXBHLEVBQXVHLEVBQXZHLEVBQTBHLEVBQTFHLEVBQTZHLEVBQTdHLEVBQWdILEVBQWhILEVBQW1ILEVBQW5ILEVBQXNILEVBQXRILEVBQXlILEVBQXpILEVBQTRILEVBQTVILEVBQStILEVBQS9ILEVBQWtJLENBQWxJLEVBQW9JLEVBQXBJLEVBQXVJLENBQXZJLEVBQXlJLEVBQXpJLEVBQTRJLEVBQTVJLEVBQStJLENBQS9JLEVBQWlKLEVBQWpKLEVBQW9KLEVBQXBKLEVBQXVKLEVBQXZKLEVBQTBKLEVBQTFKLEVBQTZKLEVBQTdKLEVBQWdLLEVBQWhLLEVBQW1LLEVBQW5LLEVBQXNLLEVBQXRLLEVBQXlLLEVBQXpLLEVBQTRLLENBQTVLLEVBQThLLEVBQTlLLEVBQWlMLEVBQWpMLEVBQW9MLEVBQXBMLEVBQXVMLEVBQXZMLEVBQTBMLEVBQTFMLEVBQTZMLEVBQTdMLEVBQWdNLEVBQWhNLEVBQW1NLEVBQW5NLEVBQXNNLEVBQXRNLENBQUQsQ0FWUjtBQVd4QlIsdUNBQW1DLEVBQUUsQ0FBQyxDQUFDLENBQUQsRUFBRyxFQUFILEVBQU0sRUFBTixFQUFTLEVBQVQsRUFBWSxFQUFaLEVBQWUsRUFBZixFQUFrQixFQUFsQixFQUFxQixFQUFyQixFQUF3QixFQUF4QixFQUEyQixFQUEzQixFQUE4QixFQUE5QixFQUFpQyxFQUFqQyxFQUFvQyxFQUFwQyxFQUF1QyxFQUF2QyxFQUEwQyxFQUExQyxFQUE2QyxFQUE3QyxFQUFnRCxFQUFoRCxFQUFtRCxFQUFuRCxFQUFzRCxFQUF0RCxFQUF5RCxDQUF6RCxFQUEyRCxFQUEzRCxFQUE4RCxFQUE5RCxFQUFpRSxDQUFqRSxFQUFtRSxFQUFuRSxFQUFzRSxFQUF0RSxFQUF5RSxFQUF6RSxFQUE0RSxFQUE1RSxFQUErRSxFQUEvRSxFQUFrRixFQUFsRixFQUFxRixFQUFyRixFQUF3RixFQUF4RixFQUEyRixFQUEzRixFQUE4RixDQUE5RixFQUFnRyxFQUFoRyxFQUFtRyxFQUFuRyxFQUFzRyxFQUF0RyxFQUF5RyxDQUF6RyxFQUEyRyxFQUEzRyxFQUE4RyxFQUE5RyxFQUFpSCxFQUFqSCxFQUFvSCxDQUFwSCxFQUFzSCxDQUF0SCxFQUF3SCxFQUF4SCxFQUEySCxFQUEzSCxFQUE4SCxFQUE5SCxFQUFpSSxFQUFqSSxFQUFvSSxFQUFwSSxFQUF1SSxFQUF2SSxFQUEwSSxFQUExSSxFQUE2SSxFQUE3SSxFQUFnSixFQUFoSixFQUFtSixFQUFuSixFQUFzSixFQUF0SixFQUF5SixDQUF6SixFQUEySixFQUEzSixFQUE4SixFQUE5SixFQUFpSyxFQUFqSyxFQUFvSyxDQUFwSyxFQUFzSyxFQUF0SyxFQUF5SyxFQUF6SyxFQUE0SyxFQUE1SyxFQUErSyxFQUEvSyxFQUFrTCxFQUFsTCxFQUFxTCxFQUFyTCxFQUF3TCxFQUF4TCxFQUEyTCxFQUEzTCxFQUE4TCxFQUE5TCxFQUFpTSxDQUFqTSxFQUFtTSxFQUFuTSxFQUFzTSxFQUF0TSxDQUFELENBWGI7QUFZeEJFLHFCQUFpQixFQUFFLENBQUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBRCxFQUFTLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQVQsRUFBaUIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakIsRUFBeUIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekIsRUFBaUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakMsRUFBeUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekMsRUFBaUQsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakQsRUFBeUQsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekQsRUFBaUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakUsRUFBeUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekUsRUFBaUYsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakYsRUFBeUYsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekYsRUFBaUcsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakcsRUFBeUcsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekcsRUFBaUgsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakgsRUFBeUgsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekgsRUFBaUksQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakksRUFBeUksQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekksRUFBaUosQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakosRUFBeUosQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekosRUFBaUssQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakssRUFBeUssQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekssRUFBaUwsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakwsRUFBeUwsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekwsRUFBaU0sQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBak0sRUFBeU0sQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBek0sRUFBaU4sQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBak4sRUFBeU4sQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBek4sRUFBaU8sQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBak8sRUFBeU8sQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBek8sRUFBaVAsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalAsRUFBeVAsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelAsRUFBaVEsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalEsRUFBeVEsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelEsRUFBaVIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalIsRUFBeVIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelIsRUFBaVMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalMsRUFBeVMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelMsRUFBaVQsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalQsRUFBeVQsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelQsRUFBaVUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalUsRUFBeVUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelUsRUFBaVYsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalYsRUFBeVYsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelYsRUFBaVcsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalcsRUFBeVcsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelcsRUFBaVgsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalgsRUFBeVgsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelgsRUFBaVksQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalksRUFBeVksQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelksRUFBaVosQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalosRUFBeVosQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelosRUFBaWEsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamEsRUFBeWEsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemEsRUFBaWIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamIsRUFBeWIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemIsRUFBaWMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamMsRUFBeWMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemMsRUFBaWQsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamQsRUFBeWQsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemQsRUFBaWUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamUsRUFBeWUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemUsRUFBaWYsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamYsRUFBeWYsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemYsRUFBaWdCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpnQixFQUF5Z0IsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemdCLEVBQWloQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqaEIsRUFBeWhCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpoQixFQUFpaUIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamlCLEVBQXlpQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6aUIsQ0FaSztBQWF4QjBCLDJCQUF1QixFQUFFLENBQUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBRCxFQUFTLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQVQsRUFBaUIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakIsRUFBeUIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekIsRUFBaUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakMsRUFBeUMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekMsRUFBaUQsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakQsRUFBeUQsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekQsRUFBaUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakUsRUFBeUUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekUsRUFBaUYsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakYsRUFBeUYsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekYsRUFBaUcsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakcsRUFBeUcsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekcsRUFBaUgsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakgsRUFBeUgsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekgsRUFBaUksQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakksRUFBeUksQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekksRUFBaUosQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakosRUFBeUosQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekosRUFBaUssQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakssRUFBeUssQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekssRUFBaUwsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBakwsRUFBeUwsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBekwsRUFBaU0sQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBak0sRUFBeU0sQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBek0sRUFBaU4sQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBak4sRUFBeU4sQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBek4sRUFBaU8sQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBak8sRUFBeU8sQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBek8sRUFBaVAsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalAsRUFBeVAsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelAsRUFBaVEsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalEsRUFBeVEsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelEsRUFBaVIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalIsRUFBeVIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelIsRUFBaVMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalMsRUFBeVMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelMsRUFBaVQsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalQsRUFBeVQsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelQsRUFBaVUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalUsRUFBeVUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelUsRUFBaVYsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalYsRUFBeVYsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelYsRUFBaVcsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalcsRUFBeVcsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelcsRUFBaVgsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalgsRUFBeVgsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelgsRUFBaVksQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalksRUFBeVksQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelksRUFBaVosQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBalosRUFBeVosQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBelosRUFBaWEsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamEsRUFBeWEsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemEsRUFBaWIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamIsRUFBeWIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemIsRUFBaWMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamMsRUFBeWMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemMsRUFBaWQsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamQsRUFBeWQsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemQsRUFBaWUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamUsRUFBeWUsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemUsRUFBaWYsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamYsRUFBeWYsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemYsRUFBaWdCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpnQixFQUF5Z0IsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemdCLEVBQWloQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqaEIsRUFBeWhCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpoQixFQUFpaUIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamlCLEVBQXlpQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6aUIsQ0FiRDtBQWN4QnZFLGlDQUE2QixFQUFFLENBQUMsQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEVBQVAsRUFBVSxFQUFWLEVBQWEsRUFBYixFQUFnQixFQUFoQixFQUFtQixFQUFuQixFQUFzQixFQUF0QixFQUF5QixFQUF6QixFQUE0QixFQUE1QixFQUErQixFQUEvQixFQUFrQyxFQUFsQyxFQUFxQyxFQUFyQyxFQUF3QyxFQUF4QyxFQUEyQyxFQUEzQyxFQUE4QyxDQUE5QyxFQUFnRCxDQUFoRCxFQUFrRCxDQUFsRCxFQUFvRCxFQUFwRCxFQUF1RCxFQUF2RCxFQUEwRCxFQUExRCxFQUE2RCxFQUE3RCxFQUFnRSxFQUFoRSxFQUFtRSxFQUFuRSxFQUFzRSxFQUF0RSxFQUF5RSxFQUF6RSxFQUE0RSxDQUE1RSxFQUE4RSxFQUE5RSxFQUFpRixFQUFqRixFQUFvRixFQUFwRixFQUF1RixFQUF2RixFQUEwRixFQUExRixFQUE2RixFQUE3RixFQUFnRyxFQUFoRyxFQUFtRyxFQUFuRyxFQUFzRyxFQUF0RyxFQUF5RyxDQUF6RyxFQUEyRyxFQUEzRyxFQUE4RyxFQUE5RyxFQUFpSCxFQUFqSCxFQUFvSCxFQUFwSCxFQUF1SCxFQUF2SCxFQUEwSCxDQUExSCxFQUE0SCxFQUE1SCxFQUErSCxFQUEvSCxFQUFrSSxFQUFsSSxFQUFxSSxFQUFySSxFQUF3SSxFQUF4SSxFQUEySSxFQUEzSSxFQUE4SSxFQUE5SSxFQUFpSixDQUFqSixFQUFtSixFQUFuSixFQUFzSixFQUF0SixFQUF5SixDQUF6SixFQUEySixFQUEzSixFQUE4SixDQUE5SixFQUFnSyxFQUFoSyxFQUFtSyxFQUFuSyxFQUFzSyxFQUF0SyxFQUF5SyxFQUF6SyxFQUE0SyxFQUE1SyxFQUErSyxFQUEvSyxFQUFrTCxFQUFsTCxFQUFxTCxDQUFyTCxFQUF1TCxFQUF2TCxFQUEwTCxFQUExTCxFQUE2TCxFQUE3TCxFQUFnTSxFQUFoTSxFQUFtTSxFQUFuTSxFQUFzTSxFQUF0TSxDQUFELENBZFA7QUFleEJPLHlDQUFxQyxFQUFFLENBQUMsQ0FBQyxDQUFELEVBQUcsRUFBSCxFQUFNLEVBQU4sRUFBUyxFQUFULEVBQVksRUFBWixFQUFlLENBQWYsRUFBaUIsRUFBakIsRUFBb0IsQ0FBcEIsRUFBc0IsRUFBdEIsRUFBeUIsRUFBekIsRUFBNEIsRUFBNUIsRUFBK0IsQ0FBL0IsRUFBaUMsRUFBakMsRUFBb0MsRUFBcEMsRUFBdUMsRUFBdkMsRUFBMEMsRUFBMUMsRUFBNkMsRUFBN0MsRUFBZ0QsRUFBaEQsRUFBbUQsRUFBbkQsRUFBc0QsRUFBdEQsRUFBeUQsRUFBekQsRUFBNEQsRUFBNUQsRUFBK0QsRUFBL0QsRUFBa0UsRUFBbEUsRUFBcUUsRUFBckUsRUFBd0UsRUFBeEUsRUFBMkUsRUFBM0UsRUFBOEUsRUFBOUUsRUFBaUYsRUFBakYsRUFBb0YsRUFBcEYsRUFBdUYsRUFBdkYsRUFBMEYsRUFBMUYsRUFBNkYsRUFBN0YsRUFBZ0csRUFBaEcsRUFBbUcsRUFBbkcsRUFBc0csRUFBdEcsRUFBeUcsRUFBekcsRUFBNEcsRUFBNUcsRUFBK0csQ0FBL0csRUFBaUgsQ0FBakgsRUFBbUgsQ0FBbkgsRUFBcUgsRUFBckgsRUFBd0gsRUFBeEgsRUFBMkgsRUFBM0gsRUFBOEgsRUFBOUgsRUFBaUksRUFBakksRUFBb0ksRUFBcEksRUFBdUksRUFBdkksRUFBMEksRUFBMUksRUFBNkksQ0FBN0ksRUFBK0ksRUFBL0ksRUFBa0osQ0FBbEosRUFBb0osRUFBcEosRUFBdUosRUFBdkosRUFBMEosRUFBMUosRUFBNkosRUFBN0osRUFBZ0ssRUFBaEssRUFBbUssRUFBbkssRUFBc0ssRUFBdEssRUFBeUssRUFBekssRUFBNEssRUFBNUssRUFBK0ssRUFBL0ssRUFBa0wsRUFBbEwsRUFBcUwsRUFBckwsRUFBd0wsQ0FBeEwsRUFBMEwsRUFBMUwsRUFBNkwsRUFBN0wsRUFBZ00sRUFBaE0sRUFBbU0sRUFBbk0sRUFBc00sRUFBdE0sQ0FBRCxDQWZmO0FBZ0J4QlYsa0NBQThCLEVBQUUsQ0FBQyxDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sRUFBUCxFQUFVLEVBQVYsRUFBYSxDQUFiLEVBQWUsRUFBZixFQUFrQixFQUFsQixFQUFxQixDQUFyQixFQUF1QixFQUF2QixFQUEwQixFQUExQixFQUE2QixDQUE3QixFQUErQixFQUEvQixFQUFrQyxFQUFsQyxFQUFxQyxFQUFyQyxFQUF3QyxFQUF4QyxFQUEyQyxFQUEzQyxFQUE4QyxFQUE5QyxFQUFpRCxFQUFqRCxFQUFvRCxFQUFwRCxFQUF1RCxFQUF2RCxFQUEwRCxFQUExRCxFQUE2RCxFQUE3RCxFQUFnRSxFQUFoRSxFQUFtRSxFQUFuRSxFQUFzRSxFQUF0RSxFQUF5RSxFQUF6RSxFQUE0RSxFQUE1RSxFQUErRSxFQUEvRSxFQUFrRixFQUFsRixFQUFxRixFQUFyRixFQUF3RixFQUF4RixFQUEyRixFQUEzRixFQUE4RixDQUE5RixFQUFnRyxFQUFoRyxFQUFtRyxFQUFuRyxFQUFzRyxFQUF0RyxFQUF5RyxFQUF6RyxFQUE0RyxFQUE1RyxFQUErRyxDQUEvRyxFQUFpSCxFQUFqSCxFQUFvSCxFQUFwSCxFQUF1SCxFQUF2SCxFQUEwSCxFQUExSCxFQUE2SCxFQUE3SCxFQUFnSSxFQUFoSSxFQUFtSSxFQUFuSSxFQUFzSSxFQUF0SSxFQUF5SSxFQUF6SSxFQUE0SSxFQUE1SSxFQUErSSxFQUEvSSxFQUFrSixFQUFsSixFQUFxSixFQUFySixFQUF3SixFQUF4SixFQUEySixFQUEzSixFQUE4SixFQUE5SixFQUFpSyxFQUFqSyxFQUFvSyxFQUFwSyxFQUF1SyxFQUF2SyxFQUEwSyxDQUExSyxFQUE0SyxFQUE1SyxFQUErSyxFQUEvSyxFQUFrTCxFQUFsTCxFQUFxTCxDQUFyTCxFQUF1TCxDQUF2TCxFQUF5TCxFQUF6TCxFQUE0TCxDQUE1TCxFQUE4TCxDQUE5TCxFQUFnTSxFQUFoTSxFQUFtTSxFQUFuTSxFQUFzTSxFQUF0TSxDQUFELENBaEJSO0FBaUJ4QkgsNkJBQXlCLEVBQUUsQ0FBQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFELEVBQVMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBVCxFQUFpQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqQixFQUF5QixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6QixFQUFpQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqQyxFQUF5QyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6QyxFQUFpRCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRCxFQUF5RCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RCxFQUFpRSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRSxFQUF5RSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RSxFQUFpRixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRixFQUF5RixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RixFQUFpRyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRyxFQUF5RyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RyxFQUFpSCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSCxFQUF5SCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SCxFQUFpSSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSSxFQUF5SSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SSxFQUFpSixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSixFQUF5SixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SixFQUFpSyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSyxFQUF5SyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SyxFQUFpTCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTCxFQUF5TCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TCxFQUFpTSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTSxFQUF5TSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TSxFQUFpTixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTixFQUF5TixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TixFQUFpTyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTyxFQUF5TyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TyxFQUFpUCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUCxFQUF5UCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6UCxFQUFpUSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUSxFQUF5USxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6USxFQUFpUixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUixFQUF5UixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6UixFQUFpUyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUyxFQUF5UyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6UyxFQUFpVCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVCxFQUF5VCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VCxFQUFpVSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVSxFQUF5VSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VSxFQUFpVixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVixFQUF5VixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VixFQUFpVyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVyxFQUF5VyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VyxFQUFpWCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqWCxFQUF5WCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6WCxFQUFpWSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqWSxFQUF5WSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6WSxFQUFpWixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqWixFQUF5WixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6WixFQUFpYSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqYSxFQUF5YSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6YSxFQUFpYixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqYixFQUF5YixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6YixFQUFpYyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqYyxFQUF5YyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6YyxFQUFpZCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqZCxFQUF5ZCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6ZCxFQUFpZSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqZSxFQUF5ZSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6ZSxFQUFpZixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqZixFQUF5ZixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6ZixFQUFpZ0IsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamdCLEVBQXlnQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6Z0IsRUFBaWhCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpoQixFQUF5aEIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemhCLEVBQWlpQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqaUIsRUFBeWlCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXppQixDQWpCSDtBQWtCeEJnQiw0QkFBd0IsRUFBRSxDQUFDLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQUQsRUFBUyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFULEVBQWlCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpCLEVBQXlCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpCLEVBQWlDLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpDLEVBQXlDLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpDLEVBQWlELENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpELEVBQXlELENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpELEVBQWlFLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpFLEVBQXlFLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpFLEVBQWlGLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpGLEVBQXlGLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpGLEVBQWlHLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpHLEVBQXlHLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpHLEVBQWlILENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpILEVBQXlILENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpILEVBQWlJLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpJLEVBQXlJLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpJLEVBQWlKLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpKLEVBQXlKLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpKLEVBQWlLLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpLLEVBQXlLLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpLLEVBQWlMLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpMLEVBQXlMLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpMLEVBQWlNLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpNLEVBQXlNLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpNLEVBQWlOLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpOLEVBQXlOLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpOLEVBQWlPLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpPLEVBQXlPLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpPLEVBQWlQLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpQLEVBQXlQLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpQLEVBQWlRLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpRLEVBQXlRLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpRLEVBQWlSLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpSLEVBQXlSLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpSLEVBQWlTLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpTLEVBQXlTLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpTLEVBQWlULENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpULEVBQXlULENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpULEVBQWlVLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpVLEVBQXlVLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpVLEVBQWlWLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpWLEVBQXlWLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpWLEVBQWlXLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpXLEVBQXlXLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpXLEVBQWlYLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpYLEVBQXlYLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpYLEVBQWlZLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpZLEVBQXlZLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpZLEVBQWlaLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpaLEVBQXlaLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpaLEVBQWlhLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWphLEVBQXlhLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXphLEVBQWliLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpiLEVBQXliLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpiLEVBQWljLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpjLEVBQXljLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpjLEVBQWlkLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpkLEVBQXlkLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpkLEVBQWllLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWplLEVBQXllLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXplLEVBQWlmLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpmLEVBQXlmLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpmLEVBQWlnQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqZ0IsRUFBeWdCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXpnQixFQUFpaEIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamhCLEVBQXloQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6aEIsRUFBaWlCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWppQixFQUF5aUIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemlCLENBbEJGO0FBb0J4QndMLHlCQUFxQixFQUFFLENBQUMsQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEVBQVAsRUFBVSxFQUFWLEVBQWEsRUFBYixFQUFnQixFQUFoQixFQUFtQixFQUFuQixFQUFzQixFQUF0QixFQUF5QixFQUF6QixFQUE0QixFQUE1QixFQUErQixFQUEvQixFQUFrQyxFQUFsQyxFQUFxQyxFQUFyQyxFQUF3QyxFQUF4QyxFQUEyQyxDQUEzQyxFQUE2QyxFQUE3QyxFQUFnRCxFQUFoRCxFQUFtRCxFQUFuRCxFQUFzRCxFQUF0RCxFQUF5RCxFQUF6RCxFQUE0RCxFQUE1RCxFQUErRCxFQUEvRCxFQUFrRSxFQUFsRSxFQUFxRSxFQUFyRSxFQUF3RSxDQUF4RSxFQUEwRSxDQUExRSxFQUE0RSxDQUE1RSxFQUE4RSxFQUE5RSxFQUFpRixFQUFqRixFQUFvRixFQUFwRixFQUF1RixFQUF2RixFQUEwRixFQUExRixFQUE2RixFQUE3RixFQUFnRyxDQUFoRyxFQUFrRyxFQUFsRyxFQUFxRyxFQUFyRyxFQUF3RyxFQUF4RyxFQUEyRyxFQUEzRyxFQUE4RyxFQUE5RyxFQUFpSCxFQUFqSCxFQUFvSCxFQUFwSCxFQUF1SCxDQUF2SCxFQUF5SCxFQUF6SCxFQUE0SCxFQUE1SCxFQUErSCxDQUEvSCxFQUFpSSxFQUFqSSxFQUFvSSxFQUFwSSxFQUF1SSxFQUF2SSxFQUEwSSxFQUExSSxFQUE2SSxDQUE3SSxFQUErSSxFQUEvSSxFQUFrSixFQUFsSixFQUFxSixFQUFySixFQUF3SixDQUF4SixFQUEwSixFQUExSixFQUE2SixFQUE3SixFQUFnSyxFQUFoSyxFQUFtSyxFQUFuSyxFQUFzSyxFQUF0SyxFQUF5SyxFQUF6SyxFQUE0SyxDQUE1SyxFQUE4SyxFQUE5SyxFQUFpTCxFQUFqTCxFQUFvTCxFQUFwTCxFQUF1TCxFQUF2TCxFQUEwTCxFQUExTCxFQUE2TCxFQUE3TCxFQUFnTSxFQUFoTSxFQUFtTSxFQUFuTSxFQUFzTSxFQUF0TSxDQUFELENBcEJDO0FBcUJ4QkMsYUFBUyxFQUFFLENBQUMsQ0FBQyxDQUFELEVBQUcsRUFBSCxFQUFNLEVBQU4sQ0FBRCxFQUFXLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxFQUFSLENBQVgsRUFBdUIsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBdkIsRUFBcUMsQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEdBQVAsQ0FBckMsRUFBaUQsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEVBQVIsQ0FBakQsRUFBNkQsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEdBQVIsQ0FBN0QsRUFBMEUsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEVBQVQsQ0FBMUUsRUFBdUYsQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEdBQVAsQ0FBdkYsRUFBbUcsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEdBQVIsQ0FBbkcsRUFBZ0gsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBaEgsRUFBOEgsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBOUgsRUFBNEksQ0FBQyxDQUFELEVBQUcsR0FBSCxFQUFPLEdBQVAsQ0FBNUksRUFBd0osQ0FBQyxDQUFELEVBQUcsRUFBSCxFQUFNLEVBQU4sQ0FBeEosRUFBa0ssQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEdBQVIsQ0FBbEssRUFBK0ssQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEVBQVQsQ0FBL0ssRUFBNEwsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEVBQVQsQ0FBNUwsRUFBeU0sQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEdBQVAsQ0FBek0sRUFBcU4sQ0FBQyxHQUFELEVBQUssQ0FBTCxFQUFPLEdBQVAsQ0FBck4sRUFBaU8sQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEVBQVIsQ0FBak8sRUFBNk8sQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEdBQVIsQ0FBN08sRUFBMFAsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBMVAsRUFBd1EsQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEVBQVAsQ0FBeFEsRUFBbVIsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEdBQVIsQ0FBblIsRUFBZ1MsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEVBQVIsQ0FBaFMsRUFBNFMsQ0FBQyxDQUFELEVBQUcsR0FBSCxFQUFPLEVBQVAsQ0FBNVMsRUFBdVQsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEdBQVIsQ0FBdlQsRUFBb1UsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEdBQVIsQ0FBcFUsRUFBaVYsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEdBQVIsQ0FBalYsRUFBOFYsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEVBQVIsQ0FBOVYsRUFBMFcsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBMVcsRUFBd1gsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBeFgsRUFBc1ksQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEVBQVIsQ0FBdFksRUFBa1osQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEdBQVIsQ0FBbFosRUFBK1osQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEdBQVIsQ0FBL1osRUFBNGEsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEVBQVIsQ0FBNWEsRUFBd2IsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEVBQVIsQ0FBeGIsRUFBb2MsQ0FBQyxHQUFELEVBQUssQ0FBTCxFQUFPLEdBQVAsQ0FBcGMsRUFBZ2QsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEdBQVIsQ0FBaGQsRUFBNmQsQ0FBQyxFQUFELEVBQUksRUFBSixFQUFPLEdBQVAsQ0FBN2QsRUFBeWUsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBemUsRUFBdWYsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEVBQVIsQ0FBdmYsRUFBbWdCLENBQUMsRUFBRCxFQUFJLEVBQUosRUFBTyxHQUFQLENBQW5nQixFQUErZ0IsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBL2dCLEVBQTZoQixDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsR0FBVCxDQUE3aEIsRUFBMmlCLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxHQUFSLENBQTNpQixFQUF3akIsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBeGpCLEVBQXNrQixDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsRUFBUixDQUF0a0IsRUFBa2xCLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQWxsQixFQUErbEIsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEVBQVIsQ0FBL2xCLEVBQTJtQixDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsR0FBVCxDQUEzbUIsRUFBeW5CLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxFQUFSLENBQXpuQixFQUFxb0IsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLENBQVIsQ0FBcm9CLEVBQWdwQixDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsRUFBUixDQUFocEIsRUFBNHBCLENBQUMsRUFBRCxFQUFJLEdBQUosRUFBUSxHQUFSLENBQTVwQixFQUF5cUIsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEVBQVQsQ0FBenFCLEVBQXNyQixDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsRUFBUixDQUF0ckIsRUFBa3NCLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULENBQWxzQixFQUFndEIsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBaHRCLEVBQTh0QixDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsRUFBVCxDQUE5dEIsRUFBMnVCLENBQUMsRUFBRCxFQUFJLEVBQUosRUFBTyxHQUFQLENBQTN1QixFQUF1dkIsQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEVBQVIsQ0FBdnZCLEVBQW13QixDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsR0FBVCxDQUFud0IsRUFBaXhCLENBQUMsRUFBRCxFQUFJLEVBQUosRUFBTyxFQUFQLENBQWp4QixFQUE0eEIsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLENBQVQsQ0FBNXhCLEVBQXd5QixDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sR0FBUCxDQUF4eUIsRUFBb3pCLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxHQUFSLENBQXB6QixFQUFpMEIsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEdBQVIsQ0FBajBCLEVBQTgwQixDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sRUFBUCxDQUE5MEIsRUFBeTFCLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULENBQXoxQixFQUF1MkIsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBdjJCLENBckJhO0FBc0J4QkMsb0JBQWdCLEVBQUUsQ0FBQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFELEVBQVMsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBVCxFQUFpQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqQixFQUF5QixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6QixFQUFpQyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqQyxFQUF5QyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6QyxFQUFpRCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRCxFQUF5RCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RCxFQUFpRSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRSxFQUF5RSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RSxFQUFpRixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRixFQUF5RixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RixFQUFpRyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqRyxFQUF5RyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6RyxFQUFpSCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSCxFQUF5SCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SCxFQUFpSSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSSxFQUF5SSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SSxFQUFpSixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSixFQUF5SixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SixFQUFpSyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqSyxFQUF5SyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6SyxFQUFpTCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTCxFQUF5TCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TCxFQUFpTSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTSxFQUF5TSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TSxFQUFpTixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTixFQUF5TixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TixFQUFpTyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqTyxFQUF5TyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6TyxFQUFpUCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUCxFQUF5UCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6UCxFQUFpUSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUSxFQUF5USxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6USxFQUFpUixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUixFQUF5UixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6UixFQUFpUyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqUyxFQUF5UyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6UyxFQUFpVCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVCxFQUF5VCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VCxFQUFpVSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVSxFQUF5VSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VSxFQUFpVixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVixFQUF5VixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VixFQUFpVyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqVyxFQUF5VyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6VyxFQUFpWCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqWCxFQUF5WCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6WCxFQUFpWSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqWSxFQUF5WSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6WSxFQUFpWixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqWixFQUF5WixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6WixFQUFpYSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqYSxFQUF5YSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6YSxFQUFpYixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqYixFQUF5YixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6YixFQUFpYyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqYyxFQUF5YyxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6YyxFQUFpZCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqZCxFQUF5ZCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6ZCxFQUFpZSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqZSxFQUF5ZSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6ZSxFQUFpZixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqZixFQUF5ZixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6ZixFQUFpZ0IsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBamdCLEVBQXlnQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUF6Z0IsRUFBaWhCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQWpoQixFQUF5aEIsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsQ0FBemhCLEVBQWlpQixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxDQUFqaUIsRUFBeWlCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLENBQXppQixDQXRCTTtBQXdCeEJDLG1CQUFlLEVBQUUsQ0FBQyxDQUFDLENBQUQsRUFBRyxFQUFILEVBQU0sR0FBTixDQUFELEVBQVksQ0FBQyxHQUFELEVBQUssRUFBTCxFQUFRLEVBQVIsQ0FBWixFQUF3QixDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsR0FBUixDQUF4QixFQUFxQyxDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsRUFBUixDQUFyQyxFQUFpRCxDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsRUFBVCxDQUFqRCxFQUE4RCxDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsR0FBUixDQUE5RCxFQUEyRSxDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsRUFBUixDQUEzRSxFQUF1RixDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sR0FBUCxDQUF2RixFQUFtRyxDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsR0FBUixDQUFuRyxFQUFnSCxDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsR0FBUixDQUFoSCxFQUE2SCxDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsRUFBUixDQUE3SCxFQUF5SSxDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsR0FBVCxDQUF6SSxFQUF1SixDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsR0FBUixDQUF2SixFQUFvSyxDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsR0FBUixDQUFwSyxFQUFpTCxDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsRUFBVCxDQUFqTCxFQUE4TCxDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsRUFBUixDQUE5TCxFQUEwTSxDQUFDLENBQUQsRUFBRyxHQUFILEVBQU8sR0FBUCxDQUExTSxFQUFzTixDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsRUFBUixDQUF0TixFQUFrTyxDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsR0FBVCxDQUFsTyxFQUFnUCxDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsR0FBVCxDQUFoUCxFQUE4UCxDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsR0FBVCxDQUE5UCxFQUE0USxDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsR0FBVCxDQUE1USxFQUEwUixDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsR0FBVCxDQUExUixFQUF3UyxDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsRUFBUixDQUF4UyxFQUFvVCxDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsR0FBUixDQUFwVCxFQUFpVSxDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsR0FBUixDQUFqVSxFQUE4VSxDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsR0FBUixDQUE5VSxFQUEyVixDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsRUFBUixDQUEzVixFQUF1VyxDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sR0FBUCxDQUF2VyxFQUFtWCxDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsR0FBUixDQUFuWCxFQUFnWSxDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsRUFBVCxDQUFoWSxFQUE2WSxDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sRUFBUCxDQUE3WSxFQUF3WixDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsQ0FBVCxDQUF4WixFQUFvYSxDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsQ0FBUixDQUFwYSxFQUErYSxDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsR0FBVCxDQUEvYSxFQUE2YixDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sR0FBUCxDQUE3YixFQUF5YyxDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsRUFBVCxDQUF6YyxFQUFzZCxDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsRUFBVCxDQUF0ZCxFQUFtZSxDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sRUFBUCxDQUFuZSxFQUE4ZSxDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsR0FBUixDQUE5ZSxFQUEyZixDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsR0FBUixDQUEzZixFQUF3Z0IsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLENBQVIsQ0FBeGdCLEVBQW1oQixDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsRUFBVCxDQUFuaEIsRUFBZ2lCLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQWhpQixFQUE2aUIsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEVBQVIsQ0FBN2lCLEVBQXlqQixDQUFDLEVBQUQsRUFBSSxDQUFKLEVBQU0sRUFBTixDQUF6akIsRUFBbWtCLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQW5rQixFQUFnbEIsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEVBQVIsQ0FBaGxCLEVBQTRsQixDQUFDLEVBQUQsRUFBSSxDQUFKLEVBQU0sRUFBTixDQUE1bEIsRUFBc21CLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxHQUFSLENBQXRtQixFQUFtbkIsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBbm5CLEVBQWlvQixDQUFDLEVBQUQsRUFBSSxDQUFKLEVBQU0sR0FBTixDQUFqb0IsRUFBNG9CLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQTVvQixFQUF5cEIsQ0FBQyxFQUFELEVBQUksR0FBSixFQUFRLEdBQVIsQ0FBenBCLEVBQXNxQixDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsRUFBUixDQUF0cUIsRUFBa3JCLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxFQUFSLENBQWxyQixFQUE4ckIsQ0FBQyxHQUFELEVBQUssQ0FBTCxFQUFPLEdBQVAsQ0FBOXJCLEVBQTBzQixDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsRUFBUixDQUExc0IsRUFBc3RCLENBQUMsRUFBRCxFQUFJLEdBQUosRUFBUSxFQUFSLENBQXR0QixFQUFrdUIsQ0FBQyxHQUFELEVBQUssQ0FBTCxFQUFPLEVBQVAsQ0FBbHVCLEVBQTZ1QixDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsRUFBUixDQUE3dUIsRUFBeXZCLENBQUMsRUFBRCxFQUFJLEdBQUosRUFBUSxHQUFSLENBQXp2QixFQUFzd0IsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBdHdCLEVBQW94QixDQUFDLEdBQUQsRUFBSyxFQUFMLEVBQVEsRUFBUixDQUFweEIsRUFBZ3lCLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxFQUFULENBQWh5QixFQUE2eUIsQ0FBQyxHQUFELEVBQUssR0FBTCxFQUFTLEdBQVQsQ0FBN3lCLEVBQTJ6QixDQUFDLEVBQUQsRUFBSSxFQUFKLEVBQU8sR0FBUCxDQUEzekIsRUFBdTBCLENBQUMsR0FBRCxFQUFLLEVBQUwsRUFBUSxFQUFSLENBQXYwQixFQUFtMUIsQ0FBQyxDQUFELEVBQUcsR0FBSCxFQUFPLEdBQVAsQ0FBbjFCLEVBQSsxQixDQUFDLEVBQUQsRUFBSSxHQUFKLEVBQVEsR0FBUixDQUEvMUI7QUF4Qk87QUFsQ3hELENBRkE7QUFnRXVDUix5RUFBZixFOzs7Ozs7Ozs7Ozs7QUNoRXhCO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFFQSxJQUFNUyxPQUFPLEdBQUcsQ0FBaEI7QUFDQSxJQUFNQyxPQUFPLEdBQUcsR0FBaEI7QUFFQSxJQUFJaFAsYUFBYSxHQUFHO0FBQ2hCaVAsb0NBQWtDLEVBQUUsNENBQUNsTyxLQUFELEVBQVFILE1BQVIsRUFBZ0JzTyxnQkFBaEIsRUFBa0NDLE1BQWxDLEVBQTZDO0FBQzdFLFFBQUk7QUFDQSxVQUFJQyxzQkFBc0IsR0FBRztBQUN6QnJJLDBCQUFrQixFQUFFc0ksd0JBQXdCLENBQUN0TyxLQUFELEVBQVFILE1BQVIsQ0FEbkI7QUFDZ0Q7QUFDekV1RCw0QkFBb0IsRUFBRW1MLHFDQUFxQyxDQUFDdk8sS0FBRCxFQUFRSCxNQUFSLENBRmxDO0FBRXFEO0FBQzlFNkQsaUNBQXlCLEVBQUU2SyxxQ0FBcUMsQ0FBQzFPLE1BQUQsRUFBUyxDQUFULENBSHZDO0FBSXpCZ0UseUNBQWlDLEVBQUUwSyxxQ0FBcUMsQ0FBQzFPLE1BQUQsRUFBUyxDQUFULENBSi9DO0FBS3pCb0QsOENBQXNDLEVBQUVzTCxxQ0FBcUMsQ0FBQzFPLE1BQUQsRUFBUyxDQUFULENBTHBEO0FBTXpCc0csZ0NBQXdCLEVBQUVtSSx3QkFBd0IsQ0FBQ3RPLEtBQUQsRUFBUW1PLGdCQUFSLENBTnpCO0FBTXNEO0FBQy9FM0osa0NBQTBCLEVBQUUrSixxQ0FBcUMsQ0FBQ3ZPLEtBQUQsRUFBUW1PLGdCQUFSLENBUHhDO0FBT3VFO0FBQ2hHOU0sMENBQWtDLEVBQUVrTixxQ0FBcUMsQ0FBQ3ZPLEtBQUQsRUFBUW1PLGdCQUFSLENBUmhEO0FBU3pCdkosdUNBQStCLEVBQUUySixxQ0FBcUMsQ0FBQ0osZ0JBQUQsRUFBbUIsQ0FBbkIsQ0FUN0M7QUFVekJySiwrQ0FBdUMsRUFBRXlKLHFDQUFxQyxDQUFDSixnQkFBRCxFQUFtQixDQUFuQixDQVZyRDtBQVd6QjNNLCtDQUF1QyxFQUFFK00scUNBQXFDLENBQUNKLGdCQUFELEVBQW1CLENBQW5CLENBWHJEO0FBWXpCN0osb0RBQTRDLEVBQUVpSyxxQ0FBcUMsQ0FBQ0osZ0JBQUQsRUFBbUIsQ0FBbkIsQ0FaMUQ7QUFhekJqTSxzREFBOEMsRUFBRXFNLHFDQUFxQyxDQUFDSixnQkFBRCxFQUFtQixDQUFuQixDQWI1RDtBQWN6QjlMLHlDQUFpQyxFQUFFa00scUNBQXFDLENBQUN2TyxLQUFELEVBQVFILE1BQVIsQ0FkL0M7QUFlekI4Qiw4Q0FBc0MsRUFBRTRNLHFDQUFxQyxDQUFDSixnQkFBRCxFQUFtQixDQUFuQixDQWZwRDtBQWdCekJLLHVDQUErQixFQUFFLElBaEJSLENBZ0JlOztBQWhCZixPQUE3QjtBQW1CQSxVQUFJSixNQUFKLEVBQ0lDLHNCQUFzQixDQUFDRywrQkFBdkIsR0FBeURELHFDQUFxQyxDQUFDdk8sS0FBRCxFQUFRSCxNQUFSLENBQTlGO0FBRUosYUFBT3dPLHNCQUFQO0FBQ0gsS0F4QkQsQ0F3QkUsT0FBTzlMLEVBQVAsRUFBVztBQUNUQyx3REFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsWUFBTUEsRUFBTjtBQUNIO0FBQ0osR0E5QmU7QUErQmhCa00sb0NBQWtDLEVBQUUsNENBQUN6TyxLQUFELEVBQVFILE1BQVIsRUFBZ0JzTyxnQkFBaEIsRUFBcUM7QUFDckUsUUFBSTtBQUNBLFVBQUlPLHNCQUFzQixHQUFHO0FBQ3pCQyxzQ0FBOEIsRUFBRUoscUNBQXFDLENBQUMxTyxNQUFELEVBQVMsQ0FBVCxDQUQ1QztBQUV6QitPLDBCQUFrQixFQUFFTix3QkFBd0IsQ0FBQ3RPLEtBQUQsRUFBUUgsTUFBUixDQUZuQjtBQUd6QmdQLGlDQUF5QixFQUFFTixxQ0FBcUMsQ0FBQ3ZPLEtBQUQsRUFBUUgsTUFBUixDQUh2QztBQUl6QmlQLGdDQUF3QixFQUFFUix3QkFBd0IsQ0FBQ3RPLEtBQUQsRUFBUW1PLGdCQUFSLENBSnpCLENBSXlEOztBQUp6RCxPQUE3QjtBQU9BLGFBQU9PLHNCQUFQO0FBQ0gsS0FURCxDQVNFLE9BQU9uTSxFQUFQLEVBQVc7QUFDVEMsd0RBQU0sQ0FBQ0MsaUNBQVAsQ0FBeUNGLEVBQXpDLEVBQTZDLHNDQUE3QztBQUNBLFlBQU1BLEVBQU47QUFDSDtBQUNKLEdBN0NlO0FBOENoQndNLG9DQUFrQyxFQUFFLDRDQUFDL08sS0FBRCxFQUFRSCxNQUFSLEVBQWdCc08sZ0JBQWhCLEVBQ3BDO0FBQ0ksUUFBSTtBQUNBLFVBQUlhLHNCQUFzQixHQUFHO0FBQ3pCeFAsc0NBQThCLEVBQUUrTyxxQ0FBcUMsQ0FBQzFPLE1BQUQsRUFBUyxDQUFULENBRDVDO0FBRXpCRiw4Q0FBc0MsRUFBRTRPLHFDQUFxQyxDQUFDMU8sTUFBRCxFQUFTLENBQVQsQ0FGcEQ7QUFHekJrRSwwQkFBa0IsRUFBRXVLLHdCQUF3QixDQUFDdE8sS0FBRCxFQUFRSCxNQUFSLENBSG5CO0FBSXpCMEQsa0NBQTBCLEVBQUVnTCxxQ0FBcUMsQ0FBQ3ZPLEtBQUQsRUFBUUgsTUFBUixDQUp4QztBQU16QlUsNENBQW9DLEVBQUVnTyxxQ0FBcUMsQ0FBQzFPLE1BQUQsRUFBUyxDQUFULENBTmxEO0FBT3pCYSxvREFBNEMsRUFBRTZOLHFDQUFxQyxDQUFDMU8sTUFBRCxFQUFTLENBQVQsQ0FQMUQ7QUFRekI2RSx3Q0FBZ0MsRUFBRTZKLHFDQUFxQyxDQUFDdk8sS0FBRCxFQUFRSCxNQUFSLENBUjlDO0FBU3pCa0YsZ0NBQXdCLEVBQUV1Six3QkFBd0IsQ0FBQ3RPLEtBQUQsRUFBUW1PLGdCQUFSLENBVHpCLENBUzJEOztBQVQzRCxPQUE3QjtBQVlBLGFBQU9hLHNCQUFQO0FBQ0gsS0FkRCxDQWNFLE9BQU96TSxFQUFQLEVBQVc7QUFDVEMsd0RBQU0sQ0FBQ0MsaUNBQVAsQ0FBeUNGLEVBQXpDLEVBQTZDLHNDQUE3QztBQUNBLFlBQU1BLEVBQU47QUFDSDtBQUNKO0FBbEVlLENBQXBCOztBQXNFQSxTQUFTZ00scUNBQVQsQ0FBK0N2TyxLQUEvQyxFQUFzREgsTUFBdEQsRUFDQTtBQUNJLE1BQUk7QUFDQSxRQUFJeU0sSUFBSSxHQUFHLElBQUk3RixLQUFKLENBQVU1RyxNQUFWLENBQVg7O0FBRUEsU0FBSyxJQUFJNkosQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRzdKLE1BQXBCLEVBQTRCNkosQ0FBQyxFQUE3QjtBQUNJNEMsVUFBSSxDQUFDNUMsQ0FBRCxDQUFKLEdBQVV4SixzREFBVSxDQUFDOEssYUFBWCxDQUF5QmhMLEtBQXpCLEVBQWdDZ08sT0FBaEMsRUFBeUNoTyxLQUF6QyxDQUFWO0FBREo7O0FBR0EsV0FBT3NNLElBQVA7QUFDSCxHQVBELENBT0UsT0FBTy9KLEVBQVAsRUFBVztBQUNUQyxzREFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsVUFBTUEsRUFBTjtBQUNIO0FBQ0o7O0FBRUQsU0FBUytMLHdCQUFULENBQWtDdE8sS0FBbEMsRUFBeUNILE1BQXpDLEVBQWlEO0FBQzdDLE1BQUk7QUFDQSxRQUFJeU0sSUFBSSxHQUFHLElBQUk3RixLQUFKLENBQVU1RyxNQUFWLENBQVg7O0FBRUEsU0FBSyxJQUFJNkosQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRzdKLE1BQXBCLEVBQTRCNkosQ0FBQyxFQUE3QjtBQUNJNEMsVUFBSSxDQUFDNUMsQ0FBRCxDQUFKLEdBQVV4SixzREFBVSxDQUFDOEssYUFBWCxDQUF5QmhMLEtBQXpCLEVBQWdDZ08sT0FBaEMsRUFBeUNDLE9BQU8sR0FBRyxDQUFuRCxDQUFWO0FBREo7O0FBR0EsV0FBTzNCLElBQVA7QUFDSCxHQVBELENBT0UsT0FBTy9KLEVBQVAsRUFBVztBQUNUQyxzREFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsVUFBTUEsRUFBTjtBQUNIO0FBQ0o7O0FBS2N0RCw0RUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUdBO0FBQ0E7QUFFQSxJQUFJZ1EsT0FBTyxHQUFHLElBQWQ7QUFFQSxJQUFNQyxNQUFNLEdBQ1o7QUFDSUMsaUJBQWUsRUFBRSwyQkFBTTtBQUNuQkQsVUFBTSxDQUFDRSxrQkFBUCxDQUEwQkMsR0FBMUI7QUFDQUMsb0JBQWdCO0FBQ25CLEdBSkw7QUFLSUMsV0FBUyxFQUFFLG1CQUFDQyxNQUFELEVBQVk7QUFBRVAsV0FBTyxHQUFHTyxNQUFWO0FBQW1CLEdBTGhEO0FBTUlDLGFBQVcsRUFBRSxJQU5qQjtBQU9JTCxvQkFBa0IsRUFBRSxFQVB4QjtBQVFJTSxtQkFBaUIsRUFBRTtBQUFBLFdBQU1SLE1BQU0sQ0FBQ0Usa0JBQVAsQ0FBMEJyUCxNQUFoQztBQUFBLEdBUnZCO0FBU0k7QUFDQTRQLFdBQVM7QUFBQTtBQUFBO0FBQUEsNEJBQUUsaUJBQU9DLGlCQUFQLEVBQTBCQyxrQkFBMUIsRUFBOENDLFlBQTlDO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUdDckgsa0JBSEQsR0FHUSxFQUhSO0FBSUNzSCxrQkFKRCxHQUlRSCxpQkFKUjtBQUtDSSxtQ0FMRCxHQUt5QixJQUFJdkosS0FBSixFQUx6Qjs7QUFBQSxvQkFPQ3NKLElBQUksQ0FBQ2hRLE1BQUwsR0FBYyxDQVBmO0FBQUE7QUFBQTtBQUFBOztBQVFLa1EsMkJBUkwsR0FRcUIxQyxtREFBVSxDQUFDQyxnQkFBWCxDQUE0QjBDLE9BQTVCLENBQW9DSixZQUFZLENBQUNDLElBQUksQ0FBQyxDQUFELENBQUosQ0FBUXhDLG1EQUFVLENBQUNFLG1DQUFuQixDQUFELENBQWhELENBUnJCO0FBU0t6TixtQkFUTCxHQVNhK1AsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRaFEsTUFUckI7QUFVS0Ysb0JBVkwsR0FVY2tRLElBQUksQ0FBQ2hRLE1BVm5CO0FBWVUrSixlQVpWLEdBWWMsQ0FaZDs7QUFBQTtBQUFBLG9CQVlpQkEsQ0FBQyxHQUFHOUosS0FackI7QUFBQTtBQUFBO0FBQUE7O0FBYVNtUSxxQ0FiVCxHQWFtQ3RRLE1BQU0sR0FBR2lLLENBYjVDOztBQUFBLG9CQWVTcUcsdUJBQXVCLElBQUlGLGFBQTNCLElBQTRDQSxhQUFhLEdBQUdFLHVCQUF1QixHQUFHdFEsTUFmL0Y7QUFBQTtBQUFBO0FBQUE7O0FBZ0JTdVEscUNBQXVCLEdBQUdELHVCQUExQjtBQWhCVDs7QUFBQTtBQVk0QnJHLGVBQUMsRUFaN0I7QUFBQTtBQUFBOztBQUFBO0FBcUJDa0csbUNBQXFCLEdBQUd6QyxtREFBVSxDQUFDQyxnQkFBWCxDQUE0QnBDLEtBQTVCLENBQWtDZ0YsdUJBQWxDLEVBQTJEQSx1QkFBdUIsR0FBR3ZRLE1BQXJGLENBQXhCOztBQXJCRDtBQXdCSCxtQkFBU2lLLEdBQVQsR0FBYSxDQUFiLEVBQWdCQSxHQUFDLEdBQUdpRyxJQUFJLENBQUNoUSxNQUF6QixFQUFpQytKLEdBQUMsRUFBbEMsRUFBc0M7QUFDdEM7QUFDSSxxQkFBU08sQ0FBVCxHQUFhLENBQWIsRUFBZ0JBLENBQUMsR0FBRzBGLElBQUksQ0FBQ2hRLE1BQXpCLEVBQWlDc0ssQ0FBQyxFQUFsQyxFQUFzQztBQUN0QztBQUNJMEYsc0JBQUksQ0FBQzFGLENBQUQsQ0FBSixDQUFRZ0csUUFBUixHQUFtQmhHLENBQW5COztBQUNBLHNCQUFJeUYsWUFBWSxDQUFDQyxJQUFJLENBQUMxRixDQUFELENBQUosQ0FBUWtELG1EQUFVLENBQUNFLG1DQUFuQixDQUFELENBQVosS0FBMEV1QyxxQkFBcUIsQ0FBQ2xHLEdBQUQsQ0FBbkcsRUFBd0c7QUFDcEdyQix3QkFBSSxDQUFDL0IsSUFBTCxDQUFVcUosSUFBSSxDQUFDMUYsQ0FBRCxDQUFkO0FBQ0g7QUFDSjtBQUNKOztBQUVHaUcsa0JBbkNELEdBbUNRLEVBbkNSO0FBQUE7QUFBQSxxQkFvQ3NCOU4sK0NBQU0sQ0FBQ3NFLEdBQVAsQ0FBV21JLE9BQU8sQ0FBQ3NCLGtCQUFSLENBQTJCQyxPQUEzQixDQUFtQyw0QkFBbkMsRUFBaUVYLGtCQUFqRSxDQUFYLENBcEN0Qjs7QUFBQTtBQW9DQ1ksMEJBcENEO0FBc0NIO0FBQ0lDLDZCQXZDRCxHQXVDbUIsRUF2Q25CO0FBd0NDQyw2QkF4Q0QsR0F3Q21CLEVBeENuQjtBQXlDQ0MsK0JBekNELEdBeUNxQixFQXpDckI7QUEwQ0NDLDhCQTFDRCxHQTBDb0IsRUExQ3BCO0FBMkNDQyw4QkEzQ0QsR0EyQ29CLEVBM0NwQjtBQTRDQ0MsNkJBNUNELEdBNENtQixFQTVDbkI7QUE2Q0NDLCtCQTdDRCxHQTZDcUIsRUE3Q3JCO0FBK0NNM0csZ0JBL0NOLEdBK0NVLENBL0NWOztBQUFBO0FBQUEsb0JBK0NhQSxFQUFDLEdBQUc1QixJQUFJLENBQUMxSSxNQS9DdEI7QUFBQTtBQUFBO0FBQUE7O0FBa0RVa1IsZUFsRFYsR0FrRGMsQ0FsRGQ7O0FBQUE7QUFBQSxvQkFrRGlCQSxDQUFDLEdBQUd4SSxJQUFJLENBQUM0QixFQUFELENBQUosQ0FBUXRLLE1BbEQ3QjtBQUFBO0FBQUE7QUFBQTs7QUFtRFNtUix1QkFuRFQsR0FtRHFCekksSUFBSSxDQUFDNEIsRUFBRCxDQUFKLENBQVE0RyxDQUFSLENBbkRyQjtBQUFBLDRCQXFEYUEsQ0FyRGI7QUFBQSw4Q0FzRGMsQ0F0RGQsd0JBeURjLENBekRkLHdCQTREYyxDQTVEZCx3QkErRGMsQ0EvRGQsd0JBa0VjLENBbEVkLHdCQXFFYyxDQXJFZCx3QkF3RWMsQ0F4RWQ7QUFBQTs7QUFBQTtBQXVEYVAsNkJBQWUsR0FBR1osWUFBWSxDQUFDb0IsU0FBRCxDQUE5QjtBQXZEYjs7QUFBQTtBQTBEYVAsNkJBQWUsR0FBR2IsWUFBWSxDQUFDb0IsU0FBRCxDQUE5QjtBQTFEYjs7QUFBQTtBQTZEYU4sK0JBQWlCLEdBQUdkLFlBQVksQ0FBQ29CLFNBQUQsQ0FBaEM7QUE3RGI7O0FBQUE7QUFnRWFMLDhCQUFnQixHQUFHZixZQUFZLENBQUNvQixTQUFELENBQS9CO0FBaEViOztBQUFBO0FBbUVhSiw4QkFBZ0IsR0FBR2hCLFlBQVksQ0FBQ29CLFNBQUQsQ0FBL0I7QUFuRWI7O0FBQUE7QUFzRWFILDZCQUFlLEdBQUdqQixZQUFZLENBQUNvQixTQUFELENBQTlCO0FBdEViOztBQUFBO0FBeUVhRiwrQkFBaUIsR0FBR2xCLFlBQVksQ0FBQ29CLFNBQUQsQ0FBaEM7QUF6RWI7O0FBQUE7QUFrRHFDRCxlQUFDLEVBbER0QztBQUFBO0FBQUE7O0FBQUE7QUE4RUMsa0JBQUk1RyxFQUFDLEtBQUssQ0FBTixJQUFXQSxFQUFDLEtBQUssQ0FBakIsSUFBc0JBLEVBQUMsS0FBSyxDQUFoQyxFQUFtQztBQUMvQmlHLG9CQUFJLElBQUksZ0RBQVI7QUFDSCxlQUZELE1BRU8sSUFBSWpHLEVBQUMsS0FBSyxDQUFWLEVBQWE7QUFDaEJpRyxvQkFBSSxJQUFJLCtDQUFSO0FBQ0g7O0FBRURBLGtCQUFJLElBQUlHLFlBQVksQ0FDZkQsT0FERyxDQUNLLGlCQURMLEVBQ3dCL0gsSUFBSSxDQUFDNEIsRUFBRCxDQUFKLENBQVFnRyxRQURoQyxFQUVIRyxPQUZHLENBRUsseUJBRkwsRUFFZ0NFLGVBRmhDLEVBR0hGLE9BSEcsQ0FHSyx5QkFITCxFQUdnQ0csZUFIaEMsRUFJSEgsT0FKRyxDQUlLLDJCQUpMLEVBSWtDSSxpQkFKbEMsRUFLSEosT0FMRyxDQUtLLDBCQUxMLEVBS2lDSyxnQkFMakMsRUFNSEwsT0FORyxDQU1LLDBCQU5MLEVBTWlDTSxnQkFOakMsRUFPSE4sT0FQRyxDQU9LLHlCQVBMLEVBT2dDTyxlQVBoQyxFQVFIUCxPQVJHLENBUUssMkJBUkwsRUFRa0NRLGlCQVJsQyxDQUFSOztBQVVBLGtCQUFJM0csRUFBQyxLQUFLLENBQU4sSUFBV0EsRUFBQyxLQUFLLENBQWpCLElBQXNCQSxFQUFDLEtBQUssQ0FBNUIsSUFBaUNBLEVBQUMsS0FBSyxDQUEzQyxFQUE4QztBQUMxQ2lHLG9CQUFJLElBQUksUUFBUjtBQUNIOztBQWhHRjtBQStDOEJqRyxnQkFBQyxFQS9DL0I7QUFBQTtBQUFBOztBQUFBO0FBbUdDOEcseUNBbkdELEdBbUcrQkMsUUFBUSxDQUFDQyxjQUFULENBQXdCcEMsT0FBTyxDQUFDcUMsNkJBQWhDLENBbkcvQjs7QUFvR0gsa0JBQUlILDJCQUFKLEVBQWlDO0FBQzdCQSwyQ0FBMkIsQ0FBQ0ksU0FBNUIsR0FBd0NqQixJQUF4QztBQUNJa0IsNkJBRnlCLEdBRVRKLFFBQVEsQ0FBQ0ssZ0JBQVQsQ0FBMEIsU0FBMUIsQ0FGUzs7QUFHN0IscUJBQVNwSCxHQUFULEdBQWEsQ0FBYixFQUFnQkEsR0FBQyxHQUFHbUgsYUFBYSxDQUFDelIsTUFBbEMsRUFBMENzSyxHQUFDLEVBQTNDLEVBQStDO0FBQzNDO0FBQ0FtSCwrQkFBYSxDQUFDbkgsR0FBRCxDQUFiLENBQWlCcUgsZ0JBQWpCLENBQWtDLE9BQWxDLEVBQTJDQyxRQUEzQyxFQUYyQyxDQUkzQzs7O0FBQ0FILCtCQUFhLENBQUNuSCxHQUFELENBQWIsQ0FBaUJxSCxnQkFBakIsQ0FBa0MsV0FBbEMsRUFBK0NFLFNBQS9DO0FBQ0g7QUFDSjs7QUE5R0U7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFnSEhwUCw2REFBTSxDQUFDQyxpQ0FBUCxjQUE2QyxzQ0FBN0M7QUFoSEc7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBRjs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSxLQVZiO0FBOEhJb1AsT0FBSztBQUFBO0FBQUE7QUFBQSw0QkFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0gzQyxvQkFBTSxDQUFDRSxrQkFBUCxHQUE0QixFQUE1QjtBQUNBRSw4QkFBZ0I7O0FBRmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBRjs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQTlIVCxDQURBOztBQXNJQSxTQUFTQSxnQkFBVCxHQUE0QjtBQUN4QixNQUFJSixNQUFNLENBQUNPLFdBQVgsRUFBd0I7QUFDcEIsUUFBSTtBQUNBUCxZQUFNLENBQUNPLFdBQVA7QUFDSCxLQUZELENBR0EsZ0JBQUssQ0FBRyxDQUpZLENBSVg7O0FBQ1o7QUFDSjs7QUFFRCxTQUFTbUMsU0FBVCxDQUFtQkUsQ0FBbkIsRUFBc0I7QUFBRztBQUNyQkEsR0FBQyxDQUFDQyxjQUFGO0FBQ0EsU0FBTyxLQUFQO0FBQ0g7O0FBRUQsU0FBU0osUUFBVCxDQUFvQkcsQ0FBcEIsRUFBdUI7QUFBRztBQUN0QixNQUFJO0FBQ0EsUUFBSTVDLE1BQU0sQ0FBQ0Usa0JBQVAsQ0FBMEJyUCxNQUExQixHQUFtQ2tQLE9BQU8sQ0FBQytDLGVBQS9DLEVBQWdFO0FBQzVELFVBQUlDLE9BQU8sR0FBR0gsQ0FBQyxDQUFDSSxhQUFGLENBQWdCQyxPQUFoQixDQUF3QkYsT0FBdEM7QUFDQS9DLFlBQU0sQ0FBQ0Usa0JBQVAsQ0FBMEIxSSxJQUExQixDQUErQnVMLE9BQS9CO0FBRUEzQyxzQkFBZ0I7QUFDbkI7QUFDSixHQVBELENBT0UsT0FBTy9NLEVBQVAsRUFBVztBQUNUQyxtREFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsVUFBTUEsRUFBTjtBQUNIO0FBQ0o7O0FBRWMyTSxxRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2S0E7Ozs7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1rRCxlQUFlLEdBQUcsQ0FBeEI7QUFDQSxJQUFNQyxnQkFBZ0IsR0FBRyxFQUF6QjtBQUVBLElBQUlDLE9BQU8sR0FBR0MsK0NBQWQ7QUFDQSxJQUFJQyxjQUFjLEdBQUcsRUFBckI7QUFDQSxJQUFJQyxlQUFlLEdBQUcsRUFBdEI7QUFDQSxJQUFJeEQsT0FBTyxHQUFHLElBQWQ7O1NBRWV5RCxlOzs7QUErQmY7Ozs7Ozs7OzswQkEvQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBK0JDLG9CQUEvQiw4REFBMEMsSUFBMUM7QUFBZ0Q5Qyw4QkFBaEQ7QUFBb0UrQyx1QkFBcEU7QUFBaUZDLDBCQUFqRjtBQUFBOztBQUVRUCxtQkFBTyxDQUFDVCxLQUFSOztBQUNNOUssZUFIZCxHQUdvQjRMLFFBQVEsS0FBSyxJQUFiLGFBQXVCMUQsT0FBTyxDQUFDNkQsT0FBL0IsNkNBQXlFN0QsT0FBTyxDQUFDNkQsT0FBakYsZ0NBSHBCO0FBS1lDLG1DQUxaLEdBS3NDQywrQkFBK0IsRUFMckUsRUFPUTs7QUFQUjtBQUFBLG1CQVE2QnhRLCtDQUFNLENBQUMwRixJQUFQLENBQ2pCbkIsR0FEaUIsRUFFakI7QUFDSSwwQkFBWWtJLE9BQU8sQ0FBQ2dFLFNBRHhCO0FBRUksMEJBQVlOLFFBRmhCO0FBR0ksNkJBQWVDLFdBSG5CO0FBSUkscUNBQXVCRyx1QkFKM0I7QUFLSSw4Q0FBZ0NQLGNBQWMsQ0FBQ1UsNEJBTG5EO0FBTUksZ0NBQWtCTCxjQUFjLElBQUk7QUFOeEMsYUFGaUIsQ0FSN0I7O0FBQUE7QUFRWTlLLG9CQVJaO0FBb0JRb0wsK0JBQW1CLENBQUNwTCxRQUFELENBQW5CO0FBcEJSO0FBQUEsbUJBc0JjdUssT0FBTyxDQUFDM0MsU0FBUixDQUFrQjZDLGNBQWMsQ0FBQzVDLGlCQUFqQyxFQUFvRDRDLGNBQWMsQ0FBQ1ksc0JBQWYsSUFBeUN2RCxrQkFBN0YsRUFBaUgyQyxjQUFjLENBQUNhLHFCQUFoSSxDQXRCZDs7QUFBQTtBQXVCUWIsMEJBQWMsQ0FBQzVDLGlCQUFmLEdBQW1DLElBQW5DO0FBQ0E0QywwQkFBYyxDQUFDYyxxQkFBZixHQUF1QyxJQUF2QztBQXhCUjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQTBCUTlRLDJEQUFNLENBQUNDLGlDQUFQLGVBQTRDLHNDQUE1QztBQTFCUjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHOzs7O0FBbUNBLElBQUk4USxLQUFLLEdBQ1Q7QUFDSTs7Ozs7Ozs7Ozs7OztBQWFBaEUsV0FBUyxFQUFFLG1CQUFDQyxNQUFELEVBQVk7QUFBRVAsV0FBTyxHQUFHTyxNQUFWOztBQUFrQjhDLFdBQU8sQ0FBQy9DLFNBQVIsQ0FBa0JDLE1BQWxCO0FBQTRCLEdBZDNFOztBQWVJOzs7O0FBSUFMLGlCQUFlLEVBQUUsMkJBQU07QUFBRW1ELFdBQU8sQ0FBQ25ELGVBQVI7QUFBNEIsR0FuQnpEOztBQW9CSTs7Ozs7QUFLQXFFLHVCQUFxQixFQUFFLCtCQUFDQyxRQUFELEVBQWM7QUFBRW5CLFdBQU8sQ0FBQzdDLFdBQVIsR0FBc0JnRSxRQUF0QjtBQUFpQyxHQXpCNUU7O0FBMEJJOzs7OztBQUtBL0QsbUJBQWlCLEVBQUU7QUFBQSxXQUFNNEMsT0FBTyxDQUFDNUMsaUJBQVIsRUFBTjtBQUFBLEdBL0J2Qjs7QUFpQ0k7Ozs7Ozs7O0FBU0FnRSx3QkFBc0I7QUFBQTtBQUFBO0FBQUEsNEJBQUMsaUJBQWdCZixRQUFoQixFQUEwQmdCLHlCQUExQixFQUFxRGYsV0FBckQsRUFBa0VDLGNBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVmSiw2QkFBZSxHQUFHLEVBQWxCO0FBRmU7QUFBQSxxQkFHVEMsZUFBZSxDQUFDQyxRQUFELEVBQVdnQix5QkFBWCxFQUFzQ2YsV0FBdEMsRUFBbURDLGNBQW5ELENBSE47O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUtmclEsNkRBQU0sQ0FBQ0MsaUNBQVAsY0FBNEMsc0NBQTVDO0FBTGU7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBRDs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSxLQTFDMUI7O0FBbURJOzs7Ozs7QUFNQTtBQUNBO0FBQ0FtUiwyQkFBeUI7QUFBQTtBQUFBO0FBQUEsNEJBQUUsa0JBQWdCL0Qsa0JBQWhCLEVBQW9DZ0QsY0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRW5CSiw2QkFBZSxDQUFDb0IseUJBQWhCLEdBQTRDaEUsa0JBQTVDO0FBRm1CO0FBQUEscUJBR2I2QyxlQUFlLENBQUMsSUFBRCxFQUFPN0Msa0JBQVAsRUFBMkIsSUFBM0IsRUFBaUNnRCxjQUFqQyxDQUhGOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFLbkJyUSw2REFBTSxDQUFDQyxpQ0FBUCxlQUE0QyxzQ0FBNUM7QUFMbUI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBRjs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSxLQTNEN0I7O0FBb0VJOzs7Ozs7O0FBT0FxUixPQUFLO0FBQUE7QUFBQTtBQUFBLDRCQUFFLGtCQUFPQyxRQUFQLEVBQWlCbEIsY0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFHS21CLDBCQUhMLEdBR29CQyw4QkFBOEIsQ0FBQzNCLE9BQU8sQ0FBQ2xELGtCQUFULENBSGxEO0FBQUE7QUFBQSxxQkFLc0I1TSwrQ0FBTSxDQUFDMEYsSUFBUCxDQUNqQitHLE9BQU8sQ0FBQzZELE9BQVIsR0FBa0IsWUFERCxFQUVqQjtBQUNJLDRCQUFZN0QsT0FBTyxDQUFDZ0UsU0FEeEI7QUFFSSw2QkFBYVQsY0FBYyxDQUFDMEIsU0FGaEM7QUFHSSw0QkFBWUgsUUFIaEI7QUFJSSx3QkFBUUMsWUFKWjtBQUtJLGtDQUFrQm5CLGNBQWMsSUFBSTtBQUx4QyxlQUZpQixDQUx0Qjs7QUFBQTtBQUtLOUssc0JBTEw7QUFBQSxnREFpQlFBLFFBakJSOztBQUFBO0FBQUE7QUFBQTtBQW9CQ3ZGLDZEQUFNLENBQUNDLGlDQUFQLGVBQTRDLHNDQUE1QztBQXBCRDs7QUFBQTtBQUFBO0FBd0JDMFIsbUJBQUs7QUF4Qk47O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBRjs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSxLQTNFVDs7QUFzR0k7Ozs7Ozs7QUFPQUMsa0JBQWdCO0FBQUE7QUFBQTtBQUFBLDRCQUFFLGtCQUFPTCxRQUFQLEVBQWlCbEIsY0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFHVkosNkJBQWUsQ0FBQzRCLGVBQWhCLEdBQWtDL0IsT0FBTyxDQUFDbEQsa0JBQVIsQ0FBMkJyUCxNQUE3RDtBQUNBeUMsNkRBQU0sQ0FBQ21FLGFBQVAsQ0FBcUIyTCxPQUFPLENBQUNsRCxrQkFBN0IsRUFBaUQsc0JBQWpEO0FBQ0E1TSw2REFBTSxDQUFDbUUsYUFBUCxDQUFxQjJMLE9BQU8sQ0FBQ0ssUUFBN0IsRUFBdUMsVUFBdkM7QUFFSUkscUNBUE0sR0FPb0JDLCtCQUErQixFQVBuRDtBQVFOZ0IsMEJBUk0sR0FRU0MsOEJBQThCLENBQUMzQixPQUFPLENBQUNsRCxrQkFBVCxDQVJ2QztBQVVWNU0sNkRBQU0sQ0FBQ21FLGFBQVAsQ0FBcUJxTixZQUFyQixFQUFtQyxnQkFBbkM7QUFWVTtBQUFBLHFCQVlXeFIsK0NBQU0sQ0FBQzBGLElBQVAsV0FDZCtHLE9BQU8sQ0FBQzZELE9BRE0sb0JBRWpCO0FBQ0ksNEJBQVk3RCxPQUFPLENBQUNnRSxTQUR4QjtBQUVJLDZCQUFhVCxjQUFjLENBQUMwQixTQUZoQztBQUdJLDRCQUFZSCxRQUhoQjtBQUlJLHdCQUFRQyxZQUpaO0FBS0ksdUNBQXVCakIsdUJBTDNCO0FBTUksZ0RBQWdDUCxjQUFjLENBQUNVLDRCQU5uRDtBQU9JLGtDQUFrQkwsY0FBYyxJQUFJO0FBUHhDLGVBRmlCLENBWlg7O0FBQUE7QUFZTjlLLHNCQVpNOztBQUFBLG1CQXdCTkEsUUFBUSxDQUFDdU0sVUF4Qkg7QUFBQTtBQUFBO0FBQUE7O0FBQUEsZ0RBeUJDdk0sUUF6QkQ7O0FBQUE7QUEyQlZ1SyxxQkFBTyxDQUFDVCxLQUFSOztBQUVBc0IsaUNBQW1CLENBQUNwTCxRQUFELENBQW5CO0FBN0JVO0FBQUEscUJBK0JKdUssT0FBTyxDQUFDM0MsU0FBUixDQUFrQjZDLGNBQWMsQ0FBQzVDLGlCQUFqQyxFQUFvRDZDLGVBQWUsQ0FBQ29CLHlCQUFwRSxFQUErRnJCLGNBQWMsQ0FBQ2EscUJBQTlHLENBL0JJOztBQUFBO0FBZ0NWYiw0QkFBYyxDQUFDNUMsaUJBQWYsR0FBbUMsSUFBbkM7QUFoQ1UsZ0RBa0NILElBbENHOztBQUFBO0FBQUE7QUFBQTtBQXNDVnBOLDZEQUFNLENBQUNDLGlDQUFQLGVBQTZDLHNDQUE3QztBQXRDVTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFGOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLEtBN0dwQjs7QUF1Skk7Ozs7Ozs7OztBQVNBOFIsa0JBQWdCO0FBQUE7QUFBQTtBQUFBLDRCQUFFLGtCQUFPUixRQUFQLEVBQWlCbkIsV0FBakIsRUFBOEIvQyxrQkFBOUIsRUFBa0RnRCxjQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQSxvQkFHTkosZUFBZSxDQUFDNEIsZUFBaEIsS0FBb0MvQixPQUFPLENBQUNsRCxrQkFBUixDQUEyQnJQLE1BSHpEO0FBQUE7QUFBQTtBQUFBOztBQUFBLGdEQUlDO0FBQUV5VSxpQ0FBaUIsRUFBRTtBQUFyQixlQUpEOztBQUFBO0FBS05SLDBCQUxNLEdBS1NDLDhCQUE4QixDQUFDM0IsT0FBTyxDQUFDbEQsa0JBQVQsQ0FMdkM7QUFBQTtBQUFBLHFCQU9TNU0sK0NBQU0sQ0FBQzBGLElBQVAsV0FDWitHLE9BQU8sQ0FBQzZELE9BREksd0JBRWY7QUFDSSw0QkFBWTdELE9BQU8sQ0FBQ2dFLFNBRHhCO0FBRUksNkJBQWFULGNBQWMsQ0FBQzBCLFNBRmhDO0FBR0ksNEJBQVlILFFBSGhCO0FBSUksd0JBQVFDLFlBSlo7QUFLSSwrQkFBZXBCLFdBTG5CO0FBTUksc0NBQXNCL0Msa0JBTjFCO0FBT0ksa0NBQWtCZ0QsY0FBYyxJQUFJO0FBUHhDLGVBRmUsQ0FQVDs7QUFBQTtBQU9OL08sb0JBUE07QUFBQSxnREFtQkhBLE1BbkJHOztBQUFBO0FBQUE7QUFBQTtBQXVCVnRCLDZEQUFNLENBQUNDLGlDQUFQLGVBQTZDLHNDQUE3QztBQXZCVTs7QUFBQTtBQUFBO0FBMkJWMFIsbUJBQUs7QUEzQks7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBRjs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSxLQWhLcEI7O0FBOExJOzs7Ozs7QUFNQU0saUNBQStCLEVBQUUsMkNBQU07QUFDbkMsV0FBT3ZVLHNEQUFVLENBQUNtTSxxQ0FBWCxDQUFpRCxDQUFqRCxFQUFvRCxFQUFwRCxFQUF3RGtCLG1EQUFVLENBQUNDLGdCQUFuRSxDQUFQO0FBQ0gsR0F0TUw7O0FBdU1JOzs7O0FBSUFxRSxPQUFLLEVBQUUsaUJBQU07QUFDVFMsV0FBTyxDQUFDVCxLQUFSO0FBQ0g7QUE3TUwsQ0FEQTs7QUFpTkEsU0FBU3NDLEtBQVQsR0FDQTtBQUFHO0FBQ0M3QixTQUFPLENBQUNULEtBQVI7O0FBQ0FXLGdCQUFjLEdBQUcsRUFBakI7QUFDQUMsaUJBQWUsR0FBRyxFQUFsQjtBQUNIOztBQUVELFNBQVNPLCtCQUFULEdBQ0E7QUFDSSxNQUFJO0FBQ0EsUUFBSTBCLHVCQUF1QixHQUFHbkgsbURBQVUsQ0FBQ0MsZ0JBQVgsQ0FBNEJ6TixNQUExRDtBQUNBeVMsa0JBQWMsQ0FBQ21DLG1CQUFmLEdBQXFDMVYsc0RBQWEsQ0FBQ3dQLGtDQUFkLENBQWlEMkQsZUFBakQsRUFBa0VDLGdCQUFsRSxFQUFvRkEsZ0JBQXBGLENBQXJDO0FBQ0FHLGtCQUFjLENBQUNVLDRCQUFmLEdBQThDalUsc0RBQWEsQ0FBQ2lQLGtDQUFkLENBQWlEa0UsZUFBakQsRUFBa0VDLGdCQUFsRSxFQUFvRkEsZ0JBQXBGLENBQTlDO0FBQ0FHLGtCQUFjLENBQUNtQyxtQkFBZixHQUFxQ25NLE1BQU0sQ0FBQ29NLE1BQVAsQ0FBY3BDLGNBQWMsQ0FBQ21DLG1CQUE3QixFQUFrRG5DLGNBQWMsQ0FBQ1UsNEJBQWpFLENBQXJDO0FBQ0EsUUFBSUkscUJBQXFCLEdBQUdwVCxzREFBVSxDQUFDOEssYUFBWCxDQUF5QjBKLHVCQUF6QixFQUFrRCxDQUFsRCxFQUFxRCxHQUFyRCxDQUE1QixDQUxBLENBS3VGOztBQUN2RmxDLGtCQUFjLENBQUNhLHFCQUFmLEdBQXVDLEVBQXZDO0FBQ0FiLGtCQUFjLENBQUNxQyxpQkFBZixHQUFtQyxJQUFJcE8sS0FBSixFQUFuQzs7QUFFQSxTQUFLLElBQUlxRCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHNEssdUJBQXBCLEVBQTZDNUssQ0FBQyxFQUE5QyxFQUFrRDtBQUFFO0FBQ2hEMEksb0JBQWMsQ0FBQ3FDLGlCQUFmLENBQWlDbk8sSUFBakMsQ0FBc0MsQ0FBQzRNLHFCQUFxQixDQUFDeEosQ0FBRCxDQUF0QixFQUEyQmdMLE1BQTNCLENBQWtDNVUsc0RBQVUsQ0FBQzhLLGFBQVgsQ0FBeUJvSCxlQUFlLEdBQUcsQ0FBM0MsRUFBOEMsQ0FBOUMsRUFBaUQsR0FBakQsQ0FBbEMsQ0FBdEM7O0FBQ0FJLG9CQUFjLENBQUNhLHFCQUFmLENBQXFDQyxxQkFBcUIsQ0FBQ3hKLENBQUQsQ0FBckIsQ0FBeUJpTCxRQUF6QixFQUFyQyxJQUE0RXhILG1EQUFVLENBQUNDLGdCQUFYLENBQTRCMUQsQ0FBNUIsQ0FBNUUsQ0FGOEMsQ0FFOEQ7QUFDL0c7O0FBRUQsUUFBSWtMLFVBQVUsR0FBR0MsaURBQVEsQ0FBQy9QLFFBQVQsQ0FBa0JxSSxtREFBVSxDQUFDSSwwQkFBN0IsRUFBeUQ2RSxjQUFjLENBQUNtQyxtQkFBeEUsRUFBNkZuQyxjQUFjLENBQUNxQyxpQkFBNUcsQ0FBakI7QUFFQSxXQUFPRyxVQUFQO0FBQ0gsR0FqQkQsQ0FpQkUsT0FBT3pTLEVBQVAsRUFDRjtBQUNJQyxtREFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsVUFBTUEsRUFBTjtBQUNIO0FBQ0o7O0FBRUQsU0FBUzBSLDhCQUFULENBQXdDOVUsYUFBeEMsRUFDQTtBQUNJLE1BQUk7QUFDQSxRQUFJK1YsVUFBVSxHQUFHalEsaURBQVEsQ0FBQ0MsUUFBVCxDQUFrQnFJLG1EQUFVLENBQUNHLFdBQTdCLEVBQTBDOEUsY0FBYyxDQUFDMkMsbUJBQXpELEVBQThFM0MsY0FBYyxDQUFDNEMsY0FBN0YsQ0FBakI7QUFDQSxRQUFJQyxXQUFXLEdBQUd2VyxvREFBVyxDQUFDQyxZQUFaLENBQXlCd08sbURBQVUsQ0FBQ0csV0FBcEMsRUFBaUQ4RSxjQUFjLENBQUMyQyxtQkFBaEUsRUFBcUZELFVBQXJGLEVBQWlHL1YsYUFBakcsQ0FBbEI7QUFFQSxXQUFPa1csV0FBUDtBQUNILEdBTEQsQ0FLRSxPQUFPOVMsRUFBUCxFQUFXO0FBQ1RDLG1EQUFNLENBQUNDLGlDQUFQLENBQXlDRixFQUF6QyxFQUE2QyxzQ0FBN0M7QUFDQSxVQUFNQSxFQUFOO0FBQ0g7QUFDSjs7QUFHRCxTQUFTNFEsbUJBQVQsQ0FBNkJwTCxRQUE3QixFQUNBO0FBQ0ksTUFBSTtBQUNBeUssa0JBQWMsR0FBR2hLLE1BQU0sQ0FBQ29NLE1BQVAsQ0FBY3BDLGNBQWQsRUFBOEJ6SyxRQUE5QixDQUFqQixDQURBLENBQzBEOztBQUUxRHlLLGtCQUFjLENBQUMyQyxtQkFBZixHQUFxQ2xXLHNEQUFhLENBQUM4UCxrQ0FBZCxDQUFpRCxDQUFqRCxFQUFvRCxFQUFwRCxFQUF3RCxFQUF4RCxDQUFyQztBQUNBeUQsa0JBQWMsQ0FBQzJDLG1CQUFmLEdBQXFDM00sTUFBTSxDQUFDb00sTUFBUCxDQUFjcEMsY0FBYyxDQUFDMkMsbUJBQTdCLEVBQWtEM0MsY0FBYyxDQUFDOEMseUJBQWpFLENBQXJDLENBSkEsQ0FJa0k7O0FBRWxJOUMsa0JBQWMsQ0FBQytDLGNBQWYsR0FBZ0M3UyxpREFBUSxDQUFDQyxPQUFULENBQWlCNEssbURBQVUsQ0FBQ0csV0FBNUIsRUFBeUM4RSxjQUFjLENBQUMyQyxtQkFBeEQsRUFBNkVwTixRQUFRLENBQUNxTixjQUF0RixDQUFoQyxDQU5BLENBTXVJOztBQUV2SSxRQUFJSSxhQUFhLEdBQUdDLGlEQUFRLENBQUNDLFNBQVQsQ0FBbUJuSSxtREFBVSxDQUFDSSwwQkFBOUIsRUFBMEQ2RSxjQUFjLENBQUNtQyxtQkFBekUsRUFBOEY1TSxRQUFRLENBQUM0TixpQkFBdkcsRUFBMEhuRCxjQUFjLENBQUNxQyxpQkFBekksQ0FBcEIsQ0FSQSxDQVVBOztBQUNBVyxpQkFBYSxHQUFHQSxhQUFhLENBQUM5TSxHQUFkLENBQWtCLFVBQUNPLEtBQUQ7QUFBQSxhQUFXQSxLQUFLLENBQUMsQ0FBRCxDQUFoQjtBQUFBLEtBQWxCLENBQWhCO0FBRUF1SixrQkFBYyxDQUFDNUMsaUJBQWYsR0FBbUMxUCxzREFBVSxDQUFDbU0scUNBQVgsQ0FBaUQsRUFBakQsRUFBcUQsQ0FBckQsRUFBd0RtSixhQUF4RCxDQUFuQztBQUNILEdBZEQsQ0FjRSxPQUFPalQsRUFBUCxFQUFXO0FBQ1RDLG1EQUFNLENBQUNDLGlDQUFQLENBQXlDRixFQUF6QyxFQUE2QyxzQ0FBN0M7QUFDQSxVQUFNQSxFQUFOO0FBQ0g7QUFFSjs7QUFFY2dSLG9FQUFmLEU7Ozs7Ozs7Ozs7OztBQ2pWQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUVBLElBQU1rQyxRQUFRLEdBQUk7QUFFZDtBQUNDQyxXQUFTLEVBQUMsbUJBQUMxVyxjQUFELEVBQWlCQyxhQUFqQixFQUFnQzJXLE1BQWhDLEVBQXdDOVMsUUFBeEMsRUFBb0Q7QUFDMUQsUUFBSTtBQUNBLFVBQUkrUyx3Q0FBd0MsR0FBR3hXLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUN1Qyw4QkFBcEQsRUFBb0Z0QyxhQUFhLENBQUN1Qyx1Q0FBbEcsQ0FBL0M7QUFDQSxVQUFJc1UsdUNBQXVDLEdBQUd6VyxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDMEMsNkJBQXBELEVBQW1GekMsYUFBYSxDQUFDMEMsc0NBQWpHLENBQTlDO0FBQ0FrVSw4Q0FBd0MsR0FBR3hXLHFEQUFTLENBQUNPLHdCQUFWLENBQW1DUCxxREFBUyxDQUFDQywwQkFBVixDQUFxQ3dXLHVDQUFyQyxFQUE4RUQsd0NBQTlFLENBQW5DLENBQTNDO0FBQ0FDLDZDQUF1QyxHQUFHelcscURBQVMsQ0FBQ08sd0JBQVYsQ0FBbUNrVyx1Q0FBbkMsQ0FBMUM7QUFDQSxVQUFJQywrQ0FBK0MsR0FBRzFXLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUNpRCxxQ0FBcEQsRUFBMkZoRCxhQUFhLENBQUNpRCw4Q0FBekcsQ0FBdEQ7QUFDQTZULHFEQUErQyxHQUFHMVcscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUN5VywrQ0FBckMsRUFBc0ZGLHdDQUF0RixDQUFsRDtBQUNBLFVBQUlHLDhDQUE4QyxHQUFHM1cscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNOLGNBQWMsQ0FBQzZGLDhCQUFwRCxFQUFvRjVGLGFBQWEsQ0FBQzZGLHVDQUFsRyxDQUFyRDtBQUNBLFVBQUltUiw2Q0FBNkMsR0FBRzVXLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUNnRSw2QkFBcEQsRUFBbUYvRCxhQUFhLENBQUNnRSxzQ0FBakcsQ0FBcEQ7QUFDQSxVQUFJaVQsbURBQW1ELEdBQUc3VyxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDcUYsbUNBQXBELEVBQXlGcEYsYUFBYSxDQUFDcUYsNENBQXZHLENBQTFEO0FBQ0EsVUFBSTZSLGlDQUFpQyxHQUFHOVcscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNOLGNBQWMsQ0FBQ3VGLGlCQUFwRCxFQUF1RXRGLGFBQWEsQ0FBQ3VGLDBCQUFyRixDQUF4QyxDQVZBLENBVTBLOztBQUMxSyxVQUFJNFIsdUJBQXVCLEdBQUcvVyxxREFBUyxDQUFDdUIsMEJBQVYsQ0FBcUM1QixjQUFjLENBQUNpSCx1QkFBcEQsRUFBNkVpUSxtREFBN0UsQ0FBOUI7QUFDQUUsNkJBQXVCLEdBQUcvVyxxREFBUyxDQUFDZ1gsc0JBQVYsQ0FBaUNMLDhDQUFqQyxFQUFpRkcsaUNBQWpGLEVBQW9IQyx1QkFBcEgsQ0FBMUI7QUFDQSxVQUFJRSxrQ0FBa0MsR0FBR2pYLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUNvRCx3QkFBcEQsRUFBOEVuRCxhQUFhLENBQUNvRCxpQ0FBNUYsQ0FBekM7QUFDQWlVLHdDQUFrQyxHQUFHalgscURBQVMsQ0FBQ3VCLDBCQUFWLENBQXFDMFYsa0NBQXJDLEVBQXlFUCwrQ0FBekUsQ0FBckM7QUFDQUssNkJBQXVCLEdBQUcvVyxxREFBUyxDQUFDQywwQkFBVixDQUFxQzhXLHVCQUFyQyxFQUE4REUsa0NBQTlELENBQTFCO0FBQ0EsVUFBSUMsaUJBQWlCLEdBQUdsWCxxREFBUyxDQUFDdUIsMEJBQVYsQ0FBcUM1QixjQUFjLENBQUN5RyxpQkFBcEQsRUFBdUV3USw2Q0FBdkUsQ0FBeEI7QUFDQSxVQUFJTyx3Q0FBd0MsR0FBR25YLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUM0RSx3QkFBcEQsRUFBOEUzRSxhQUFhLENBQUM0RSxpQ0FBNUYsQ0FBL0M7QUFDQSxVQUFJNFMsc0NBQXNDLEdBQUdwWCxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDMkYsc0JBQXBELEVBQTRFMUYsYUFBYSxDQUFDMkYsK0JBQTFGLENBQTdDO0FBQ0FnUixZQUFNLEdBQUd2VyxxREFBUyxDQUFDdUIsMEJBQVYsQ0FBcUNnVixNQUFyQyxFQUE2Q0UsdUNBQTdDLENBQVQ7QUFFQSxVQUFJbFUscUJBQXFCLEdBQUcxQixzREFBVSxDQUFDMkIsa0JBQVgsQ0FBOEI3QyxjQUFjLENBQUM0RSx3QkFBZixDQUF3QyxDQUF4QyxFQUEyQzdELE1BQXpFLEVBQWlGZixjQUFjLENBQUM0RSx3QkFBZixDQUF3QzdELE1BQXpILENBQTVCO0FBRUE2VixZQUFNLEdBQUd2VyxxREFBUyxDQUFDeUMsMEJBQVYsQ0FDTEYscUJBREssRUFFSHdVLHVCQUZHLEVBR0hLLHNDQUhHLEVBSUhiLE1BSkcsRUFLSDVXLGNBQWMsQ0FBQytPLGVBTFosRUFNSDlPLGFBQWEsQ0FBQzZQLHdCQU5YLEVBT0g5UCxjQUFjLENBQUNnRyxlQVBaLEVBUUgvRixhQUFhLENBQUNrSCx3QkFSWCxDQUFUO0FBV0EsVUFBSXVRLG1DQUFtQyxHQUFHclgscURBQVMsQ0FBQ08sd0JBQVYsQ0FBbUNQLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUNvQyx5QkFBcEQsRUFBK0VuQyxhQUFhLENBQUNvQyxrQ0FBN0YsQ0FBbkMsQ0FBMUM7QUFFQXVVLFlBQU0sR0FBR3ZXLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDc1csTUFBckMsRUFBNkN2VyxxREFBUyxDQUFDQywwQkFBVixDQUFxQ0QscURBQVMsQ0FBQ08sd0JBQVYsQ0FBbUMwVyxrQ0FBbkMsQ0FBckMsRUFBNkdqWCxxREFBUyxDQUFDdUIsMEJBQVYsQ0FBcUM4VixtQ0FBckMsRUFBMEViLHdDQUExRSxDQUE3RyxDQUE3QyxDQUFUO0FBQ0EsVUFBSW5RLDJCQUEyQixHQUFHckcscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNOLGNBQWMsQ0FBQ21FLFdBQXBELEVBQWlFbEUsYUFBYSxDQUFDbUUsb0JBQS9FLENBQWxDLENBckNBLENBcUN3Sjs7QUFDeEpzQyxpQ0FBMkIsR0FBR3JHLHFEQUFTLENBQUNnWCxzQkFBVixDQUFpQ0csd0NBQWpDLEVBQTJFOVEsMkJBQTNFLEVBQXdHNlEsaUJBQXhHLENBQTlCO0FBRUEsVUFBSUksZ0NBQWdDLEdBQUd0WCxxREFBUyxDQUFDQywwQkFBVixDQUFxQ0QscURBQVMsQ0FBQ08sd0JBQVYsQ0FBbUNQLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUM4TyxnQkFBcEQsRUFBc0U5TyxjQUFjLENBQUN5RyxpQkFBckYsQ0FBbkMsQ0FBckMsRUFBa0xwRyxxREFBUyxDQUFDTyx3QkFBVixDQUFtQ1gsYUFBYSxDQUFDNFAseUJBQWpELENBQWxMLENBQXZDO0FBQ0E4SCxzQ0FBZ0MsR0FBR3RYLHFEQUFTLENBQUNPLHdCQUFWLENBQW1DUCxxREFBUyxDQUFDdUIsMEJBQVYsQ0FBcUMrVixnQ0FBckMsRUFBdUVWLDZDQUF2RSxDQUFuQyxDQUFuQztBQUVBLFVBQUlXLHFDQUFxQyxHQUFHdlgscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNOLGNBQWMsQ0FBQzRPLHFCQUFwRCxFQUEyRTNPLGFBQWEsQ0FBQzBQLDhCQUF6RixDQUE1QztBQUNBLFVBQUlrSSxTQUFTLEdBQUd4WCxxREFBUyxDQUFDQywwQkFBVixDQUFxQ0QscURBQVMsQ0FBQ3VCLDBCQUFWLENBQXFDa0MsUUFBckMsRUFBK0M4VCxxQ0FBL0MsQ0FBckMsRUFBNEhELGdDQUE1SCxDQUFoQjtBQUNBLFVBQUlHLGdDQUFnQyxHQUFHelgscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNOLGNBQWMsQ0FBQ3lFLGdCQUFwRCxFQUFzRXhFLGFBQWEsQ0FBQ3lFLHlCQUFwRixDQUF2QztBQUVBbVQsZUFBUyxHQUFHeFgscURBQVMsQ0FBQ3lDLDBCQUFWLENBQ1JGLHFCQURRLEVBRU44RCwyQkFGTSxFQUdOb1IsZ0NBSE0sRUFJTkQsU0FKTSxFQUtON1gsY0FBYyxDQUFDNk8sU0FMVCxFQU1ONU8sYUFBYSxDQUFDMlAsa0JBTlIsRUFPTjVQLGNBQWMsQ0FBQ2lGLFNBUFQsRUFRTmhGLGFBQWEsQ0FBQytHLGtCQVJSLENBQVo7QUFXQSxVQUFJK1EsVUFBVSxHQUFHdEIsUUFBUSxDQUFDdUIsYUFBVCxDQUF1QnBCLE1BQXZCLEVBQStCaUIsU0FBL0IsRUFBMEMvVCxRQUExQyxDQUFqQixDQTFEQSxDQTBEc0U7QUFHdEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQSxhQUFPaVUsVUFBUDtBQUNILEtBckVELENBcUVFLE9BQU94VSxFQUFQLEVBQ0Y7QUFDSUMsd0RBQU0sQ0FBQ0MsaUNBQVAsQ0FBeUNGLEVBQXpDLEVBQTZDLHNDQUE3QztBQUNBLFlBQU1BLEVBQU47QUFDSDtBQUNMLEdBOUVhO0FBZ0ZkeVUsZUFBYSxFQUFDLHVCQUFDcEIsTUFBRCxFQUFTaUIsU0FBVCxFQUFvQi9ULFFBQXBCLEVBQ2Q7QUFDSSxRQUFJO0FBQ0EsVUFBSWdCLE1BQU0sR0FBRyxJQUFJMkMsS0FBSixFQUFiOztBQUVBLFdBQUssSUFBSXFELENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUc4TCxNQUFNLENBQUM3VixNQUEzQixFQUFtQytKLENBQUMsRUFBcEMsRUFBd0M7QUFDcEMsWUFBSW1OLFNBQVMsR0FBR3JCLE1BQU0sQ0FBQzlMLENBQUQsQ0FBdEI7QUFDQSxZQUFJb04sS0FBSyxHQUFHLEtBQVo7O0FBRUEsYUFBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHTixTQUFTLENBQUM5VyxNQUE5QixFQUFzQ29YLENBQUMsRUFBdkMsRUFBMkM7QUFFdkM7QUFDQSxjQUFJalgsc0RBQVUsQ0FBQ3lKLGtCQUFYLENBQThCa04sU0FBUyxDQUFDTSxDQUFELENBQXZDLEVBQTRDRixTQUE1QyxDQUFKLEVBQTREO0FBQ3hEQyxpQkFBSyxHQUFHLElBQVI7QUFDQXBULGtCQUFNLENBQUM0QyxJQUFQLENBQVk1RCxRQUFRLENBQUNxVSxDQUFELENBQXBCO0FBRUE7QUFDSDtBQUNKOztBQUVELFlBQUksQ0FBQ0QsS0FBTCxFQUNJO0FBQ0E7QUFDQTtBQUNQOztBQUVELGFBQU9wVCxNQUFQO0FBQ0gsS0F6QkQsQ0F5QkUsT0FBT3ZCLEVBQVAsRUFBVztBQUNUQyx3REFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsWUFBTUEsRUFBTjtBQUNIO0FBQ0o7QUEvR2EsQ0FBbEI7QUFtSGVrVCx1RUFBZixFOzs7Ozs7Ozs7Ozs7QUN2SEE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQSxJQUFNUixRQUFRLEdBQUc7QUFDYi9QLFVBQVEsRUFBRSxrQkFBQ2xHLGNBQUQsRUFBaUJDLGFBQWpCLEVBQWdDNkQsUUFBaEMsRUFBNkM7QUFDbkQsUUFBSTtBQUNBLFVBQUlzVSxRQUFRLEdBQUcsRUFBZjtBQUVBQSxjQUFRLENBQUN2VyxZQUFULEdBQXdCd1csYUFBYSxDQUFDclksY0FBRCxFQUFpQkMsYUFBakIsRUFBZ0M2RCxRQUFoQyxFQUEwQyxLQUExQyxDQUFyQztBQUNBc1UsY0FBUSxDQUFDclYsVUFBVCxHQUFzQnVWLGVBQWUsQ0FBQ3RZLGNBQUQsRUFBaUJDLGFBQWpCLEVBQWdDLEtBQWhDLENBQXJDO0FBRUEsYUFBT21ZLFFBQVA7QUFDSCxLQVBELENBT0UsT0FBTzdVLEVBQVAsRUFBVztBQUNUQyx3REFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsWUFBTUEsRUFBTjtBQUNIO0FBQ0o7QUFiWSxDQUFqQjs7QUFnQkEsU0FBUytVLGVBQVQsQ0FBeUJ0WSxjQUF6QixFQUF5Q0MsYUFBekMsRUFDQTtBQUNJLE1BQUk7QUFDQSxRQUFJeUcsMkJBQTJCLEdBQUdyRyxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDdUYsaUJBQXBELEVBQXVFdEYsYUFBYSxDQUFDdUYsMEJBQXJGLENBQWxDLENBREEsQ0FDb0s7O0FBQ3BLLFFBQUkrUyxTQUFTLEdBQUdyWCxzREFBVSxDQUFDMkIsa0JBQVgsQ0FBOEI3QyxjQUFjLENBQUN1RixpQkFBZixDQUFpQyxDQUFqQyxFQUFvQ3hFLE1BQWxFLEVBQTBFZixjQUFjLENBQUN1RixpQkFBZixDQUFpQ3hFLE1BQTNHLEVBQW1ILENBQW5ILENBQWhCO0FBQ0EsUUFBSStXLGdDQUFnQyxHQUFHelgscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNOLGNBQWMsQ0FBQzJGLHNCQUFwRCxFQUE0RTFGLGFBQWEsQ0FBQzJGLCtCQUExRixDQUF2QyxDQUhBLENBR21MOztBQUNuTCxRQUFJNFIsd0NBQXdDLEdBQUduWCxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDNkYsOEJBQXBELEVBQW9GNUYsYUFBYSxDQUFDNkYsdUNBQWxHLENBQS9DLENBSkEsQ0FJMk07O0FBRTNNLFFBQUlvQixRQUFRLEdBQUc3RyxxREFBUyxDQUFDeUMsMEJBQVYsQ0FDWDBVLHdDQURXLEVBRVQ5USwyQkFGUyxFQUdUb1IsZ0NBSFMsRUFJVFMsU0FKUyxFQUtUdlksY0FBYyxDQUFDK08sZUFMTixFQU1UOU8sYUFBYSxDQUFDNlAsd0JBTkwsQ0FBZixDQU5BLENBWStDOztBQUUvQyxXQUFPNUksUUFBUDtBQUNILEdBZkQsQ0FlRSxPQUFPM0QsRUFBUCxFQUFXO0FBQ1RDLHNEQUFNLENBQUNDLGlDQUFQLENBQXlDRixFQUF6QyxFQUE2QyxzQ0FBN0M7QUFDQSxVQUFNQSxFQUFOO0FBQ0g7QUFDSixDLENBRUQ7OztBQUNBLFNBQVM4VSxhQUFULENBQXVCclksY0FBdkIsRUFBdUNDLGFBQXZDLEVBQXNENkQsUUFBdEQsRUFDQTtBQUNJLE1BQUk7QUFDQSxRQUFJNEMsMkJBQTJCLEdBQUdyRyxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDbUUsV0FBcEQsRUFBaUVsRSxhQUFhLENBQUNtRSxvQkFBL0UsQ0FBbEMsQ0FEQSxDQUN3Sjs7QUFDeEosUUFBSTBULGdDQUFnQyxHQUFHelgscURBQVMsQ0FBQ0MsMEJBQVYsQ0FBcUNOLGNBQWMsQ0FBQ3lFLGdCQUFwRCxFQUFzRXhFLGFBQWEsQ0FBQ3lFLHlCQUFwRixDQUF2QyxDQUZBLENBRXVLOztBQUN2SyxRQUFJOFMsd0NBQXdDLEdBQUduWCxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDNEUsd0JBQXBELEVBQThFM0UsYUFBYSxDQUFDNEUsaUNBQTVGLENBQS9DLENBSEEsQ0FHK0w7O0FBQy9MLFFBQUkrUyxxQ0FBcUMsR0FBR3ZYLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTixjQUFjLENBQUM0TyxxQkFBcEQsRUFBMkUzTyxhQUFhLENBQUMwUCw4QkFBekYsQ0FBNUM7QUFDQSxRQUFJc0gsNkNBQTZDLEdBQUc1VyxxREFBUyxDQUFDQywwQkFBVixDQUFxQ04sY0FBYyxDQUFDZ0UsNkJBQXBELEVBQW1GL0QsYUFBYSxDQUFDZ0Usc0NBQWpHLENBQXBELENBTEEsQ0FLOE07QUFFOU07QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxRQUFJc1UsU0FBUyxHQUFHbFkscURBQVMsQ0FBQ3VCLDBCQUFWLENBQXFDa0MsUUFBckMsRUFBK0M4VCxxQ0FBL0MsQ0FBaEI7QUFDQSxRQUFJRCxnQ0FBZ0MsR0FBR3RYLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDTCxhQUFhLENBQUM0UCx5QkFBbkQsRUFBOEU3UCxjQUFjLENBQUM4TyxnQkFBN0YsQ0FBdkM7QUFDQTZJLG9DQUFnQyxHQUFHdFgscURBQVMsQ0FBQ3VCLDBCQUFWLENBQXFDK1YsZ0NBQXJDLEVBQXVFViw2Q0FBdkUsQ0FBbkM7QUFFQXNCLGFBQVMsR0FBR2xZLHFEQUFTLENBQUNDLDBCQUFWLENBQXFDaVksU0FBckMsRUFBZ0RaLGdDQUFoRCxDQUFaO0FBRUEsUUFBSTVRLFVBQVUsR0FBRzFHLHFEQUFTLENBQUN5QywwQkFBVixDQUNiMFUsd0NBRGEsRUFFWDlRLDJCQUZXLEVBR1hvUixnQ0FIVyxFQUlYUyxTQUpXLEVBS1h2WSxjQUFjLENBQUM2TyxTQUxKLEVBTVg1TyxhQUFhLENBQUMyUCxrQkFOSCxDQVFiO0FBQ0E7QUFDQTtBQUNBO0FBWGEsS0FBakIsQ0FuQkEsQ0ErQkc7O0FBRUgsV0FBTzdJLFVBQVA7QUFDSCxHQWxDRCxDQWtDRSxPQUFPeEQsRUFBUCxFQUFXO0FBQ1RDLHNEQUFNLENBQUNDLGlDQUFQLENBQXlDRixFQUF6QyxFQUE2QyxzQ0FBN0M7QUFDQSxVQUFNQSxFQUFOO0FBQ0g7QUFDSjs7QUFFYzBTLHVFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3RGQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBRUEsSUFBTTVWLFNBQVMsR0FBRztBQUVkbVksU0FBTyxFQUFDLGlCQUFDQyxPQUFELEVBQVUvTyxHQUFWLEVBQ1I7QUFDSSxRQUFJO0FBQ0EsVUFBSSxDQUFDK08sT0FBTCxFQUNJLE1BQU1qVixrREFBTSxDQUFDNEQsb0NBQVAsQ0FBNEMsMEJBQTVDLEVBQXdFLHNDQUF4RSxDQUFOO0FBRUosVUFBSSxDQUFDc0MsR0FBTCxFQUNJLE1BQU1sRyxrREFBTSxDQUFDNEQsb0NBQVAsQ0FBNEMsc0JBQTVDLEVBQW9FLHNDQUFwRSxDQUFOO0FBRUosVUFBSXFSLE9BQU8sQ0FBQzFYLE1BQVIsS0FBbUIySSxHQUFHLENBQUMzSSxNQUEzQixFQUNJLE1BQU15QyxrREFBTSxDQUFDNEQsb0NBQVAsQ0FBNEMsbUNBQTVDLEVBQWlGLHNDQUFqRixDQUFOO0FBRUosVUFBSXRDLE1BQU0sR0FBRyxJQUFJMkMsS0FBSixDQUFVZ1IsT0FBTyxDQUFDMVgsTUFBbEIsQ0FBYjs7QUFFQSxXQUFLLElBQUkrSixDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHcEIsR0FBRyxDQUFDM0ksTUFBeEIsRUFBZ0MrSixDQUFDLEVBQWpDO0FBQ0loRyxjQUFNLENBQUNnRyxDQUFELENBQU4sR0FBWTJOLE9BQU8sQ0FBQy9PLEdBQUcsQ0FBQ29CLENBQUQsQ0FBSixDQUFuQjtBQURKOztBQUdBLGFBQU9oRyxNQUFQO0FBQ0gsS0FoQkQsQ0FnQkUsT0FBT3ZCLEVBQVAsRUFBVztBQUNUQyx3REFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsWUFBTUEsRUFBTjtBQUNIO0FBQ0osR0F4QmE7QUEwQmQ7QUFDQWpELDRCQUEwQixFQUFDLG9DQUFDbVksT0FBRCxFQUFVL08sR0FBVixFQUMzQjtBQUNJLFFBQUk7QUFDQSxVQUFJLENBQUMrTyxPQUFMLEVBQ0ksTUFBTWpWLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0QywwQkFBNUMsRUFBd0Usc0NBQXhFLENBQU47QUFDSixVQUFJLENBQUNzQyxHQUFMLEVBQ0ksTUFBTWxHLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0QyxzQkFBNUMsRUFBb0Usc0NBQXBFLENBQU4sQ0FKSixDQU1BOztBQUNBLFVBQUlxUixPQUFPLENBQUMxWCxNQUFSLEtBQW1CMkksR0FBRyxDQUFDM0ksTUFBdkIsSUFBaUNHLHNEQUFVLENBQUM2SSxnQkFBWCxDQUE0QjBPLE9BQTVCLE1BQXlDdlgsc0RBQVUsQ0FBQzZJLGdCQUFYLENBQTRCTCxHQUE1QjtBQUFpQztBQUEvRyxRQUNJLE1BQU1sRyxrREFBTSxDQUFDNEQsb0NBQVAsQ0FBNEMsbUNBQTVDLEVBQWlGLHNDQUFqRixDQUFOO0FBRUosVUFBSXRDLE1BQU0sR0FBRyxJQUFJMkMsS0FBSixFQUFiOztBQUVBLFdBQUssSUFBSXFELENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdwQixHQUFHLENBQUMzSSxNQUF4QixFQUFnQytKLENBQUMsRUFBakM7QUFDSWhHLGNBQU0sQ0FBQzRDLElBQVAsQ0FBWXJILFNBQVMsQ0FBQ21ZLE9BQVYsQ0FBa0JDLE9BQU8sQ0FBQzNOLENBQUQsQ0FBekIsRUFBOEJwQixHQUFHLENBQUNvQixDQUFELENBQWpDLENBQVo7QUFESjs7QUFHQSxhQUFPaEcsTUFBUDtBQUNILEtBaEJELENBZ0JFLE9BQU92QixFQUFQLEVBQVc7QUFDVEMsd0RBQU0sQ0FBQ0MsaUNBQVAsQ0FBeUNGLEVBQXpDLEVBQTZDLHNDQUE3QztBQUNBLFlBQU1BLEVBQU47QUFDSDtBQUNKLEdBakRhO0FBa0RkM0IsNEJBQTBCLEVBQUMsb0NBQUM2VyxPQUFELEVBQVMvTyxHQUFULEVBQzlCO0FBQ08sUUFBSTtBQUNBLFVBQUksQ0FBQytPLE9BQUwsRUFDSSxNQUFNalYsa0RBQU0sQ0FBQzRELG9DQUFQLENBQTRDLDBCQUE1QyxFQUF3RSxzQ0FBeEUsQ0FBTjtBQUNKLFVBQUksQ0FBQ3NDLEdBQUwsRUFDSSxNQUFNbEcsa0RBQU0sQ0FBQzRELG9DQUFQLENBQTRDLHNCQUE1QyxFQUFvRSxzQ0FBcEUsQ0FBTixDQUpKLENBTUE7O0FBQ0EsVUFBSWxHLHNEQUFVLENBQUM2SSxnQkFBWCxDQUE0QkwsR0FBNUIsTUFBcUMrTyxPQUFPLENBQUMxWDtBQUFPO0FBQXhELFFBQ0ksTUFBTXlDLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0QyxtQ0FBNUMsRUFBaUYsc0NBQWpGLENBQU47QUFFSixVQUFJdEMsTUFBTSxHQUFHekUsU0FBUyxDQUFDbVksT0FBVixDQUFrQkMsT0FBbEIsRUFBMkJ2WCxzREFBVSxDQUFDaUosa0JBQVgsQ0FBOEJULEdBQTlCLENBQTNCLENBQWI7QUFFQSxhQUFPNUUsTUFBUDtBQUNILEtBYkQsQ0FhRSxPQUFPdkIsRUFBUCxFQUFXO0FBQ1RDLHdEQUFNLENBQUNDLGlDQUFQLENBQXlDRixFQUF6QyxFQUE2QyxzQ0FBN0M7QUFDQSxZQUFNQSxFQUFOO0FBQ0g7QUFDUCxHQXJFZ0I7QUFzRWJELG9CQUFrQixFQUFDLDRCQUFDb1Ysd0JBQUQsRUFBMkJELE9BQTNCLEVBQW9DL08sR0FBcEMsRUFDcEI7QUFDSyxRQUFJO0FBQ0EsVUFBSSxDQUFDZ1Asd0JBQUwsRUFDSSxNQUFNbFYsa0RBQU0sQ0FBQzRELG9DQUFQLENBQTRDLDJDQUE1QyxFQUF5RixzQ0FBekYsQ0FBTjtBQUVKLFVBQUksQ0FBQ3FSLE9BQUwsRUFDSSxNQUFNalYsa0RBQU0sQ0FBQzRELG9DQUFQLENBQTRDLDBCQUE1QyxFQUF3RSxzQ0FBeEUsQ0FBTjtBQUVKLFVBQUksQ0FBQ3NDLEdBQUwsRUFDSSxNQUFNbEcsa0RBQU0sQ0FBQzRELG9DQUFQLENBQTRDLHNCQUE1QyxFQUFvRSxzQ0FBcEUsQ0FBTjtBQUVKLFVBQUlsRyxzREFBVSxDQUFDNkksZ0JBQVgsQ0FBNEIyTyx3QkFBNUIsTUFBMERoUCxHQUFHLENBQUMzSSxNQUE5RCxJQUF3RTBYLE9BQU8sQ0FBQzFYLE1BQVIsS0FBbUIySSxHQUFHLENBQUMzSSxNQUEvRixJQUF5R0csc0RBQVUsQ0FBQzZJLGdCQUFYLENBQTRCME8sT0FBNUIsS0FBd0N2WCxzREFBVSxDQUFDNkksZ0JBQVgsQ0FBNEJMLEdBQTVCO0FBQWlDO0FBQXRMLFFBQ0ksTUFBTWxHLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0QyxtQ0FBNUMsRUFBaUYsc0NBQWpGLENBQU47QUFFSixVQUFJdVIsYUFBYSxHQUFHelgsc0RBQVUsQ0FBQ2lKLGtCQUFYLENBQThCdU8sd0JBQTlCLENBQXBCO0FBRUEsVUFBSTVULE1BQU0sR0FBRyxJQUFJMkMsS0FBSixFQUFiOztBQUVBLFdBQUssSUFBSXFELENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdwQixHQUFHLENBQUMzSSxNQUF4QixFQUFnQytKLENBQUMsRUFBakM7QUFDSWhHLGNBQU0sQ0FBQzRDLElBQVAsQ0FBWXJILFNBQVMsQ0FBQ21ZLE9BQVYsQ0FBa0JDLE9BQU8sQ0FBQzNOLENBQUQsQ0FBekIsRUFBOEJwQixHQUFHLENBQUNpUCxhQUFhLENBQUM3TixDQUFELENBQWQsQ0FBakMsQ0FBWjtBQURKOztBQUdBLGFBQU9oRyxNQUFQO0FBQ0gsS0FyQkQsQ0FxQkUsT0FBT3ZCLEVBQVAsRUFBVztBQUNUQyx3REFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsWUFBTUEsRUFBTjtBQUNIO0FBQ0wsR0FqR2E7QUFtR2Q4VCx3QkFBc0IsRUFBQyxnQ0FBQ3FCLHdCQUFELEVBQTJCRCxPQUEzQixFQUFvQy9PLEdBQXBDLEVBQ3ZCO0FBQ0ksUUFBSTtBQUNBLFVBQUksQ0FBQ2dQLHdCQUFMLEVBQ0ksTUFBTWxWLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0QywyQ0FBNUMsRUFBeUYsc0NBQXpGLENBQU47QUFFSixVQUFJLENBQUNxUixPQUFMLEVBQ0ksTUFBTWpWLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0QywwQkFBNUMsRUFBd0Usc0NBQXhFLENBQU47QUFFSixVQUFJLENBQUNzQyxHQUFMLEVBQ0ksTUFBTWxHLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0QyxzQkFBNUMsRUFBb0Usc0NBQXBFLENBQU47QUFFSixVQUFJbEcsc0RBQVUsQ0FBQzZJLGdCQUFYLENBQTRCMk8sd0JBQTVCLE1BQTBEaFAsR0FBRyxDQUFDM0ksTUFBOUQsSUFBd0UwWCxPQUFPLENBQUMxWCxNQUFSLEtBQW1CMkksR0FBRyxDQUFDM0ksTUFBL0YsSUFBeUdHLHNEQUFVLENBQUM2SSxnQkFBWCxDQUE0QjBPLE9BQTVCLEtBQXdDdlgsc0RBQVUsQ0FBQzZJLGdCQUFYLENBQTRCTCxHQUE1QjtBQUFpQztBQUF0TCxRQUNJLE1BQU1sRyxrREFBTSxDQUFDNEQsb0NBQVAsQ0FBNEMsbUNBQTVDLEVBQWlGLHNDQUFqRixDQUFOO0FBRUosVUFBSXVSLGFBQWEsR0FBR3pYLHNEQUFVLENBQUNpSixrQkFBWCxDQUE4QnVPLHdCQUE5QixDQUFwQjtBQUVBLFVBQUk1VCxNQUFNLEdBQUcsSUFBSTJDLEtBQUosRUFBYjs7QUFFQSxXQUFLLElBQUlxRCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHcEIsR0FBRyxDQUFDM0ksTUFBeEIsRUFBZ0MrSixDQUFDLEVBQWpDO0FBQ0loRyxjQUFNLENBQUM0QyxJQUFQLENBQVlySCxTQUFTLENBQUNtWSxPQUFWLENBQWtCQyxPQUFPLENBQUNFLGFBQWEsQ0FBQzdOLENBQUQsQ0FBZCxDQUF6QixFQUE2Q3BCLEdBQUcsQ0FBQ29CLENBQUQsQ0FBaEQsQ0FBWjtBQURKOztBQUdBLGFBQU9oRyxNQUFQO0FBQ0gsS0FyQkQsQ0FxQkUsT0FBT3ZCLEVBQVAsRUFBVztBQUNUQyx3REFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsWUFBTUEsRUFBTjtBQUNIO0FBQ0osR0E5SGE7QUFnSWQzQywwQkFBd0IsRUFBQyxrQ0FBQzhJLEdBQUQsRUFDekI7QUFDSSxRQUFJO0FBQ0EsVUFBSSxDQUFDQSxHQUFMLEVBQ0ksTUFBTWxHLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0QyxzQkFBNUMsRUFBb0Usc0NBQXBFLENBQU47O0FBRUosVUFBSUssS0FBSyxDQUFDeUMsT0FBTixDQUFjUixHQUFHLENBQUMsQ0FBRCxDQUFqQixDQUFKLEVBQTJCO0FBQ3ZCLFlBQUk1RSxNQUFNLEdBQUcsSUFBSTJDLEtBQUosRUFBYjs7QUFFQSxhQUFLLElBQUlpRCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHaEIsR0FBRyxDQUFDM0ksTUFBeEIsRUFBZ0MySixDQUFDLEVBQWpDO0FBQ0k1RixnQkFBTSxDQUFDNEMsSUFBUCxDQUFZckgsU0FBUyxDQUFDTyx3QkFBVixDQUFtQzhJLEdBQUcsQ0FBQ2dCLENBQUQsQ0FBdEMsQ0FBWjtBQURKOztBQUdBLGVBQU81RixNQUFQO0FBQ0gsT0FQRCxNQVFLO0FBQ0QsWUFBSUEsT0FBTSxHQUFHLElBQUkyQyxLQUFKLENBQVVpQyxHQUFHLENBQUMzSSxNQUFkLENBQWI7O0FBRUEsYUFBSyxJQUFJK0osQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR3BCLEdBQUcsQ0FBQzNJLE1BQXhCLEVBQWdDK0osQ0FBQyxFQUFqQztBQUNJaEcsaUJBQU0sQ0FBQzRFLEdBQUcsQ0FBQ29CLENBQUQsQ0FBSixDQUFOLEdBQWlCQSxDQUFqQjtBQURKOztBQUdBLGVBQU9oRyxPQUFQO0FBQ0g7QUFDSixLQXBCRCxDQW9CRSxPQUFPdkIsRUFBUCxFQUFXO0FBQ1RDLHdEQUFNLENBQUNDLGlDQUFQLENBQXlDRixFQUF6QyxFQUE2QyxzQ0FBN0M7QUFDQSxZQUFNQSxFQUFOO0FBQ0g7QUFFSixHQTNKYTtBQTZKZHFWLFlBQVUsRUFBQyxvQkFBQ0MsU0FBRCxFQUFZQyxTQUFaLEVBQ1g7QUFDSSxRQUFJO0FBQ0EsVUFBSSxDQUFDRCxTQUFMLEVBQ0ksTUFBTXJWLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0Qyw0QkFBNUMsRUFBMEUsc0NBQTFFLENBQU47QUFFSixVQUFJLENBQUMwUixTQUFMLEVBQ0ksTUFBTXRWLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0Qyw0QkFBNUMsRUFBMEUsc0NBQTFFLENBQU47QUFFSixVQUFJMlIscUJBQXFCLEtBQUs3WCxzREFBVSxDQUFDNkksZ0JBQVgsQ0FBNEIrTyxTQUE1QixDQUE5QixFQUNJLE1BQU10VixrREFBTSxDQUFDNEQsb0NBQVAsQ0FBNEMsbUNBQTVDLEVBQWlGLHNDQUFqRixDQUFOO0FBRUosVUFBSTJSLHFCQUFxQixHQUFHN1gsc0RBQVUsQ0FBQzZJLGdCQUFYLENBQTRCOE8sU0FBNUIsQ0FBNUI7QUFFQSxVQUFJL1QsTUFBTSxHQUFHLElBQUkyQyxLQUFKLENBQVVzUixxQkFBVixDQUFiOztBQUVBLFdBQUssSUFBSWpPLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdpTyxxQkFBcEIsRUFBMkNqTyxDQUFDLEVBQTVDO0FBQ0loRyxjQUFNLENBQUNnRyxDQUFELENBQU4sR0FBWStOLFNBQVMsQ0FBQy9OLENBQUQsQ0FBVCxHQUFlZ08sU0FBUyxDQUFDaE8sQ0FBRCxDQUFwQztBQURKOztBQUdBLGFBQU9oRyxNQUFQO0FBQ0gsS0FsQkQsQ0FrQkUsT0FBT3ZCLEVBQVAsRUFBVztBQUNUQyx3REFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsWUFBTUEsRUFBTjtBQUNIO0FBQ0osR0FyTGE7QUF1TGR5VixvQkFBa0IsRUFBQyw0QkFBQ1AsT0FBRCxFQUNuQjtBQUFBLHNDQURnQ1EsUUFDaEM7QUFEZ0NBLGNBQ2hDO0FBQUE7O0FBQ0ksUUFBSTtBQUNBLFVBQUksQ0FBQ1IsT0FBTCxFQUNJLE1BQU1qVixrREFBTSxDQUFDNEQsb0NBQVAsQ0FBNEMsMEJBQTVDLEVBQXdFLHNDQUF4RSxDQUFOO0FBRUosVUFBSSxDQUFDNlIsUUFBTCxFQUNJLE1BQU16VixrREFBTSxDQUFDNEQsb0NBQVAsQ0FBNEMsMkJBQTVDLEVBQXlFLHNDQUF6RSxDQUFOOztBQUVKLFdBQUssSUFBSTBELENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdtTyxRQUFRLENBQUNsWSxNQUE3QixFQUFxQytKLENBQUMsRUFBdEM7QUFDSTJOLGVBQU8sR0FBR1MsaUJBQWlCLENBQUNULE9BQUQsRUFBVVEsUUFBUSxDQUFDbk8sQ0FBRCxDQUFsQixDQUEzQjtBQURKOztBQUdBLGFBQU8yTixPQUFQO0FBQ0gsS0FYRCxDQVdFLE9BQU9sVixFQUFQLEVBQVc7QUFDVEMsd0RBQU0sQ0FBQ0MsaUNBQVAsQ0FBeUNGLEVBQXpDLEVBQTZDLHNDQUE3QztBQUNBLFlBQU1BLEVBQU47QUFDSDtBQUNKLEdBeE1hO0FBME1iMlYsbUJBQWlCLEVBQUMsMkJBQUNMLFNBQUQsRUFBWUMsU0FBWixFQUNuQjtBQUNLLFFBQUk7QUFDQSxVQUFJLENBQUNELFNBQUwsRUFDSSxNQUFNclYsa0RBQU0sQ0FBQzRELG9DQUFQLENBQTRDLDRCQUE1QyxFQUEwRSxzQ0FBMUUsQ0FBTjtBQUNKLFVBQUksQ0FBQzBSLFNBQUwsRUFDSSxNQUFNdFYsa0RBQU0sQ0FBQzRELG9DQUFQLENBQTRDLDRCQUE1QyxFQUEwRSxzQ0FBMUUsQ0FBTjtBQUVKLFVBQUl0QyxNQUFNLEdBQUcsSUFBSTJDLEtBQUosRUFBYjtBQUVBLFVBQUlvUixTQUFTLENBQUM5WCxNQUFWLEtBQXFCK1gsU0FBUyxDQUFDL1gsTUFBL0IsSUFBeUNHLHNEQUFVLENBQUM2SSxnQkFBWCxDQUE0QjhPLFNBQTVCLE1BQTJDM1gsc0RBQVUsQ0FBQzZJLGdCQUFYLENBQTRCK08sU0FBNUI7QUFBdUM7QUFBL0gsUUFDSSxNQUFNdFYsa0RBQU0sQ0FBQzRELG9DQUFQLENBQTRDLG1DQUE1QyxFQUFpRixzQ0FBakYsQ0FBTjs7QUFFSixXQUFLLElBQUkwRCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHK04sU0FBUyxDQUFDOVgsTUFBOUIsRUFBc0MrSixDQUFDLEVBQXZDO0FBQ0loRyxjQUFNLENBQUNxVSxNQUFQLENBQWNDLEdBQWQsQ0FBa0JSLFVBQVUsQ0FBQ0MsU0FBUyxDQUFDL04sQ0FBRCxDQUFWLEVBQWVnTyxTQUFTLENBQUNoTyxDQUFELENBQXhCLENBQTVCO0FBREo7O0FBR0EsYUFBT2hHLE1BQVA7QUFDSCxLQWZELENBZUUsT0FBT3ZCLEVBQVAsRUFBVztBQUNUQyx3REFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsWUFBTUEsRUFBTjtBQUNIO0FBQ0wsR0EvTmE7QUFtT2Q4VixvQkFBa0IsRUFBQyw0QkFBQ0MsWUFBRCxFQUFlVCxTQUFmLEVBQTBCQyxTQUExQixFQUNuQjtBQUNJLFFBQUk7QUFDQSxVQUFJLENBQUNRLFlBQUwsRUFDSSxNQUFNOVYsa0RBQU0sQ0FBQzRELG9DQUFQLENBQTRDLCtCQUE1QyxFQUE2RSxzQ0FBN0UsQ0FBTjtBQUVKLFVBQUksQ0FBQ3lSLFNBQUwsRUFDSSxNQUFNclYsa0RBQU0sQ0FBQzRELG9DQUFQLENBQTRDLDRCQUE1QyxFQUEwRSxzQ0FBMUUsQ0FBTjtBQUVKLFVBQUksQ0FBQzBSLFNBQUwsRUFDSSxNQUFNdFYsa0RBQU0sQ0FBQzRELG9DQUFQLENBQTRDLDRCQUE1QyxFQUEwRSxzQ0FBMUUsQ0FBTjtBQUVKLFVBQUkyUixxQkFBcUIsR0FBRzdYLHNEQUFVLENBQUM2SSxnQkFBWCxDQUE0QjhPLFNBQTVCLENBQTVCO0FBQ0EsVUFBSS9ULE1BQU0sR0FBRyxJQUFJMkMsS0FBSixDQUFVc1IscUJBQVYsQ0FBYjtBQUVBLFVBQUlBLHFCQUFxQixLQUFLN1gsc0RBQVUsQ0FBQzZJLGdCQUFYLENBQTRCdVAsWUFBNUIsQ0FBMUIsSUFBdUVwWSxzREFBVSxDQUFDNkksZ0JBQVgsQ0FBNEIrTyxTQUE1QixNQUEyQzVYLHNEQUFVLENBQUM2SSxnQkFBWCxDQUE0QnVQLFlBQTVCLENBQXRILEVBQ0ksTUFBTTlWLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0QyxtQ0FBNUMsRUFBaUYsc0NBQWpGLENBQU47O0FBRUosV0FBSyxJQUFJMEQsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR2lPLHFCQUFwQixFQUEyQ2pPLENBQUMsRUFBNUMsRUFBZ0Q7QUFDNUMsWUFBSXlPLE1BQU0sR0FBR1YsU0FBUyxDQUFDL04sQ0FBRCxDQUFULEdBQWVnTyxTQUFTLENBQUNRLFlBQVksQ0FBQ3hPLENBQUQsQ0FBYixDQUFyQztBQUNBaEcsY0FBTSxDQUFDZ0csQ0FBRCxDQUFOLEdBQVl5TyxNQUFaO0FBQ0g7O0FBRUQsYUFBT3pVLE1BQVA7QUFDSCxLQXRCRCxDQXNCRSxPQUFPdkIsRUFBUCxFQUFXO0FBQ1RDLHdEQUFNLENBQUNDLGlDQUFQLENBQXlDRixFQUF6QyxFQUE2QyxzQ0FBN0M7QUFDQSxZQUFNQSxFQUFOO0FBQ0g7QUFDSixHQS9QYTtBQWlRZFQsNEJBQTBCLEVBQUMsb0NBQUMwVyxxQkFBRCxFQUF3QkMsYUFBeEIsRUFBdUNDLGFBQXZDLEVBQXNEakIsT0FBdEQsRUFDM0I7QUFBQSx1Q0FENkZRLFFBQzdGO0FBRDZGQSxjQUM3RjtBQUFBOztBQUNJLFFBQUk7QUFDQSxVQUFJLENBQUNPLHFCQUFMLEVBQ0ksTUFBTWhXLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0Qyx3Q0FBNUMsRUFBc0Ysc0NBQXRGLENBQU47QUFFSixVQUFJLENBQUNxUyxhQUFMLEVBQ0ksTUFBTWpXLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0QyxnQ0FBNUMsRUFBOEUsc0NBQTlFLENBQU47QUFFSixVQUFJLENBQUNzUyxhQUFMLEVBQ0ksTUFBTWxXLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0QyxnQ0FBNUMsRUFBOEUsc0NBQTlFLENBQU47QUFFSixVQUFJLENBQUNxUixPQUFMLEVBQ0ksTUFBTWpWLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0QywwQkFBNUMsRUFBd0Usc0NBQXhFLENBQU47QUFFSixVQUFJLENBQUM2UixRQUFMLEVBQ0ksTUFBTXpWLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0QywyQkFBNUMsRUFBeUUsc0NBQXpFLENBQU47QUFFSixVQUFJbEcsc0RBQVUsQ0FBQzZJLGdCQUFYLENBQTRCeVAscUJBQTVCLE1BQXVEQyxhQUFhLENBQUMxWSxNQUFyRSxJQUErRUcsc0RBQVUsQ0FBQzZJLGdCQUFYLENBQTRCMlAsYUFBNUIsTUFBK0NqQixPQUFPLENBQUMxWDtBQUFPO0FBQWpKLFFBQ0ksTUFBTXlDLGtEQUFNLENBQUM0RCxvQ0FBUCxDQUE0QyxtQ0FBNUMsRUFBaUYsc0NBQWpGLENBQU47QUFFSixVQUFJdVMsYUFBYSxHQUFHelksc0RBQVUsQ0FBQ2lKLGtCQUFYLENBQThCcVAscUJBQTlCLENBQXBCO0FBQ0EsVUFBSUksU0FBUyxHQUFHMVksc0RBQVUsQ0FBQ2lKLGtCQUFYLENBQThCdVAsYUFBOUIsQ0FBaEI7O0FBRUEsV0FBSyxJQUFJNU8sQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR21PLFFBQVEsQ0FBQ2xZLE1BQTdCLEVBQXFDK0osQ0FBQyxFQUF0QztBQUNJMk4sZUFBTyxHQUFHcFksU0FBUyxDQUFDd1oseUJBQVYsQ0FBb0NGLGFBQXBDLEVBQW1ERixhQUFuRCxFQUFrRUcsU0FBbEUsRUFBNkVuQixPQUE3RSxFQUFzRlEsUUFBUSxDQUFDbk8sQ0FBRCxDQUE5RixDQUFWO0FBREo7O0FBR0EsYUFBTzJOLE9BQVA7QUFDSCxLQTFCRCxDQTBCRSxPQUFPbFYsRUFBUCxFQUFXO0FBQ1RDLHdEQUFNLENBQUNDLGlDQUFQLENBQXlDRixFQUF6QyxFQUE2QyxzQ0FBN0M7QUFDQSxZQUFNQSxFQUFOO0FBQ0g7QUFDSixHQWpTYTtBQW1TZHNXLDJCQUF5QixFQUFDLG1DQUFDTCxxQkFBRCxFQUF3QkMsYUFBeEIsRUFBdUNDLGFBQXZDLEVBQXNEYixTQUF0RCxFQUFrRUMsU0FBbEUsRUFDMUI7QUFDSSxRQUFJO0FBQ0EsVUFBSSxDQUFDVSxxQkFBTCxFQUNJLE1BQU1oVyxrREFBTSxDQUFDNEQsb0NBQVAsQ0FBNEMsd0NBQTVDLEVBQXNGLHNDQUF0RixDQUFOO0FBRUosVUFBSSxDQUFDcVMsYUFBTCxFQUNJLE1BQU1qVyxrREFBTSxDQUFDNEQsb0NBQVAsQ0FBNEMsZ0NBQTVDLEVBQThFLHNDQUE5RSxDQUFOO0FBRUosVUFBSSxDQUFDc1MsYUFBTCxFQUNJLE1BQU1sVyxrREFBTSxDQUFDNEQsb0NBQVAsQ0FBNEMsZ0NBQTVDLEVBQThFLHNDQUE5RSxDQUFOO0FBRUosVUFBSSxDQUFDeVIsU0FBTCxFQUNJLE1BQU1yVixrREFBTSxDQUFDNEQsb0NBQVAsQ0FBNEMsNEJBQTVDLEVBQTBFLHNDQUExRSxDQUFOO0FBRUosVUFBSSxDQUFDMFIsU0FBTCxFQUNJLE1BQU10VixrREFBTSxDQUFDNEQsb0NBQVAsQ0FBNEMsNEJBQTVDLEVBQTBFLHNDQUExRSxDQUFOO0FBRUosVUFBSXRDLE1BQU0sR0FBRyxJQUFJMkMsS0FBSixFQUFiO0FBRUEsVUFBSW9SLFNBQVMsQ0FBQzlYLE1BQVYsS0FBcUIwWSxhQUFhLENBQUMxWSxNQUFuQyxJQUE2QytYLFNBQVMsQ0FBQy9YLE1BQVYsS0FBcUIwWSxhQUFhLENBQUMxWSxNQUFoRixJQUEwRkcsc0RBQVUsQ0FBQzZJLGdCQUFYLENBQTRCOE8sU0FBNUIsTUFBMkMzWCxzREFBVSxDQUFDNkksZ0JBQVgsQ0FBNEIwUCxhQUE1QixDQUFySSxJQUFtTHZZLHNEQUFVLENBQUM2SSxnQkFBWCxDQUE0QitPLFNBQTVCLE1BQTJDNVgsc0RBQVUsQ0FBQzZJLGdCQUFYLENBQTRCMFAsYUFBNUI7QUFBMkM7QUFBN1EsUUFDSSxNQUFNalcsa0RBQU0sQ0FBQzRELG9DQUFQLENBQTRDLG1DQUE1QyxFQUFpRixzQ0FBakYsQ0FBTjs7QUFFSixXQUFLLElBQUkwRCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHK04sU0FBUyxDQUFDOVgsTUFBOUIsRUFBc0MrSixDQUFDLEVBQXZDO0FBQ0loRyxjQUFNLENBQUM0QyxJQUFQLENBQVlySCxTQUFTLENBQUNnWixrQkFBVixDQUE2QkksYUFBYSxDQUFDRCxxQkFBcUIsQ0FBQzFPLENBQUQsQ0FBdEIsQ0FBMUMsRUFBc0UrTixTQUFTLENBQUMvTixDQUFELENBQS9FLEVBQW9GZ08sU0FBUyxDQUFDWSxhQUFhLENBQUM1TyxDQUFELENBQWQsQ0FBN0YsQ0FBWjtBQURKOztBQUdBLGFBQU9oRyxNQUFQO0FBQ0gsS0F6QkQsQ0F5QkUsT0FBT3ZCLEVBQVAsRUFBVztBQUNUQyx3REFBTSxDQUFDQyxpQ0FBUCxDQUF5Q0YsRUFBekMsRUFBNkMsc0NBQTdDO0FBQ0EsWUFBTUEsRUFBTjtBQUNIO0FBQ0o7QUFsVWEsQ0FBbEI7QUFzVWVsRCx3RUFBZixFIiwiZmlsZSI6Im5Lb2RlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIHdlYnBhY2tVbml2ZXJzYWxNb2R1bGVEZWZpbml0aW9uKHJvb3QsIGZhY3RvcnkpIHtcblx0aWYodHlwZW9mIGV4cG9ydHMgPT09ICdvYmplY3QnICYmIHR5cGVvZiBtb2R1bGUgPT09ICdvYmplY3QnKVxuXHRcdG1vZHVsZS5leHBvcnRzID0gZmFjdG9yeSgpO1xuXHRlbHNlIGlmKHR5cGVvZiBkZWZpbmUgPT09ICdmdW5jdGlvbicgJiYgZGVmaW5lLmFtZClcblx0XHRkZWZpbmUoW10sIGZhY3RvcnkpO1xuXHRlbHNlIGlmKHR5cGVvZiBleHBvcnRzID09PSAnb2JqZWN0Jylcblx0XHRleHBvcnRzW1wibktvZGVcIl0gPSBmYWN0b3J5KCk7XG5cdGVsc2Vcblx0XHRyb290W1wibktvZGVcIl0gPSBmYWN0b3J5KCk7XG59KSh3aW5kb3csIGZ1bmN0aW9uKCkge1xucmV0dXJuICIsIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0ge307XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSBcIi4vc3JjL25Lb2RlLmpzXCIpO1xuIiwiaW1wb3J0IHRyYW5zZm9ybSBmcm9tICcuL3RyYW5zZm9ybS5qcyc7XHJcbmltcG9ydCBkYXJjQ29tbW9uIGZyb20gJy4vZGFyY0NvbW1vbi5qcyc7XHJcbmltcG9ydCBjb21tb24gZnJvbSAnLi9jb21tb24uanMnO1xyXG5cclxudmFyIGNsaWVudE1lcmdlID0ge1xyXG4gICAgbWVyZ2VNZXNzYWdlOiAocGVyc2lzdGVudEtleXMsIGVwaGVtZXJhbEtleXMsIERBUkNkYXRhLCBpbnB1dFNlcXVlbmNlKSA9PiB7XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCBhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlQWxwaGFiZXRLZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJDbGllbnRTaHVmZmxlS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyQ2xpZW50U2h1ZmZsZUVwaGVtZXJhbEtleSk7XHJcbiAgICAgICAgICAgIGxldCBhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25BbHBoYWJldEtleSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5PdXRlckNsaWVudFNodWZmbGVGdW5jdGlvbktleSwgZXBoZW1lcmFsS2V5cy5PdXRlckNsaWVudFNodWZmbGVGdW5jdGlvbkVwaGVtZXJhbEtleSk7XHJcblxyXG4gICAgICAgICAgICBhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlQWxwaGFiZXRLZXkgPSB0cmFuc2Zvcm0udHJhbnNmb3JtYXRpb25Db21wbGltZW50KHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlQWxwaGFiZXRLZXksIGFwcGxpZWRPdXRlckNsaWVudFNodWZmbGVGdW5jdGlvbkFscGhhYmV0S2V5KSk7XHJcblxyXG4gICAgICAgICAgICAvL0RldGVybWluZSBNZWRpdW0gZGltZW5zaW9uc1xyXG4gICAgICAgICAgICBsZXQgaGVpZ2h0ID0gcGVyc2lzdGVudEtleXMuQ2xpZW50TWVkaXVtS2V5Lmxlbmd0aDtcclxuICAgICAgICAgICAgbGV0IHdpZHRoID0gcGVyc2lzdGVudEtleXMuQ2xpZW50TWVkaXVtS2V5WzBdLmxlbmd0aDtcclxuICAgICAgICAgICAgbGV0IG1zZ0xlbiA9IGlucHV0U2VxdWVuY2UubGVuZ3RoO1xyXG5cclxuICAgICAgICAgICAgLy9HZW5lcmF0ZSByYW5kb20gaW5wdXQgc2VxdWVuY2UgZm9yIG1lc3NhZ2UgcGFkZGluZ1xyXG4gICAgICAgICAgICBpbnB1dFNlcXVlbmNlID0gZGFyY0NvbW1vbi5yYW5kTmV3SW50cyhpbnB1dFNlcXVlbmNlLCBoZWlnaHQsIDAsIGhlaWdodCk7XHJcblxyXG5cclxuICAgICAgICAgICAgbGV0IGFwcGxpZWRJbnB1dFNlcXVlbmNlID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKGFwcGxpZWRPdXRlckNsaWVudFNodWZmbGVBbHBoYWJldEtleSwgW2lucHV0U2VxdWVuY2VdKTtcclxuICAgICAgICAgICAgbGV0IGFwcGxpZWRPdXRlckNsaWVudFNodWZmbGVNZWRpdW1LZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJDbGllbnRTaHVmZmxlTWVkaXVtS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyQ2xpZW50U2h1ZmZsZU1lZGl1bUVwaGVtZXJhbEtleSk7XHJcbiAgICAgICAgICAgIGxldCBhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25NZWRpdW1LZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25NZWRpdW1LZXksIGVwaGVtZXJhbEtleXMuT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25NZWRpdW1FcGhlbWVyYWxLZXkpO1xyXG5cclxuICAgICAgICAgICAgYXBwbGllZE91dGVyQ2xpZW50U2h1ZmZsZU1lZGl1bUtleSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlTWVkaXVtS2V5LCBhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25NZWRpdW1LZXkpO1xyXG5cclxuICAgICAgICAgICAgYXBwbGllZElucHV0U2VxdWVuY2UgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24oYXBwbGllZElucHV0U2VxdWVuY2UsIGFwcGxpZWRPdXRlckNsaWVudFNodWZmbGVNZWRpdW1LZXkpO1xyXG5cclxuICAgICAgICAgICAgbGV0IG1lc3NhZ2UgPSB0cmFuc2Zvcm0ucGVybXV0ZU91dGVyVHJhbnNmb3JtYXRpb24oREFSQ2RhdGEuQWxwaGFiZXREYXRhLCBhcHBsaWVkSW5wdXRTZXF1ZW5jZSk7XHJcblxyXG4gICAgICAgICAgICAvLyoqKioqICBHZW5lcmF0ZSByYW5kb20gaW5wdXQgZGF0YSB0byB0cmlnZ2VyIGVuZC1vZi1tZXNzYWdlIChFT00pIGR1cmluZyBkZWNyeXB0aW9uIGJ5IHNlcnZlciAgKioqKipcXFxcXHJcbiAgICAgICAgICAgIC8vTk9URTogVGhlIHJhbmRvbSBzZXJpZXMgb2YgYnl0ZXMgYWN0cyBhcyBhbiBFT00gaW5kaWNhdG9yIGR1cmluZyBkZWNyeXB0aW9uIGJlY2F1c2UgYSBtYXRjaGluZyBzZXQgb2YgdmFsdWVzIGluIHRoZSBEQVJDIGFscGhhYmV0IHdpbGwgbm90IGV4aXN0LiBcclxuICAgICAgICAgICAgLy8gICAgICBEQVJDIGlzIGRlc2lnbmVkIHRvIGludGVycHJldCBhbiB1bnJlc29sdmFibGUgc2V0IG9mIGJ5dGVzIGFzIEVPTS4gXHJcbiAgICAgICAgICAgIC8vICAgICAgSWYgdGhlIGZ1bGwgREFSQyBhbHBoYWJldCBrZXkgc3BhY2UgKGV2ZXJ5IHBvc3NpYmxlIGNvbWJpbmF0aW9uIG9mIGJ5dGUgdmFsdWVzKSBpcyB1c2VkLCBcclxuICAgICAgICAgICAgLy8gICAgICAgIFJhbmRVbmlxdWVOZXdCeXRlcygpIHdpbGwgbm90IHJldHVybiBhIG5ldyBkaXN0aW5jdCBzZXJpZXMgb2YgYnl0ZXMsIFxyXG4gICAgICAgICAgICAvLyAgICAgICAgYnV0IHJhdGhlciBhIHJhbmRvbSBzZXQgb2YgYnl0ZXMgdGhhdCBhbHJlYWR5IGV4aXN0cyBzb21ld2hlcmUgaW4gdGhlIERBUkMgYWxwaGFiZXQuIFxyXG4gICAgICAgICAgICAvLyAgICAgIFN1Y2ggY2FzZXMgd2lsbCBvY2N1ciB3aGVuIHRoZSBrZXkuaGVpZ2h0ID49IDI1Nl5rZXkud2lkdGguIFxyXG4gICAgICAgICAgICAvLyAgICAgIFRoZSBtb3N0IHJlYWxpc3RpYyBleGFtcGxlIGlzIGZ1bGwtYnl0ZSBzdXBwb3J0IGZvciB0aGUgdHJhbnNmZXIgb2YgZGlnaXRhbCBmaWxlcy9kb2N1bWVudHMgb3Igc3RyZWFtaW5nIGRhdGEgKGUuZy4gYXVkaW8vdmlkZW8pLlxyXG4gICAgICAgICAgICAvLyAgICAgIFRvIGJlIGFibGUgdG8gc3VjY2Vzc2Z1bGx5IGVuY2lwaGVyIGFuZCBkZWNpcGhlciB0aGlzIHR5cGUgb2YgZGF0YSwgXHJcbiAgICAgICAgICAgIC8vICAgICAgICBldmVyeSBwb3NzaWJsZSBieXRlIHZhbHVlIG11c3QgYmUgcmVwcmVzZW50ZWQgaW4gdGhlIERBUkMgYWxwaGFiZXQgKGtleS5oZWlnaHQgPSAyNTYpLlxyXG4gICAgICAgICAgICAvLyAgICAgIFdoZW4gdGhpcyBkYXRhIGlzIGVuY29kZWQgb24gYSBzaW5nbGUtYnl0ZS1wZXItYnl0ZSBpbXBsZW1lbnRhdGlvbiAoa2V5LndpZHRoID0gMSksIFxyXG4gICAgICAgICAgICAvLyAgICAgICAgaXQgaXMgaW1wb3NzaWJsZSB0byBkZWZpbmUgYSBieXRlIHZhbHVlIHRoYXQgaXMgbm90IGEgdmFsaWQgbWVtYmVyIG9mIHRoZSBEQVJDIGFscGhhYmV0IChrZXkuaGVpZ2h0ezI1Nn0gPj0gMjU2XmtleS53aWR0aHsxfSA9IFRSVUUpLlxyXG4gICAgICAgICAgICAvLyAgICAgIEhvd2V2ZXIsIHRoaXMgd2lsbCBub3QgcHJldmVudCBEQVJDIGRlY3J5cHRpb24gZnJvbSBjb21wbGV0aW5nIHN1Y2Nlc3NmdWxseS4gXHJcbiAgICAgICAgICAgIC8vICAgICAgRmlsZXMgaGF2ZSBhIGJ1aWx0LWluIGVuZC1vZi1maWxlIChFT0YpIGRlc2lnbmF0b3IsIFxyXG4gICAgICAgICAgICAvLyAgICAgICAgc28gREFSQyB3aWxsIGFwcGVuZCB0aGUgUmFuZFVuaXF1ZU5ld0J5dGVzKCkgZ2VuZXJhdGVkIHZhbHVlcyBhbmQgcGFkIHRoZSByZW1haW5kZXIgb2YgdGhlIGZpbmFsIG1lc3NhZ2UgYmxvY2ssXHJcbiAgICAgICAgICAgIC8vICAgICAgICBidXQgdGhlIHJhbmRvbSBkYXRhIHdpbGwgYmUgaWdub3JlZCBiZWNhdXNlIHRoZSByZWNlaXZpbmcgc3lzdGVtIHdpbGwgc3RvcCByZWFkaW5nIHRoZSBmaWxlIGF0IEVPRi5cclxuICAgICAgICAgICAgLy8gICAgICBTdHJlYW1pbmcgZGF0YSBpcyBwcm9jZXNzZWQgaW4gcmVhbC10aW1lLCBcclxuICAgICAgICAgICAgLy8gICAgICAgIHNvIGFueSByYW5kb20gZGF0YSBhcHBlbmRlZCB0byB0aGUgZW5kIG9mIHRoZSBzdHJlYW0gd2lsbCBiZSBpbnRlcnByZXRlZCBhcyBiYWNrZ3JvdW5kIG5vaXNlLFxyXG4gICAgICAgICAgICAvLyAgICAgICAgYW5kIGJlIGlnbm9yZWQgYnkgdGhlIHN0cmVhbSBwbGF5ZXIuXHJcbiAgICAgICAgICAgIC8vICAgICAgSWYgYW55IHVuc3BlY3VsYXRlZCBpc3N1ZXMgYXJpc2UgZnJvbSB0aGlzIHByb2Nlc3MgZm9yIGtleS5oZWlnaHQgPj0gMjU2XmtleS53aWR0aCBzY2VuYXJpb3MsIFxyXG4gICAgICAgICAgICAvLyAgICAgICAgYW4gaW5pdGlhbCBzdGVwIGNhbiBiZSBhZGRlZCB0byBjb252ZXJ0IHRoZSBmaWxlIG9yIHN0cmVhbSBpbnRvIGEgbnVtYmVyIGJhc2UgdGhhdCBmaXRzIHdpdGhpbiB0aGUgYnl0ZSAtIDEgc3BhY2UuXHJcbiAgICAgICAgICAgIC8vICAgICAgQSBmaW5hbCBzdGVwIHdvdWxkIGFsc28gYmUgcmVxdWlyZWQgdG8gY29udmVydCB0aGUgZGVjcnlwdGVkIGRhdGEgYmFjayBpbnRvIGl0J3Mgb3JpZ2luYWwgbnVtYmVyIGJhc2UuXHJcbiAgICAgICAgICAgIC8vICAgICAgVGhlc2UgYWRkaXRpb25hbCBzdGVwIHdvdWxkIG9idmlvdXNseSByZXF1aXJlIHNpZ25pZmljYW50bHkgbW9yZSBwcm9jZXNzaW5nLCBcclxuICAgICAgICAgICAgLy8gICAgICAgIGFuZCB0aHVzIHNob3VsZCBiZSBhdm9pZGVkIGlmIHBvc3NpYmxlLlxyXG4gICAgICAgICAgICAvLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcXFxcXHJcbiAgICAgICAgICAgIGxldCBpbnB1dEVPTSA9IGRhcmNDb21tb24ucmFuZFVuaXF1ZU5ld0J5dGVzKERBUkNkYXRhLkFscGhhYmV0RGF0YSwgd2lkdGgsIDAsIDI1Nik7XHJcblxyXG4gICAgICAgICAgICAvL0NhbGN1bGF0ZSBtZWRpdW0gbWF4IG9yZGluYWwgdG8gYmUgdXNlZCBpbiB0aGUgZWxzZSBicmFuY2ggYmVsb3cgc28gdGhhdCB0aGUgaWYgYW5kIGVsc2UgYnJhbmNoZXMgd2lsbCBoYXZlIGlkZW50aWNhbCBleGVjdXRpb24gdGltZSBhbmQgbWVtb3J5IHByb2ZpbGUgXHJcbiAgICAgICAgICAgIGxldCBtZWRpdW1NYXhPcmQgPSBoZWlnaHQgLSAxO1xyXG5cclxuICAgICAgICAgICAgLy9HZW5lcmF0ZSBsb29rdXAgYXJyYXkgdG8gbWFwIHBhZGRpbmcgdG8gbWVzc2FnZVxyXG4gICAgICAgICAgICBsZXQgbWVzc2FnZVBhZEtleSA9IHRyYW5zZm9ybS50cmFuc2Zvcm1hdGlvbkNvbXBsaW1lbnQoYXBwbGllZE91dGVyQ2xpZW50U2h1ZmZsZU1lZGl1bUtleSk7XHJcblxyXG4gICAgICAgICAgICAvL0dldCBkYXRhIGZvciBsYXN0IGlucHV0IGluIG1lc3NhZ2VcclxuICAgICAgICAgICAgbGV0IGxhc3RJbnB1dCA9IG1lc3NhZ2VbbWVzc2FnZVBhZEtleVswXVttZWRpdW1NYXhPcmRdXTtcclxuXHJcbiAgICAgICAgICAgIGlmIChtc2dMZW4gPCBoZWlnaHQpXHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlW21lc3NhZ2VQYWRLZXlbMF1bbXNnTGVuXV0gPSBpbnB1dEVPTTsgLy9JbnRlcmplY3QgaW5wdXRFT00gaW50byB0aGUgbWVzc2FnZVxyXG4gICAgICAgICAgICBlbHNlIC8vUmVxdWlyZWQgdG8gbWFpbnRhaW4gY29uc3RhbnQgZXhlY3V0aW9uIHRpbWUgYW5kIG1lbW9yeSBwcm9maWxlIHJlZ2FyZGxlc3Mgb2YgYnJhbmNoXHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlW21lc3NhZ2VQYWRLZXlbMF1bbWVkaXVtTWF4T3JkXV0gPSBsYXN0SW5wdXQ7IC8vSW50ZXJqZWN0IGxhc3RJbnB1dCBpbnRvIHRoZSBtZXNzYWdlXHJcblxyXG4gICAgICAgICAgICBsZXQgYXBwbGllZFBvc2l0aW9uRnVuY3Rpb25LZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuUG9zaXRpb25GdW5jdGlvbk1lZGl1bUtleSwgZXBoZW1lcmFsS2V5cy5Qb3NpdGlvbkZ1bmN0aW9uTWVkaXVtRXBoZW1lcmFsS2V5KTtcclxuICAgICAgICAgICAgbGV0IGFwcGxpZWRPdXRlclBvc2l0aW9uRnVuY3Rpb25LZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJQb3NpdGlvbkZ1bmN0aW9uTWVkaXVtS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyUG9zaXRpb25GdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleSk7XHJcblxyXG4gICAgICAgICAgICBsZXQgYXBwbGllZE91dGVyUG9zaXRpb25TaHVmZmxlS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLk91dGVyUG9zaXRpb25TaHVmZmxlTWVkaXVtS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyUG9zaXRpb25TaHVmZmxlTWVkaXVtRXBoZW1lcmFsS2V5KTtcclxuXHJcbiAgICAgICAgICAgIGFwcGxpZWRPdXRlclBvc2l0aW9uRnVuY3Rpb25LZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24oYXBwbGllZE91dGVyUG9zaXRpb25TaHVmZmxlS2V5LCBhcHBsaWVkT3V0ZXJQb3NpdGlvbkZ1bmN0aW9uS2V5KTtcclxuXHJcbiAgICAgICAgICAgIGFwcGxpZWRPdXRlckNsaWVudFNodWZmbGVNZWRpdW1LZXkgPSB0cmFuc2Zvcm0udHJhbnNmb3JtYXRpb25Db21wbGltZW50KGFwcGxpZWRPdXRlckNsaWVudFNodWZmbGVNZWRpdW1LZXkpO1xyXG4gICAgICAgICAgICBhcHBsaWVkT3V0ZXJQb3NpdGlvbkZ1bmN0aW9uS2V5ID0gdHJhbnNmb3JtLnRyYW5zZm9ybWF0aW9uQ29tcGxpbWVudCh0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24oYXBwbGllZE91dGVyQ2xpZW50U2h1ZmZsZU1lZGl1bUtleSwgYXBwbGllZE91dGVyUG9zaXRpb25GdW5jdGlvbktleSkpO1xyXG5cclxuICAgICAgICAgICAgbGV0IGlkZW50aXR5T3V0ZXJGdW5jdGlvbiA9IGRhcmNDb21tb24uaW5pdGlhbGl6ZU5ld0FycmF5KHBlcnNpc3RlbnRLZXlzLk91dGVyUG9zaXRpb25GdW5jdGlvbk1lZGl1bUtleVswXS5sZW5ndGgsIHBlcnNpc3RlbnRLZXlzLk91dGVyUG9zaXRpb25GdW5jdGlvbk1lZGl1bUtleS5sZW5ndGgpO1xyXG5cclxuICAgICAgICAgICAgbWVzc2FnZSA9IHRyYW5zZm9ybS5zdWJzdGl0dXRlRnVuY3Rpb25PcGVyYW5kcyhcclxuICAgICAgICAgICAgICAgIGFwcGxpZWRPdXRlclBvc2l0aW9uRnVuY3Rpb25LZXlcclxuICAgICAgICAgICAgICAgICwgYXBwbGllZFBvc2l0aW9uRnVuY3Rpb25LZXlcclxuICAgICAgICAgICAgICAgICwgaWRlbnRpdHlPdXRlckZ1bmN0aW9uXHJcbiAgICAgICAgICAgICAgICAsIERBUkNkYXRhLk1lZGl1bURhdGFcclxuICAgICAgICAgICAgICAgICwgbWVzc2FnZVxyXG4gICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgbGV0IGFwcGxpZWRPdXRlclBvc2l0aW9uU2h1ZmZsZUZ1bmN0aW9uS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLk91dGVyUG9zaXRpb25TaHVmZmxlRnVuY3Rpb25NZWRpdW1LZXksIGVwaGVtZXJhbEtleXMuT3V0ZXJQb3NpdGlvblNodWZmbGVGdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleSk7XHJcblxyXG4gICAgICAgICAgICBsZXQgYXBwbGllZFBvc2l0aW9uU2h1ZmZsZUtleSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5Qb3NpdGlvblNodWZmbGVNZWRpdW1LZXksIGVwaGVtZXJhbEtleXMuUG9zaXRpb25TaHVmZmxlTWVkaXVtRXBoZW1lcmFsS2V5KTtcclxuXHJcbiAgICAgICAgICAgIGFwcGxpZWRPdXRlclBvc2l0aW9uU2h1ZmZsZUtleSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlTWVkaXVtS2V5LCBhcHBsaWVkT3V0ZXJQb3NpdGlvblNodWZmbGVLZXkpO1xyXG4gICAgICAgICAgICBhcHBsaWVkT3V0ZXJQb3NpdGlvblNodWZmbGVGdW5jdGlvbktleSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihhcHBsaWVkT3V0ZXJQb3NpdGlvblNodWZmbGVGdW5jdGlvbktleSwgYXBwbGllZE91dGVyUG9zaXRpb25GdW5jdGlvbktleSk7XHJcblxyXG4gICAgICAgICAgICBtZXNzYWdlID0gdHJhbnNmb3JtLnBlcm11dGVPdXRlclRyYW5zZm9ybWF0aW9uKHRyYW5zZm9ybS5wZXJtdXRlRnVuY3Rpb25NYXAoYXBwbGllZE91dGVyUG9zaXRpb25TaHVmZmxlRnVuY3Rpb25LZXksIG1lc3NhZ2UsIGFwcGxpZWRQb3NpdGlvblNodWZmbGVLZXkpLCBhcHBsaWVkT3V0ZXJQb3NpdGlvblNodWZmbGVLZXkpO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XHJcbiAgICAgICAgfSBjYXRjaCAoZXgpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcImVhOWJhYjg0LTJmY2YtNDI0OC05NDM0LTI5MDljYjFkMDQ4YVwiKTtcclxuICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xpZW50TWVyZ2U7IiwiaW1wb3J0IHRyYW5zZm9ybSBmcm9tICcuL3RyYW5zZm9ybS5qcyc7XHJcbmltcG9ydCBjb21tb24gZnJvbSAnLi9jb21tb24uanMnO1xyXG5cclxudmFyIGNsaWVudFJ4ID0ge1xyXG4gICAgcmVjZWl2ZToocGVyc2lzdGVudEtleXMsIGVwaGVtZXJhbEtleXMsIERBUkNkYXRhKT0+XHJcbiAgICB7ICAgICAgICBcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBEQVJDZGF0YS5BbHBoYWJldERhdGEgPSByZWNlaXZlQWxwaGFiZXQocGVyc2lzdGVudEtleXMsIGVwaGVtZXJhbEtleXMsIERBUkNkYXRhLkFscGhhYmV0RGF0YSk7XHJcbiAgICAgICAgICAgIERBUkNkYXRhLk1lZGl1bURhdGEgPSByZWNlaXZlTWVkaXVtKHBlcnNpc3RlbnRLZXlzLCBlcGhlbWVyYWxLZXlzLCBEQVJDZGF0YS5NZWRpdW1EYXRhKTtcclxuICAgICAgICAgICAgcmV0dXJuIERBUkNkYXRhO1xyXG4gICAgICAgIH0gY2F0Y2ggKGV4KSB7XHJcbiAgICAgICAgICAgIGNvbW1vbi5hZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8oZXgsIFwiOWJiNjFiNGYtMTZhYS00YTI4LTg3ODctZGIxYWNjYmQzNThjXCIpO1xyXG4gICAgICAgICAgICB0aHJvdyBleDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn07XHJcblxyXG4vLzEpIEtleTsgMikgU3Vic3RpdHV0aW9uczsgMykgSW5uZXIgUGVybXV0YXRpb25zOyA0KSBPdXRlciBQZXJtdXRhdGlvbnNcclxuZnVuY3Rpb24gcmVjZWl2ZUFscGhhYmV0KHBlcnNpc3RlbnRLZXlzLCBlcGhlbWVyYWxLZXlzLCBhbHBoYWJldClcclxue1xyXG4gICAgdHJ5IHtcclxuICAgICAgICBsZXQgYXBwbGllZE91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLk91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uRXBoZW1lcmFsS2V5KTtcclxuICAgICAgICBsZXQgYXBwbGllZEZ1bmN0aW9uS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLkZ1bmN0aW9uS2V5LCBlcGhlbWVyYWxLZXlzLkZ1bmN0aW9uRXBoZW1lcmFsS2V5KTtcclxuICAgICAgICBsZXQgYXBwbGllZENsaWVudFNodWZmbGVLZXlBID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLkNsaWVudFNodWZmbGVLZXlBLCBlcGhlbWVyYWxLZXlzLkNsaWVudFNodWZmbGVFcGhlbWVyYWxLZXlBKTtcclxuICAgICAgICBsZXQgYXBwbGllZE91dGVyRnVuY3Rpb25LZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJGdW5jdGlvbktleSwgZXBoZW1lcmFsS2V5cy5PdXRlckZ1bmN0aW9uRXBoZW1lcmFsS2V5KTtcclxuICAgICAgICBsZXQgYXBwbGllZE91dGVyRnVuY3Rpb25GdW5jdGlvbktleSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5PdXRlckZ1bmN0aW9uRnVuY3Rpb25LZXksIGVwaGVtZXJhbEtleXMuT3V0ZXJGdW5jdGlvbkZ1bmN0aW9uRXBoZW1lcmFsS2V5KTtcclxuXHJcbiAgICAgICAgbGV0IHJlc3VsdCA9IHRyYW5zZm9ybS5zdWJzdGl0dXRlRnVuY3Rpb25PcGVyYW5kcyhcclxuICAgICAgICAgICAgYXBwbGllZE91dGVyRnVuY3Rpb25GdW5jdGlvbktleSxcclxuICAgICAgICAgICAgYXBwbGllZEZ1bmN0aW9uS2V5LFxyXG4gICAgICAgICAgICBhcHBsaWVkT3V0ZXJGdW5jdGlvbktleSxcclxuICAgICAgICAgICAgYWxwaGFiZXQsXHJcbiAgICAgICAgICAgIGVwaGVtZXJhbEtleXMuQ2xpZW50RXBoZW1lcmFsS2V5LFxyXG4gICAgICAgICAgICBwZXJzaXN0ZW50S2V5cy5DbGllbnRLZXksXHJcbiAgICAgICAgICAgIHBlcnNpc3RlbnRLZXlzLk11dHVhbEtleVxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGFscGhhYmV0ID0gcmVzdWx0O1xyXG5cclxuICAgICAgICAvL3JlbmFtZSBUcmFuc3Bvc2VYIHRvIElubmVyVHJhbnNwb3NlP1xyXG4gICAgICAgIGFscGhhYmV0ID0gdHJhbnNmb3JtLnBlcm11dGVGdW5jdGlvbk1hcChhcHBsaWVkT3V0ZXJTZXJ2ZXJTaHVmZmxlRnVuY3Rpb25LZXksIGFscGhhYmV0LCBhcHBsaWVkQ2xpZW50U2h1ZmZsZUtleUEpO1xyXG4gICAgICAgIGxldCBhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLk91dGVyQ2xpZW50U2h1ZmZsZUtleSwgZXBoZW1lcmFsS2V5cy5PdXRlckNsaWVudFNodWZmbGVFcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgIGxldCBhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25LZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25LZXksIGVwaGVtZXJhbEtleXMuT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25FcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgIGFwcGxpZWRPdXRlckNsaWVudFNodWZmbGVLZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24oYXBwbGllZE91dGVyQ2xpZW50U2h1ZmZsZUtleSwgYXBwbGllZE91dGVyQ2xpZW50U2h1ZmZsZUZ1bmN0aW9uS2V5KTtcclxuICAgICAgICBhbHBoYWJldCA9IHRyYW5zZm9ybS5wZXJtdXRlT3V0ZXJUcmFuc2Zvcm1hdGlvbihhbHBoYWJldCwgYXBwbGllZE91dGVyQ2xpZW50U2h1ZmZsZUtleSk7XHJcblxyXG4gICAgICAgIHJldHVybiBhbHBoYWJldDtcclxuICAgIH0gY2F0Y2ggKGV4KSB7XHJcbiAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhleCwgXCJkMmNiMWI0ZS1lMTEwLTQxY2YtYTZlNi05ZjRlNzE4ZDkzYTlcIik7XHJcbiAgICAgICAgdGhyb3cgZXg7XHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJlY2VpdmVNZWRpdW0ocGVyc2lzdGVudEtleXMsIGVwaGVtZXJhbEtleXMsIG1lZGl1bSkge1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgICAgbGV0IGFwcGxpZWRPdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbktleSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5PdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbk1lZGl1bUtleSwgZXBoZW1lcmFsS2V5cy5PdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleSk7XHJcbiAgICAgICAgbGV0IGFwcGxpZWRGdW5jdGlvbktleSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5GdW5jdGlvbk1lZGl1bUtleSwgZXBoZW1lcmFsS2V5cy5GdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleSk7XHJcbiAgICAgICAgbGV0IGFwcGxpZWRDbGllbnRTaHVmZmxlS2V5QSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5DbGllbnRTaHVmZmxlTWVkaXVtS2V5QSwgZXBoZW1lcmFsS2V5cy5DbGllbnRTaHVmZmxlTWVkaXVtRXBoZW1lcmFsS2V5QSk7XHJcbiAgICAgICAgbGV0IGFwcGxpZWRPdXRlckZ1bmN0aW9uS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLk91dGVyRnVuY3Rpb25NZWRpdW1LZXksIGVwaGVtZXJhbEtleXMuT3V0ZXJGdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleSk7XHJcbiAgICAgICAgbGV0IGFwcGxpZWRPdXRlckZ1bmN0aW9uRnVuY3Rpb25LZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJGdW5jdGlvbkZ1bmN0aW9uTWVkaXVtS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyRnVuY3Rpb25GdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleSk7XHJcblxyXG4gICAgICAgIGxldCByZXN1bHQgPSB0cmFuc2Zvcm0uc3Vic3RpdHV0ZUZ1bmN0aW9uT3BlcmFuZHMoXHJcbiAgICAgICAgICAgIGFwcGxpZWRPdXRlckZ1bmN0aW9uRnVuY3Rpb25LZXksXHJcbiAgICAgICAgICAgIGFwcGxpZWRGdW5jdGlvbktleSxcclxuICAgICAgICAgICAgYXBwbGllZE91dGVyRnVuY3Rpb25LZXksXHJcbiAgICAgICAgICAgIG1lZGl1bSxcclxuICAgICAgICAgICAgZXBoZW1lcmFsS2V5cy5DbGllbnRNZWRpdW1FcGhlbWVyYWxLZXksXHJcbiAgICAgICAgICAgIHBlcnNpc3RlbnRLZXlzLkNsaWVudE1lZGl1bUtleSxcclxuICAgICAgICAgICAgcGVyc2lzdGVudEtleXMuTXV0dWFsTWVkaXVtS2V5XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgbWVkaXVtID0gcmVzdWx0O1xyXG5cclxuICAgICAgICBtZWRpdW0gPSB0cmFuc2Zvcm0ucGVybXV0ZUZ1bmN0aW9uTWFwKGFwcGxpZWRPdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbktleSwgbWVkaXVtLCBhcHBsaWVkQ2xpZW50U2h1ZmZsZUtleUEpO1xyXG4gICAgICAgIGxldCBhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLk91dGVyQ2xpZW50U2h1ZmZsZU1lZGl1bUtleSwgZXBoZW1lcmFsS2V5cy5PdXRlckNsaWVudFNodWZmbGVNZWRpdW1FcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgIGxldCBhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25LZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25NZWRpdW1LZXksIGVwaGVtZXJhbEtleXMuT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25NZWRpdW1FcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgIGFwcGxpZWRPdXRlckNsaWVudFNodWZmbGVLZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24oYXBwbGllZE91dGVyQ2xpZW50U2h1ZmZsZUtleSwgYXBwbGllZE91dGVyQ2xpZW50U2h1ZmZsZUZ1bmN0aW9uS2V5KTtcclxuICAgICAgICBtZWRpdW0gPSB0cmFuc2Zvcm0ucGVybXV0ZU91dGVyVHJhbnNmb3JtYXRpb24obWVkaXVtLCBhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlS2V5KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIG1lZGl1bTtcclxuICAgIH0gY2F0Y2ggKGV4KSB7XHJcbiAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhleCwgXCI3M2NiZmJlYS0yYjk2LTQyNzAtOTM2ZS00Y2UzODdmYjRhMjdcIik7XHJcbiAgICAgICAgdGhyb3cgZXg7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsaWVudFJ4OyIsImltcG9ydCB0cmFuc2Zvcm0gZnJvbSAnLi90cmFuc2Zvcm0uanMnO1xyXG5pbXBvcnQgZGFyY0NvbW1vbiBmcm9tICcuL2RhcmNDb21tb24uanMnO1xyXG5pbXBvcnQgY29tbW9uIGZyb20gJy4vY29tbW9uLmpzJztcclxuXHJcbnZhciBjbGllbnRUeCA9IHtcclxuICAgIHRyYW5zbWl0OihwZXJzaXN0ZW50S2V5cywgZXBoZW1lcmFsS2V5cywgREFSQ2RhdGEpPT5cclxuICAgIHsgICBcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBEQVJDZGF0YS5BbHBoYWJldERhdGEgPSB0cmFuc21pdEFscGhhYmV0KHBlcnNpc3RlbnRLZXlzLCBlcGhlbWVyYWxLZXlzLCBEQVJDZGF0YS5BbHBoYWJldERhdGEpO1xyXG4gICAgICAgICAgICBEQVJDZGF0YS5NZWRpdW1EYXRhID0gdHJhbnNtaXRNZWRpdW0ocGVyc2lzdGVudEtleXMsIGVwaGVtZXJhbEtleXMsIERBUkNkYXRhLk1lZGl1bURhdGEpO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIERBUkNkYXRhO1xyXG4gICAgICAgIH0gY2F0Y2ggKGV4KSB7XHJcbiAgICAgICAgICAgIGNvbW1vbi5hZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8oZXgsIFwiNzc4YzZiNmUtYTJlNy00NjBlLWFhMzMtNTU2MzYyY2NjMTJmXCIpO1xyXG4gICAgICAgICAgICB0aHJvdyBleDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn07XHJcblxyXG5mdW5jdGlvbiB0cmFuc21pdEFscGhhYmV0KHBlcnNpc3RlbnRLZXlzLCBlcGhlbWVyYWxLZXlzLCBhbHBoYWJldClcclxue1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgICAgbGV0IGNsaWVudFNodWZmbEVwaGVtZXJhbEtleUIgPSB0cmFuc2Zvcm0udHJhbnNmb3JtYXRpb25Db21wbGltZW50KGVwaGVtZXJhbEtleXMuQ2xpZW50U2h1ZmZsZUVwaGVtZXJhbEtleUEpO1xyXG4gICAgICAgIGxldCBhcHBsaWVkT3V0ZXJTZXJ2ZXJTaHVmZmxlRnVuY3Rpb25LZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJTZXJ2ZXJTaHVmZmxlRnVuY3Rpb25LZXksIGVwaGVtZXJhbEtleXMuT3V0ZXJTZXJ2ZXJTaHVmZmxlRnVuY3Rpb25FcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgIGxldCBhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLk91dGVyQ2xpZW50U2h1ZmZsZUtleSwgZXBoZW1lcmFsS2V5cy5PdXRlckNsaWVudFNodWZmbGVFcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgIGxldCBhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25LZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25LZXksIGVwaGVtZXJhbEtleXMuT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25FcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgIGxldCBpbnB1dE91dGVyQ2xpZW50U2h1ZmZsZUtleSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlS2V5LCBhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25LZXkpO1xyXG4gICAgICAgIGxldCBpbnB1dE91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKGFwcGxpZWRPdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbktleSwgaW5wdXRPdXRlckNsaWVudFNodWZmbGVLZXkpO1xyXG4gICAgICAgIGxldCBhcHBsaWVkT3V0ZXJGdW5jdGlvbkZ1bmN0aW9uS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLk91dGVyRnVuY3Rpb25GdW5jdGlvbktleSwgZXBoZW1lcmFsS2V5cy5PdXRlckZ1bmN0aW9uRnVuY3Rpb25FcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgIGFwcGxpZWRPdXRlckZ1bmN0aW9uRnVuY3Rpb25LZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24oYXBwbGllZE91dGVyRnVuY3Rpb25GdW5jdGlvbktleSwgaW5wdXRPdXRlckNsaWVudFNodWZmbGVLZXkpO1xyXG4gICAgICAgIGxldCBhcHBsaWVkRnVuY3Rpb25LZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuRnVuY3Rpb25LZXksIGVwaGVtZXJhbEtleXMuRnVuY3Rpb25FcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgIGFwcGxpZWRGdW5jdGlvbktleSA9IHRyYW5zZm9ybS5wZXJtdXRlT3V0ZXJUcmFuc2Zvcm1hdGlvbihhcHBsaWVkRnVuY3Rpb25LZXksIGFwcGxpZWRPdXRlckZ1bmN0aW9uRnVuY3Rpb25LZXkpO1xyXG4gICAgICAgIGxldCByZW9yZGVyZWRTaHVmZmxlS2V5WCA9IHRyYW5zZm9ybS5wZXJtdXRlT3V0ZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5DbGllbnRTaHVmZmxlS2V5WCwgaW5wdXRPdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbktleSk7XHJcbiAgICAgICAgbGV0IGZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihhcHBsaWVkRnVuY3Rpb25LZXksIHJlb3JkZXJlZFNodWZmbGVLZXlYKTtcclxuICAgICAgICAvL15eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXlxcXFxcclxuXHJcbiAgICAgICAgLy92dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZcXFxcICBcclxuICAgICAgICBsZXQgY2xpZW50U2h1ZmZsS2V5QiA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbih0cmFuc2Zvcm0udHJhbnNmb3JtYXRpb25Db21wbGltZW50KHBlcnNpc3RlbnRLZXlzLkNsaWVudFNodWZmbGVLZXlBKSwgcGVyc2lzdGVudEtleXMuQ2xpZW50U2h1ZmZsZUtleVgpO1xyXG4gICAgICAgIC8vXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXFxcXFxyXG5cclxuICAgICAgICBsZXQgaW5wdXRDbGllbnRTaHVmZmxlS2V5QiA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihjbGllbnRTaHVmZmxFcGhlbWVyYWxLZXlCLCBjbGllbnRTaHVmZmxLZXlCKTsgLy9Ob3RlIHRoZSByZXZlcnNlZCBzZXF1ZW5jZSBvZiB0aGUgYXJndW1lbnRzLlxyXG4gICAgICAgIGxldCBzaHVmZmxlZEl0ZW1zID0gdHJhbnNmb3JtLnBlcm11dGVGdW5jdGlvbk1hcChpbnB1dE91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uS2V5LCBhbHBoYWJldCwgaW5wdXRDbGllbnRTaHVmZmxlS2V5Qik7XHJcbiAgICAgICAgbGV0IGFwcGxpZWRPdXRlckZ1bmN0aW9uS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLk91dGVyRnVuY3Rpb25LZXksIGVwaGVtZXJhbEtleXMuT3V0ZXJGdW5jdGlvbkVwaGVtZXJhbEtleSk7XHJcbiAgICAgICAgbGV0IGlucHV0T3V0ZXJGdW5jdGlvbktleSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihhcHBsaWVkT3V0ZXJGdW5jdGlvbktleSwgaW5wdXRPdXRlckNsaWVudFNodWZmbGVLZXkpO1xyXG4gICAgICAgIGxldCBpZGVudGl0eU91dGVyRnVuY3Rpb24gPSBkYXJjQ29tbW9uLmluaXRpYWxpemVOZXdBcnJheShwZXJzaXN0ZW50S2V5cy5PdXRlckZ1bmN0aW9uRnVuY3Rpb25LZXlbMF0ubGVuZ3RoLCBwZXJzaXN0ZW50S2V5cy5PdXRlckZ1bmN0aW9uRnVuY3Rpb25LZXkubGVuZ3RoKTtcclxuXHJcbiAgICAgICAgbGV0IHR4QWxwaGFiZXQgPSB0cmFuc2Zvcm0uc3Vic3RpdHV0ZUZ1bmN0aW9uT3BlcmFuZHMoXHJcbiAgICAgICAgICAgIGlkZW50aXR5T3V0ZXJGdW5jdGlvblxyXG4gICAgICAgICAgICAsIGZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZFxyXG4gICAgICAgICAgICAsIGlucHV0T3V0ZXJGdW5jdGlvbktleVxyXG4gICAgICAgICAgICAsIHNodWZmbGVkSXRlbXNcclxuICAgICAgICAgICAgLCBlcGhlbWVyYWxLZXlzLkNsaWVudEVwaGVtZXJhbEtleVxyXG4gICAgICAgICAgICAsIHBlcnNpc3RlbnRLZXlzLkNsaWVudEtleVxyXG4gICAgICAgICAgICAsIGVwaGVtZXJhbEtleXMuTXV0dWFsRXBoZW1lcmFsS2V5XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHR4QWxwaGFiZXQ7XHJcbiAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgIGNvbW1vbi5hZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8oZXgsIFwiNzI4MTljZTItNjkyZS00MGIzLWI0OTgtOWRlM2JmMzEwMTZjXCIpO1xyXG4gICAgICAgIHRocm93IGV4O1xyXG4gICAgfVxyXG59XHJcblxyXG4gICAgZnVuY3Rpb24gdHJhbnNtaXRNZWRpdW0ocGVyc2lzdGVudEtleXMsIGVwaGVtZXJhbEtleXMsIG1lZGl1bSlcclxuICAgIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAvL3Z2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dlxcXFwgICAgICAgIFxyXG4gICAgICAgICAgICBsZXQgY2xpZW50U2h1ZmZsRXBoZW1lcmFsS2V5QiA9IHRyYW5zZm9ybS50cmFuc2Zvcm1hdGlvbkNvbXBsaW1lbnQoZXBoZW1lcmFsS2V5cy5DbGllbnRTaHVmZmxlTWVkaXVtRXBoZW1lcmFsS2V5QSk7XHJcbiAgICAgICAgICAgIC8vXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXFxcXFxyXG5cclxuICAgICAgICAgICAgbGV0IGFwcGxpZWRPdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbktleSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5PdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbk1lZGl1bUtleSwgZXBoZW1lcmFsS2V5cy5PdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleSk7XHJcbiAgICAgICAgICAgIGxldCBhcHBsaWVkT3V0ZXJDbGllbnRTaHVmZmxlS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLk91dGVyQ2xpZW50U2h1ZmZsZU1lZGl1bUtleSwgZXBoZW1lcmFsS2V5cy5PdXRlckNsaWVudFNodWZmbGVNZWRpdW1FcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgICAgICBsZXQgYXBwbGllZE91dGVyQ2xpZW50U2h1ZmZsZUZ1bmN0aW9uS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLk91dGVyQ2xpZW50U2h1ZmZsZUZ1bmN0aW9uTWVkaXVtS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyQ2xpZW50U2h1ZmZsZUZ1bmN0aW9uTWVkaXVtRXBoZW1lcmFsS2V5KTtcclxuICAgICAgICAgICAgbGV0IGlucHV0T3V0ZXJDbGllbnRTaHVmZmxlS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKGFwcGxpZWRPdXRlckNsaWVudFNodWZmbGVLZXksIGFwcGxpZWRPdXRlckNsaWVudFNodWZmbGVGdW5jdGlvbktleSk7XHJcbiAgICAgICAgICAgIGxldCBpbnB1dE91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKGFwcGxpZWRPdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbktleSwgaW5wdXRPdXRlckNsaWVudFNodWZmbGVLZXkpO1xyXG4gICAgICAgICAgICBsZXQgYXBwbGllZE91dGVyRnVuY3Rpb25GdW5jdGlvbktleSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5PdXRlckZ1bmN0aW9uRnVuY3Rpb25NZWRpdW1LZXksIGVwaGVtZXJhbEtleXMuT3V0ZXJGdW5jdGlvbkZ1bmN0aW9uTWVkaXVtRXBoZW1lcmFsS2V5KTtcclxuICAgICAgICAgICAgYXBwbGllZE91dGVyRnVuY3Rpb25GdW5jdGlvbktleSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihhcHBsaWVkT3V0ZXJGdW5jdGlvbkZ1bmN0aW9uS2V5LCBpbnB1dE91dGVyQ2xpZW50U2h1ZmZsZUtleSk7XHJcbiAgICAgICAgICAgIGxldCBhcHBsaWVkRnVuY3Rpb25LZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuRnVuY3Rpb25NZWRpdW1LZXksIGVwaGVtZXJhbEtleXMuRnVuY3Rpb25NZWRpdW1FcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgICAgICBhcHBsaWVkRnVuY3Rpb25LZXkgPSB0cmFuc2Zvcm0ucGVybXV0ZU91dGVyVHJhbnNmb3JtYXRpb24oYXBwbGllZEZ1bmN0aW9uS2V5LCBhcHBsaWVkT3V0ZXJGdW5jdGlvbkZ1bmN0aW9uS2V5KTtcclxuICAgICAgICAgICAgbGV0IHJlb3JkZXJlZFNodWZmbGVLZXlYID0gdHJhbnNmb3JtLnBlcm11dGVPdXRlclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLkNsaWVudFNodWZmbGVNZWRpdW1LZXlYLCBpbnB1dE91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uS2V5KTtcclxuICAgICAgICAgICAgbGV0IGZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihhcHBsaWVkRnVuY3Rpb25LZXksIHJlb3JkZXJlZFNodWZmbGVLZXlYKTtcclxuICAgICAgICAgICAgLy9eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5cXFxcXHJcblxyXG5cclxuICAgICAgICAgICAgLy92dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZcXFxcXHJcbiAgICAgICAgICAgIGxldCBjbGllbnRTaHVmZmxLZXlCID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHRyYW5zZm9ybS50cmFuc2Zvcm1hdGlvbkNvbXBsaW1lbnQocGVyc2lzdGVudEtleXMuQ2xpZW50U2h1ZmZsZU1lZGl1bUtleUEpLCBwZXJzaXN0ZW50S2V5cy5DbGllbnRTaHVmZmxlTWVkaXVtS2V5WCk7XHJcbiAgICAgICAgICAgIC8vXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXl5eXFxcXFxyXG5cclxuICAgICAgICAgICAgbGV0IGlucHV0Q2xpZW50U2h1ZmZsZUtleUIgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24oY2xpZW50U2h1ZmZsRXBoZW1lcmFsS2V5QiwgY2xpZW50U2h1ZmZsS2V5Qik7IC8vTm90ZSB0aGUgcmV2ZXJzZWQgc2VxdWVuY2Ugb2YgdGhlIGFyZ3VtZW50cy5cclxuICAgICAgICAgICAgbGV0IHNodWZmbGVkSXRlbXMgPSB0cmFuc2Zvcm0ucGVybXV0ZUZ1bmN0aW9uTWFwKGlucHV0T3V0ZXJTZXJ2ZXJTaHVmZmxlRnVuY3Rpb25LZXksIG1lZGl1bSwgaW5wdXRDbGllbnRTaHVmZmxlS2V5Qik7XHJcbiAgICAgICAgICAgIGxldCBhcHBsaWVkT3V0ZXJGdW5jdGlvbktleSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5PdXRlckZ1bmN0aW9uTWVkaXVtS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyRnVuY3Rpb25NZWRpdW1FcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgICAgICBsZXQgaW5wdXRPdXRlckZ1bmN0aW9uS2V5ID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKGFwcGxpZWRPdXRlckZ1bmN0aW9uS2V5LCBpbnB1dE91dGVyQ2xpZW50U2h1ZmZsZUtleSk7XHJcbiAgICAgICAgICAgIGxldCBpZGVudGl0eU91dGVyRnVuY3Rpb24gPSBkYXJjQ29tbW9uLmluaXRpYWxpemVOZXdBcnJheShwZXJzaXN0ZW50S2V5cy5PdXRlckZ1bmN0aW9uRnVuY3Rpb25NZWRpdW1LZXlbMF0ubGVuZ3RoLCBwZXJzaXN0ZW50S2V5cy5PdXRlckZ1bmN0aW9uRnVuY3Rpb25NZWRpdW1LZXkubGVuZ3RoKTtcclxuXHJcbiAgICAgICAgICAgIGxldCB0eE1lZGl1bSA9IHRyYW5zZm9ybS5zdWJzdGl0dXRlRnVuY3Rpb25PcGVyYW5kcyhcclxuICAgICAgICAgICAgICAgIGlkZW50aXR5T3V0ZXJGdW5jdGlvblxyXG4gICAgICAgICAgICAgICAgLCBmdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWRcclxuICAgICAgICAgICAgICAgICwgaW5wdXRPdXRlckZ1bmN0aW9uS2V5XHJcbiAgICAgICAgICAgICAgICAsIHNodWZmbGVkSXRlbXNcclxuICAgICAgICAgICAgICAgICwgZXBoZW1lcmFsS2V5cy5DbGllbnRNZWRpdW1FcGhlbWVyYWxLZXlcclxuICAgICAgICAgICAgICAgICwgcGVyc2lzdGVudEtleXMuQ2xpZW50TWVkaXVtS2V5XHJcbiAgICAgICAgICAgICAgICAsIGVwaGVtZXJhbEtleXMuTXV0dWFsTWVkaXVtRXBoZW1lcmFsS2V5XHJcbiAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gdHhNZWRpdW07XHJcbiAgICAgICAgfSBjYXRjaCAoZXgpIHtcclxuICAgICAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhleCwgXCIwYTc3OWQ5Yy0wMmE3LTQxMDktOGIyZC1hMjlkZTdjZTk3YzNcIik7XHJcbiAgICAgICAgICAgIHRocm93IGV4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsaWVudFR4OyIsImNvbnN0IGNvbW1vbiA9IHsgXHJcbiAgICBjcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXI6IChtZXNzYWdlLCBuS29kZU1ldGhvZElkZW50aWZpZXIpID0+IHtcclxuICAgICAgICBsZXQgZXJyb3IgPSBuZXcgRXJyb3IobWVzc2FnZSk7XHJcbiAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhlcnJvciwgbktvZGVNZXRob2RJZGVudGlmaWVyKTtcclxuICAgICAgICByZXR1cm4gZXJyb3I7XHJcbiAgICB9LFxyXG4gICAgYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvOiAoZXJyb3IsIG5Lb2RlTWV0aG9kSWRlbnRpZmllcikgPT4ge1xyXG4gICAgICAgIGlmICghZXJyb3IubktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2spXHJcbiAgICAgICAgICAgIGVycm9yLm5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrID0gbmV3IEFycmF5KCk7XHJcbiAgICAgICAgZXJyb3IubktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2sucHVzaChuS29kZU1ldGhvZElkZW50aWZpZXIpO1xyXG4gICAgfSxcclxuICAgIGNoZWNrRm9yVmFsdWU6IChhcnJheSwgYXJyYXlOYW1lKSA9PiB7XHJcbiAgICAgICAgaWYgKGFycmF5ID09PSBudWxsIHx8IGFycmF5ID09PSBbXSB8fCBhcnJheSA9PT0gMCkgICAgICAgXHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJHthcnJheU5hbWV9IGlzIG51bGwgb3IgZW1wdHlgKTsgICAgICAgIFxyXG5cclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH0sXHJcblxyXG4gICAgZ2V0Oih1cmwsIHJldHVybkpzb24gPSBmYWxzZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgICAgIC8vIGRvIHRoZSB1c3VhbCBIdHRwIHJlcXVlc3RcclxuICAgICAgICAgICAgbGV0IHJlcXVlc3QgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGNhY2hlQnVzdGVyID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogOTk5OTk5OTkpICsgMTAwMDAwMDA7XHJcbiAgICAgICAgICAgICBcclxuICAgICAgICAgICAgcmVxdWVzdC5vcGVuKCdHRVQnLCB1cmwgKyAnP189JyArIGNhY2hlQnVzdGVyLCB0cnVlKTtcclxuXHJcbiAgICAgICAgICAgIHJlcXVlc3Qub25sb2FkID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlcXVlc3Quc3RhdHVzID09PSAyMDApIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocmV0dXJuSnNvbikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKEpTT04ucGFyc2UocmVxdWVzdC5yZXNwb25zZSkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUocmVxdWVzdC5yZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYocmVxdWVzdC5zdGF0dXMgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVqZWN0KHJlcXVlc3QpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgcmVxdWVzdC5vbmVycm9yID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgcmVqZWN0KGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJIVFRQIEdFVCBOZXR3b3JrIGVycm9yXCIsIFwiN2U1ZjFmYzQtZTA5MS00MGNjLWJjNGEtZGM2ZDlmNzM5Y2EzXCIpKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHJlcXVlc3Quc2VuZCgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSxcclxuXHJcbiAgICBwb3N0Oih1cmwsIHBheWxvYWQpID0+IHtcclxuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xyXG4gICAgICAgICAgICBsZXQgcmVxdWVzdCA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xyXG4gICAgICAgICAgICByZXF1ZXN0Lm9wZW4oJ1BPU1QnLCB1cmwsIHRydWUpO1xyXG5cclxuICAgICAgICAgICByZXF1ZXN0LnNldFJlcXVlc3RIZWFkZXIoJ0NvbnRlbnQtVHlwZScsICdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQ7IGNoYXJzZXQ9VVRGLTgnKTtcclxuXHJcbiAgICAgICAgICAgIHJlcXVlc3Qub25yZWFkeXN0YXRlY2hhbmdlID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlcXVlc3QucmVhZHlTdGF0ZSA9PT0gNCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXF1ZXN0LnN0YXR1cyA9PT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXN1bHQgPSByZXF1ZXN0LnJlc3BvbnNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IEpTT04ucGFyc2UocmVzdWx0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhdGNoIHsgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUocmVzdWx0KTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYocmVxdWVzdC5zdGF0dXMgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vcmVqZWN0KG5ldyBlcnJvcignNDlGQUU5QkQtQUNDNS00RjY0LThFMDUtQ0JGMEE0MjFGRDBDJywgcmVxdWVzdCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZWplY3QocmVxdWVzdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgY29uc3QgZW5jb2RlZCA9IE9iamVjdC5rZXlzKHBheWxvYWQpLm1hcChrZXkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiAocGF5bG9hZFtrZXldKSA9PT0gXCJvYmplY3RcIilcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAvL3JldHVybiBPYmplY3Qua2V5cyhwYXlsb2FkW2tleV0pLm1hcCgoYXJyYXksIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgcmV0dXJuIGFycmF5Lm1hcCh2YWx1ZSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgIHJldHVybiBcIktleXNbXCIgKyBpbmRleCArIFwiXVtdPVwiICsgZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyAgICB9KS5qb2luKCcmJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy99KS5qb2luKCcmJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGVuY29kZVVSSUNvbXBvbmVudChrZXkpICsgJz0nICsgSlNPTi5zdHJpbmdpZnkocGF5bG9hZFtrZXldKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGVuY29kZVVSSUNvbXBvbmVudChrZXkpICsgJz0nICsgZW5jb2RlVVJJQ29tcG9uZW50KHBheWxvYWRba2V5XSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pLmpvaW4oJyYnKTtcclxuXHJcbiAgICAgICAgICAgIHJlcXVlc3Qub25lcnJvciA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIHJlamVjdChjb21tb24uY3JlYXRlRXJyb3JXaXRoTmtvZGVNZXRob2RJZGVudGlmaWVyKFwiSFRUUCBQT1NUIE5ldHdvcmsgZXJyb3JcIixcIjEzNzllYWI0LWUxNWUtNGU3Yy04MzBlLWIzNzRmNzNiZGI3N1wiKSk7Ly9uZXcgZXJyb3IoJ0E3NjFGRkUzLTNDMzctNDg5NC05RjlGLTQyMEE5QUM1RTNCNicpKTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHJlcXVlc3Quc2VuZChlbmNvZGVkKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNvbW1vbjtcclxuIiwiaW1wb3J0IGNvbW1vbiBmcm9tICcuL2NvbW1vbi5qcyc7XHJcblxyXG5jb25zdCBkYXJjQ29tbW9uID0geyAgICBcclxuICAgIGdldERhcmNLZXlMZW5ndGg6IChhcnJheSkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCBjb3VudCA9IDA7XHJcbiAgICAgICAgICAgIGZvciAobGV0IHZhbHVlIG9mIGFycmF5KSB7XHJcbiAgICAgICAgICAgICAgICBjb3VudCArPSBBcnJheS5pc0FycmF5KHZhbHVlKSA/IHZhbHVlLmxlbmd0aCA6IDE7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldHVybiBjb3VudDtcclxuICAgICAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcIjg3ZGNkMjk5LTc5YTMtNGEyNC04ZjgxLWJlYjdiMTgyNzQwMlwiKTtcclxuICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBmbGF0dGVuVHdvRGltQXJyYXk6ICh0d29EaW1BcnJheSkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCByZXN1bHQgPSBuZXcgQXJyYXkoKTtcclxuXHJcbiAgICAgICAgICAgIGZvciAobGV0IHZhbHVlIG9mIHR3b0RpbUFycmF5KVxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgc3ViVmFsdWUgb2YgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnB1c2goc3ViVmFsdWUpO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgICAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcImE5MWIxYWU4LTdlM2YtNDUzMS1iOGEyLTQ5NTg3YTRkMjA0N1wiKTtcclxuICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBpbml0aWFsaXplTmV3QXJyYXk6ICh3aWR0aCwgaGVpZ2h0LCB2YWx1ZSkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCBlbXB0eSA9IG5ldyBBcnJheSgpO1xyXG4gICAgICAgICAgICBsZXQgZWxlbWVudCA9IG5ldyBBcnJheSgpO1xyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgdyA9IDA7IHcgPCB3aWR0aDsgdysrKVxyXG4gICAgICAgICAgICAgICAgZWxlbWVudC5wdXNoKHZhbHVlID09PSB1bmRlZmluZWQgfHwgdmFsdWUgPT09IG51bGwgPyB3IDogdmFsdWUpO1xyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgaCA9IDA7IGggPCBoZWlnaHQ7IGgrKylcclxuICAgICAgICAgICAgICAgIGVtcHR5LnB1c2goZWxlbWVudCk7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gZW1wdHk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXgpIHtcclxuICAgICAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhleCwgXCI3OTJmNzViNC0yYmI2LTRhZmQtOTVhYi1hZWZhYWE0YjI2OWFcIik7XHJcbiAgICAgICAgICAgIHRocm93IGV4O1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgYXJyYXlFbGVtZW50c01hdGNoOiAoYXJyYXkxLCBhcnJheTIpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAoYXJyYXkxLmxlbmd0aCAhPT0gYXJyYXkyLmxlbmd0aClcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgIGxldCByZXN1bHQgPSB0cnVlO1xyXG4gICAgICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IGFycmF5MS5sZW5ndGg7IHgrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKGFycmF5MVt4XSAhPT0gYXJyYXkyW3hdKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfSBjYXRjaCAoZXgpIHtcclxuICAgICAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhleCwgXCIwYTU3OGU4MS1mNmExLTQxZGEtYjA0Ny1iOWEzZTQ1MzEzYmVcIik7XHJcbiAgICAgICAgICAgIHRocm93IGV4O1xyXG4gICAgICAgIH1cclxuICAgIH0sLy9ieXRlW11bXSBieXRlcywgaW50IGNvdW50LCBpbnQgbWluLCBpbnQgbWF4XHJcbiAgICByYW5kVW5pcXVlTmV3Qnl0ZXM6IChieXRlcywgY291bnQsIG1pbiwgbWF4KSA9PlxyXG4gICAge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCBieXRlTWF4ID0gMjU2O1xyXG4gICAgICAgICAgICBsZXQgYnl0ZU1pbiA9IDA7XHJcblxyXG4gICAgICAgICAgICAvL1ZlcmlmeSB0aGF0IGFsbCBwYXJhbWV0ZXJzIGFyZSB2YWxpZCBmb3IgYnl0ZSBkYXRhXHJcbiAgICAgICAgICAgIGlmIChjb3VudCA8IDAgfHwgY291bnQgPiBieXRlTWF4IHx8IG1pbiA8IGJ5dGVNaW4gfHwgbWluID4gYnl0ZU1heCB8fCBtYXggPCBieXRlTWluIHx8IG1heCA+IGJ5dGVNYXggfHwgbWluID4gbWF4KVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIkFyZ3VtZW50KHMpIG91dCBvZiByYW5nZVwiLCBcImI4OTM1YjRjLWVmMjgtNDliNy1hOWUxLWFjNzI1ODkzMzI5MlwiKTsgXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgLy9EZXRlcm1pbmUgYXJyYXkgZGltZW5zaW9uc1xyXG4gICAgICAgICAgICBsZXQgaGVpZ2h0ID0gYnl0ZXMubGVuZ3RoO1xyXG4gICAgICAgICAgICBsZXQgd2lkdGggPSBieXRlc1swXS5sZW5ndGg7XHJcblxyXG4gICAgICAgICAgICAvL1ZlcmlmeSB0aGF0IGFsbCBieXRlcyBzdWItYXJyYXlzIGFyZSB1bmlmb3JtIGluIHNpemVcclxuICAgICAgICAgICAgbGV0IGNvbnRyYSA9IG5ldyBBcnJheSgpO1xyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDE7IGkgPCBoZWlnaHQ7IGkrKylcclxuICAgICAgICAgICAgICAgIGlmIChieXRlc1tpXS5sZW5ndGggIT09IHdpZHRoKVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRyYS5wdXNoKGkpO1xyXG5cclxuICAgICAgICAgICAgaWYgKGNvbnRyYS5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIlNpemUgb2YgYnl0ZXMgc3ViLWFycmF5cyBtdXN0IGJlIHVuaWZvcm1cIiwgXCJiODkzNWI0Yy1lZjI4LTQ5YjctYTllMS1hYzcyNTg5MzMyOTJcIik7IFxyXG5cclxuICAgICAgICAgICAgY29udHJhID0gbnVsbDtcclxuXHJcbiAgICAgICAgICAgIC8vQmVnaW4gcHJvY2Vzc1xyXG4gICAgICAgICAgICBsZXQgc3VjY2VzcyA9IG5ldyBBcnJheSh3aWR0aCk7XHJcbiAgICAgICAgICAgIGxldCBjaG9zZW4gPSBuZXcgQXJyYXkoKTtcclxuICAgICAgICAgICAgbGV0IHBhc3MgPSAwO1xyXG4gICAgICAgICAgICBsZXQgZmFpbCA9IDA7XHJcbiAgICAgICAgICAgIGxldCByYW5kTnVtID0gMDtcclxuICAgICAgICAgICAgbGV0IGhpdCA9IDA7XHJcbiAgICAgICAgICAgIGxldCBtaXNzID0gMDtcclxuICAgICAgICAgICAgbGV0IG9yZCA9IDA7XHJcbiAgICAgICAgICAgIGxldCBzY3JhcCA9IDA7XHJcblxyXG4gICAgICAgICAgICAvL1JhbmRvbSBwZXJtdXRhdGlvblxyXG4gICAgICAgICAgICBsZXQgb3JkaW5hbCA9IGRhcmNDb21tb24ucmFuZFVuaXF1ZUludCh3aWR0aCwgMCwgd2lkdGgpOy8vUmFuZFVuaXF1ZUludCBtYXggaXMgRVhjbHVzaXZlXHJcblxyXG4gICAgICAgICAgICAvL1JhbmRvbSBieXRlIGJsb2NrXHJcbiAgICAgICAgICAgIGxldCBzZXQgPSBkYXJjQ29tbW9uLnJhbmRVbmlxdWVJbnQod2lkdGgsIDAsIGJ5dGVNYXgpOy8vUmFuZFVuaXF1ZUJ5dGUgbWF4IGlzIEVYY2x1c2l2ZVxyXG5cclxuICAgICAgICAgICAgLy9CdWlsZCBwb3NzaWJsZSB2YWxpZCB2YWx1ZXNcclxuICAgICAgICAgICAgbGV0IHBvc3NpYmxlID0gbmV3IEFycmF5KCk7XHJcblxyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gbWluOyBpIDwgbWF4OyBpKyspXHJcbiAgICAgICAgICAgICAgICBwb3NzaWJsZS5wdXNoKGkpO1xyXG5cclxuICAgICAgICAgICAgLy9JZGVudGlmeSBwb3NzaWJsZSBvcmRpbmFsIGFuZCB2YWx1ZSBjb21iaW5hdGlvbnMgd2hpY2ggYXJlIGRpc3RpbmN0IGFjcm9zcyBhbGwgYnl0ZXNbXVxyXG4gICAgICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IHdpZHRoOyB4KyspIHtcclxuICAgICAgICAgICAgICAgIGxldCBhdmFpbCA9IHBvc3NpYmxlLnNsaWNlKDApOy8vQ29udmVydEFsbCB0byBieXRlIHRvIGVuc3VyZSB0aGF0IGF2YWlsIGlzIGEgQ09QWSBvZiBwb3NzaWJsZSwgYW5kIGJlY2F1c2UgYnl0ZSBpcyBtb3JlIG1lbW9yeSBlZmZpY2llbnQgdGhhbiBpbnQuXHJcblxyXG4gICAgICAgICAgICAgICAgLy9SZW1vdmUgZWFjaCBlbGVtZW50IHZhbHVlIGluIGJ5dGVzW3ldW29yZGluYWxbeF1dIGZyb20gYXZhaWxbXVxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgeSA9IDA7IHkgPCBoZWlnaHQ7IHkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCB6ID0gYXZhaWwuQ291bnQgLSAxO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBkbyB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhdmFpbFt6XSA9PT0gYnl0ZXNbeV1bb3JkaW5hbFt4XV0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF2YWlsLnNwbGljZSh6LCAxKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHotLTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgei0tO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB9IHdoaWxlICh6ID49IDApO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHN1Y2Nlc3NbeF0gPSBhdmFpbC5sZW5ndGggPiAwO1xyXG4gICAgICAgICAgICAgICAgcmFuZE51bSA9IGRhcmNDb21tb24ucmFuZE51bSgwLCBhdmFpbC5sZW5ndGgpO1xyXG4gICAgICAgICAgICAgICAgY2hvc2VuLnB1c2goYXZhaWxbcmFuZE51bV0pO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvL0NvbnNvbGlkYXRlIGlkZW50aWZpZWQgb3JkaW5hbCBhbmQgdmFsdWUgY29tYmluYXRpb25zIHRvIGEgc2luZ2xlIHBhaXIuXHJcbiAgICAgICAgICAgIGZvciAobGV0IHggPSAwOyB4IDwgd2lkdGg7IHgrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHN1Y2Nlc3NbeF0pIHtcclxuICAgICAgICAgICAgICAgICAgICBwYXNzID0gY2hvc2VuW3hdO1xyXG4gICAgICAgICAgICAgICAgICAgIGhpdCA9IHg7XHJcbiAgICAgICAgICAgICAgICAgICAgb3JkID0gb3JkaW5hbFt4XTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2UgLy9Bc3NpZ24gYXJyYXkgZWxlbWVudCBhbmQgdmFyaWFibGUgdG8gbWFpbnRhaW4gY29uc3RhbnQgZXhlY3V0aW9uIHRpbWUgYW5kIG1lbW9yeSBwcm9maWxlIHJlZ2FyZGxlc3Mgb2YgYnJhbmNoLlxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIGZhaWwgPSBjaG9zZW5beF07XHJcbiAgICAgICAgICAgICAgICAgICAgbWlzcyA9IHg7XHJcbiAgICAgICAgICAgICAgICAgICAgc2NyYXAgPSBvcmRpbmFsW3hdO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBzZXRbb3JkXSA9IHBhc3M7ICAvL0lmIHRoZSBmdWxsIGJ5dGVzW11bXSBzcGFjZSAoZXZlcnkgcG9zc2libGUgY29tYmluYXRpb24gb2YgYnl0ZSB2YWx1ZXMpIGlzIHVzZWQsIHNldCB3aWxsIG5vdCBiZSBhIG5ldyBkaXN0aW5jdCBzZXJpZXMgb2YgYnl0ZXMsIGJ1dCByYXRoZXIgYSByYW5kb20gc2VyaWVzIG9mIGJ5dGVzIHRoYXQgYWxyZWFkeSBleGlzdHMgc29tZXdoZXJlIGluIGJ5dGVzW11bXS4gIFxyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHNldDtcclxuICAgICAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcImI4OTM1YjRjLWVmMjgtNDliNy1hOWUxLWFjNzI1ODkzMzI5MlwiKTtcclxuICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIHJhbmROZXdJbnRzOiAoaW50cywgY291bnQsIG1pbiwgbWF4KSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgbGV0IG1zZ0xlbiA9IGludHMubGVuZ3RoO1xyXG5cclxuICAgICAgICAgICAgLy9HZW5lcmF0ZSByYW5kb20gdmFsdWVzIGZvciBwYWRkaW5nXHJcbiAgICAgICAgICAgIGxldCBzZXRQYWQgPSBkYXJjQ29tbW9uLnJhbmRJbnQoY291bnQsIG1pbiwgbWF4KTtcclxuXHJcbiAgICAgICAgICAgIGxldCBzZXQgPSBuZXcgQXJyYXkoKTtcclxuXHJcbiAgICAgICAgICAgIC8vUGFkIHNldCB3aXRoIHJhbmRvbSB2YWx1ZXNcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtYXg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKG1zZ0xlbiA+IGkpXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0LnB1c2goaW50c1tpXSk7XHJcbiAgICAgICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0LnB1c2goc2V0UGFkW2ldKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHNldDtcclxuICAgICAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcImJjYWViYzQ5LTM3ZGMtNDVmYi1iOTNmLTc4YzQ2ZmI2NWE5YlwiKTtcclxuICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIHJhbmRJbnQ6KGNvdW50LCBtaW4sIG1heCkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCBhcnJheSA9IG5ldyBBcnJheShjb3VudCk7XHJcblxyXG4gICAgICAgICAgICBmb3IgKGxldCBiID0gMDsgYiA8IGNvdW50OyBiKyspXHJcbiAgICAgICAgICAgICAgICBhcnJheVtiXSA9IGRhcmNDb21tb24ucmFuZE51bShtaW4sIG1heCk7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gYXJyYXk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXgpIHtcclxuICAgICAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhleCwgXCIzM2FiZjUwMC1lMDJkLTRjYjYtODM0OS0xMmU1ZTliMGZkMmNcIik7XHJcbiAgICAgICAgICAgIHRocm93IGV4O1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvL0luY2x1c2l2ZSBtaW4gZXhjbHVzaXZlIG1heFxyXG4gICAgcmFuZFVuaXF1ZUludDogKGNvdW50LCBtaW4sIG1heCkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGlmIChtYXggPD0gbWluIHx8IGNvdW50IDwgMCB8fFxyXG4gICAgICAgICAgICAgICAgLy8gbWF4IC0gbWluID4gMCByZXF1aXJlZCB0byBhdm9pZCBvdmVyZmxvd1xyXG4gICAgICAgICAgICAgICAgKGNvdW50ID4gbWF4IC0gbWluICYmIG1heCAtIG1pbiA+IDApKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgLy90aHJvdyBuZXcgQXJndW1lbnRPdXRPZlJhbmdlRXhjZXB0aW9uKFwiUmFuZ2UgXCIgKyBtaW4gKyBcIiB0byBcIiArIG1heCArIFwiIChcIiArIChtYXggLSBtaW4pICsgXCIgdmFsdWVzKSwgb3IgY291bnQgXCIgKyBjb3VudCArIFwiIGlzIGlsbGVnYWxcIik7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGdlbmVyYXRlIGNvdW50IHJhbmRvbSB2YWx1ZXMuXHJcbiAgICAgICAgICAgIGxldCBjYW5kaWRhdGVzID0ge307XHJcblxyXG4gICAgICAgICAgICAvLyBzdGFydCBjb3VudCB2YWx1ZXMgYmVmb3JlIG1heCwgYW5kIGVuZCBhdCBtYXhcclxuICAgICAgICAgICAgZm9yIChsZXQgdG9wID0gbWF4IC0gY291bnQ7IHRvcCA8IG1heDsgdG9wKyspIHtcclxuICAgICAgICAgICAgICAgIGxldCByYW5kTnVtUmVzdWx0ID0gZGFyY0NvbW1vbi5yYW5kTnVtKG1pbiwgdG9wICsgMSk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGNhbmRpZGF0ZXNbcmFuZE51bVJlc3VsdF0gPT09IHRydWUpXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY29sbGlzaW9uLCBhZGQgaW5jbHVzaXZlIG1heC5cclxuICAgICAgICAgICAgICAgICAgICAvLyB3aGljaCBjb3VsZCBub3QgcG9zc2libHkgaGF2ZSBiZWVuIGFkZGVkIGJlZm9yZS5cclxuICAgICAgICAgICAgICAgICAgICBjYW5kaWRhdGVzW3RvcF0gPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICAgICAgICAgIGNhbmRpZGF0ZXNbcmFuZE51bVJlc3VsdF0gPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgIC8vIGxvYWQgdGhlbSBpbiB0byBhbiBhcnJheSwgdG8gc29ydFxyXG4gICAgICAgICAgICBsZXQgcmVzdWx0ID0gT2JqZWN0LmtleXMoY2FuZGlkYXRlcyk7XHJcblxyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCBjb3VudDsgeCsrKVxyXG4gICAgICAgICAgICAgICAgcmVzdWx0W3hdID0gcGFyc2VJbnQocmVzdWx0W3hdLCAxMCk7XHJcblxyXG4gICAgICAgICAgICAvLyBzaHVmZmxlIHRoZSByZXN1bHRzIGJlY2F1c2UgSGFzaFNldCBoYXMgbWVzc2VkXHJcbiAgICAgICAgICAgIC8vIHdpdGggdGhlIG9yZGVyLCBhbmQgdGhlIGFsZ29yaXRobSBkb2VzIG5vdCBwcm9kdWNlXHJcbiAgICAgICAgICAgIC8vIHJhbmRvbS1vcmRlcmVkIHJlc3VsdHMgKGUuZy4gbWF4LTEgd2lsbCBuZXZlciBiZSB0aGUgZmlyc3QgdmFsdWUpXHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAoY291bnQgLSAxKTsgaSA+IDA7IGktLSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IGsgPSBkYXJjQ29tbW9uLnJhbmROdW0oMCwgaSk7IC8vVE9ETzogY2hlY2sgMCBpcyBsb3dlc3RcclxuICAgICAgICAgICAgICAgIGxldCB0bXAgPSByZXN1bHRba107XHJcblxyXG4gICAgICAgICAgICAgICAgcmVzdWx0W2tdID0gcmVzdWx0W2ldO1xyXG4gICAgICAgICAgICAgICAgcmVzdWx0W2ldID0gdG1wO1xyXG4gICAgICAgICAgICB9XHJcblxyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgICAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcIjA5NWVlMzExLTA1YjQtNGUyNS04ZTg5LWNmNjNiYjFiNWZjYlwiKTtcclxuICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8vSW5jbHVzaXZlIG1pbiwgZXhjbHVzaXZlIG1heFxyXG4gICAgcmFuZE51bTogKG1pbiwgbWF4KSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgbWluID0gTWF0aC5jZWlsKG1pbik7XHJcbiAgICAgICAgICAgIG1heCA9IE1hdGguZmxvb3IobWF4KTtcclxuICAgICAgICAgICAgLy9yZXR1cm4gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogKG1heCAtIDEgLSBtaW4gKyAxKSkgKyBtaW47XHJcbiAgICAgICAgICAgIHJldHVybiBzZWN1cmVfcmFuZChtaW4sIG1heCk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXgpIHtcclxuICAgICAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhleCwgXCJlMjViYWQyZC0wZGI0LTRmM2YtOWUyYS1mZTIxMjFmZjQzZmNcIik7XHJcbiAgICAgICAgICAgIHRocm93IGV4O1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBzdHJ1Y3R1cmVGbGF0dGVuZWRUd29EaW1lbnNpb25hbEFycmF5OiAoaGVpZ2h0LCB3aWR0aCwgZGF0YSkgPT5cclxuICAgIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAoaGVpZ2h0ICogd2lkdGggIT09IGRhdGEubGVuZ3RoKVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIkFyZ3VtZW50cyBvdXQgb2YgcmFuZ2VcIiwgXCI5NzQzZTQ4YS05YjNhLTQyMjEtYWNjYS05ZmJjMTgzMGMxZGZcIik7IFxyXG5cclxuICAgICAgICAgICAgbGV0IG91dGVyQXJyYXkgPSBuZXcgQXJyYXkoKTtcclxuICAgICAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCBoZWlnaHQ7IHgrKykge1xyXG4gICAgICAgICAgICAgICAgbGV0IGlubmVyQXJyYXkgPSBuZXcgQXJyYXkoKTtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IHkgPSAwOyB5IDwgd2lkdGg7IHkrKylcclxuICAgICAgICAgICAgICAgICAgICBpbm5lckFycmF5LnB1c2goZGF0YVt3aWR0aCAqIHggKyB5XSk7XHJcblxyXG4gICAgICAgICAgICAgICAgb3V0ZXJBcnJheS5wdXNoKGlubmVyQXJyYXkpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gb3V0ZXJBcnJheTtcclxuICAgICAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcIjk3NDNlNDhhLTliM2EtNDIyMS1hY2NhLTlmYmMxODMwYzFkZlwiKTtcclxuICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59O1xyXG5cclxuLyoqXHJcbiAqIEphdmFzY3JpcHQgQ1NQUk5HIGZvciBJbnRlZ2Vycy4gIFRha2VuIGZyb20gaHR0cHM6Ly9naXN0LmdpdGh1Yi5jb20vcGFyYWdvbmllLXNjb3R0L2M3YTczZmQwZjc1OWU0NTFjZjA3XHJcbiAqIEBwYXJhbSB7aW50fSBtaW4gSW5jbHVzaXZlIG1pbmltdW0gdmFsdWVcclxuICogQHBhcmFtIHtpbnR9IG1heCBFeGNsdXNpdmUgbWF4aW11bSB2YWx1ZVxyXG4gKiBAcmV0dXJucyB7aW50fSBSYW5kb20gdmFsdWVcclxuICovXHJcbmZ1bmN0aW9uIHNlY3VyZV9yYW5kKG1pbiwgbWF4KSB7XHJcbiAgICB2YXIgcnZhbCA9IDA7XHJcbiAgICB2YXIgcmFuZ2UgPSBtYXggLSBtaW47XHJcbiAgICBpZiAocmFuZ2UgPCAyKSB7XHJcbiAgICAgICAgcmV0dXJuIG1pbjtcclxuICAgIH1cclxuXHJcbiAgICB2YXIgYml0c19uZWVkZWQgPSBNYXRoLmNlaWwoTWF0aC5sb2cyKHJhbmdlKSk7XHJcbiAgICBpZiAoYml0c19uZWVkZWQgPiA1Mykge1xyXG4gICAgICAgIHRocm93IG5ldyBFeGNlcHRpb24oXCJXZSBjYW5ub3QgZ2VuZXJhdGUgbnVtYmVycyBsYXJnZXIgdGhhbiA1MyBiaXRzLlwiKTtcclxuICAgIH1cclxuICAgIHZhciBieXRlc19uZWVkZWQgPSBNYXRoLmNlaWwoYml0c19uZWVkZWQgLyA4KTtcclxuICAgIHZhciBtYXNrID0gTWF0aC5wb3coMiwgYml0c19uZWVkZWQpIC0gMTtcclxuICAgIC8vIDc3NzYgLT4gKDJeMTMgPSA4MTkyKSAtMSA9PSA4MTkxIG9yIDB4MDAwMDExMTEgMTExMTExMTFcclxuXHJcbiAgICAvLyBDcmVhdGUgYnl0ZSBhcnJheSBhbmQgZmlsbCB3aXRoIE4gcmFuZG9tIG51bWJlcnNcclxuICAgIHZhciBieXRlQXJyYXkgPSBuZXcgVWludDhBcnJheShieXRlc19uZWVkZWQpO1xyXG4gICAgd2luZG93LmNyeXB0by5nZXRSYW5kb21WYWx1ZXMoYnl0ZUFycmF5KTtcclxuXHJcbiAgICB2YXIgcCA9IChieXRlc19uZWVkZWQgLSAxKSAqIDg7XHJcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGJ5dGVzX25lZWRlZDsgaSsrKSB7XHJcbiAgICAgICAgcnZhbCArPSBieXRlQXJyYXlbaV0gKiBNYXRoLnBvdygyLCBwKTtcclxuICAgICAgICBwIC09IDg7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gVXNlICYgdG8gYXBwbHkgdGhlIG1hc2sgYW5kIHJlZHVjZSB0aGUgbnVtYmVyIG9mIHJlY3Vyc2l2ZSBsb29rdXBzXHJcbiAgICBydmFsID0gcnZhbCAmIG1hc2s7XHJcblxyXG4gICAgaWYgKHJ2YWwgPj0gcmFuZ2UpIHtcclxuICAgICAgICAvLyBJbnRlZ2VyIG91dCBvZiBhY2NlcHRhYmxlIHJhbmdlXHJcbiAgICAgICAgcmV0dXJuIHNlY3VyZV9yYW5kKG1pbiwgbWF4KTtcclxuICAgIH1cclxuICAgIC8vIFJldHVybiBhbiBpbnRlZ2VyIHRoYXQgZmFsbHMgd2l0aGluIHRoZSByYW5nZVxyXG4gICAgcmV0dXJuIG1pbiArIHJ2YWw7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGRhcmNDb21tb247IiwibGV0IGRhcmNDb25maWcgPVxyXG4vLyBAanNjcmFtYmxlciBlbmFibGUgbnVtYmVyVG9TdHJpbmcsIHN0cmluZ0NvbmNlYWxpbmcsIGlkZW50aWZpZXJzUmVuYW1pbmdcclxue1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFUVFJJQlVURV9WQUxVRVM6IFszNywgMjUxLCA1NSwgMjUzLCA3NiwgMTQ2LCAyNTIsIDIxMiwgMTM4LCA2MywgNjcsIDE3OSwgMTg3LCAzNiwgMjE2LCAxMSwgNzAsIDEyNSwgMTk5LCAxNTYsIDY2LCAxMDAsIDkyLCAyNCwgNDYsIDIwOSwgMjksIDE3NCwgODYsIDEwNCwgMTI4LCAyMDQsIDExMiwgMTY3LCAxMTAsIDE1OCwgOCwgMTgzLCAyMzUsIDE3NiwgMjQ0LCA2NCwgOTEsIDE2MywgMjAwLCAxNTMsIDAsIDE0MSwgMTgsIDIwMSwgMTA1LCAxODIsIDE4NiwgMTEzLCAyLCA5NiwgMTQzLCAxOTMsIDE2LCAxNTEsIDE0LCAxMDEsIDIyMSwgMTE5LCAyNDEsIDExOCwgMTAsIDIxLCA4MCwgMjA3XSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBPU0lUSU9OX0FUVFJJQlVURV9PUkRJTkFMX1BPU0lUSU9OOiA2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ0xJRU5UX0tFWVM6IHsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE91dGVyRnVuY3Rpb25LZXk6IFtbMywgNywgOSwgMCwgMSwgNCwgNSwgMiwgOCwgNl1dLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE91dGVyRnVuY3Rpb25GdW5jdGlvbktleTogW1szLDQsOSw1LDcsMSwwLDYsMiw4XV0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT3V0ZXJTZXJ2ZXJTaHVmZmxlRnVuY3Rpb25LZXk6IFtbOCw1LDcsMCw5LDIsNiwzLDQsMV1dLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBNdXR1YWxLZXk6IFtbMjEwLDk3LDI0NSwxMywxMzcsNDUsMTM1XSxbODAsMTg2LDE1MCwyMjMsMjUyLDE1OCwyMTZdLFsyMzMsMTA2LDE3OSw5MywyMjgsMjAyLDE2Ml0sWzE2MiwxOCw2OCwxMjgsNzIsMSw4OF0sWzY0LDExNyw3Miw2NiwxNyw2LDI0N10sWzIzLDE0OSw4OCw5MSwxNDAsMTg0LDIzXSxbMTY2LDE3Miw1MywyMjYsMTgzLDk4LDZdLFsxNCwxMjMsMTAwLDIyNywyNDQsMTQxLDE2NV0sWzExMiw4MSwyMzgsMTcsMTEsNTcsMTRdLFszNiwxNjYsMTEsMTAyLDEyMCw1MSwxMDddXSwgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBGdW5jdGlvbktleTogW1swLDUsMyw0LDEsMiw2XSxbNCwxLDMsNiw1LDIsMF0sWzIsNCwzLDUsNiwxLDBdLFs1LDMsMiw2LDEsMCw0XSxbMywyLDQsMSw1LDAsNl0sWzYsMCwyLDEsNCw1LDNdLFsxLDUsMiwwLDYsMyw0XSxbMCwyLDUsNCwxLDYsM10sWzIsMSw1LDAsNCwzLDZdLFs0LDMsNiw1LDAsMSwyXV0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2xpZW50U2h1ZmZsZUtleVg6IFtbMSwzLDIsMCw2LDUsNF0sWzUsNCwzLDYsMSwwLDJdLFszLDUsMSw2LDAsNCwyXSxbNSwwLDMsNiw0LDEsMl0sWzAsNiw1LDQsMSwyLDNdLFs2LDEsNSwzLDAsMiw0XSxbNiwxLDUsMCwyLDMsNF0sWzYsMiwwLDEsMyw1LDRdLFsyLDYsNCwwLDMsNSwxXSxbMywxLDIsNCw1LDAsNl1dLCAgICBcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTXV0dWFsTWVkaXVtS2V5OiBbWzE1NSwxNzIsMTAyLDExLDcyLDMzLDg4XSxbNjUsNzgsNjYsMjUsMjQ1LDk3LDhdLFsyMDIsNzUsMTI4LDg5LDE3NSwxMiwyMjhdLFsxMTgsMTc3LDIzNyw2NSw0MCwxNSw2NV0sWzkzLDI4LDE3NiwxMTUsMTMsMjA1LDI0OF0sWzE5MywyNTQsMTI2LDYwLDIyNSwyMjIsMjE3XSxbMzMsMTIyLDE2OSwxMTcsNCwyMzEsMTQxXSxbMzYsMjQ2LDIxMSw1MiwxOTIsMjAxLDE1N10sWzI0OSwxMTUsOCwxMTcsMjIxLDEzOSwyMDVdLFsyMTQsMTUzLDEyNywxNjksMjA5LDE2NSw2XV0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT3V0ZXJGdW5jdGlvbk1lZGl1bUtleTogW1s3LDIsNCwzLDEsOCwwLDYsOSw1XV0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT3V0ZXJGdW5jdGlvbkZ1bmN0aW9uTWVkaXVtS2V5OiBbWzUsNCwyLDcsOCw2LDEsOSwwLDNdXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbk1lZGl1bUtleTogW1s5LDIsNCwwLDgsMywxLDYsNSw3XV0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRnVuY3Rpb25NZWRpdW1LZXk6IFtbMiw1LDQsMCwxLDMsNl0sWzAsMywyLDYsNCwxLDVdLFs0LDMsMiw2LDUsMCwxXSxbMiwxLDUsMyw0LDYsMF0sWzQsNSw2LDIsMywwLDFdLFswLDEsNCw1LDMsMiw2XSxbMyw2LDAsMiw0LDUsMV0sWzIsMCwzLDUsNiwxLDRdLFs1LDAsMyw2LDQsMiwxXSxbNiwzLDUsNCwyLDEsMF1dLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENsaWVudFNodWZmbGVNZWRpdW1LZXlYOiBbWzAsNCw2LDEsMywyLDVdLFs1LDIsMSwwLDQsNiwzXSxbMCwzLDYsNCw1LDIsMV0sWzMsNCwwLDEsMiw2LDVdLFs1LDYsMSwzLDIsMCw0XSxbMyw2LDAsMSw1LDIsNF0sWzYsMyw0LDEsMiw1LDBdLFswLDIsNiw0LDMsMSw1XSxbMyw1LDIsNCw2LDAsMV0sWzQsMCwyLDUsMSwzLDZdXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPdXRlclBvc2l0aW9uU2h1ZmZsZU1lZGl1bUtleTogW1sxLDksNCwzLDAsOCw1LDcsNiwyXV0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT3V0ZXJQb3NpdGlvblNodWZmbGVGdW5jdGlvbk1lZGl1bUtleTogW1syLDEsOSw2LDAsOCwzLDcsNSw0XV0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT3V0ZXJQb3NpdGlvbkZ1bmN0aW9uTWVkaXVtS2V5OiBbWzksMSw1LDMsOCw0LDAsNiw3LDJdXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQb3NpdGlvbkZ1bmN0aW9uTWVkaXVtS2V5OiBbWzMsNCwwLDEsNiwyLDVdLFszLDEsNSwwLDYsMiw0XSxbMywxLDUsNCw2LDIsMF0sWzAsMSwzLDQsNiw1LDJdLFs0LDEsMywyLDAsNiw1XSxbNSwyLDQsMCw2LDEsM10sWzAsNSw0LDIsMSw2LDNdLFs2LDIsNCwxLDUsMCwzXSxbMywwLDQsMiw1LDYsMV0sWzMsNSwwLDQsNiwyLDFdXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQb3NpdGlvblNodWZmbGVNZWRpdW1LZXk6IFtbMSwwLDIsMyw1LDYsNF0sWzEsNCwyLDYsMyw1LDBdLFsyLDUsMyw2LDAsNCwxXSxbMSw0LDAsNSwzLDIsNl0sWzIsMSwwLDUsMyw2LDRdLFsxLDUsNiw0LDAsMiwzXSxbMSwzLDYsMCw1LDIsNF0sWzMsMCwyLDUsMSw2LDRdLFszLDQsMCw2LDIsNSwxXSxbMiwxLDAsNCwzLDUsNl1dLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbGllbnRLZXk6IFtbMTQyLDgsMTU1LDE2MiwxOTksMjksMTU0XSxbMTQsMjI3LDE0MCw1MCw4LDI2LDEzNV0sWzE4LDI2LDczLDIyNCw3NywxMDQsMTk4XSxbNSwyMDQsMTM3LDE5NCwxOTMsMTg2LDE0M10sWzE0OSwyNDUsMTk0LDE3NywyMTcsMTExLDg1XSxbMzksMTY0LDg2LDI0NCwxNDAsOSwyNDJdLFs5MCwyMTUsODYsMTUxLDIyOCwzNSwxMDldLFsyNTQsMTY4LDE3MCwyMDEsMTk4LDE5Nyw3Ml0sWzE1NSwxNzcsODcsMTYzLDg0LDI0OCw5N10sWzExNSwyMCwyMjUsMTkzLDE1LDU5LDUwXV0sICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2xpZW50U2h1ZmZsZUtleUE6IFtbNCw2LDUsMSwyLDAsM10sWzEsMyw2LDQsMiw1LDBdLFsxLDUsMCw0LDMsMiw2XSxbMiw2LDQsMCwzLDUsMV0sWzIsNCwzLDAsNSwxLDZdLFs2LDUsMywxLDQsMCwyXSxbNCw1LDMsMCw2LDEsMl0sWzEsNiwyLDUsNCwzLDBdLFswLDEsNSwyLDMsNiw0XSxbNSwwLDQsMiw2LDEsM11dLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPdXRlckNsaWVudFNodWZmbGVLZXk6IFtbMCw2LDUsNyw5LDIsMyw4LDEsNF1dLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE91dGVyQ2xpZW50U2h1ZmZsZUZ1bmN0aW9uS2V5OiBbWzIsNyw2LDksMyw1LDgsNCwwLDFdXSwgXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE91dGVyQ2xpZW50U2h1ZmZsZU1lZGl1bUtleTogW1s3LDYsNSw0LDAsOCwxLDIsOSwzXV0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25NZWRpdW1LZXk6IFtbNiw3LDEsNSw0LDksMCwzLDgsMl1dLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENsaWVudFNodWZmbGVNZWRpdW1LZXlBOiBbWzEsNiw1LDIsNCwzLDBdLFs2LDAsNCwzLDIsMSw1XSxbMSwwLDIsNiwzLDQsNV0sWzYsNCw1LDIsMSwwLDNdLFs2LDEsMiw0LDMsNSwwXSxbNiw0LDAsMiwzLDEsNV0sWzQsMiwwLDMsMSw2LDVdLFsxLDIsNCw2LDUsMCwzXSxbNSwwLDMsMSwyLDYsNF0sWzYsMywyLDUsMSwwLDRdXSwgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENsaWVudE1lZGl1bUtleTogW1sxODAsODYsMjA2LDIxMCwxMCwxNTYsMTg1XSxbNzIsMjQwLDE3MCwxODUsMTUyLDU3LDE1OF0sWzE2NiwxMjAsMTAzLDQwLDE1OSwyMDUsMTVdLFsxMDUsNzAsMjI0LDIwOCwxNTcsMjYsNjddLFs3MiwxOTMsNDAsMTc3LDk2LDE1OSwxNjBdLFs0NCwxMzMsMzksMjE2LDE2MiwyMTIsNF0sWzM0LDExNCw4MSwxNzQsMjE4LDE0MSwxXSxbMTcxLDIzNCwzMywyNDUsMTQsMTUzLDM4XSxbNjEsMTk4LDUzLDU4LDIxMCwxNzgsMzldLFs2NywyMDcsMTk5LDI0MCwxNTksMjI2LDE4Ml1dXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LCAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNFUlZFUl9EQVJDX0FUVFJJQlVURV9LRVlTOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT3V0ZXJGdW5jdGlvbktleTogW1szNSw1MiwxOSwyNCwzLDI2LDQyLDY3LDEzLDE3LDM3LDcsMzksNjAsNjEsMTUsMzQsMTgsMzYsMjksMjMsMTEsNDEsNiw1OCw5LDEsNDgsNDksNDUsNTEsNDAsNTUsMjAsNDQsMzEsMjgsNSw2OCwyMiw1MCw1NCwyMSwxMiw1Niw4LDI3LDEwLDY0LDMyLDU5LDMzLDM4LDQzLDQ3LDE0LDAsMTYsNDYsMzAsMiw2Niw2Miw2MywyNSw1Myw1Nyw2OSw0LDY1XV0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT3V0ZXJGdW5jdGlvbkZ1bmN0aW9uS2V5OiBbWzI5LDI3LDM3LDgsMTcsMzAsNTQsNTgsMiwyMyw0Nyw1Nyw1MCwxMywyMSw3LDUzLDMyLDI0LDQ0LDIwLDY4LDQyLDQ5LDY1LDYyLDM5LDYzLDQ2LDYxLDE4LDEwLDUsMzgsNTIsMCwxOSw2MCwyOCwzMywyMiw2NywxNSw1OSw1NSw0MSw5LDE0LDYsNDAsMyw0NSw1MSwzMSwxMSwxMiwzNiw2OSwxLDM0LDY2LDM1LDE2LDQzLDU2LDI2LDQ4LDQsMjUsNjRdXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbktleTogW1s2OCw2NiwzMyw2NCwxMCwxMiw5LDIsNSw1OSw0LDE0LDI5LDQ5LDE1LDM4LDM0LDgsNDgsNjAsMjYsMzAsNjMsNTAsNjEsNiwxMyw0NiwzOSw1NSw1Miw0MywzMiwxMSwyNyw1MSw1MywyNSw0MSwyMiwxLDM3LDIxLDY5LDcsNDAsNjIsMjAsNDUsMzEsMTgsMTcsNjUsMywzNSw1NCw1Niw0Nyw2NywxOSwyMyw0NCw1Nyw1OCwxNiwzNiwwLDQyLDI0LDI4XV0sIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE11dHVhbEtleTogW1syNiw2MywyMzRdLFs0OCwzMCwxODVdLFs4Nyw3MCwxMjRdLFsxNDQsMTcyLDEzXSxbMTEwLDE0NCw3XSxbOSw0OSwxMjddLFsxMjgsMjI1LDg0XSxbMjQwLDEzMiwxODZdLFsyMTksMTg3LDZdLFsxODYsMTU2LDEzN10sWzYyLDUzLDE5MV0sWzIwNywxMjUsMTM2XSxbNzIsMTg4LDI1Ml0sWzE3MywyMDAsNDFdLFsyMDEsMTYzLDEyN10sWzg0LDI1MSwyMjZdLFsxMTksMTIxLDkxXSxbMTY2LDI0NSwxNDNdLFs3OSwyMiw5MF0sWzIwMiwyMDIsMzNdLFsyMTIsNjcsMjhdLFsxMjMsMTU4LDU0XSxbMTgsMTcxLDcyXSxbMTY0LDE2MywyNDVdLFsxNzYsMTY5LDgyXSxbNSwyMjcsOTVdLFs5MSw5Nyw1MV0sWzcyLDQ3LDEyMl0sWzI1LDE3NCwxOTFdLFsxODAsMjAzLDc1XSxbNjMsNTYsMTQyXSxbMTgzLDEzOCw2OF0sWzYzLDMxLDIzMV0sWzExNyw0LDE0MF0sWzIwOCwxNywyMjZdLFsyNDQsOTAsMTAyXSxbMTU3LDExMSw3MF0sWzIzOSwyNDIsNjVdLFsyMDIsMTU3LDc2XSxbMTU3LDE3NiwxNV0sWzE2OCw5NSwyMTZdLFsyMTYsMTcwLDIxOV0sWzIxNywxOTksMjQ2XSxbNDEsNjAsNDJdLFsyMDksMjI0LDEwN10sWzE1NiwxODQsMTU3XSxbMTQsMTUwLDcxXSxbMzAsODMsMTg5XSxbMTYxLDExOCwxNzhdLFs4OCwyNSwxMjddLFs1NCwyMDQsMjU1XSxbMjMzLDI0Niw4OF0sWzIyMywyMzMsNTFdLFs3LDk3LDkxXSxbMjM0LDc1LDJdLFs4NiwyNSwxNTJdLFs3NCwyMTQsMjBdLFsxNDksNjIsMjE4XSxbMjE3LDEyLDZdLFsyMSwyNDgsMTQzXSxbMTkzLDI4LDEzMl0sWzE4OSw1NCwxNjFdLFsxNjgsMjUsMTQ0XSxbMTk1LDU4LDEzMF0sWzE5OCw5MywyMDBdLFsxMDcsMzYsMTcwXSxbMTA2LDUwLDEwNF0sWzE4OSwyNDQsNDFdLFs0NSwxMjksMTBdLFsyMzIsMjM5LDIwMV1dLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBGdW5jdGlvbktleTogW1syLDAsMV0sWzIsMCwxXSxbMSwwLDJdLFswLDEsMl0sWzEsMCwyXSxbMCwyLDFdLFswLDIsMV0sWzEsMiwwXSxbMCwyLDFdLFswLDIsMV0sWzEsMiwwXSxbMCwyLDFdLFsyLDEsMF0sWzEsMiwwXSxbMCwyLDFdLFswLDIsMV0sWzEsMiwwXSxbMSwwLDJdLFsxLDAsMl0sWzAsMiwxXSxbMSwyLDBdLFsxLDAsMl0sWzAsMSwyXSxbMCwyLDFdLFsyLDEsMF0sWzIsMCwxXSxbMSwyLDBdLFsxLDAsMl0sWzIsMCwxXSxbMiwxLDBdLFsxLDIsMF0sWzIsMSwwXSxbMiwwLDFdLFswLDEsMl0sWzAsMSwyXSxbMCwyLDFdLFswLDEsMl0sWzIsMSwwXSxbMiwxLDBdLFsxLDIsMF0sWzIsMSwwXSxbMiwxLDBdLFswLDIsMV0sWzEsMiwwXSxbMiwxLDBdLFsxLDAsMl0sWzIsMSwwXSxbMSwyLDBdLFsyLDAsMV0sWzIsMCwxXSxbMSwyLDBdLFsyLDAsMV0sWzIsMSwwXSxbMiwwLDFdLFsyLDEsMF0sWzIsMSwwXSxbMiwwLDFdLFsxLDAsMl0sWzEsMiwwXSxbMSwyLDBdLFsxLDAsMl0sWzAsMiwxXSxbMCwxLDJdLFsyLDEsMF0sWzAsMSwyXSxbMSwyLDBdLFsxLDIsMF0sWzEsMCwyXSxbMiwxLDBdLFsyLDEsMF1dLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENsaWVudFNodWZmbGVLZXlYOiBbWzEsMCwyXSxbMCwyLDFdLFsyLDAsMV0sWzAsMiwxXSxbMSwyLDBdLFswLDIsMV0sWzEsMiwwXSxbMiwwLDFdLFswLDEsMl0sWzEsMCwyXSxbMCwxLDJdLFswLDIsMV0sWzAsMSwyXSxbMCwyLDFdLFswLDEsMl0sWzEsMiwwXSxbMSwwLDJdLFsyLDEsMF0sWzAsMiwxXSxbMSwwLDJdLFsxLDIsMF0sWzAsMiwxXSxbMSwwLDJdLFsxLDIsMF0sWzAsMSwyXSxbMSwyLDBdLFswLDIsMV0sWzIsMCwxXSxbMiwwLDFdLFsyLDEsMF0sWzEsMCwyXSxbMiwwLDFdLFsxLDAsMl0sWzAsMSwyXSxbMCwxLDJdLFswLDIsMV0sWzAsMiwxXSxbMSwwLDJdLFswLDEsMl0sWzIsMCwxXSxbMSwwLDJdLFswLDIsMV0sWzIsMCwxXSxbMiwxLDBdLFsyLDEsMF0sWzAsMSwyXSxbMCwyLDFdLFswLDIsMV0sWzAsMiwxXSxbMiwxLDBdLFswLDEsMl0sWzAsMiwxXSxbMCwyLDFdLFsyLDEsMF0sWzIsMCwxXSxbMCwxLDJdLFswLDIsMV0sWzEsMiwwXSxbMiwxLDBdLFsxLDAsMl0sWzEsMCwyXSxbMCwxLDJdLFswLDEsMl0sWzAsMSwyXSxbMSwwLDJdLFsxLDAsMl0sWzEsMCwyXSxbMSwyLDBdLFswLDIsMV0sWzAsMiwxXV0sICAgXHJcbiAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBNdXR1YWxNZWRpdW1LZXk6IFtbMjEwLDIwOSwyMzhdLFs5NCwxMzgsMjUxXSxbMjQ0LDU3LDEzMV0sWzcyLDEyOSw1MV0sWzEzOCwyMzksOTBdLFs3MCwyMDcsMTI0XSxbNTEsMjI0LDc4XSxbMTMsMjUwLDIyNV0sWzIxMCwyMTYsMTAzXSxbMzMsMTY4LDIwM10sWzg1LDQwLDE4OF0sWzU4LDI0NywxNjJdLFsxNDIsMjE3LDcxXSxbMTI4LDE4NSw4Nl0sWzExLDgzLDIyNF0sWzI1MCwxOTAsMjZdLFszMCwyMjQsNThdLFszNiwxNjYsMzZdLFsxNDMsMjI2LDEwN10sWzY3LDE3OSw3XSxbMTIwLDI0NCwyNDNdLFsxMTUsMTUyLDExMl0sWzUzLDMsMTNdLFsyMzAsMjIwLDIxN10sWzE0Miw2Myw2OV0sWzI1NSwxNDEsMjA4XSxbMTY0LDIsMTE4XSxbMTU4LDE5MiwyMzZdLFs5Miw1Miw3NF0sWzExMSw1MywxNDNdLFsxMTYsMjIxLDEzMV0sWzIxLDYyLDU4XSxbMjUwLDc4LDg3XSxbMzUsMjEyLDI1NF0sWzIxOCwxMTQsMjU1XSxbMTIyLDE2OSwxMzRdLFsyMjYsMTE4LDE4OF0sWzMsMTEzLDJdLFs4MiwxNjYsMjE2XSxbMTk3LDI4LDE5N10sWzE4NCw1Nyw5N10sWzE4OCw5MSwxMDNdLFsxNzEsMTYzLDE2NF0sWzIxMSwyNiwyMDldLFsxNDAsMTc1LDcxXSxbMTAzLDE0Miw1Ml0sWzEyOSwyNDgsMTU1XSxbMTI0LDIxMSwzXSxbMzIsNDEsMTgwXSxbMTI0LDExMSwxNzRdLFsxMzYsMjUzLDEzMF0sWzE3OSwxNjUsNTFdLFsxMjksMTM1LDE4M10sWzQyLDY0LDE5MF0sWzI0NSw1NCwxOTZdLFsxNDEsMTg5LDI0XSxbNDMsMTYsMTRdLFs3NiwxOCwxODZdLFsxMywzNCwxODJdLFs3MiwyLDNdLFs0MSwxODMsMTQ0XSxbMjI4LDY1LDIzOF0sWzYsMjMyLDEwMl0sWzIwLDg3LDE4N10sWzE1LDk4LDU2XSxbMTcxLDE3NCwyMF0sWzIyMCwxMTUsMjJdLFs2NCwxNTQsMTIxXSxbMTQxLDEwOCwxMTFdLFszNSwyMzksNzZdXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPdXRlckZ1bmN0aW9uTWVkaXVtS2V5OiBbWzMwLDYzLDY1LDQzLDQ5LDE4LDM5LDQsMTUsMTIsMjAsMjksNjksNjQsMzYsNTMsNDEsNDIsNjEsNjIsMTMsNTUsMiw1OCw0NCw2NiwwLDUwLDEwLDUxLDQ4LDMyLDUyLDksMzMsNTQsMzEsMyw2OCwyNSwxOSw0Niw1OSwyMyw1NywxNiw1Niw2LDQ3LDY3LDcsMjEsMzUsNDUsOCwzNywxNCwyMiwxNywyNCwyNiwyOCwxMSwzNCw2MCw1LDM4LDEsNDAsMjddXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPdXRlckZ1bmN0aW9uRnVuY3Rpb25NZWRpdW1LZXk6IFtbMTIsMTksNTQsMzAsMTUsOSw0NCw0OSwzLDI4LDIwLDE0LDM2LDY5LDI1LDYxLDYzLDYsNjIsMjEsMSwyLDM1LDQ3LDM5LDIyLDQsMjksNjgsMjQsMjcsNDYsMjYsNjAsMzcsMTEsNTAsMzEsNjYsNjcsNDMsMzgsNDgsMTYsMzMsOCw1Miw3LDQxLDUxLDAsNTYsMzIsNTcsNTgsNDIsNjQsNTMsMTgsMTMsNSw1OSw0NSwzNCwxNywyMywxMCw0MCw2NSw1NV1dLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uTWVkaXVtS2V5OiBbWzQsMzUsMjUsNTgsNjMsNjksNDIsNDQsNjAsMjgsNTksNjEsNDksMjcsMzEsNjgsNDMsNTEsMjEsNiwzMiwxNSwyLDE0LDU1LDUwLDMwLDM3LDM4LDQ1LDIzLDQ3LDAsMTYsNTcsNjIsOCwxMCw0Niw2NSwxLDMsMTEsNDgsMzYsMjYsMTcsNDAsNTIsNjQsNTMsMzMsMzksNSw1Niw2NywxMyw5LDM0LDU0LDE5LDE4LDIwLDI0LDI5LDY2LDIyLDcsNDEsMTJdXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBGdW5jdGlvbk1lZGl1bUtleTogW1swLDIsMV0sWzIsMCwxXSxbMiwxLDBdLFsxLDAsMl0sWzIsMSwwXSxbMiwwLDFdLFsyLDAsMV0sWzAsMSwyXSxbMSwyLDBdLFsyLDEsMF0sWzIsMCwxXSxbMCwyLDFdLFsxLDAsMl0sWzAsMSwyXSxbMCwyLDFdLFsxLDAsMl0sWzIsMSwwXSxbMiwwLDFdLFsyLDAsMV0sWzEsMiwwXSxbMSwyLDBdLFsyLDAsMV0sWzEsMiwwXSxbMSwwLDJdLFswLDIsMV0sWzEsMCwyXSxbMCwxLDJdLFsyLDAsMV0sWzIsMCwxXSxbMiwwLDFdLFsyLDEsMF0sWzIsMSwwXSxbMCwxLDJdLFswLDIsMV0sWzIsMSwwXSxbMiwxLDBdLFsyLDEsMF0sWzEsMCwyXSxbMiwxLDBdLFsyLDAsMV0sWzEsMiwwXSxbMCwyLDFdLFswLDEsMl0sWzAsMSwyXSxbMiwxLDBdLFsyLDAsMV0sWzAsMSwyXSxbMiwwLDFdLFswLDEsMl0sWzAsMiwxXSxbMCwxLDJdLFswLDEsMl0sWzEsMCwyXSxbMCwyLDFdLFswLDEsMl0sWzEsMiwwXSxbMSwwLDJdLFsxLDAsMl0sWzIsMCwxXSxbMCwxLDJdLFsyLDEsMF0sWzAsMiwxXSxbMiwxLDBdLFsyLDAsMV0sWzAsMiwxXSxbMiwwLDFdLFsyLDAsMV0sWzIsMSwwXSxbMiwwLDFdLFswLDEsMl1dLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENsaWVudFNodWZmbGVNZWRpdW1LZXlYOiBbWzIsMCwxXSxbMiwwLDFdLFswLDEsMl0sWzIsMSwwXSxbMSwyLDBdLFswLDIsMV0sWzIsMSwwXSxbMSwwLDJdLFsxLDAsMl0sWzEsMiwwXSxbMSwwLDJdLFswLDEsMl0sWzAsMSwyXSxbMSwyLDBdLFswLDEsMl0sWzAsMSwyXSxbMiwxLDBdLFsyLDAsMV0sWzIsMSwwXSxbMSwwLDJdLFsyLDAsMV0sWzIsMCwxXSxbMSwyLDBdLFsyLDAsMV0sWzEsMiwwXSxbMiwxLDBdLFsyLDEsMF0sWzEsMCwyXSxbMiwwLDFdLFsyLDEsMF0sWzEsMCwyXSxbMiwwLDFdLFsyLDEsMF0sWzIsMCwxXSxbMiwwLDFdLFswLDEsMl0sWzIsMCwxXSxbMSwyLDBdLFsxLDIsMF0sWzIsMCwxXSxbMSwyLDBdLFswLDIsMV0sWzIsMSwwXSxbMCwxLDJdLFsyLDEsMF0sWzAsMiwxXSxbMCwxLDJdLFsxLDAsMl0sWzEsMiwwXSxbMCwyLDFdLFswLDEsMl0sWzAsMiwxXSxbMCwxLDJdLFsyLDEsMF0sWzAsMSwyXSxbMiwxLDBdLFswLDEsMl0sWzEsMiwwXSxbMSwyLDBdLFsyLDEsMF0sWzAsMSwyXSxbMCwyLDFdLFsyLDEsMF0sWzEsMiwwXSxbMSwwLDJdLFsyLDAsMV0sWzAsMSwyXSxbMiwwLDFdLFswLDEsMl0sWzEsMCwyXV0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT3V0ZXJQb3NpdGlvblNodWZmbGVNZWRpdW1LZXk6IFtbNDIsNTYsNDUsMTMsNjEsNDYsMzksMzEsMTYsNjMsMzUsMjIsMjUsMzIsNDksOSw1LDAsNTgsNTUsNDAsMTksMjMsNjIsNjUsNTEsMSw1OSwxOCwzMCw0OCw2OSw2NCwyNCwxNywzNCw2LDUwLDY2LDU3LDM4LDYwLDQsMjEsMjcsNjgsNDMsMjgsMzYsMzcsNyw0NCwxMSwzLDUyLDIsMjAsMTIsNTQsNDEsMjYsMzMsNTMsOCwxMCwxNCw0NywyOSwxNSw2N11dLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE91dGVyUG9zaXRpb25TaHVmZmxlRnVuY3Rpb25NZWRpdW1LZXk6IFtbNiwzNiwxNSw1NCw0NSw5LDY5LDgsMTMsNDEsMTIsMiwzMCwzMSw1Nyw1MCwyOCw0MCwyNiwzNyw2NCw0OCwxOSw0NywyNCw1OCw2MywzMiwxOCw1OSwxMSw1NSwzNSw1Myw0Niw2OCwzOCw0NCwwLDcsMSwzOSwxMCwxNCwyOSwyMCw2NiwxNiw0OSw1LDU2LDQsMzMsMjEsNjEsMTcsNjcsNjIsNjAsMjcsNjUsMjMsMjUsNTIsMywyMiwzNCw0Miw1MSw0M11dLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE91dGVyUG9zaXRpb25GdW5jdGlvbk1lZGl1bUtleTogW1syNCw0Niw1MywyMSwyLDQxLDQzLDAsMjAsMTYsMyw1MSw0NywxMywxOSw2MywzOSw2MiwxNyw2NCw1Miw2MSwzNiwzNywyOSwzNCwzMiw1NSw0OCwyNSw2NywxNCw3LDE1LDU0LDIzLDQyLDY1LDYsNDUsNTcsMjgsMzUsNDQsNjgsMTIsNjksNTAsNjYsMjYsMTgsMjIsMzAsNTYsMjcsNTksMzEsMTEsNCw0MCwzMywxMCw5LDgsNjAsMSw1LDU4LDQ5LDM4XV0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUG9zaXRpb25GdW5jdGlvbk1lZGl1bUtleTogW1syLDAsMV0sWzEsMiwwXSxbMCwxLDJdLFsxLDAsMl0sWzEsMiwwXSxbMCwxLDJdLFsyLDEsMF0sWzEsMCwyXSxbMSwwLDJdLFswLDEsMl0sWzEsMCwyXSxbMiwxLDBdLFsyLDAsMV0sWzAsMiwxXSxbMiwxLDBdLFswLDEsMl0sWzEsMiwwXSxbMiwxLDBdLFswLDEsMl0sWzIsMSwwXSxbMSwwLDJdLFswLDEsMl0sWzIsMSwwXSxbMCwxLDJdLFsyLDEsMF0sWzIsMSwwXSxbMSwwLDJdLFsxLDIsMF0sWzIsMCwxXSxbMSwyLDBdLFswLDEsMl0sWzEsMCwyXSxbMSwwLDJdLFswLDIsMV0sWzAsMiwxXSxbMiwwLDFdLFswLDEsMl0sWzIsMCwxXSxbMCwxLDJdLFsyLDAsMV0sWzAsMiwxXSxbMSwyLDBdLFswLDIsMV0sWzAsMiwxXSxbMSwwLDJdLFsxLDAsMl0sWzEsMiwwXSxbMSwwLDJdLFswLDIsMV0sWzEsMCwyXSxbMiwwLDFdLFsxLDAsMl0sWzIsMCwxXSxbMSwwLDJdLFsxLDIsMF0sWzIsMCwxXSxbMiwxLDBdLFswLDEsMl0sWzAsMSwyXSxbMSwwLDJdLFsxLDIsMF0sWzAsMiwxXSxbMCwxLDJdLFsxLDAsMl0sWzEsMCwyXSxbMSwwLDJdLFsyLDEsMF0sWzAsMiwxXSxbMiwwLDFdLFsyLDAsMV1dLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBvc2l0aW9uU2h1ZmZsZU1lZGl1bUtleTogW1swLDEsMl0sWzIsMCwxXSxbMiwxLDBdLFsyLDAsMV0sWzAsMiwxXSxbMiwxLDBdLFswLDEsMl0sWzEsMiwwXSxbMCwxLDJdLFswLDIsMV0sWzAsMSwyXSxbMCwyLDFdLFsyLDEsMF0sWzIsMCwxXSxbMiwxLDBdLFsyLDEsMF0sWzAsMiwxXSxbMCwxLDJdLFsyLDAsMV0sWzAsMiwxXSxbMCwyLDFdLFsyLDEsMF0sWzEsMiwwXSxbMiwxLDBdLFsyLDEsMF0sWzAsMSwyXSxbMiwwLDFdLFsyLDAsMV0sWzIsMCwxXSxbMiwxLDBdLFsyLDAsMV0sWzAsMiwxXSxbMCwxLDJdLFsyLDAsMV0sWzIsMCwxXSxbMSwyLDBdLFsxLDAsMl0sWzAsMSwyXSxbMCwxLDJdLFsyLDEsMF0sWzIsMSwwXSxbMCwyLDFdLFswLDIsMV0sWzIsMSwwXSxbMiwxLDBdLFsyLDEsMF0sWzIsMCwxXSxbMiwxLDBdLFsyLDEsMF0sWzEsMiwwXSxbMCwyLDFdLFsxLDAsMl0sWzAsMSwyXSxbMiwwLDFdLFsyLDAsMV0sWzEsMiwwXSxbMSwwLDJdLFsxLDAsMl0sWzEsMCwyXSxbMiwxLDBdLFswLDEsMl0sWzIsMCwxXSxbMiwxLDBdLFsyLDAsMV0sWzEsMCwyXSxbMCwxLDJdLFsxLDIsMF0sWzEsMCwyXSxbMiwxLDBdLFswLDIsMV1dLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPdXRlclNlcnZlclNodWZmbGVLZXk6IFtbMjYsNTIsNTgsMjcsMzMsMzYsMzgsNTEsNjcsNDMsMzUsNDIsNjQsNjIsMywzNywxMCwxOSw2NSwxOCw2Myw1MywzOSw1Nyw4LDUsNyw0MCwxMiwyNCwzNCw2OCw2Niw5LDExLDQ3LDU5LDQ2LDQxLDI5LDYwLDYsMjgsMTMsMCwyMiwxNiwxNCwxNSwyLDIzLDQ5LDE3LDQsNTYsNTAsMjEsMjUsMzAsNDgsMSw2OSwyMCw2MSw1NSwzMSw1NCw0NSw0NCwzMl1dLCAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU2VydmVyS2V5OiBbWzYsMTcsNzFdLFsxNDUsNjYsODRdLFsxMTUsMjA5LDE3N10sWzIwLDE0LDE4OV0sWzc0LDIyMyw0OF0sWzE4Niw4MCwyNDFdLFsyMjgsMTU3LDc4XSxbOTEsNTAsMjQyXSxbOTgsMTUyLDEzNV0sWzE0NSwxMjQsMTMwXSxbMjMyLDEwOCwxNTldLFswLDExMSwxNTddLFszLDEyLDM5XSxbMTQzLDQ0LDE1NV0sWzIyNiwxMzksNTFdLFsyMTMsMjE3LDU2XSxbOTUsMjMsMjQ5XSxbMTUzLDMsMjIzXSxbMTQyLDYyLDEyXSxbMTcyLDU1LDEwN10sWzExMCwyNTQsMjQzXSxbMzAsNzgsNzJdLFs2MywyMzUsMTI4XSxbNTYsMTc2LDI1XSxbMCwxNjQsODRdLFszMSwxMTMsMjQwXSxbMTIzLDkwLDE1OF0sWzE1NCw0MiwyNTRdLFsxMjcsNDYsMTZdLFsxMjEsMTkwLDE5MF0sWzIyMiwxMzAsMjM0XSxbMjE2LDg0LDM2XSxbMjI5LDU3LDE4OV0sWzE1Miw1OSwxNjddLFsxOTUsMjAsNTJdLFsxNjgsNDksMjZdLFsxNDUsNywyMDRdLFsxOCwxMTUsMTI4XSxbMzQsMzIsMTk2XSxbMTQ2LDI1MywyNTNdLFsxMzQsMzEsNDZdLFs1NSwxMSwyMjNdLFsxMjIsMTg5LDE5OV0sWzEzOCwyMTMsMTQ0XSxbMTEyLDQ5LDE0NV0sWzE5MSwxMDQsMTE3XSxbMTIsMTM2LDU0XSxbMjAyLDI0OCw4MV0sWzUwLDE4MSw2MF0sWzE2NSwxMzAsMTI0XSxbMTM5LDE2LDUzXSxbMzUsMTczLDNdLFs4OCwyMDIsNDRdLFs0MywxNjcsMTY0XSxbMjI5LDE5NCwyOV0sWzIzOSwxMCwyNl0sWzIxOSwyNDMsMTk5XSxbMTQwLDEwNywxMDddLFsxMzgsMjUxLDI4XSxbMzksODQsMTk1XSxbMjIwLDE2LDU3XSxbMjQzLDIxOCwyMTFdLFszMiw5NCw3NF0sWzE3NCwxOTMsNl0sWzMxLDg1LDIxNl0sWzE1OSwyMywxNDRdLFsxOSwxMjQsMjI0XSxbNDUsOTMsMTFdLFsxOTksMjQzLDE2NV0sWzI1MCwxNjAsMjUxXV0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU2VydmVyU2h1ZmZsZUtleTogW1sxLDIsMF0sWzIsMCwxXSxbMCwxLDJdLFsxLDIsMF0sWzIsMCwxXSxbMSwwLDJdLFswLDEsMl0sWzIsMSwwXSxbMCwxLDJdLFsyLDAsMV0sWzAsMSwyXSxbMCwxLDJdLFsxLDIsMF0sWzIsMSwwXSxbMCwxLDJdLFswLDEsMl0sWzIsMCwxXSxbMCwyLDFdLFsyLDAsMV0sWzIsMSwwXSxbMSwwLDJdLFswLDEsMl0sWzEsMCwyXSxbMCwyLDFdLFswLDEsMl0sWzEsMiwwXSxbMiwxLDBdLFsyLDAsMV0sWzAsMSwyXSxbMCwxLDJdLFswLDEsMl0sWzAsMSwyXSxbMiwxLDBdLFsyLDEsMF0sWzEsMiwwXSxbMCwyLDFdLFsyLDAsMV0sWzEsMiwwXSxbMiwxLDBdLFswLDEsMl0sWzIsMSwwXSxbMiwxLDBdLFsxLDIsMF0sWzEsMCwyXSxbMSwwLDJdLFsyLDAsMV0sWzAsMiwxXSxbMSwyLDBdLFsyLDAsMV0sWzAsMSwyXSxbMiwwLDFdLFswLDEsMl0sWzEsMCwyXSxbMCwyLDFdLFswLDEsMl0sWzAsMiwxXSxbMCwyLDFdLFsxLDIsMF0sWzIsMSwwXSxbMCwxLDJdLFsyLDEsMF0sWzEsMiwwXSxbMCwyLDFdLFsyLDEsMF0sWzAsMSwyXSxbMCwxLDJdLFswLDEsMl0sWzEsMiwwXSxbMCwyLDFdLFsxLDAsMl1dLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU2VydmVyTWVkaXVtS2V5OiBbWzksODQsMjAzXSxbMjMwLDEyLDk0XSxbMTY0LDMyLDIzM10sWzM0LDE2OCw1N10sWzIyMywxODUsMjZdLFs0NywxNTksMTA2XSxbMjM1LDkzLDE5XSxbNTgsOTAsMTE4XSxbMTg0LDIwLDI0OV0sWzEzOSw4NCwyNTBdLFsyMTgsNDQsNzldLFsyMDEsMTA1LDIyMV0sWzIzOCw3NSwyMjhdLFsxMywxMDcsMjIwXSxbMjAyLDIxNyw0Nl0sWzQ4LDE2MSw4NV0sWzUsMTA1LDE5OF0sWzEyLDE3NiwzNV0sWzE4NiwyMDIsMjA1XSxbMjIyLDExOSwxMzNdLFsxMzksMTIxLDEyNF0sWzEyMywxMzQsMjQ1XSxbMTY1LDEwNSwxNDJdLFsxMzQsNjEsMzhdLFsyNDQsNDUsMTE1XSxbMTg0LDU1LDEzOF0sWzc5LDExNywxNTNdLFsxOTYsODYsNDJdLFs3NCwyOSwyMzddLFsxOTIsNjksMjA3XSxbMTk0LDE4Niw0M10sWzExLDkyLDQ1XSxbMTM5LDIyOCw0XSxbMTA4LDI5LDddLFsxMzAsMTQ4LDI0MV0sWzc1LDk2LDE2Ml0sWzE3MCwyMDMsNjldLFsyMDIsMjAyLDg0XSxbNjEsNTUsMzVdLFs1MywxMDQsMTQyXSxbNzIsMjI0LDE2M10sWzczLDIwNywzXSxbMTQ3LDEzMyw2NV0sWzE0NywxMTEsMjRdLFs4NSwyMDYsMzBdLFs1OSw4LDQ0XSxbMTg5LDEyNiw0OF0sWzY1LDE1NSwzMF0sWzUwLDcsODFdLFsyNTAsOTMsMTYxXSxbMjM3LDEzMCwxMDJdLFs2MywyLDI0M10sWzIyMywxNDksNTNdLFsxNSwyMTQsMjEyXSxbMjQ0LDkyLDgzXSxbMjQ5LDk2LDE5XSxbMjExLDIsMTQwXSxbMjMsMTIxLDU3XSxbODUsMTc1LDY5XSxbMjEyLDIsNzVdLFs1NCwxNjgsMTBdLFszMiwxMDQsMTM2XSxbMTE5LDE0MiwyMDhdLFsyMDcsNzgsNjhdLFsxMTEsMTExLDE4XSxbMTQ4LDE5MSwxOThdLFsyNSw1MywxOTBdLFsxNTMsNjUsMThdLFszLDE5NywxMzNdLFszMiwyMTAsMjI2XV1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBvcnQgZGVmYXVsdCBkYXJjQ29uZmlnOyIsImltcG9ydCBkYXJjQ29tbW9uIGZyb20gJy4vZGFyY0NvbW1vbi5qcyc7XHJcbmltcG9ydCBjb21tb24gZnJvbSAnLi9jb21tb24uanMnO1xyXG5cclxuY29uc3QgcmFuZE1pbiA9IDA7XHJcbmNvbnN0IHJhbmRNYXggPSAyNTU7XHJcblxyXG52YXIgZXBoZW1lcmFsS2V5cyA9IHtcclxuICAgIGdlbmVyYXRlU2hhcmVkSW5zdGFuY2VUcmFuc2xhdGlvbnM6ICh3aWR0aCwgaGVpZ2h0LCBpbnB1dEJsb2NrTGVuZ3RoLCB1cGRhdGUpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBsZXQgc2hhcmVkRXBoZW1lcmFsS2V5c09iaiA9IHtcclxuICAgICAgICAgICAgICAgIE11dHVhbEVwaGVtZXJhbEtleTogZ2V0TmV3RGF0YVRyYW5zbGF0aW9uS2V5KHdpZHRoLCBoZWlnaHQpLCAgICAgICAgICAgICAvL0FkZHMgTXV0dWFsIHRyYW5zbGF0aW9uOyBwcmV2ZW50cyBkaWZmZXJlbnRpYWwgY3J5cHRhbmFseXNpcyBiZXR3ZWVuIFR4IGFuZCBSeFxyXG4gICAgICAgICAgICAgICAgRnVuY3Rpb25FcGhlbWVyYWxLZXk6IGdldE5ld1NodWZmbGVPckZ1bmN0aW9uVHJhbnNsYXRpb25LZXkod2lkdGgsIGhlaWdodCksICAgLy9TZXNzaW9uLVNwZWNpZmljIFRyYW5zbGF0aW9uIEZ1bmN0aW9uOyBJbnN1bGF0ZXMgU2Vzc2lvbnMgZnJvbSBvbiBhbm90aGVyIGluIHRoZSBldmVudCBvZiBPYmZ1c2NhdGVkIEphdmEgU2NyaXB0IGNvbXByb21pc2VcclxuICAgICAgICAgICAgICAgIE91dGVyRnVuY3Rpb25FcGhlbWVyYWxLZXk6IGdldE5ld1NodWZmbGVPckZ1bmN0aW9uVHJhbnNsYXRpb25LZXkoaGVpZ2h0LCAxKSxcclxuICAgICAgICAgICAgICAgIE91dGVyRnVuY3Rpb25GdW5jdGlvbkVwaGVtZXJhbEtleTogZ2V0TmV3U2h1ZmZsZU9yRnVuY3Rpb25UcmFuc2xhdGlvbktleShoZWlnaHQsIDEpLFxyXG4gICAgICAgICAgICAgICAgT3V0ZXJTZXJ2ZXJTaHVmZmxlRnVuY3Rpb25FcGhlbWVyYWxLZXk6IGdldE5ld1NodWZmbGVPckZ1bmN0aW9uVHJhbnNsYXRpb25LZXkoaGVpZ2h0LCAxKSxcclxuICAgICAgICAgICAgICAgIE11dHVhbE1lZGl1bUVwaGVtZXJhbEtleTogZ2V0TmV3RGF0YVRyYW5zbGF0aW9uS2V5KHdpZHRoLCBpbnB1dEJsb2NrTGVuZ3RoKSwgICAvL0FkZHMgTXV0dWFsIHRyYW5zbGF0aW9uOyBwcmV2ZW50cyBkaWZmZXJlbnRpYWwgY3J5cHRhbmFseXNpcyBiZXR3ZWVuIFR4IGFuZCBSeCAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgRnVuY3Rpb25NZWRpdW1FcGhlbWVyYWxLZXk6IGdldE5ld1NodWZmbGVPckZ1bmN0aW9uVHJhbnNsYXRpb25LZXkod2lkdGgsIGlucHV0QmxvY2tMZW5ndGgpLCAgICAgLy9TZXNzaW9uLVNwZWNpZmljIFRyYW5zbGF0aW9uIEZ1bmN0aW9uOyBJbnN1bGF0ZXMgU2Vzc2lvbnMgZnJvbSBvbiBhbm90aGVyIGluIHRoZSBldmVudCBvZiBPYmZ1c2NhdGVkIEphdmEgU2NyaXB0IGNvbXByb21pc2VcclxuICAgICAgICAgICAgICAgIFBvc2l0aW9uRnVuY3Rpb25NZWRpdW1FcGhlbWVyYWxLZXk6IGdldE5ld1NodWZmbGVPckZ1bmN0aW9uVHJhbnNsYXRpb25LZXkod2lkdGgsIGlucHV0QmxvY2tMZW5ndGgpLFxyXG4gICAgICAgICAgICAgICAgT3V0ZXJGdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleTogZ2V0TmV3U2h1ZmZsZU9yRnVuY3Rpb25UcmFuc2xhdGlvbktleShpbnB1dEJsb2NrTGVuZ3RoLCAxKSxcclxuICAgICAgICAgICAgICAgIE91dGVyRnVuY3Rpb25GdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleTogZ2V0TmV3U2h1ZmZsZU9yRnVuY3Rpb25UcmFuc2xhdGlvbktleShpbnB1dEJsb2NrTGVuZ3RoLCAxKSxcclxuICAgICAgICAgICAgICAgIE91dGVyUG9zaXRpb25GdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleTogZ2V0TmV3U2h1ZmZsZU9yRnVuY3Rpb25UcmFuc2xhdGlvbktleShpbnB1dEJsb2NrTGVuZ3RoLCAxKSxcclxuICAgICAgICAgICAgICAgIE91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uTWVkaXVtRXBoZW1lcmFsS2V5OiBnZXROZXdTaHVmZmxlT3JGdW5jdGlvblRyYW5zbGF0aW9uS2V5KGlucHV0QmxvY2tMZW5ndGgsIDEpLFxyXG4gICAgICAgICAgICAgICAgT3V0ZXJQb3NpdGlvblNodWZmbGVGdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleTogZ2V0TmV3U2h1ZmZsZU9yRnVuY3Rpb25UcmFuc2xhdGlvbktleShpbnB1dEJsb2NrTGVuZ3RoLCAxKSxcclxuICAgICAgICAgICAgICAgIFBvc2l0aW9uU2h1ZmZsZU1lZGl1bUVwaGVtZXJhbEtleTogZ2V0TmV3U2h1ZmZsZU9yRnVuY3Rpb25UcmFuc2xhdGlvbktleSh3aWR0aCwgaGVpZ2h0KSxcclxuICAgICAgICAgICAgICAgIE91dGVyUG9zaXRpb25TaHVmZmxlTWVkaXVtRXBoZW1lcmFsS2V5OiBnZXROZXdTaHVmZmxlT3JGdW5jdGlvblRyYW5zbGF0aW9uS2V5KGlucHV0QmxvY2tMZW5ndGgsIDEpLFxyXG4gICAgICAgICAgICAgICAgVG9rZW5VcGRhdGVGdW5jdGlvbkVwaGVtZXJhbEtleTogbnVsbCAgIC8vVXBkYXRlLVNwZWNpZmljIFVwZGF0ZSBUcmFuc2xhdGlvbiBGdW5jdGlvbjsgSW5zdWxhdGVzIFVwZGF0ZXMgZnJvbSBvbiBhbm90aGVyIGluIHRoZSBldmVudCBvZiBPYmZ1c2NhdGVkIEphdmEgU2NyaXB0IGNvbXByb21pc2UgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIGlmICh1cGRhdGUpXHJcbiAgICAgICAgICAgICAgICBzaGFyZWRFcGhlbWVyYWxLZXlzT2JqLlRva2VuVXBkYXRlRnVuY3Rpb25FcGhlbWVyYWxLZXkgPSBnZXROZXdTaHVmZmxlT3JGdW5jdGlvblRyYW5zbGF0aW9uS2V5KHdpZHRoLCBoZWlnaHQpO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHNoYXJlZEVwaGVtZXJhbEtleXNPYmo7XHJcbiAgICAgICAgfSBjYXRjaCAoZXgpIHtcclxuICAgICAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhleCwgXCI3YWM3YzU0NS0xM2NjLTQ0YTctODM1Yi0zM2I1Mzg1YWY0Y2FcIik7XHJcbiAgICAgICAgICAgIHRocm93IGV4O1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBnZW5lcmF0ZVNlcnZlckluc3RhbmNlVHJhbnNsYXRpb25zOiAod2lkdGgsIGhlaWdodCwgaW5wdXRCbG9ja0xlbmd0aCkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCBzZXJ2ZXJFcGhlbWVyYWxLZXlzT2JqID0ge1xyXG4gICAgICAgICAgICAgICAgT3V0ZXJTZXJ2ZXJTaHVmZmxlRXBoZW1lcmFsS2V5OiBnZXROZXdTaHVmZmxlT3JGdW5jdGlvblRyYW5zbGF0aW9uS2V5KGhlaWdodCwgMSksXHJcbiAgICAgICAgICAgICAgICBTZXJ2ZXJFcGhlbWVyYWxLZXk6IGdldE5ld0RhdGFUcmFuc2xhdGlvbktleSh3aWR0aCwgaGVpZ2h0KSxcclxuICAgICAgICAgICAgICAgIFNlcnZlclNodWZmbGVFcGhlbWVyYWxLZXk6IGdldE5ld1NodWZmbGVPckZ1bmN0aW9uVHJhbnNsYXRpb25LZXkod2lkdGgsIGhlaWdodCksXHJcbiAgICAgICAgICAgICAgICBTZXJ2ZXJNZWRpdW1FcGhlbWVyYWxLZXk6IGdldE5ld0RhdGFUcmFuc2xhdGlvbktleSh3aWR0aCwgaW5wdXRCbG9ja0xlbmd0aCkgICAgICAgLy9BZGRzIFNlcnZlci1TaWRlIHRyYW5zbGF0aW9uIGV4Y2x1c2l2ZSB0byB0aGUgU2VydmVyLVNpZGVcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiBzZXJ2ZXJFcGhlbWVyYWxLZXlzT2JqO1xyXG4gICAgICAgIH0gY2F0Y2ggKGV4KSB7XHJcbiAgICAgICAgICAgIGNvbW1vbi5hZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8oZXgsIFwiYTkzN2JlMTQtOGYyNi00YTAzLThjYWYtMDNiNTRhZDkwNGU2XCIpO1xyXG4gICAgICAgICAgICB0aHJvdyBleDtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgZ2VuZXJhdGVDbGllbnRJbnN0YW5jZVRyYW5zbGF0aW9uczogKHdpZHRoLCBoZWlnaHQsIGlucHV0QmxvY2tMZW5ndGgpID0+XHJcbiAgICB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgbGV0IGNsaWVudEVwaGVtZXJhbEtleXNPYmogPSB7XHJcbiAgICAgICAgICAgICAgICBPdXRlckNsaWVudFNodWZmbGVFcGhlbWVyYWxLZXk6IGdldE5ld1NodWZmbGVPckZ1bmN0aW9uVHJhbnNsYXRpb25LZXkoaGVpZ2h0LCAxKSxcclxuICAgICAgICAgICAgICAgIE91dGVyQ2xpZW50U2h1ZmZsZUZ1bmN0aW9uRXBoZW1lcmFsS2V5OiBnZXROZXdTaHVmZmxlT3JGdW5jdGlvblRyYW5zbGF0aW9uS2V5KGhlaWdodCwgMSksXHJcbiAgICAgICAgICAgICAgICBDbGllbnRFcGhlbWVyYWxLZXk6IGdldE5ld0RhdGFUcmFuc2xhdGlvbktleSh3aWR0aCwgaGVpZ2h0KSxcclxuICAgICAgICAgICAgICAgIENsaWVudFNodWZmbGVFcGhlbWVyYWxLZXlBOiBnZXROZXdTaHVmZmxlT3JGdW5jdGlvblRyYW5zbGF0aW9uS2V5KHdpZHRoLCBoZWlnaHQpLFxyXG5cclxuICAgICAgICAgICAgICAgIE91dGVyQ2xpZW50U2h1ZmZsZU1lZGl1bUVwaGVtZXJhbEtleTogZ2V0TmV3U2h1ZmZsZU9yRnVuY3Rpb25UcmFuc2xhdGlvbktleShoZWlnaHQsIDEpLFxyXG4gICAgICAgICAgICAgICAgT3V0ZXJDbGllbnRTaHVmZmxlRnVuY3Rpb25NZWRpdW1FcGhlbWVyYWxLZXk6IGdldE5ld1NodWZmbGVPckZ1bmN0aW9uVHJhbnNsYXRpb25LZXkoaGVpZ2h0LCAxKSxcclxuICAgICAgICAgICAgICAgIENsaWVudFNodWZmbGVNZWRpdW1FcGhlbWVyYWxLZXlBOiBnZXROZXdTaHVmZmxlT3JGdW5jdGlvblRyYW5zbGF0aW9uS2V5KHdpZHRoLCBoZWlnaHQpLFxyXG4gICAgICAgICAgICAgICAgQ2xpZW50TWVkaXVtRXBoZW1lcmFsS2V5OiBnZXROZXdEYXRhVHJhbnNsYXRpb25LZXkod2lkdGgsIGlucHV0QmxvY2tMZW5ndGgpICAgICAgICAgLy9BZGRzIENsaWVudC1TaWRlIHRyYW5zbGF0aW9uIGV4Y2x1c2l2ZSB0byB0aGUgQ2xpZW50LVNpZGVcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiBjbGllbnRFcGhlbWVyYWxLZXlzT2JqO1xyXG4gICAgICAgIH0gY2F0Y2ggKGV4KSB7XHJcbiAgICAgICAgICAgIGNvbW1vbi5hZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8oZXgsIFwiNjQzOGJkZWEtMjZiZC00MWNmLThhMDAtZmQ1ZDcyN2Y0YjAwXCIpO1xyXG4gICAgICAgICAgICB0aHJvdyBleDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG59O1xyXG5cclxuZnVuY3Rpb24gZ2V0TmV3U2h1ZmZsZU9yRnVuY3Rpb25UcmFuc2xhdGlvbktleSh3aWR0aCwgaGVpZ2h0KVxyXG57XHJcbiAgICB0cnkge1xyXG4gICAgICAgIGxldCBkYXRhID0gbmV3IEFycmF5KGhlaWdodCk7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGggPSAwOyBoIDwgaGVpZ2h0OyBoKyspXHJcbiAgICAgICAgICAgIGRhdGFbaF0gPSBkYXJjQ29tbW9uLnJhbmRVbmlxdWVJbnQod2lkdGgsIHJhbmRNaW4sIHdpZHRoKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGRhdGE7XHJcbiAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgIGNvbW1vbi5hZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8oZXgsIFwiMmQwNjI2M2ItYmMyYi00OTFiLTg4YmEtZWY5NjljMTNjYjJmXCIpO1xyXG4gICAgICAgIHRocm93IGV4O1xyXG4gICAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBnZXROZXdEYXRhVHJhbnNsYXRpb25LZXkod2lkdGgsIGhlaWdodCkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgICBsZXQgZGF0YSA9IG5ldyBBcnJheShoZWlnaHQpO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBoID0gMDsgaCA8IGhlaWdodDsgaCsrKVxyXG4gICAgICAgICAgICBkYXRhW2hdID0gZGFyY0NvbW1vbi5yYW5kVW5pcXVlSW50KHdpZHRoLCByYW5kTWluLCByYW5kTWF4ICsgMSk7XHJcblxyXG4gICAgICAgIHJldHVybiBkYXRhO1xyXG4gICAgfSBjYXRjaCAoZXgpIHtcclxuICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcImJmMjQ2YmM2LTc4YWItNDYxOC1hODMyLTQ2YWRjODlhMGY4NFwiKTtcclxuICAgICAgICB0aHJvdyBleDtcclxuICAgIH1cclxufVxyXG5cclxuXHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZXBoZW1lcmFsS2V5czsiLCJpbXBvcnQgY29tbW9uIGZyb20gJy4vY29tbW9uJztcclxuaW1wb3J0IGRhcmNDb25maWcgZnJvbSAnLi9kYXJjQ29uZmlnJztcclxuXHJcbmxldCBfY29uZmlnID0gbnVsbDtcclxuXHJcbmNvbnN0IGtleXBhZCA9XHJcbntcclxuICAgIHJlbW92ZUxhc3RFbnRyeTogKCkgPT4ge1xyXG4gICAgICAgIGtleXBhZC5zZWxlY3RlZEtleU9yZGluYWwucG9wKCk7XHJcbiAgICAgICAgZmlyZUNoYW5nZWRFdmVudCgpO1xyXG4gICAgfSwgIFxyXG4gICAgc2V0Q29uZmlnOiAoY29uZmlnKSA9PiB7IF9jb25maWcgPSBjb25maWc7IH0sXHJcbiAgICBuS29kQ2hhbmdlZDogbnVsbCxcclxuICAgIHNlbGVjdGVkS2V5T3JkaW5hbDogW10sXHJcbiAgICBjdXJyZW50TktvZExlbmd0aDogKCkgPT4ga2V5cGFkLnNlbGVjdGVkS2V5T3JkaW5hbC5sZW5ndGgsXHJcbiAgICAvLyAgUkVUVVJOIEhUTUwgS0VZUEFEXHJcbiAgICBnZXRLZXlwYWQ6IGFzeW5jIChhdHRyaWJ1dGVEYXJjRGF0YSwgdGVtcGxhdGVJZGVudGlmaWVyLCBhdHRyaWJ1dGVNYXApID0+IHsgICAgICAgXHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCBrZXlzID0gW107XHJcbiAgICAgICAgICAgIGxldCBjb3B5ID0gYXR0cmlidXRlRGFyY0RhdGE7XHJcbiAgICAgICAgICAgIGxldCBhdHRyaWJ1dGVQb3NpdGlvbkRhdGEgPSBuZXcgQXJyYXkoKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChjb3B5Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgIGxldCBwb3NpdGlvbkluZGV4ID0gZGFyY0NvbmZpZy5BVFRSSUJVVEVfVkFMVUVTLmluZGV4T2YoYXR0cmlidXRlTWFwW2NvcHlbMF1bZGFyY0NvbmZpZy5QT1NJVElPTl9BVFRSSUJVVEVfT1JESU5BTF9QT1NJVElPTl1dKTtcclxuICAgICAgICAgICAgICAgIGxldCB3aWR0aCA9IGNvcHlbMF0ubGVuZ3RoO1xyXG4gICAgICAgICAgICAgICAgbGV0IGhlaWdodCA9IGNvcHkubGVuZ3RoO1xyXG4gICAgICAgICAgICAgICAgbGV0IHBvc2l0aW9uQXJyYXlTdGFydEluZGV4O1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCB3aWR0aDsgeCsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRBbHBoYWJldFBvc2l0aW9uID0gaGVpZ2h0ICogeDtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRBbHBoYWJldFBvc2l0aW9uIDw9IHBvc2l0aW9uSW5kZXggJiYgcG9zaXRpb25JbmRleCA8IGN1cnJlbnRBbHBoYWJldFBvc2l0aW9uICsgaGVpZ2h0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uQXJyYXlTdGFydEluZGV4ID0gY3VycmVudEFscGhhYmV0UG9zaXRpb247XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBhdHRyaWJ1dGVQb3NpdGlvbkRhdGEgPSBkYXJjQ29uZmlnLkFUVFJJQlVURV9WQUxVRVMuc2xpY2UocG9zaXRpb25BcnJheVN0YXJ0SW5kZXgsIHBvc2l0aW9uQXJyYXlTdGFydEluZGV4ICsgaGVpZ2h0KTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCBjb3B5Lmxlbmd0aDsgeCsrKSAvL2xvb3AgdGhyb3VnaCBudW1iZXIgb2Yga2V5c1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNvcHkubGVuZ3RoOyBpKyspIC8vVXNlIGluZGV4IG9mIG91dGVyIGxvb3AgdG8gYWRkIGNvcnJlY3Qga2V5IGJ5IG1hdGNoaW5nIHRvIHRoZSBjb3JyZXNwb25kaW5nIGF0dHJpYnV0ZSBwb3NpdGlvblxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvcHlbaV0ub2xkSW5kZXggPSBpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChhdHRyaWJ1dGVNYXBbY29weVtpXVtkYXJjQ29uZmlnLlBPU0lUSU9OX0FUVFJJQlVURV9PUkRJTkFMX1BPU0lUSU9OXV0gPT09IGF0dHJpYnV0ZVBvc2l0aW9uRGF0YVt4XSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXlzLnB1c2goY29weVtpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBsZXQgaHRtbCA9IFwiXCI7XHJcbiAgICAgICAgICAgIGxldCBodG1sVGVtcGxhdGUgPSBhd2FpdCBjb21tb24uZ2V0KF9jb25maWcuSFRNTF9URU1QTEFURV9QQVRILnJlcGxhY2UoLyhcXCR7dGVtcGxhdGVJZGVudGlmaWVyfSkrL2csIHRlbXBsYXRlSWRlbnRpZmllcikpO1xyXG5cclxuICAgICAgICAgICAgLy8gIFBSRVAgUE9TSVRJT04gUkVQTEFDRU1FTlRTXHJcbiAgICAgICAgICAgIGxldCBhdHRyaWJ1dGVTZXRPbmUgPSBcIlwiO1xyXG4gICAgICAgICAgICBsZXQgYXR0cmlidXRlU2V0VHdvID0gXCJcIjtcclxuICAgICAgICAgICAgbGV0IGF0dHJpYnV0ZVNldFRocmVlID0gXCJcIjtcclxuICAgICAgICAgICAgbGV0IGF0dHJpYnV0ZVNldEZvdXIgPSBcIlwiO1xyXG4gICAgICAgICAgICBsZXQgYXR0cmlidXRlU2V0Rml2ZSA9IFwiXCI7XHJcbiAgICAgICAgICAgIGxldCBhdHRyaWJ1dGVTZXRTaXggPSBcIlwiO1xyXG4gICAgICAgICAgICBsZXQgYXR0cmlidXRlU2V0U2V2ZW4gPSBcIlwiO1xyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBrZXlzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgMiwgNywgNCwgNiwgMywgNSwgMVxyXG4gICAgICAgICAgICAgICAgLy8gIDAsIDEsIDIsIDMsIDQsIDUsIDZcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwga2V5c1tpXS5sZW5ndGg7IGorKykge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBhdHRyaWJ1dGUgPSBrZXlzW2ldW2pdO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKGopIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAwOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cmlidXRlU2V0T25lID0gYXR0cmlidXRlTWFwW2F0dHJpYnV0ZV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cmlidXRlU2V0VHdvID0gYXR0cmlidXRlTWFwW2F0dHJpYnV0ZV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAyOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cmlidXRlU2V0VGhyZWUgPSBhdHRyaWJ1dGVNYXBbYXR0cmlidXRlXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDM6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyaWJ1dGVTZXRGb3VyID0gYXR0cmlidXRlTWFwW2F0dHJpYnV0ZV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSA0OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cmlidXRlU2V0Rml2ZSA9IGF0dHJpYnV0ZU1hcFthdHRyaWJ1dGVdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgNTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJpYnV0ZVNldFNpeCA9IGF0dHJpYnV0ZU1hcFthdHRyaWJ1dGVdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgNjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJpYnV0ZVNldFNldmVuID0gYXR0cmlidXRlTWFwW2F0dHJpYnV0ZV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGkgPT09IDAgfHwgaSA9PT0gMyB8fCBpID09PSA2KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbCArPSAnPGRpdiBjbGFzcz1cInJvdyBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBtdC0yXCI+JztcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoaSA9PT0gOSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGh0bWwgKz0gJzxkaXYgY2xhc3M9XCJyb3cganVzdGlmeS1jb250ZW50LWFyb3VuZCBtdC0yXCI+JztcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBodG1sICs9IGh0bWxUZW1wbGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC8oXFwke2luZGV4ZXJ9KSsvZywga2V5c1tpXS5vbGRJbmRleClcclxuICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvKFxcJHthdHRyaWJ1dGVTZXRPbmV9KSsvZywgYXR0cmlidXRlU2V0T25lKVxyXG4gICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC8oXFwke2F0dHJpYnV0ZVNldFR3b30pKy9nLCBhdHRyaWJ1dGVTZXRUd28pXHJcbiAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoLyhcXCR7YXR0cmlidXRlU2V0VGhyZWV9KSsvZywgYXR0cmlidXRlU2V0VGhyZWUpXHJcbiAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoLyhcXCR7YXR0cmlidXRlU2V0Rm91cn0pKy9nLCBhdHRyaWJ1dGVTZXRGb3VyKVxyXG4gICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC8oXFwke2F0dHJpYnV0ZVNldEZpdmV9KSsvZywgYXR0cmlidXRlU2V0Rml2ZSlcclxuICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvKFxcJHthdHRyaWJ1dGVTZXRTaXh9KSsvZywgYXR0cmlidXRlU2V0U2l4KVxyXG4gICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC8oXFwke2F0dHJpYnV0ZVNldFNldmVufSkrL2csIGF0dHJpYnV0ZVNldFNldmVuKTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoaSA9PT0gMiB8fCBpID09PSA1IHx8IGkgPT09IDggfHwgaSA9PT0gOSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGh0bWwgKz0gXCI8L2Rpdj5cIjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgbGV0IGludGVyZmFjZVBsYWNlaG9sZGVyRWxlbWVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKF9jb25maWcuSU5URVJGQUNFX0hUTUxfUExBQ0VIT0xERVJfSUQpO1xyXG4gICAgICAgICAgICBpZiAoaW50ZXJmYWNlUGxhY2Vob2xkZXJFbGVtZW50KSB7XHJcbiAgICAgICAgICAgICAgICBpbnRlcmZhY2VQbGFjZWhvbGRlckVsZW1lbnQuaW5uZXJIVE1MID0gaHRtbDtcclxuICAgICAgICAgICAgICAgIHZhciBjbGlja2FibGVLZXlzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi5zcXVhcmVcIik7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNsaWNrYWJsZUtleXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2NsaWNrYWJsZUtleXNbaV0ucmVtb3ZlRXZlbnRMaXN0ZW5lcignY2xpY2snLCBjbGlja0tleSk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2xpY2thYmxlS2V5c1tpXS5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgY2xpY2tLZXkpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAvL2NsaWNrYWJsZUtleXNbaV0ucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywga2V5RG93bik7XHJcbiAgICAgICAgICAgICAgICAgICAgY2xpY2thYmxlS2V5c1tpXS5hZGRFdmVudExpc3RlbmVyKFwibW91c2Vkb3duXCIsIG1vdXNlZG93bik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcImI1OGQ2MmQxLTdlYmYtNGViNi1iZTA3LTMyZDM0NTY0ZWI5ZFwiKTtcclxuICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGNsZWFyOiBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAga2V5cGFkLnNlbGVjdGVkS2V5T3JkaW5hbCA9IFtdO1xyXG4gICAgICAgIGZpcmVDaGFuZ2VkRXZlbnQoKTtcclxuICAgIH1cclxuICBcclxufTtcclxuXHJcbmZ1bmN0aW9uIGZpcmVDaGFuZ2VkRXZlbnQoKSB7XHJcbiAgICBpZiAoa2V5cGFkLm5Lb2RDaGFuZ2VkKSB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAga2V5cGFkLm5Lb2RDaGFuZ2VkKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhdGNoeyB9IC8vc3dhbGxvdyBlcnJvclxyXG4gICAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBtb3VzZWRvd24oZSkgeyAgLy8gIFRIRSBLRVkgQ0xJQ0tTLiBXRSBET04nVCBMRVQgSU1QTEVNRU5UQVRJT04gSEFWRSBBQ0NFUyBUTyBLRVkgQ0xJQ0sgQkVDQVVTRSBPRiBTRU5TSVRJVklUWS5cclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIHJldHVybiBmYWxzZTtcclxufVxyXG5cclxuZnVuY3Rpb24gY2xpY2tLZXkgIChlKSB7ICAvLyAgVEhFIEtFWSBDTElDS1MuIFdFIERPTidUIExFVCBJTVBMRU1FTlRBVElPTiBIQVZFIEFDQ0VTIFRPIEtFWSBDTElDSyBCRUNBVVNFIE9GIFNFTlNJVElWSVRZLlxyXG4gICAgdHJ5IHtcclxuICAgICAgICBpZiAoa2V5cGFkLnNlbGVjdGVkS2V5T3JkaW5hbC5sZW5ndGggPCBfY29uZmlnLk1BWF9OS09EX0xFTkdUSCkge1xyXG4gICAgICAgICAgICB2YXIgaW5kZXhlciA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0LmluZGV4ZXI7XHJcbiAgICAgICAgICAgIGtleXBhZC5zZWxlY3RlZEtleU9yZGluYWwucHVzaChpbmRleGVyKTtcclxuXHJcbiAgICAgICAgICAgIGZpcmVDaGFuZ2VkRXZlbnQoKTtcclxuICAgICAgICB9XHJcbiAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgIGNvbW1vbi5hZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8oZXgsIFwiOWNkYzYyODQtYTczOS00ZmNjLTkxZGQtOGJhNWM5MGU3YmE1XCIpO1xyXG4gICAgICAgIHRocm93IGV4O1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBrZXlwYWQ7IiwiLyoqXHJcbiAqIFRoZSBuS29kZSBBUElcclxuICogQG1vZHVsZSBuS29kZVxyXG4gKi9cclxuXHJcbmltcG9ydCBjb21tb24gZnJvbSAnLi9jb21tb24nO1xyXG5pbXBvcnQgZGFyY0NvbmZpZyBmcm9tICcuL2RhcmNDb25maWcnO1xyXG5pbXBvcnQgS2V5cGFkIGZyb20gJy4va2V5cGFkJztcclxuaW1wb3J0IGVwaGVtZXJhbEtleXMgZnJvbSAnLi9lcGhlbWVyYWxLZXlzJztcclxuaW1wb3J0IGNsaWVudE1lcmdlIGZyb20gJy4vY2xpZW50TWVyZ2UnO1xyXG5pbXBvcnQgY2xpZW50VHggZnJvbSAnLi9jbGllbnRUeCc7XHJcbmltcG9ydCBjbGllbnRSeCBmcm9tICcuL2NsaWVudFJ4JztcclxuaW1wb3J0IHNlcnZlclR4IGZyb20gJy4vc2VydmVyVHgnO1xyXG5pbXBvcnQgc2VydmVyUnggZnJvbSAnLi9zZXJ2ZXJSeCc7XHJcbmltcG9ydCBkYXJjQ29tbW9uIGZyb20gJy4vZGFyY0NvbW1vbi5qcyc7XHJcbmNvbnN0IEFUVFJJQlVURV9XSURUSCA9IDM7XHJcbmNvbnN0IEFUVFJJQlVURV9IRUlHSFQgPSA3MDtcclxuXHJcbmxldCBfa2V5cGFkID0gS2V5cGFkO1xyXG5sZXQgX2ludGVyZmFjZURhdGEgPSB7fTtcclxubGV0IF9jcmVhdGVOS29kRGF0YSA9IHt9O1xyXG5sZXQgX2NvbmZpZyA9IG51bGw7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBjcmVhdGVJbnRlcmZhY2UodXNlck5hbWUgPSBudWxsLCB0ZW1wbGF0ZUlkZW50aWZpZXIsIGZpbmdlcnByaW50LCBhZGRpdGlvbmFsRGF0YSkgeyAgICAvLyAgQ1JFQVRFUyBOS09EIElOVEVSRkFDRVxyXG4gICAgdHJ5IHtcclxuICAgICAgICBfa2V5cGFkLmNsZWFyKCk7XHJcbiAgICAgICAgY29uc3QgdXJsID0gdXNlck5hbWUgIT09IG51bGwgPyBgJHtfY29uZmlnLkFQSV9VUkx9L2FwaS9ua29kL2dldExvZ2luSW50ZXJmYWNlYCA6IGAke19jb25maWcuQVBJX1VSTH0vYXBpL25rb2QvZ2VuZXJhdGVJbnRlcmZhY2VgO1xyXG5cclxuICAgICAgICBsZXQgZEFSQ1BoYXNlMUF0dHJpYnV0ZURhdGEgPSBnZXRBdHRyaWJ1dGVEYXRhRm9yVHJhbnNtaXNzaW9uKCk7XHJcblxyXG4gICAgICAgIC8vX2ludGVyZmFjZURhdGEgPSBhd2FpdCBjb21tb24uZ2V0KHVybCwgdHJ1ZSk7XHJcbiAgICAgICAgbGV0IHJlc3BvbnNlID0gYXdhaXQgY29tbW9uLnBvc3QoXHJcbiAgICAgICAgICAgIHVybCxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgXCJDbGllbnRJZFwiOiBfY29uZmlnLkNMSUVOVF9JRCxcclxuICAgICAgICAgICAgICAgIFwiVXNlck5hbWVcIjogdXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgICBcIkZpbmdlcnByaW50XCI6IGZpbmdlcnByaW50LFxyXG4gICAgICAgICAgICAgICAgXCJBdHRyaWJ1dGVQMURBUkNEYXRhXCI6IGRBUkNQaGFzZTFBdHRyaWJ1dGVEYXRhLFxyXG4gICAgICAgICAgICAgICAgXCJBdHRyaWJ1dGVNdXR1YWxFcGhlbWVyYWxLZXlzXCI6IF9pbnRlcmZhY2VEYXRhLmF0dHJpYnV0ZU11dHVhbEVwaGVtZXJhbEtleXMsXHJcbiAgICAgICAgICAgICAgICBcIkFkZGl0aW9uYWxEYXRhXCI6IGFkZGl0aW9uYWxEYXRhIHx8IFwiXCJcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIFxyXG4gICAgICAgIHByb2Nlc3NSZWNlaXZlZERhdGEocmVzcG9uc2UpO1xyXG5cclxuICAgICAgICBhd2FpdCBfa2V5cGFkLmdldEtleXBhZChfaW50ZXJmYWNlRGF0YS5hdHRyaWJ1dGVEYXJjRGF0YSwgX2ludGVyZmFjZURhdGEuVXNlclRlbXBsYXRlSWRlbnRpZmllciB8fCB0ZW1wbGF0ZUlkZW50aWZpZXIsIF9pbnRlcmZhY2VEYXRhLm1hcHBlZEF0dHJpYnV0ZVZhbHVlcyk7XHJcbiAgICAgICAgX2ludGVyZmFjZURhdGEuYXR0cmlidXRlRGFyY0RhdGEgPSBudWxsO1xyXG4gICAgICAgIF9pbnRlcmZhY2VEYXRhLmF0dHJpYnV0ZUxvb2t1cFZhbHVlcyA9IG51bGw7ICAgICAgICBcclxuICAgIH0gY2F0Y2ggKGV4KSB7XHJcbiAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhleCxcIjAyZmQzMmU1LTk0ODktNGY3Yi1hOGNiLTgwNzcwMjc2MWExMVwiKTtcclxuICAgICAgICB0aHJvdyBleDtcclxuICAgIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFRoZSBuS29kZSBKYXZhU2NyaXB0IEFQSVxyXG4gKiAgQHB1YmxpY1xyXG4gKiAqL1xyXG5sZXQgbktvZGUgPVxyXG57ICAgIFxyXG4gICAgLyoqXHJcbiAgICAgKiBTZXQgdGhlIGNvbmZpZ3VyYXRpb24gdmFsdWVzIG5lZWRlZCBmb3IgbktvZGUgdG8gZnVuY3Rpb24gY29ycmVjdGx5LiAgVGhpcyBtdXN0IGJlIGNhbGxlZCBiZWZvcmUgYW55IG90aGVyIGZ1bmN0aW9ucy4gICAgIFxyXG4gICAgICogQG1lbWJlck9mIG1vZHVsZTpuS29kZSNcclxuICAgICAqIEBwYXJhbSAge09iamVjdH0gY29uZmlnIEFuIG9iamVjdCBjb250YWluaW5nIHRoZSByZXF1aXJlZCBjb25maWcgdmFsdWVzXHJcbiAgICAgKiBAcGFyYW0gIHtzdHJpbmd9IGNvbmZpZy5BUElfVVJMIFRoZSBiYXNlIFVSTCBmb3IgdGhlIFJFU1Qgc2VydmljZSBjb250YWluaW5nIHRoZSBuS29kZSBzZXJ2ZXIgQVBJIGNhbGxzXHJcbiAgICAgKiBAcGFyYW0gIHtzdHJpbmd9IGNvbmZpZy5IVE1MX1RFTVBMQVRFX1BBVEggVGhlIHBhdGggdG8gdGhlIHRlbXBsYXRlcyBmb3IgdGhlIHZhcmlvdXMgbktvZGUgaW50ZXJmYWNlcy4gIFxyXG4gICAgICogJHt0ZW1wbGF0ZUlkZW50aWZpZXJ9IGluIHRoZSBwYXRoIHdpbGwgYmUgcmVwbGFjZWQgd2l0aCB0aGUgdGVtcGxhdGVJZGVudGlmaWVyIHZhbHVlIGZvciB0aGUgaW50ZXJmYWNlIHRoYXQgc2hvdWxkIGJlIGxvYWRlZC5cclxuICAgICAqIEZvciBleDogYXNzZXRzL25Lb2RlVGVtcGxhdGVzLyR7dGVtcGxhdGVJZGVudGlmaWVyfS5odG1sXHJcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gY29uZmlnLkNMSUVOVF9JRCBUaGUgR1VJRCBpZGVudGlmaWVyIGZvciB0aGUgY2xpZW50L2N1c3RvbWVyIHRoZSB3ZWJzaXRlIGlzIGZvci4gIFRoZSBHVUlEIG1heSBiZSBkZWZpbmVkIHdpdGggb3Igd2l0aG91dCBoeXBlbnNcclxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBjb25maWcuSU5URVJGQUNFX0hUTUxfUExBQ0VIT0xERVJfSUQgVGhlIGlkIG9mIHRoZSBIVE1MIGVsZW1lbnQgdGhhdCBzaG91bGQgY29udGFpbiB0aGUgcmVuZGVyZWQgbktvZGUgaW50ZXJmYWNlXHJcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gY29uZmlnLk1BWF9OS09EX0xFTkdUSCBBIG51bWJlciBpbmRpY2F0aW5nIHRoZSBtYXhpbXVtIG5Lb2RlIGxlbmd0aCB0aGF0IHNob3VsZCBiZSBhbGxvd2VkLiAgTm90ZSB0aGF0IHRoZSBzeXN0ZW0gYWxsb3dlZCBsaW1pdCBpcyBjdXJyZW50bHkgMTBcclxuICAgICAqIEBwYXJhbSB7bnVtYmVyfSBjb25maWcuTUlOX05LT0RfTEVOR1RIIEEgbnVtYmVyIGluZGljYXRpbmcgdGhlIG1pbmltdW0gbktvZGUgbGVuZ3RoIHRoYXQgc2hvdWxkIGJlIGFsbG93ZWQuIFxyXG4gICAgICogKi9cclxuICAgIHNldENvbmZpZzogKGNvbmZpZykgPT4geyBfY29uZmlnID0gY29uZmlnOyBfa2V5cGFkLnNldENvbmZpZyhjb25maWcpOyB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiBSZW1vdmVzIHRoZSBsYXN0IHZhbHVlIHRoZSB1c2VyIGhhcyBlbnRlcmVkLiAgQ2FsbHMgQHNlZSBzZXRLb2RDaGFuZ2VkQ2FsbGJhY2sgaWYgaXQgaGFzIGJlZW4gc2V0XHJcbiAgICAgKiBAbWVtYmVyT2YgbW9kdWxlOm5Lb2RlI1xyXG4gICAgICogKi9cclxuICAgIHJlbW92ZUxhc3RFbnRyeTogKCkgPT4geyBfa2V5cGFkLnJlbW92ZUxhc3RFbnRyeSgpOyB9LCAgICBcclxuICAgIC8qKlxyXG4gICAgICogU2V0cyB0aGUgZnVuY3Rpb24gdG8gYmUgY2FsbGVkIHdoZW4gdGhlIGVudGVyZWQgbktvZGUgaGFzIGJlZW4gY2hhbmdlZCAoY2xlYXJlZCwgYW5vdGhlciBrZXkgc2VsZWN0ZWQsIGV0YylcclxuICAgICAqIEBtZW1iZXJPZiBtb2R1bGU6bktvZGUjXHJcbiAgICAgKiBAcGFyYW0ge3JlcXVlc3RDYWxsYmFja30gY2FsbGJhY2sgQSBwYXJhbWV0ZXJsZXNzIGZ1bmN0aW9uIHRvIGJlIGNhbGxlZCBcclxuICAgICAqICovXHJcbiAgICBzZXRLb2RDaGFuZ2VkQ2FsbGJhY2s6IChjYWxsYmFjaykgPT4geyBfa2V5cGFkLm5Lb2RDaGFuZ2VkID0gY2FsbGJhY2s7IH0sXHJcbiAgICAvKipcclxuICAgICAqIEdldHMgdGhlIGN1cnJlbnQgZW50ZXJkIG5Lb2RlIGxlbmd0aFxyXG4gICAgICogQG1lbWJlck9mIG1vZHVsZTpuS29kZSNcclxuICAgICAqIEByZXR1cm5zIHtudW1iZXJ9IFRoZSBjdXJyZW50IGVudGVyZCBuS29kZSBsZW5ndGhcclxuICAgICAqICovXHJcbiAgICBjdXJyZW50TktvZExlbmd0aDogKCkgPT4gX2tleXBhZC5jdXJyZW50TktvZExlbmd0aCgpLFxyXG5cclxuICAgIC8qKiAgICAgXHJcbiAgICAgKiBHZW5lcmF0ZXMgdGhlIGludGVyZmFjZSBmb3IgYSB1c2VyIHRvIGxvZ2luXHJcbiAgICAgKiBAbWVtYmVyT2YgbW9kdWxlOm5Lb2RlI1xyXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IHVzZXJOYW1lIFRoZSB1c2VybmFtZSBmb3Igd2hpY2ggdGhlIGxvZ2luIGludGVyZmFjZSBzaG91bGQgYmUgZ2VuZXJhdGVkIGZvclxyXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IGRlZmF1bHRUZW1wbGF0ZUlkZW50aWZpZXIgVGhlIGRlZmF1bHQgdGVtcGxhdGUgaWRlbnRpZmllciB0byBiZSB1c2VkIGluIGNhc2UgdGhlIHVzZXJuYW1lIGRvZXNuJ3QgZXhpc3RcclxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBmaW5nZXJwcmludCBUaGUgYnJvd3NlciBmaW5nZXJwcmludCBvZiB0aGUgdXNlci4gIFxyXG4gICAgICogQHBhcmFtIHthbnl9IGFkZGl0aW9uYWxEYXRhIEFueSBhZGRpdGlvbmFsIGRhdGEgeW91IHdpc2ggdG8gYmUgc2VudCB0byB0aGUgc2VydmVyXHJcbiAgICAgKi9cclxuICAgIFxyXG4gICAgZ2VuZXJhdGVMb2dpbkludGVyZmFjZTphc3luYyBmdW5jdGlvbiAodXNlck5hbWUsIGRlZmF1bHRUZW1wbGF0ZUlkZW50aWZpZXIsIGZpbmdlcnByaW50LCBhZGRpdGlvbmFsRGF0YSkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIF9jcmVhdGVOS29kRGF0YSA9IHt9O1xyXG4gICAgICAgICAgICBhd2FpdCBjcmVhdGVJbnRlcmZhY2UodXNlck5hbWUsIGRlZmF1bHRUZW1wbGF0ZUlkZW50aWZpZXIsIGZpbmdlcnByaW50LCBhZGRpdGlvbmFsRGF0YSk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXgpIHtcclxuICAgICAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhleCxcIjE3ZjY1MTQ4LWNhMzEtNGRlYS1hYzVjLWUxODRmMGZmOGNlZlwiKTtcclxuICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgfVxyXG4gICAgfSwgICBcclxuICAgIC8qKlxyXG4gICAgICogR2VuZXJhdGVzIHRoZSBpbnRlcmZhY2UgdXNlZCBmb3IgdGhlIGZpcnN0IHN0ZXAgb2YgY3JlYXRpbmcgb3IgY2hhbmdpbmcgYSBuS29kZVxyXG4gICAgICogQG1lbWJlck9mIG1vZHVsZTpuS29kZSNcclxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSB0ZW1wbGF0ZUlkZW50aWZpZXIgVGhlIGludGVyZmFjZSB0ZW1wbGF0ZSB0byB1c2VcclxuICAgICAqIEBwYXJhbSB7YW55fSBhZGRpdGlvbmFsRGF0YSBBbnkgYWRkaXRpb25hbCBkYXRhIHlvdSB3aXNoIHRvIGJlIHNlbnQgdG8gdGhlIHNlcnZlclxyXG4gICAgICovXHJcbiAgICAvLyBAanNjcmFtYmxlciBkZWZpbmUgc2VsZkRlZmVuZGluZyB7dGhyZXNob2xkOiAxLCBvcHRpb25zOiBbdG9sZXJhdGVNaW5pZmljYXRpb24sdG9sZXJhdGVCZW5pZ25Qb2lzb25pbmddfSBhcyBzZFxyXG4gICAgLy8gQGpzY3JhbWJsZXIgZW5hYmxlIHNkXHJcbiAgICBnZW5lcmF0ZVJlZ2lzdGVySW50ZXJmYWNlOiBhc3luYyBmdW5jdGlvbiAodGVtcGxhdGVJZGVudGlmaWVyLCBhZGRpdGlvbmFsRGF0YSkgeyAgICAgICAgXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgX2NyZWF0ZU5Lb2REYXRhLnNldHVwTmtvZFRlbXBsYXRlU2VsZWN0b3IgPSB0ZW1wbGF0ZUlkZW50aWZpZXI7XHJcbiAgICAgICAgICAgIGF3YWl0IGNyZWF0ZUludGVyZmFjZShudWxsLCB0ZW1wbGF0ZUlkZW50aWZpZXIsIG51bGwsIGFkZGl0aW9uYWxEYXRhKTtcclxuICAgICAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LFwiOTRmMzc1YTYtZTA3Yy00ODEzLThjMzQtMDQ2ZGRjYTNiMmYyXCIpO1xyXG4gICAgICAgICAgICB0aHJvdyBleDtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiBTZW5kcyB0aGUgdXNlcidzIGVudGVyZWQgbktvZGUgdG8gY29uZmlybSBpZiB0aGUgdXNlciBjYW4gbG9naW4gY29ycmVjdGx5XHJcbiAgICAgKiBAbWVtYmVyT2YgbW9kdWxlOm5Lb2RlI1xyXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IHVzZXJuYW1lIFRoZSB1c2VybmFtZSBvZiB0aGUgdXNlclxyXG4gICAgICogQHBhcmFtIHthbnl9IGFkZGl0aW9uYWxEYXRhIEFueSBhZGRpdGlvbmFsIGRhdGEgeW91IHdpc2ggdG8gYmUgc2VudCB0byB0aGUgc2VydmVyXHJcbiAgICAgKiBAcmV0dXJucyB7YW55fSBEYXRhIGZyb20gdGhlIHNlcnZlciBjb250YWluaW5nIGluZm9ybWF0aW9uIGFvYnV0IHRoZSBsb2dpbiBhdHRlbXB0LiAgVGhpcyBjYW4gdmFyeSBkZXBlbmRpbmcgdXBvbiB0aGUgaW1wbGVtZW50YXRpb25cclxuICAgICAqKi9cclxuICAgIGxvZ2luOiBhc3luYyAodXNlcm5hbWUsIGFkZGl0aW9uYWxEYXRhKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuXHJcbiAgICAgICAgICAgIGxldCBuZXdLZXlWYWx1ZXMgPSBwcmVwYXJlS2V5SW5wdXRGb3JUcmFuc21pc3Npb24oX2tleXBhZC5zZWxlY3RlZEtleU9yZGluYWwpO1xyXG5cclxuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gYXdhaXQgY29tbW9uLnBvc3QoXHJcbiAgICAgICAgICAgICAgICBfY29uZmlnLkFQSV9VUkwgKyBcIi9hcGkvbmtvZC9cIixcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBcIkNsaWVudElkXCI6IF9jb25maWcuQ0xJRU5UX0lELFxyXG4gICAgICAgICAgICAgICAgICAgIFwiU2Vzc2lvbklkXCI6IF9pbnRlcmZhY2VEYXRhLlNlc3Npb25JZCxcclxuICAgICAgICAgICAgICAgICAgICBcIlVzZXJOYW1lXCI6IHVzZXJuYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiS2V5c1wiOiBuZXdLZXlWYWx1ZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJBZGRpdGlvbmFsRGF0YVwiOiBhZGRpdGlvbmFsRGF0YSB8fCBcIlwiXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIC8vYXdhaXQgZmluYWwoKTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiByZXNwb25zZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2F0Y2ggKGV4KSB7XHJcbiAgICAgICAgICAgIGNvbW1vbi5hZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8oZXgsXCIxYTI1ZTM2NS02MGUxLTRjNDEtOGM2Zi04NjhhNjM4MDhiYjNcIik7XHJcbiAgICAgICAgICAgIHRocm93IGV4O1xyXG4gICAgICAgIH1cclxuICAgICAgICBmaW5hbGx5IHsgICAgICAgICAgIFxyXG4gICAgICAgICAgICBmaW5hbCgpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIFNldHMgdGhlIHVzZXIncyBuS29kZSBmb3IgdGhlIGZpcnN0IHN0ZXAgaW4gY3JlYXRpbmcvY2hhbmdpbmcgYSBuS29kZS4gUGVyZm9ybXMgYSBzcGVjaWFsIHNodWZmbGUgb24gdGhlIGludGVyZmFjZSBmb3IgdGhlIHVzZXIgdG8gY29uZmlybSB0aGUgZW50ZXJlZCBuS29kZSBpbiB0aGUgc2Vjb25kIHN0ZXAuXHJcbiAgICAgKiBAbWVtYmVyT2YgbW9kdWxlOm5Lb2RlI1xyXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IHVzZXJuYW1lIFRoZSB1c2VybmFtZSBvZiB0aGUgdXNlclxyXG4gICAgICogQHBhcmFtIHthbnl9IGFkZGl0aW9uYWxEYXRhIEFueSBhZGRpdGlvbmFsIGRhdGEgeW91IHdpc2ggdG8gYmUgc2VudCB0byB0aGUgc2VydmVyXHJcbiAgICAgKiBAcmV0dXJucyB7YW55fSBUaGUgcmVzcG9uc2UgZGF0YSBpZiB0aGUgdXNlciBleGlzdHMsIHRydWUgb3RoZXJ3aXNlXHJcbiAgICAgKiAqL1xyXG4gICAgY3JlYXRlTktvZGVTdGVwMTogYXN5bmMgKHVzZXJuYW1lLCBhZGRpdGlvbmFsRGF0YSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgX2NyZWF0ZU5Lb2REYXRhLmZpcnN0TktvZExlbmd0aCA9IF9rZXlwYWQuc2VsZWN0ZWRLZXlPcmRpbmFsLmxlbmd0aDtcclxuICAgICAgICAgICAgY29tbW9uLmNoZWNrRm9yVmFsdWUoX2tleXBhZC5zZWxlY3RlZEtleU9yZGluYWwsICdTZWxlY3RlZCBrZXkgb3JkaW5hbCcpO1xyXG4gICAgICAgICAgICBjb21tb24uY2hlY2tGb3JWYWx1ZShfa2V5cGFkLnVzZXJOYW1lLCAnVXNlcm5hbWUnKTtcclxuXHJcbiAgICAgICAgICAgIGxldCBkQVJDUGhhc2UxQXR0cmlidXRlRGF0YSA9IGdldEF0dHJpYnV0ZURhdGFGb3JUcmFuc21pc3Npb24oKTtcclxuICAgICAgICAgICAgbGV0IG5ld0tleVZhbHVlcyA9IHByZXBhcmVLZXlJbnB1dEZvclRyYW5zbWlzc2lvbihfa2V5cGFkLnNlbGVjdGVkS2V5T3JkaW5hbCk7XHJcblxyXG4gICAgICAgICAgICBjb21tb24uY2hlY2tGb3JWYWx1ZShuZXdLZXlWYWx1ZXMsICdOZXcga2V5IHZhbHVlcycpO1xyXG5cclxuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gYXdhaXQgY29tbW9uLnBvc3QoXHJcbiAgICAgICAgICAgICAgICBgJHtfY29uZmlnLkFQSV9VUkx9L2FwaS9ua29kL3NldGAsXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgXCJDbGllbnRJZFwiOiBfY29uZmlnLkNMSUVOVF9JRCxcclxuICAgICAgICAgICAgICAgICAgICBcIlNlc3Npb25JZFwiOiBfaW50ZXJmYWNlRGF0YS5TZXNzaW9uSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJVc2VyTmFtZVwiOiB1c2VybmFtZSxcclxuICAgICAgICAgICAgICAgICAgICBcIktleXNcIjogbmV3S2V5VmFsdWVzLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiQXR0cmlidXRlUDFEQVJDRGF0YVwiOiBkQVJDUGhhc2UxQXR0cmlidXRlRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICBcIkF0dHJpYnV0ZU11dHVhbEVwaGVtZXJhbEtleXNcIjogX2ludGVyZmFjZURhdGEuYXR0cmlidXRlTXV0dWFsRXBoZW1lcmFsS2V5cyxcclxuICAgICAgICAgICAgICAgICAgICBcIkFkZGl0aW9uYWxEYXRhXCI6IGFkZGl0aW9uYWxEYXRhIHx8IFwiXCJcclxuICAgICAgICAgICAgICAgIH0pOyAgICAgICAgICAgXHJcblxyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UudXNlckV4aXN0cykgXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2U7ICAgICAgICAgICAgXHJcblxyXG4gICAgICAgICAgICBfa2V5cGFkLmNsZWFyKCk7XHJcblxyXG4gICAgICAgICAgICBwcm9jZXNzUmVjZWl2ZWREYXRhKHJlc3BvbnNlKTtcclxuXHJcbiAgICAgICAgICAgIGF3YWl0IF9rZXlwYWQuZ2V0S2V5cGFkKF9pbnRlcmZhY2VEYXRhLmF0dHJpYnV0ZURhcmNEYXRhLCBfY3JlYXRlTktvZERhdGEuc2V0dXBOa29kVGVtcGxhdGVTZWxlY3RvciwgX2ludGVyZmFjZURhdGEubWFwcGVkQXR0cmlidXRlVmFsdWVzKTtcclxuICAgICAgICAgICAgX2ludGVyZmFjZURhdGEuYXR0cmlidXRlRGFyY0RhdGEgPSBudWxsO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhdGNoIChleClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGNvbW1vbi5hZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8oZXgsIFwiMDQxYjE3YmItY2NmZS00NDYzLWE2MDYtNDAyZDA0MTI0MjU3XCIpO1xyXG4gICAgICAgICAgICB0aHJvdyBleDtcclxuICAgICAgICB9ICAgICAgICBcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIFRoZSBzZWNvbmQgKGNvbmZpcm1hdGlvbikgc3RlcCBvZiBjcmVhdGluZy9jaGFuZ2luZyBhIHVzZXIncyBuS29kZS5cclxuICAgICAqIEBtZW1iZXJPZiBtb2R1bGU6bktvZGUjXHJcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gdXNlcm5hbWUgVGhlIHVzZXJuYW1lIG9mIHRoZSB1c2VyXHJcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gZmluZ2VycHJpbnQgVGhlIGJyb3dzZXIgZmluZ2VycHJpbnQgb2YgdGhlIHVzZXIuXHJcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gdGVtcGxhdGVJZGVudGlmaWVyIFRoZSBpZGVudGlmaWVyIGZvciB0aGUgbktvZGUgaW50ZXJmYWNlIHRoZSB1c2VyIGhhcyBzZWxlY3RlZFxyXG4gICAgICogQHBhcmFtIHthbnl9IGFkZGl0aW9uYWxEYXRhIEFueSBhZGRpdGlvbmFsIGRhdGEgeW91IHdpc2ggdG8gYmUgc2VudCB0byB0aGUgc2VydmVyXHJcbiAgICAgKiBAcmV0dXJucyB7YW55fSBBbiBvYmplY3QgY29udGFpbmluZyB0aGUgcmVzdWx0IG9mIGF0dGVtcHRpbmcgdG8gY3JlYXRlL2NoYW5nZSBhIHVzZXIncyBuS29kZS4gIFRoaXMgY2FuIHZhcnkgZGVwZW5kaW5nIHVwb24gdGhlIGltcGxlbWVudGF0aW9uLlxyXG4gICAgICogKi9cclxuICAgIGNyZWF0ZU5Lb2RlU3RlcDI6IGFzeW5jICh1c2VybmFtZSwgZmluZ2VycHJpbnQsIHRlbXBsYXRlSWRlbnRpZmllciwgYWRkaXRpb25hbERhdGEpID0+IHtcclxuICAgICAgICB0cnkge1xyXG5cclxuICAgICAgICAgICAgaWYgKF9jcmVhdGVOS29kRGF0YS5maXJzdE5Lb2RMZW5ndGggIT09IF9rZXlwYWQuc2VsZWN0ZWRLZXlPcmRpbmFsLmxlbmd0aClcclxuICAgICAgICAgICAgICAgIHJldHVybiB7IE5Lb2RMZW5ndGhVbmVxdWFsOiB0cnVlIH07XHJcbiAgICAgICAgICAgIGxldCBuZXdLZXlWYWx1ZXMgPSBwcmVwYXJlS2V5SW5wdXRGb3JUcmFuc21pc3Npb24oX2tleXBhZC5zZWxlY3RlZEtleU9yZGluYWwpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgbGV0IHJlc3VsdCA9IGF3YWl0IGNvbW1vbi5wb3N0KFxyXG4gICAgICAgICAgICAgICAgYCR7X2NvbmZpZy5BUElfVVJMfS9hcGkvbmtvZC9jb25maXJtYCxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBcIkNsaWVudElkXCI6IF9jb25maWcuQ0xJRU5UX0lELFxyXG4gICAgICAgICAgICAgICAgICAgIFwiU2Vzc2lvbklkXCI6IF9pbnRlcmZhY2VEYXRhLlNlc3Npb25JZCxcclxuICAgICAgICAgICAgICAgICAgICBcIlVzZXJOYW1lXCI6IHVzZXJuYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiS2V5c1wiOiBuZXdLZXlWYWx1ZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJGaW5nZXJwcmludFwiOiBmaW5nZXJwcmludCxcclxuICAgICAgICAgICAgICAgICAgICBcIlRlbXBsYXRlSWRlbnRpZmllclwiOiB0ZW1wbGF0ZUlkZW50aWZpZXIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJBZGRpdGlvbmFsRGF0YVwiOiBhZGRpdGlvbmFsRGF0YSB8fCBcIlwiXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfSBcclxuICAgICAgICBjYXRjaCAoZXgpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcIjZmNmM2NDhkLTM2M2ItNGE1Mi04MWE0LWU3ZDUwMzgwZDlmOFwiKTtcclxuICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZpbmFsbHkge1xyXG4gICAgICAgICAgICBmaW5hbCgpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIEdldHMgdGhlIGF0dHJpYnV0ZSBzZXRzIGFuZCB2YWx1ZXMgdXNlZCBmb3IgdGhlIGNsaWVudFxyXG4gICAgICogQG1lbWJlck9mIG1vZHVsZTpuS29kZSNcclxuICAgICAqIEByZXR1cm5zIHtBcnJheS48QXJyYXkuPG51bWJlcj4+fSBBIDIgZGltZW5zaW9uYWwgYXJyYXkgY29udGFpbmluZyBhdHRyaWJ1dGUgc2V0cyBhbmQgdmFsdWVzLiAgVGhlIGZpcnN0IGRpbWVuc2lvbiBpcyB0aGUgYXR0cmlidXRlIHNldCBhbmQgdGhlIHNlY29uZCBkaW1lbnNpb25cclxuICAgICAqIGlzIHRoZSBhdHRyaWJ1dGUgdmFsdWVzIHVzZWQgZm9yIHRoYXQgYXR0cmlidXRlIHNldC5cclxuICAgICAqICovXHJcbiAgICBnZXRDbGllbnRBdHRyaWJ1dGVTZXRzQW5kVmFsdWVzOiAoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIGRhcmNDb21tb24uc3RydWN0dXJlRmxhdHRlbmVkVHdvRGltZW5zaW9uYWxBcnJheSg3LCAxMCwgZGFyY0NvbmZpZy5BVFRSSUJVVEVfVkFMVUVTKTtcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIENsZWFycyBhbnkgaW5wdXQgdmFsdWVzLiAgQ2FsbHMgQHNlZSBuS29kZS5zZXRLb2RDaGFuZ2VkQ2FsbGJhY2sgaWYgaXQgaGFzIGJlZW4gc2V0XHJcbiAgICAgKiBAbWVtYmVyT2YgbW9kdWxlOm5Lb2RlI1xyXG4gICAgICogKi9cclxuICAgIGNsZWFyOiAoKSA9PiB7XHJcbiAgICAgICAgX2tleXBhZC5jbGVhcigpOyAgXHJcbiAgICB9XHJcbn07XHJcblxyXG5mdW5jdGlvbiBmaW5hbCgpXHJcbnsgIC8vICBSRVNFVCBUSEUgQlJPV1NFUiBNRU1PUlkgVE8gV0lQRSBBTEwgVkFMVUVTICAgICAgIFxyXG4gICAgX2tleXBhZC5jbGVhcigpOyBcclxuICAgIF9pbnRlcmZhY2VEYXRhID0ge307XHJcbiAgICBfY3JlYXRlTktvZERhdGEgPSB7fTtcclxufSBcclxuXHJcbmZ1bmN0aW9uIGdldEF0dHJpYnV0ZURhdGFGb3JUcmFuc21pc3Npb24oKVxyXG57XHJcbiAgICB0cnkge1xyXG4gICAgICAgIGxldCBudW1iZXJPZkF0dHJpYnV0ZVZhbHVlcyA9IGRhcmNDb25maWcuQVRUUklCVVRFX1ZBTFVFUy5sZW5ndGg7XHJcbiAgICAgICAgX2ludGVyZmFjZURhdGEuc2VydmVyRXBoZW1lcmFsS2V5cyA9IGVwaGVtZXJhbEtleXMuZ2VuZXJhdGVTZXJ2ZXJJbnN0YW5jZVRyYW5zbGF0aW9ucyhBVFRSSUJVVEVfV0lEVEgsIEFUVFJJQlVURV9IRUlHSFQsIEFUVFJJQlVURV9IRUlHSFQpO1xyXG4gICAgICAgIF9pbnRlcmZhY2VEYXRhLmF0dHJpYnV0ZU11dHVhbEVwaGVtZXJhbEtleXMgPSBlcGhlbWVyYWxLZXlzLmdlbmVyYXRlU2hhcmVkSW5zdGFuY2VUcmFuc2xhdGlvbnMoQVRUUklCVVRFX1dJRFRILCBBVFRSSUJVVEVfSEVJR0hULCBBVFRSSUJVVEVfSEVJR0hUKTtcclxuICAgICAgICBfaW50ZXJmYWNlRGF0YS5zZXJ2ZXJFcGhlbWVyYWxLZXlzID0gT2JqZWN0LmFzc2lnbihfaW50ZXJmYWNlRGF0YS5zZXJ2ZXJFcGhlbWVyYWxLZXlzLCBfaW50ZXJmYWNlRGF0YS5hdHRyaWJ1dGVNdXR1YWxFcGhlbWVyYWxLZXlzKTtcclxuICAgICAgICBsZXQgYXR0cmlidXRlTG9va3VwVmFsdWVzID0gZGFyY0NvbW1vbi5yYW5kVW5pcXVlSW50KG51bWJlck9mQXR0cmlidXRlVmFsdWVzLCAwLCAyNTYpOyAvL0dlbmVyYXRlIHJhbmRvbSB2YWx1ZXMgdG8gc2VuZCB0byBzZXJ2ZXJcclxuICAgICAgICBfaW50ZXJmYWNlRGF0YS5tYXBwZWRBdHRyaWJ1dGVWYWx1ZXMgPSB7fTtcclxuICAgICAgICBfaW50ZXJmYWNlRGF0YS5hdHRyaWJ1dGVBbHBoYWJldCA9IG5ldyBBcnJheSgpO1xyXG5cclxuICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IG51bWJlck9mQXR0cmlidXRlVmFsdWVzOyB4KyspIHsgLy9BZGQgYWRkaXRpb25hbCByYW5kb20gdmFsdWVzIHRvIHZhbHVlc1xyXG4gICAgICAgICAgICBfaW50ZXJmYWNlRGF0YS5hdHRyaWJ1dGVBbHBoYWJldC5wdXNoKFthdHRyaWJ1dGVMb29rdXBWYWx1ZXNbeF1dLmNvbmNhdChkYXJjQ29tbW9uLnJhbmRVbmlxdWVJbnQoQVRUUklCVVRFX1dJRFRIIC0gMSwgMCwgMjU2KSkpO1xyXG4gICAgICAgICAgICBfaW50ZXJmYWNlRGF0YS5tYXBwZWRBdHRyaWJ1dGVWYWx1ZXNbYXR0cmlidXRlTG9va3VwVmFsdWVzW3hdLnRvU3RyaW5nKCldID0gZGFyY0NvbmZpZy5BVFRSSUJVVEVfVkFMVUVTW3hdOyAvL0J1aWxkIGxvb2t1cFxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGRBUkNQaGFzZTEgPSBzZXJ2ZXJUeC50cmFuc21pdChkYXJjQ29uZmlnLlNFUlZFUl9EQVJDX0FUVFJJQlVURV9LRVlTLCBfaW50ZXJmYWNlRGF0YS5zZXJ2ZXJFcGhlbWVyYWxLZXlzLCBfaW50ZXJmYWNlRGF0YS5hdHRyaWJ1dGVBbHBoYWJldCk7XHJcblxyXG4gICAgICAgIHJldHVybiBkQVJDUGhhc2UxO1xyXG4gICAgfSBjYXRjaCAoZXgpXHJcbiAgICB7XHJcbiAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhleCwgXCJkOWY3YTQ0MS1kZGNlLTQ0NTYtYmQzOC03OGYxOGYxZWI2NmRcIik7XHJcbiAgICAgICAgdGhyb3cgZXg7XHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHByZXBhcmVLZXlJbnB1dEZvclRyYW5zbWlzc2lvbihpbnB1dFNlcXVlbmNlKVxyXG57ICAgXHJcbiAgICB0cnkge1xyXG4gICAgICAgIGxldCBkQVJDUGhhc2UzID0gY2xpZW50VHgudHJhbnNtaXQoZGFyY0NvbmZpZy5DTElFTlRfS0VZUywgX2ludGVyZmFjZURhdGEuY2xpZW50RXBoZW1lcmFsS2V5cywgX2ludGVyZmFjZURhdGEuS2V5cGFkRGFyY0RhdGEpO1xyXG4gICAgICAgIGxldCBkQVJDTWVzc2FnZSA9IGNsaWVudE1lcmdlLm1lcmdlTWVzc2FnZShkYXJjQ29uZmlnLkNMSUVOVF9LRVlTLCBfaW50ZXJmYWNlRGF0YS5jbGllbnRFcGhlbWVyYWxLZXlzLCBkQVJDUGhhc2UzLCBpbnB1dFNlcXVlbmNlKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGRBUkNNZXNzYWdlO1xyXG4gICAgfSBjYXRjaCAoZXgpIHtcclxuICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcIjJkZTZmMzc2LTA3ZjMtNDM0NC1iZTNiLTFhNWZmNTQ4ODUzMVwiKTtcclxuICAgICAgICB0aHJvdyBleDtcclxuICAgIH1cclxufVxyXG5cclxuXHJcbmZ1bmN0aW9uIHByb2Nlc3NSZWNlaXZlZERhdGEocmVzcG9uc2UpXHJcbnsgICAgXHJcbiAgICB0cnkge1xyXG4gICAgICAgIF9pbnRlcmZhY2VEYXRhID0gT2JqZWN0LmFzc2lnbihfaW50ZXJmYWNlRGF0YSwgcmVzcG9uc2UpOyAvL01lcmdlIHJlc3BvbnNlIHdpdGggZXhpc3RpbmcgZGF0YVxyXG5cclxuICAgICAgICBfaW50ZXJmYWNlRGF0YS5jbGllbnRFcGhlbWVyYWxLZXlzID0gZXBoZW1lcmFsS2V5cy5nZW5lcmF0ZUNsaWVudEluc3RhbmNlVHJhbnNsYXRpb25zKDcsIDEwLCAxMCk7XHJcbiAgICAgICAgX2ludGVyZmFjZURhdGEuY2xpZW50RXBoZW1lcmFsS2V5cyA9IE9iamVjdC5hc3NpZ24oX2ludGVyZmFjZURhdGEuY2xpZW50RXBoZW1lcmFsS2V5cywgX2ludGVyZmFjZURhdGEuS2V5cGFkTXV0dWFsRXBoZW1lcmFsS2V5cyk7IC8vTWVyZ2UgbXV0dWFsIGtleXMgaW50byBnZW5lcmF0ZWQgY2xpZW50IG9ubHkga2V5c1xyXG5cclxuICAgICAgICBfaW50ZXJmYWNlRGF0YS5rZXlwYWREYXJjRGF0YSA9IGNsaWVudFJ4LnJlY2VpdmUoZGFyY0NvbmZpZy5DTElFTlRfS0VZUywgX2ludGVyZmFjZURhdGEuY2xpZW50RXBoZW1lcmFsS2V5cywgcmVzcG9uc2UuS2V5cGFkRGFyY0RhdGEpOyAvL1RyYW5zZm9ybSBEQVJDIHBoYXNlIDEgZGF0YSBpbnRvIHBoYXNlIDJcclxuXHJcbiAgICAgICAgbGV0IGF0dHJpYnV0ZURhdGEgPSBzZXJ2ZXJSeC50cmFuc2xhdGUoZGFyY0NvbmZpZy5TRVJWRVJfREFSQ19BVFRSSUJVVEVfS0VZUywgX2ludGVyZmFjZURhdGEuc2VydmVyRXBoZW1lcmFsS2V5cywgcmVzcG9uc2UuQXR0cmlidXRlRGFyY0RhdGEsIF9pbnRlcmZhY2VEYXRhLmF0dHJpYnV0ZUFscGhhYmV0KTtcclxuXHJcbiAgICAgICAgLy9HZXQganVzdCBmaXJzdCBwb3NpdGlvbiBvZiBkYXRhXHJcbiAgICAgICAgYXR0cmlidXRlRGF0YSA9IGF0dHJpYnV0ZURhdGEubWFwKCh2YWx1ZSkgPT4gdmFsdWVbMF0pO1xyXG5cclxuICAgICAgICBfaW50ZXJmYWNlRGF0YS5hdHRyaWJ1dGVEYXJjRGF0YSA9IGRhcmNDb21tb24uc3RydWN0dXJlRmxhdHRlbmVkVHdvRGltZW5zaW9uYWxBcnJheSgxMCwgNywgYXR0cmlidXRlRGF0YSk7XHJcbiAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgIGNvbW1vbi5hZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8oZXgsIFwiNmZlYzczZGEtMmE5Ni00MTc4LWJlZGYtMmJmNjM5NGNiYTNmXCIpO1xyXG4gICAgICAgIHRocm93IGV4O1xyXG4gICAgfVxyXG4gICAgXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IG5Lb2RlOyIsImltcG9ydCB0cmFuc2Zvcm0gZnJvbSAnLi90cmFuc2Zvcm0uanMnO1xyXG5pbXBvcnQgZGFyY0NvbW1vbiBmcm9tICcuL2RhcmNDb21tb24uanMnO1xyXG5pbXBvcnQgY29tbW9uIGZyb20gJy4vY29tbW9uLmpzJztcclxuXHJcbmNvbnN0IHNlcnZlclJ4ID0gIHtcclxuXHJcbiAgICAvLzEpIEtleSBQcmVwYXJhdGlvbnM7IDIpIE91dGVyIE1lZGl1bSBQZXJtdXRhdGlvbnMgMykgTWVkaXVtIFN1YnN0aXR1dGlvbnM7IDQpIE91dGVyL0lubmVyIE1lc3NhZ2UgUGVybXV0YXRpb25zO1xyXG4gICAgIHRyYW5zbGF0ZToocGVyc2lzdGVudEtleXMsIGVwaGVtZXJhbEtleXMsIHJ4RGF0YSwgYWxwaGFiZXQpID0+e1xyXG4gICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgbGV0IG91dGVyUG9zaXRpb25GdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWQgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJQb3NpdGlvbkZ1bmN0aW9uTWVkaXVtS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyUG9zaXRpb25GdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleSk7XHJcbiAgICAgICAgICAgICBsZXQgb3V0ZXJQb3NpdGlvblNodWZmbGVFcGhlbWVyYWxLZXlBcHBsaWVkID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLk91dGVyUG9zaXRpb25TaHVmZmxlTWVkaXVtS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyUG9zaXRpb25TaHVmZmxlTWVkaXVtRXBoZW1lcmFsS2V5KTtcclxuICAgICAgICAgICAgIG91dGVyUG9zaXRpb25GdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWQgPSB0cmFuc2Zvcm0udHJhbnNmb3JtYXRpb25Db21wbGltZW50KHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihvdXRlclBvc2l0aW9uU2h1ZmZsZUVwaGVtZXJhbEtleUFwcGxpZWQsIG91dGVyUG9zaXRpb25GdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWQpKTtcclxuICAgICAgICAgICAgIG91dGVyUG9zaXRpb25TaHVmZmxlRXBoZW1lcmFsS2V5QXBwbGllZCA9IHRyYW5zZm9ybS50cmFuc2Zvcm1hdGlvbkNvbXBsaW1lbnQob3V0ZXJQb3NpdGlvblNodWZmbGVFcGhlbWVyYWxLZXlBcHBsaWVkKTtcclxuICAgICAgICAgICAgIGxldCBvdXRlclBvc2l0aW9uU2h1ZmZsZUZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5PdXRlclBvc2l0aW9uU2h1ZmZsZUZ1bmN0aW9uTWVkaXVtS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyUG9zaXRpb25TaHVmZmxlRnVuY3Rpb25NZWRpdW1FcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgICAgICAgb3V0ZXJQb3NpdGlvblNodWZmbGVGdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWQgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ob3V0ZXJQb3NpdGlvblNodWZmbGVGdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWQsIG91dGVyUG9zaXRpb25GdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWQpO1xyXG4gICAgICAgICAgICAgbGV0IG91dGVyRnVuY3Rpb25GdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleUFwcGxpZWQgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJGdW5jdGlvbkZ1bmN0aW9uTWVkaXVtS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyRnVuY3Rpb25GdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleSk7XHJcbiAgICAgICAgICAgICBsZXQgb3V0ZXJTZXJ2ZXJTaHVmZmxlRnVuY3Rpb25FcGhlbWVyYWxLZXlBcHBsaWVkID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLk91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uRXBoZW1lcmFsS2V5KTtcclxuICAgICAgICAgICAgIGxldCBvdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleUFwcGxpZWQgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJTZXJ2ZXJTaHVmZmxlRnVuY3Rpb25NZWRpdW1LZXksIGVwaGVtZXJhbEtleXMuT3V0ZXJTZXJ2ZXJTaHVmZmxlRnVuY3Rpb25NZWRpdW1FcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgICAgICAgbGV0IGZ1bmN0aW9uTWVkaXVtRXBoZW1lcmFsS2V5QXBwbGllZCA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5GdW5jdGlvbk1lZGl1bUtleSwgZXBoZW1lcmFsS2V5cy5GdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleSk7ICAgICAgICAgICAgICAgICAvL0N1c3RvbWVyLVNwZWNpZmljIFRyYW5zbGF0aW9uIEZ1bmN0aW9uIGRlZmluaW5nIGhvdyB0cmFuc2xhdGlvbiBpcyBhcHBsaWVkIHRvIGRhdGE7IEluc3VsYXRlcyBDdXN0b21lcnMgZnJvbSBvbmUgYW5vdGhlcjsgSW1iZWRkZWQgaW4gT2JmdXNjYXRlZCBKYXZhIFNjcmlwdCAoV2lkZ2V0KVxyXG4gICAgICAgICAgICAgbGV0IGNsaWVudFNodWZmbGVNZWRpdW1LZXlYID0gdHJhbnNmb3JtLnBlcm11dGVPdXRlclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLkNsaWVudFNodWZmbGVNZWRpdW1LZXlYLCBvdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleUFwcGxpZWQpO1xyXG4gICAgICAgICAgICAgY2xpZW50U2h1ZmZsZU1lZGl1bUtleVggPSB0cmFuc2Zvcm0ucGVybXV0ZUZ1bmN0aW9uT3BlcmFuZChvdXRlckZ1bmN0aW9uRnVuY3Rpb25NZWRpdW1FcGhlbWVyYWxLZXlBcHBsaWVkLCBmdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleUFwcGxpZWQsIGNsaWVudFNodWZmbGVNZWRpdW1LZXlYKTtcclxuICAgICAgICAgICAgIGxldCBwb3NpdGlvblNodWZmbGVFcGhlbWVyYWxLZXlBcHBsaWVkID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLlBvc2l0aW9uU2h1ZmZsZU1lZGl1bUtleSwgZXBoZW1lcmFsS2V5cy5Qb3NpdGlvblNodWZmbGVNZWRpdW1FcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgICAgICAgcG9zaXRpb25TaHVmZmxlRXBoZW1lcmFsS2V5QXBwbGllZCA9IHRyYW5zZm9ybS5wZXJtdXRlT3V0ZXJUcmFuc2Zvcm1hdGlvbihwb3NpdGlvblNodWZmbGVFcGhlbWVyYWxLZXlBcHBsaWVkLCBvdXRlclBvc2l0aW9uU2h1ZmZsZUZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCk7XHJcbiAgICAgICAgICAgICBjbGllbnRTaHVmZmxlTWVkaXVtS2V5WCA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihjbGllbnRTaHVmZmxlTWVkaXVtS2V5WCwgcG9zaXRpb25TaHVmZmxlRXBoZW1lcmFsS2V5QXBwbGllZCk7XHJcbiAgICAgICAgICAgICBsZXQgY2xpZW50U2h1ZmZsZUtleVggPSB0cmFuc2Zvcm0ucGVybXV0ZU91dGVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuQ2xpZW50U2h1ZmZsZUtleVgsIG91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCk7XHJcbiAgICAgICAgICAgICBsZXQgb3V0ZXJGdW5jdGlvbkZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5PdXRlckZ1bmN0aW9uRnVuY3Rpb25LZXksIGVwaGVtZXJhbEtleXMuT3V0ZXJGdW5jdGlvbkZ1bmN0aW9uRXBoZW1lcmFsS2V5KTtcclxuICAgICAgICAgICAgIGxldCBvdXRlckZ1bmN0aW9uTWVkaXVtRXBoZW1lcmFsS2V5QXBwbGllZCA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5PdXRlckZ1bmN0aW9uTWVkaXVtS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyRnVuY3Rpb25NZWRpdW1FcGhlbWVyYWxLZXkpO1xyXG4gICAgICAgICAgICAgcnhEYXRhID0gdHJhbnNmb3JtLnBlcm11dGVPdXRlclRyYW5zZm9ybWF0aW9uKHJ4RGF0YSwgb3V0ZXJQb3NpdGlvblNodWZmbGVFcGhlbWVyYWxLZXlBcHBsaWVkKTtcclxuXHJcbiAgICAgICAgICAgICBsZXQgaWRlbnRpdHlPdXRlckZ1bmN0aW9uID0gZGFyY0NvbW1vbi5pbml0aWFsaXplTmV3QXJyYXkocGVyc2lzdGVudEtleXMuT3V0ZXJGdW5jdGlvbkZ1bmN0aW9uS2V5WzBdLmxlbmd0aCwgcGVyc2lzdGVudEtleXMuT3V0ZXJGdW5jdGlvbkZ1bmN0aW9uS2V5Lmxlbmd0aCk7XHJcblxyXG4gICAgICAgICAgICAgcnhEYXRhID0gdHJhbnNmb3JtLnN1YnN0aXR1dGVGdW5jdGlvbk9wZXJhbmRzKFxyXG4gICAgICAgICAgICAgICAgIGlkZW50aXR5T3V0ZXJGdW5jdGlvblxyXG4gICAgICAgICAgICAgICAgICwgY2xpZW50U2h1ZmZsZU1lZGl1bUtleVhcclxuICAgICAgICAgICAgICAgICAsIG91dGVyRnVuY3Rpb25NZWRpdW1FcGhlbWVyYWxLZXlBcHBsaWVkXHJcbiAgICAgICAgICAgICAgICAgLCByeERhdGFcclxuICAgICAgICAgICAgICAgICAsIHBlcnNpc3RlbnRLZXlzLlNlcnZlck1lZGl1bUtleVxyXG4gICAgICAgICAgICAgICAgICwgZXBoZW1lcmFsS2V5cy5TZXJ2ZXJNZWRpdW1FcGhlbWVyYWxLZXlcclxuICAgICAgICAgICAgICAgICAsIHBlcnNpc3RlbnRLZXlzLk11dHVhbE1lZGl1bUtleVxyXG4gICAgICAgICAgICAgICAgICwgZXBoZW1lcmFsS2V5cy5NdXR1YWxNZWRpdW1FcGhlbWVyYWxLZXlcclxuICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgbGV0IHBvc2l0aW9uRnVuY3Rpb25FcGhlbWVyYWxLZXlBcHBsaWVkID0gdHJhbnNmb3JtLnRyYW5zZm9ybWF0aW9uQ29tcGxpbWVudCh0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuUG9zaXRpb25GdW5jdGlvbk1lZGl1bUtleSwgZXBoZW1lcmFsS2V5cy5Qb3NpdGlvbkZ1bmN0aW9uTWVkaXVtRXBoZW1lcmFsS2V5KSk7XHJcblxyXG4gICAgICAgICAgICAgcnhEYXRhID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHJ4RGF0YSwgdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHRyYW5zZm9ybS50cmFuc2Zvcm1hdGlvbkNvbXBsaW1lbnQocG9zaXRpb25TaHVmZmxlRXBoZW1lcmFsS2V5QXBwbGllZCksIHRyYW5zZm9ybS5wZXJtdXRlT3V0ZXJUcmFuc2Zvcm1hdGlvbihwb3NpdGlvbkZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCwgb3V0ZXJQb3NpdGlvbkZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCkpKTtcclxuICAgICAgICAgICAgIGxldCBmdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWQgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuRnVuY3Rpb25LZXksIGVwaGVtZXJhbEtleXMuRnVuY3Rpb25FcGhlbWVyYWxLZXkpOyAgICAgICAgICAgICAgICAgLy9DdXN0b21lci1TcGVjaWZpYyBUcmFuc2xhdGlvbiBGdW5jdGlvbiBkZWZpbmluZyBob3cgdHJhbnNsYXRpb24gaXMgYXBwbGllZCB0byBkYXRhOyBJbnN1bGF0ZXMgQ3VzdG9tZXJzIGZyb20gb25lIGFub3RoZXI7IEltYmVkZGVkIGluIE9iZnVzY2F0ZWQgSmF2YSBTY3JpcHQgKFdpZGdldClcclxuICAgICAgICAgICAgIGZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCA9IHRyYW5zZm9ybS5wZXJtdXRlRnVuY3Rpb25PcGVyYW5kKG91dGVyRnVuY3Rpb25GdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWQsIGZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCwgY2xpZW50U2h1ZmZsZUtleVgpO1xyXG5cclxuICAgICAgICAgICAgIGxldCBzZXJ2ZXJTaHVmZmxlRXBoZW1lcmFsS2V5QXBwbGllZCA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbih0cmFuc2Zvcm0udHJhbnNmb3JtYXRpb25Db21wbGltZW50KHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5TZXJ2ZXJTaHVmZmxlS2V5LCBwZXJzaXN0ZW50S2V5cy5DbGllbnRTaHVmZmxlS2V5WCkpLCB0cmFuc2Zvcm0udHJhbnNmb3JtYXRpb25Db21wbGltZW50KGVwaGVtZXJhbEtleXMuU2VydmVyU2h1ZmZsZUVwaGVtZXJhbEtleSkpO1xyXG4gICAgICAgICAgICAgc2VydmVyU2h1ZmZsZUVwaGVtZXJhbEtleUFwcGxpZWQgPSB0cmFuc2Zvcm0udHJhbnNmb3JtYXRpb25Db21wbGltZW50KHRyYW5zZm9ybS5wZXJtdXRlT3V0ZXJUcmFuc2Zvcm1hdGlvbihzZXJ2ZXJTaHVmZmxlRXBoZW1lcmFsS2V5QXBwbGllZCwgb3V0ZXJTZXJ2ZXJTaHVmZmxlRnVuY3Rpb25FcGhlbWVyYWxLZXlBcHBsaWVkKSk7XHJcblxyXG4gICAgICAgICAgICAgbGV0IG91dGVyU2VydmVyU2h1ZmZsZUVwaGVtZXJhbEtleUFwcGxpZWQgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJTZXJ2ZXJTaHVmZmxlS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyU2VydmVyU2h1ZmZsZUVwaGVtZXJhbEtleSk7XHJcbiAgICAgICAgICAgICBsZXQgYWxwaGFQcmVwID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHRyYW5zZm9ybS5wZXJtdXRlT3V0ZXJUcmFuc2Zvcm1hdGlvbihhbHBoYWJldCwgb3V0ZXJTZXJ2ZXJTaHVmZmxlRXBoZW1lcmFsS2V5QXBwbGllZCksIHNlcnZlclNodWZmbGVFcGhlbWVyYWxLZXlBcHBsaWVkKTtcclxuICAgICAgICAgICAgIGxldCBvdXRlckZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5PdXRlckZ1bmN0aW9uS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyRnVuY3Rpb25FcGhlbWVyYWxLZXkpO1xyXG5cclxuICAgICAgICAgICAgIGFscGhhUHJlcCA9IHRyYW5zZm9ybS5zdWJzdGl0dXRlRnVuY3Rpb25PcGVyYW5kcyhcclxuICAgICAgICAgICAgICAgICBpZGVudGl0eU91dGVyRnVuY3Rpb25cclxuICAgICAgICAgICAgICAgICAsIGZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZFxyXG4gICAgICAgICAgICAgICAgICwgb3V0ZXJGdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWRcclxuICAgICAgICAgICAgICAgICAsIGFscGhhUHJlcFxyXG4gICAgICAgICAgICAgICAgICwgcGVyc2lzdGVudEtleXMuU2VydmVyS2V5XHJcbiAgICAgICAgICAgICAgICAgLCBlcGhlbWVyYWxLZXlzLlNlcnZlckVwaGVtZXJhbEtleVxyXG4gICAgICAgICAgICAgICAgICwgcGVyc2lzdGVudEtleXMuTXV0dWFsS2V5XHJcbiAgICAgICAgICAgICAgICAgLCBlcGhlbWVyYWxLZXlzLk11dHVhbEVwaGVtZXJhbEtleVxyXG4gICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgICBsZXQgc2VydmVyRGF0YSA9IHNlcnZlclJ4LnJlc29sdmVSeERhdGEocnhEYXRhLCBhbHBoYVByZXAsIGFscGhhYmV0KTsgLy9SZXZlcnQgUnggZGF0YSBiYWNrIGludG8gb3JpZ2luYWwgQXR0cmlidXRlIFZhbHVlcyBcclxuXHJcblxyXG4gICAgICAgICAgICAgLy8jaWYgQ0xJRU5UX1RPS0VOXHJcbiAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLCBUb2tlbktleS5EYXRhXHJcbiAgICAgICAgICAgICAvLyNlbmRpZlxyXG4gICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgIC8vICAgICAgICAgICAgfTsgLy9SZXZlcnQgUnggZGF0YSBiYWNrIGludG8gb3JpZ2luYWwgQXR0cmlidXRlIFZhbHVlcyBcclxuXHJcblxyXG4gICAgICAgICAgICAgcmV0dXJuIHNlcnZlckRhdGE7XHJcbiAgICAgICAgIH0gY2F0Y2ggKGV4KVxyXG4gICAgICAgICB7XHJcbiAgICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcIjgwMmQ5Y2I3LTk2OWEtNGE5Ny05ZDMzLTFiODdiNjBjNzA1OVwiKTtcclxuICAgICAgICAgICAgIHRocm93IGV4O1xyXG4gICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIHJlc29sdmVSeERhdGE6KHJ4RGF0YSwgYWxwaGFQcmVwLCBhbHBoYWJldCkgPT5cclxuICAgIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBsZXQgcmVzdWx0ID0gbmV3IEFycmF5KCk7XHJcblxyXG4gICAgICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IHJ4RGF0YS5sZW5ndGg7IHgrKykge1xyXG4gICAgICAgICAgICAgICAgbGV0IGZpbmRBcnJheSA9IHJ4RGF0YVt4XTtcclxuICAgICAgICAgICAgICAgIGxldCBtYXRjaCA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGEgPSAwOyBhIDwgYWxwaGFQcmVwLmxlbmd0aDsgYSsrKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8vaWYgKEFyY2FudW1Db21tb24uQ29tbW9uLkdldFN0cmluZyhhbHBoYVByZXBbYV0uVG9BcnJheSgpLCBcIixcIikgPT0gQXJjYW51bUNvbW1vbi5Db21tb24uR2V0U3RyaW5nKGZpbmRBcnJheSwgXCIsXCIpKVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChkYXJjQ29tbW9uLmFycmF5RWxlbWVudHNNYXRjaChhbHBoYVByZXBbYV0sIGZpbmRBcnJheSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWF0Y2ggPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaChhbHBoYWJldFthXSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKCFtYXRjaClcclxuICAgICAgICAgICAgICAgICAgICAvLyAgICByZXR1cm4gbnVsbDsgIC8vRmFpbHVyZSBhdCBhbnkgcG9pbnQgaXMgYSBjb21wbGV0ZSBmYWlsdXJlOyBEbyBub3QgY29udGludWUsIGFzIGl0IHdpbGwgb25seSBwcm92aWRlIGluc2lnaHQgZm9yIGhhY2tlcnMgdG8gZGV0ZXJtaW5lIHdoaWNoIGtleXMgbWlnaHQgbWF0Y2gsIHJldHVybiBudWxsLlxyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgIEZhaWxNYXRjaCA9IHRydWU7ICAvL0FkZGVkIGJlY2F1c2UsIGlmIHNvbWUgaW5wdXRzIGRvIG5vdCBtYXRjaCwgaXQgd2lsbCBza2lwIHRoZW0gYW5kIGNvbnRpbnVlLCB0aGVuIGdpdmUgYSBmYWxzZSBwb3NpdGl2ZSBpZiB0aGUgY29ycmVjdCBpbnB1dHMgYXBwZWFyIGluIHNlcXVlbmNlIGxhdGVyIGluIHRoZSBzdHJlYW0uXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfSBjYXRjaCAoZXgpIHtcclxuICAgICAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhleCwgXCI4MmQ0MWY1Yy01NTA3LTQ1NGYtYjQ2ZC04MDI2MGY4NDllNzhcIik7XHJcbiAgICAgICAgICAgIHRocm93IGV4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBzZXJ2ZXJSeDsiLCJpbXBvcnQgdHJhbnNmb3JtIGZyb20gJy4vdHJhbnNmb3JtLmpzJztcclxuaW1wb3J0IGRhcmNDb21tb24gZnJvbSAnLi9kYXJjQ29tbW9uLmpzJztcclxuaW1wb3J0IGNvbW1vbiBmcm9tICcuL2NvbW1vbi5qcyc7XHJcblxyXG5jb25zdCBzZXJ2ZXJUeCA9IHsgICAgICAgIFxyXG4gICAgdHJhbnNtaXQ6IChwZXJzaXN0ZW50S2V5cywgZXBoZW1lcmFsS2V5cywgYWxwaGFiZXQpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBsZXQgZGFyY0RhdGEgPSB7fTtcclxuXHJcbiAgICAgICAgICAgIGRhcmNEYXRhLkFscGhhYmV0RGF0YSA9IHRyYW5zbGF0ZURhdGEocGVyc2lzdGVudEtleXMsIGVwaGVtZXJhbEtleXMsIGFscGhhYmV0LCBmYWxzZSk7XHJcbiAgICAgICAgICAgIGRhcmNEYXRhLk1lZGl1bURhdGEgPSB0cmFuc2xhdGVNZWRpdW0ocGVyc2lzdGVudEtleXMsIGVwaGVtZXJhbEtleXMsIGZhbHNlKTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiBkYXJjRGF0YTtcclxuICAgICAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcIjY2YmM2MjU0LWY4NWMtNDQ3ZC1iZTE2LWM5MmY0ZDdiZDNiM1wiKTtcclxuICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59O1xyXG5cclxuZnVuY3Rpb24gdHJhbnNsYXRlTWVkaXVtKHBlcnNpc3RlbnRLZXlzLCBlcGhlbWVyYWxLZXlzKVxyXG57ICAgIFxyXG4gICAgdHJ5IHtcclxuICAgICAgICBsZXQgZnVuY3Rpb25FcGhlbWVyYWxLZXlBcHBsaWVkID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKHBlcnNpc3RlbnRLZXlzLkZ1bmN0aW9uTWVkaXVtS2V5LCBlcGhlbWVyYWxLZXlzLkZ1bmN0aW9uTWVkaXVtRXBoZW1lcmFsS2V5KTsgICAgICAgICAgICAgICAgIC8vQ3VzdG9tZXItU3BlY2lmaWMgVHJhbnNsYXRpb24gRnVuY3Rpb24gZGVmaW5pbmcgaG93IHRyYW5zbGF0aW9uIGlzIGFwcGxpZWQgdG8gZGF0YTsgSW5zdWxhdGVzIEN1c3RvbWVycyBmcm9tIG9uZSBhbm90aGVyOyBJbWJlZGRlZCBpbiBPYmZ1c2NhdGVkIEphdmEgU2NyaXB0IChXaWRnZXQpXHJcbiAgICAgICAgbGV0IGlucHV0RGF0YSA9IGRhcmNDb21tb24uaW5pdGlhbGl6ZU5ld0FycmF5KHBlcnNpc3RlbnRLZXlzLkZ1bmN0aW9uTWVkaXVtS2V5WzBdLmxlbmd0aCwgcGVyc2lzdGVudEtleXMuRnVuY3Rpb25NZWRpdW1LZXkubGVuZ3RoLCAwKTtcclxuICAgICAgICBsZXQgb3V0ZXJGdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWQgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJGdW5jdGlvbk1lZGl1bUtleSwgZXBoZW1lcmFsS2V5cy5PdXRlckZ1bmN0aW9uTWVkaXVtRXBoZW1lcmFsS2V5KTsgICAgICAgICAgICAgICAgIC8vQ3VzdG9tZXItU3BlY2lmaWMgVHJhbnNsYXRpb24gRnVuY3Rpb24gZGVmaW5pbmcgaG93IHRyYW5zbGF0aW9uIGlzIGFwcGxpZWQgdG8gZGF0YTsgSW5zdWxhdGVzIEN1c3RvbWVycyBmcm9tIG9uZSBhbm90aGVyOyBJbWJlZGRlZCBpbiBPYmZ1c2NhdGVkIEphdmEgU2NyaXB0IChXaWRnZXQpXHJcbiAgICAgICAgbGV0IG91dGVyRnVuY3Rpb25GdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWQgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJGdW5jdGlvbkZ1bmN0aW9uTWVkaXVtS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyRnVuY3Rpb25GdW5jdGlvbk1lZGl1bUVwaGVtZXJhbEtleSk7ICAgICAgICAgICAgICAgICAvL0N1c3RvbWVyLVNwZWNpZmljIFRyYW5zbGF0aW9uIEZ1bmN0aW9uIGRlZmluaW5nIGhvdyB0cmFuc2xhdGlvbiBpcyBhcHBsaWVkIHRvIGRhdGE7IEluc3VsYXRlcyBDdXN0b21lcnMgZnJvbSBvbmUgYW5vdGhlcjsgSW1iZWRkZWQgaW4gT2JmdXNjYXRlZCBKYXZhIFNjcmlwdCAoV2lkZ2V0KVxyXG5cclxuICAgICAgICBsZXQgdHhNZWRpdW0gPSB0cmFuc2Zvcm0uc3Vic3RpdHV0ZUZ1bmN0aW9uT3BlcmFuZHMoXHJcbiAgICAgICAgICAgIG91dGVyRnVuY3Rpb25GdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWRcclxuICAgICAgICAgICAgLCBmdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWRcclxuICAgICAgICAgICAgLCBvdXRlckZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZFxyXG4gICAgICAgICAgICAsIGlucHV0RGF0YVxyXG4gICAgICAgICAgICAsIHBlcnNpc3RlbnRLZXlzLlNlcnZlck1lZGl1bUtleVxyXG4gICAgICAgICAgICAsIGVwaGVtZXJhbEtleXMuU2VydmVyTWVkaXVtRXBoZW1lcmFsS2V5KTsgLy9CdWlsZCBkYXRhIGZvciBUeCAgICAgICBcclxuXHJcbiAgICAgICAgcmV0dXJuIHR4TWVkaXVtO1xyXG4gICAgfSBjYXRjaCAoZXgpIHtcclxuICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcIjQyNzI4ODMzLWYzODEtNDI2Yy1iYWI4LTU3YWVjYjVkYTU3OVwiKTtcclxuICAgICAgICB0aHJvdyBleDtcclxuICAgIH1cclxufVxyXG5cclxuLy8xKSBLZXkgUHJlcGFyYXRpb25zOyAyKSBPdXRlciBQZXJtdXRhdGlvbnM7IDMpIElubmVyIFBlcm11dGF0aW9uczsgNCkgU3Vic3RpdHV0aW9uc1xyXG5mdW5jdGlvbiB0cmFuc2xhdGVEYXRhKHBlcnNpc3RlbnRLZXlzLCBlcGhlbWVyYWxLZXlzLCBhbHBoYWJldClcclxueyAgICBcclxuICAgIHRyeSB7XHJcbiAgICAgICAgbGV0IGZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5GdW5jdGlvbktleSwgZXBoZW1lcmFsS2V5cy5GdW5jdGlvbkVwaGVtZXJhbEtleSk7ICAgICAgICAgICAgICAgICAvL0N1c3RvbWVyLVNwZWNpZmljIFRyYW5zbGF0aW9uIEZ1bmN0aW9uIGRlZmluaW5nIGhvdyB0cmFuc2xhdGlvbiBpcyBhcHBsaWVkIHRvIGRhdGE7IEluc3VsYXRlcyBDdXN0b21lcnMgZnJvbSBvbmUgYW5vdGhlcjsgSW1iZWRkZWQgaW4gT2JmdXNjYXRlZCBKYXZhIFNjcmlwdCAoV2lkZ2V0KVxyXG4gICAgICAgIGxldCBvdXRlckZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5PdXRlckZ1bmN0aW9uS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyRnVuY3Rpb25FcGhlbWVyYWxLZXkpOyAgICAgICAgICAgICAgICAgLy9DdXN0b21lci1TcGVjaWZpYyBUcmFuc2xhdGlvbiBGdW5jdGlvbiBkZWZpbmluZyBob3cgdHJhbnNsYXRpb24gaXMgYXBwbGllZCB0byBkYXRhOyBJbnN1bGF0ZXMgQ3VzdG9tZXJzIGZyb20gb25lIGFub3RoZXI7IEltYmVkZGVkIGluIE9iZnVzY2F0ZWQgSmF2YSBTY3JpcHQgKFdpZGdldClcclxuICAgICAgICBsZXQgb3V0ZXJGdW5jdGlvbkZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5PdXRlckZ1bmN0aW9uRnVuY3Rpb25LZXksIGVwaGVtZXJhbEtleXMuT3V0ZXJGdW5jdGlvbkZ1bmN0aW9uRXBoZW1lcmFsS2V5KTsgICAgICAgICAgICAgICAgIC8vQ3VzdG9tZXItU3BlY2lmaWMgVHJhbnNsYXRpb24gRnVuY3Rpb24gZGVmaW5pbmcgaG93IHRyYW5zbGF0aW9uIGlzIGFwcGxpZWQgdG8gZGF0YTsgSW5zdWxhdGVzIEN1c3RvbWVycyBmcm9tIG9uZSBhbm90aGVyOyBJbWJlZGRlZCBpbiBPYmZ1c2NhdGVkIEphdmEgU2NyaXB0IChXaWRnZXQpXHJcbiAgICAgICAgbGV0IG91dGVyU2VydmVyU2h1ZmZsZUVwaGVtZXJhbEtleUFwcGxpZWQgPSB0cmFuc2Zvcm0ucGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb24ocGVyc2lzdGVudEtleXMuT3V0ZXJTZXJ2ZXJTaHVmZmxlS2V5LCBlcGhlbWVyYWxLZXlzLk91dGVyU2VydmVyU2h1ZmZsZUVwaGVtZXJhbEtleSk7XHJcbiAgICAgICAgbGV0IG91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihwZXJzaXN0ZW50S2V5cy5PdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbktleSwgZXBoZW1lcmFsS2V5cy5PdXRlclNlcnZlclNodWZmbGVGdW5jdGlvbkVwaGVtZXJhbEtleSk7ICAgICAgICAgICAgICAgICAvL0N1c3RvbWVyLVNwZWNpZmljIFRyYW5zbGF0aW9uIEZ1bmN0aW9uIGRlZmluaW5nIGhvdyB0cmFuc2xhdGlvbiBpcyBhcHBsaWVkIHRvIGRhdGE7IEluc3VsYXRlcyBDdXN0b21lcnMgZnJvbSBvbmUgYW5vdGhlcjsgSW1iZWRkZWQgaW4gT2JmdXNjYXRlZCBKYXZhIFNjcmlwdCAoV2lkZ2V0KVxyXG5cclxuICAgICAgICAvLyNpZiBDTElFTlRfVE9LRU5cclxuICAgICAgICAvLyAgICAgICAgICAgIC8vSW4gQ2xpZW50XHJcbiAgICAgICAgLy8gICAgICAgICAgICAvL0RhdGFUcmFuc2xhdGlvbiBUb2tlbktleSA9ICgoRGF0YVRyYW5zbGF0aW9uQ2xpZW50VG9rZW4paW50ZXJBY3Rvci5HZXRBY3RvcihEYXRhVHJhbnNsYXRpb25JbmRleC5UcmFuc2xhdGlvbi5DbGllbnRUcmFuc2xhdGlvbikpLlRva2VuS2V5O1xyXG4gICAgICAgIC8vICAgICAgICAgICBEYXRhVHJhbnNsYXRpb24gVG9rZW5LZXkgPSBDbGllbnQuVG9rZW5LZXk7XHJcbiAgICAgICAgLy8jZW5kaWZcclxuXHJcbiAgICAgICAgbGV0IGlucHV0RGF0YSA9IHRyYW5zZm9ybS5wZXJtdXRlT3V0ZXJUcmFuc2Zvcm1hdGlvbihhbHBoYWJldCwgb3V0ZXJTZXJ2ZXJTaHVmZmxlRXBoZW1lcmFsS2V5QXBwbGllZCk7XHJcbiAgICAgICAgbGV0IHNlcnZlclNodWZmbGVFcGhlbWVyYWxLZXlBcHBsaWVkID0gdHJhbnNmb3JtLnBlcm11dGVJbm5lclRyYW5zZm9ybWF0aW9uKGVwaGVtZXJhbEtleXMuU2VydmVyU2h1ZmZsZUVwaGVtZXJhbEtleSwgcGVyc2lzdGVudEtleXMuU2VydmVyU2h1ZmZsZUtleSk7XHJcbiAgICAgICAgc2VydmVyU2h1ZmZsZUVwaGVtZXJhbEtleUFwcGxpZWQgPSB0cmFuc2Zvcm0ucGVybXV0ZU91dGVyVHJhbnNmb3JtYXRpb24oc2VydmVyU2h1ZmZsZUVwaGVtZXJhbEtleUFwcGxpZWQsIG91dGVyU2VydmVyU2h1ZmZsZUZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZCk7XHJcblxyXG4gICAgICAgIGlucHV0RGF0YSA9IHRyYW5zZm9ybS5wZXJtdXRlSW5uZXJUcmFuc2Zvcm1hdGlvbihpbnB1dERhdGEsIHNlcnZlclNodWZmbGVFcGhlbWVyYWxLZXlBcHBsaWVkKTtcclxuXHJcbiAgICAgICAgbGV0IHR4QWxwaGFiZXQgPSB0cmFuc2Zvcm0uc3Vic3RpdHV0ZUZ1bmN0aW9uT3BlcmFuZHMoXHJcbiAgICAgICAgICAgIG91dGVyRnVuY3Rpb25GdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWRcclxuICAgICAgICAgICAgLCBmdW5jdGlvbkVwaGVtZXJhbEtleUFwcGxpZWRcclxuICAgICAgICAgICAgLCBvdXRlckZ1bmN0aW9uRXBoZW1lcmFsS2V5QXBwbGllZFxyXG4gICAgICAgICAgICAsIGlucHV0RGF0YVxyXG4gICAgICAgICAgICAsIHBlcnNpc3RlbnRLZXlzLlNlcnZlcktleVxyXG4gICAgICAgICAgICAsIGVwaGVtZXJhbEtleXMuU2VydmVyRXBoZW1lcmFsS2V5XHJcblxyXG4gICAgICAgICAgICAvLyAgICAjaWYgQ0xJRU5UX1RPS0VOXHJcbiAgICAgICAgICAgIC8vICAgICAgICAvL19UT0RPLTg6IFJlbmFtZSB0byBDbGllbnRUcmFuc2xhdGlvblxyXG4gICAgICAgICAgICAvLyAgICAgICAgLCBUb2tlbktleS5EYXRhXHJcbiAgICAgICAgICAgIC8vI2VuZGlmXHJcbiAgICAgICAgKTsgLy9CdWlsZCBkYXRhIGZvciBUeCAgICAgIFxyXG5cclxuICAgICAgICByZXR1cm4gdHhBbHBoYWJldDtcclxuICAgIH0gY2F0Y2ggKGV4KSB7XHJcbiAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhleCwgXCI5NjY5NTRhNi03OTRlLTQ2ZDEtODgxNi1hMDcyOTIyYzAwY2ZcIik7XHJcbiAgICAgICAgdGhyb3cgZXg7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHNlcnZlclR4OyIsImltcG9ydCBkYXJjQ29tbW9uIGZyb20gJy4vZGFyY0NvbW1vbi5qcyc7XHJcbmltcG9ydCBjb21tb24gZnJvbSAnLi9jb21tb24uanMnO1xyXG5cclxuY29uc3QgdHJhbnNmb3JtID0ge1xyXG4gICAgXHJcbiAgICBwZXJtdXRlOihvcGVyYW5kLCBtYXApPT5cclxuICAgIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAoIW9wZXJhbmQpXHJcbiAgICAgICAgICAgICAgICB0aHJvdyBjb21tb24uY3JlYXRlRXJyb3JXaXRoTmtvZGVNZXRob2RJZGVudGlmaWVyKFwib3BlcmFuZCBpcyBudWxsIG9yIGVtcHR5XCIsIFwiNzYxM2E1OWEtNmI1OC00NDc4LTk1ZGQtNDgzZGNkZGZmNzllXCIpO1xyXG5cclxuICAgICAgICAgICAgaWYgKCFtYXApXHJcbiAgICAgICAgICAgICAgICB0aHJvdyBjb21tb24uY3JlYXRlRXJyb3JXaXRoTmtvZGVNZXRob2RJZGVudGlmaWVyKFwibWFwIGlzIG51bGwgb3IgZW1wdHlcIiwgXCI3NjEzYTU5YS02YjU4LTQ0NzgtOTVkZC00ODNkY2RkZmY3OWVcIik7XHJcblxyXG4gICAgICAgICAgICBpZiAob3BlcmFuZC5sZW5ndGggIT09IG1hcC5sZW5ndGgpXHJcbiAgICAgICAgICAgICAgICB0aHJvdyBjb21tb24uY3JlYXRlRXJyb3JXaXRoTmtvZGVNZXRob2RJZGVudGlmaWVyKFwiQXJndW1lbnRzIGFyZSBub3QgZXF1YWwgaW4gbGVuZ3RoXCIsIFwiNzYxM2E1OWEtNmI1OC00NDc4LTk1ZGQtNDgzZGNkZGZmNzllXCIpOyAgICAgICAgICAgICAgICBcclxuXHJcbiAgICAgICAgICAgIGxldCByZXN1bHQgPSBuZXcgQXJyYXkob3BlcmFuZC5sZW5ndGgpO1xyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCBtYXAubGVuZ3RoOyB4KyspXHJcbiAgICAgICAgICAgICAgICByZXN1bHRbeF0gPSBvcGVyYW5kW21hcFt4XV07XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgIH0gY2F0Y2ggKGV4KSB7XHJcbiAgICAgICAgICAgIGNvbW1vbi5hZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8oZXgsIFwiNzYxM2E1OWEtNmI1OC00NDc4LTk1ZGQtNDgzZGNkZGZmNzllXCIpO1xyXG4gICAgICAgICAgICB0aHJvdyBleDtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vb3BlcmFuZCBhbmQgbWFwIHNob3VsZCBib3RoIGJlIHR3byBkaW1lbnNpb25hbCBhcnJheXMgaGVyZVxyXG4gICAgcGVybXV0ZUlubmVyVHJhbnNmb3JtYXRpb246KG9wZXJhbmQsIG1hcCk9PlxyXG4gICAge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGlmICghb3BlcmFuZClcclxuICAgICAgICAgICAgICAgIHRocm93IGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJvcGVyYW5kIGlzIG51bGwgb3IgZW1wdHlcIiwgXCIyMjU5MDgzNy0wZGJmLTRkNWUtOWEyZi04MmZkOGFhYWQzMTFcIik7XHJcbiAgICAgICAgICAgIGlmICghbWFwKVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIm1hcCBpcyBudWxsIG9yIGVtcHR5XCIsIFwiMjI1OTA4MzctMGRiZi00ZDVlLTlhMmYtODJmZDhhYWFkMzExXCIpO1xyXG5cclxuICAgICAgICAgICAgLy9OT1RFOiBsZW5ndGggY29ycmVzcG9uZHMgdG8gaGVpZ2h0IHByb3BlcnR5IGluIEMjIGNsYXNzXHJcbiAgICAgICAgICAgIGlmIChvcGVyYW5kLmxlbmd0aCAhPT0gbWFwLmxlbmd0aCB8fCBkYXJjQ29tbW9uLmdldERhcmNLZXlMZW5ndGgob3BlcmFuZCkgIT09IGRhcmNDb21tb24uZ2V0RGFyY0tleUxlbmd0aChtYXApIC8qfHwgIW9wZXJhbmQuVmFsaWREYXRhIHx8ICFtYXAuVmFsaWREYXRhKi8pXHJcbiAgICAgICAgICAgICAgICB0aHJvdyBjb21tb24uY3JlYXRlRXJyb3JXaXRoTmtvZGVNZXRob2RJZGVudGlmaWVyKFwiQXJndW1lbnRzIGFyZSBub3QgZXF1YWwgaW4gbGVuZ3RoXCIsIFwiMjI1OTA4MzctMGRiZi00ZDVlLTlhMmYtODJmZDhhYWFkMzExXCIpO1xyXG5cclxuICAgICAgICAgICAgbGV0IHJlc3VsdCA9IG5ldyBBcnJheSgpO1xyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCBtYXAubGVuZ3RoOyB4KyspXHJcbiAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh0cmFuc2Zvcm0ucGVybXV0ZShvcGVyYW5kW3hdLCBtYXBbeF0pKTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfSBjYXRjaCAoZXgpIHtcclxuICAgICAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhleCwgXCIyMjU5MDgzNy0wZGJmLTRkNWUtOWEyZi04MmZkOGFhYWQzMTFcIik7XHJcbiAgICAgICAgICAgIHRocm93IGV4O1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBwZXJtdXRlT3V0ZXJUcmFuc2Zvcm1hdGlvbjoob3BlcmFuZCxtYXApID0+XHJcblx0e1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGlmICghb3BlcmFuZClcclxuICAgICAgICAgICAgICAgIHRocm93IGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJvcGVyYW5kIGlzIG51bGwgb3IgZW1wdHlcIiwgXCIyZjYxZDdlOS04YmIyLTQxYzUtODIyNS1jZWU2NTI3ZTU4ZDFcIik7XHJcbiAgICAgICAgICAgIGlmICghbWFwKVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIm1hcCBpcyBudWxsIG9yIGVtcHR5XCIsIFwiMmY2MWQ3ZTktOGJiMi00MWM1LTgyMjUtY2VlNjUyN2U1OGQxXCIpO1xyXG5cclxuICAgICAgICAgICAgLy9OT1RFOiBsZW5ndGggY29ycmVzcG9uZHMgdG8gaGVpZ2h0IHByb3BlcnR5IGluIEMjIGNsYXNzXHJcbiAgICAgICAgICAgIGlmIChkYXJjQ29tbW9uLmdldERhcmNLZXlMZW5ndGgobWFwKSAhPT0gb3BlcmFuZC5sZW5ndGggLyp8fCAhb3BlcmFuZC5WYWxpZERhdGEgfHwgIW1hcC5WYWxpZERhdGEqLylcclxuICAgICAgICAgICAgICAgIHRocm93IGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJBcmd1bWVudHMgYXJlIG5vdCBlcXVhbCBpbiBsZW5ndGhcIiwgXCIyZjYxZDdlOS04YmIyLTQxYzUtODIyNS1jZWU2NTI3ZTU4ZDFcIik7XHJcblxyXG4gICAgICAgICAgICBsZXQgcmVzdWx0ID0gdHJhbnNmb3JtLnBlcm11dGUob3BlcmFuZCwgZGFyY0NvbW1vbi5mbGF0dGVuVHdvRGltQXJyYXkobWFwKSk7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgIH0gY2F0Y2ggKGV4KSB7XHJcbiAgICAgICAgICAgIGNvbW1vbi5hZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8oZXgsIFwiMmY2MWQ3ZTktOGJiMi00MWM1LTgyMjUtY2VlNjUyN2U1OGQxXCIpO1xyXG4gICAgICAgICAgICB0aHJvdyBleDtcclxuICAgICAgICB9XHJcblx0fSxcclxuICAgICBwZXJtdXRlRnVuY3Rpb25NYXA6KG91dGVyUGVybXV0YXRpb25GdW5jdGlvbiwgb3BlcmFuZCwgbWFwKT0+XHJcbiAgICB7XHJcbiAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICBpZiAoIW91dGVyUGVybXV0YXRpb25GdW5jdGlvbilcclxuICAgICAgICAgICAgICAgICB0aHJvdyBjb21tb24uY3JlYXRlRXJyb3JXaXRoTmtvZGVNZXRob2RJZGVudGlmaWVyKFwib3V0ZXJQZXJtdXRhdGlvbkZ1bmN0aW9uIGlzIG51bGwgb3IgZW1wdHlcIiwgXCIyZWQwMmU2Ny1mNzQxLTQ1YjItOWM1OC0yZjI5ZDViNzJiMDJcIik7XHJcblxyXG4gICAgICAgICAgICAgaWYgKCFvcGVyYW5kKVxyXG4gICAgICAgICAgICAgICAgIHRocm93IGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJvcGVyYW5kIGlzIG51bGwgb3IgZW1wdHlcIiwgXCIyZWQwMmU2Ny1mNzQxLTQ1YjItOWM1OC0yZjI5ZDViNzJiMDJcIik7XHJcblxyXG4gICAgICAgICAgICAgaWYgKCFtYXApXHJcbiAgICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIm1hcCBpcyBudWxsIG9yIGVtcHR5XCIsIFwiMmVkMDJlNjctZjc0MS00NWIyLTljNTgtMmYyOWQ1YjcyYjAyXCIpO1xyXG5cclxuICAgICAgICAgICAgIGlmIChkYXJjQ29tbW9uLmdldERhcmNLZXlMZW5ndGgob3V0ZXJQZXJtdXRhdGlvbkZ1bmN0aW9uKSAhPT0gbWFwLmxlbmd0aCB8fCBvcGVyYW5kLmxlbmd0aCAhPT0gbWFwLmxlbmd0aCB8fCBkYXJjQ29tbW9uLmdldERhcmNLZXlMZW5ndGgob3BlcmFuZCkgIT0gZGFyY0NvbW1vbi5nZXREYXJjS2V5TGVuZ3RoKG1hcCkgLyp8fCAhb3V0ZXJQZXJtdXRhdGlvbkZ1bmN0aW9uLlZhbGlkRGF0YSB8fCAhb3BlcmFuZC5WYWxpZERhdGEgfHwgIW1hcC5WYWxpZERhdGEqLylcclxuICAgICAgICAgICAgICAgICB0aHJvdyBjb21tb24uY3JlYXRlRXJyb3JXaXRoTmtvZGVNZXRob2RJZGVudGlmaWVyKFwiQXJndW1lbnRzIGFyZSBub3QgZXF1YWwgaW4gbGVuZ3RoXCIsIFwiMmVkMDJlNjctZjc0MS00NWIyLTljNTgtMmYyOWQ1YjcyYjAyXCIpO1xyXG5cclxuICAgICAgICAgICAgIGxldCBvdXRlclNodWZGdW5jID0gZGFyY0NvbW1vbi5mbGF0dGVuVHdvRGltQXJyYXkob3V0ZXJQZXJtdXRhdGlvbkZ1bmN0aW9uKTtcclxuXHJcbiAgICAgICAgICAgICBsZXQgcmVzdWx0ID0gbmV3IEFycmF5KCk7XHJcblxyXG4gICAgICAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCBtYXAubGVuZ3RoOyB4KyspXHJcbiAgICAgICAgICAgICAgICAgcmVzdWx0LnB1c2godHJhbnNmb3JtLnBlcm11dGUob3BlcmFuZFt4XSwgbWFwW291dGVyU2h1ZkZ1bmNbeF1dKSk7XHJcblxyXG4gICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgICAgICAgfSBjYXRjaCAoZXgpIHtcclxuICAgICAgICAgICAgIGNvbW1vbi5hZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8oZXgsIFwiMmVkMDJlNjctZjc0MS00NWIyLTljNTgtMmYyOWQ1YjcyYjAyXCIpO1xyXG4gICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgcGVybXV0ZUZ1bmN0aW9uT3BlcmFuZDoob3V0ZXJQZXJtdXRhdGlvbkZ1bmN0aW9uLCBvcGVyYW5kLCBtYXApPT5cclxuICAgIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAoIW91dGVyUGVybXV0YXRpb25GdW5jdGlvbilcclxuICAgICAgICAgICAgICAgIHRocm93IGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJvdXRlclBlcm11dGF0aW9uRnVuY3Rpb24gaXMgbnVsbCBvciBlbXB0eVwiLCBcIjQxMGNmYjkzLWNkMTktNGVmNC1iMjI3LWYzNThiYWVlNGE5NVwiKTtcclxuXHJcbiAgICAgICAgICAgIGlmICghb3BlcmFuZClcclxuICAgICAgICAgICAgICAgIHRocm93IGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJvcGVyYW5kIGlzIG51bGwgb3IgZW1wdHlcIiwgXCI0MTBjZmI5My1jZDE5LTRlZjQtYjIyNy1mMzU4YmFlZTRhOTVcIik7XHJcblxyXG4gICAgICAgICAgICBpZiAoIW1hcClcclxuICAgICAgICAgICAgICAgIHRocm93IGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJtYXAgaXMgbnVsbCBvciBlbXB0eVwiLCBcIjQxMGNmYjkzLWNkMTktNGVmNC1iMjI3LWYzNThiYWVlNGE5NVwiKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChkYXJjQ29tbW9uLmdldERhcmNLZXlMZW5ndGgob3V0ZXJQZXJtdXRhdGlvbkZ1bmN0aW9uKSAhPT0gbWFwLmxlbmd0aCB8fCBvcGVyYW5kLmxlbmd0aCAhPT0gbWFwLmxlbmd0aCB8fCBkYXJjQ29tbW9uLmdldERhcmNLZXlMZW5ndGgob3BlcmFuZCkgIT0gZGFyY0NvbW1vbi5nZXREYXJjS2V5TGVuZ3RoKG1hcCkgLyp8fCAhb3V0ZXJQZXJtdXRhdGlvbkZ1bmN0aW9uLlZhbGlkRGF0YSB8fCAhb3BlcmFuZC5WYWxpZERhdGEgfHwgIW1hcC5WYWxpZERhdGEqLylcclxuICAgICAgICAgICAgICAgIHRocm93IGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJBcmd1bWVudHMgYXJlIG5vdCBlcXVhbCBpbiBsZW5ndGhcIiwgXCI0MTBjZmI5My1jZDE5LTRlZjQtYjIyNy1mMzU4YmFlZTRhOTVcIik7XHJcblxyXG4gICAgICAgICAgICBsZXQgb3V0ZXJTaHVmRnVuYyA9IGRhcmNDb21tb24uZmxhdHRlblR3b0RpbUFycmF5KG91dGVyUGVybXV0YXRpb25GdW5jdGlvbik7XHJcblxyXG4gICAgICAgICAgICBsZXQgcmVzdWx0ID0gbmV3IEFycmF5KCk7XHJcblxyXG4gICAgICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IG1hcC5sZW5ndGg7IHgrKylcclxuICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHRyYW5zZm9ybS5wZXJtdXRlKG9wZXJhbmRbb3V0ZXJTaHVmRnVuY1t4XV0sIG1hcFt4XSkpO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgICAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcIjQxMGNmYjkzLWNkMTktNGVmNC1iMjI3LWYzNThiYWVlNGE5NVwiKTtcclxuICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICB0cmFuc2Zvcm1hdGlvbkNvbXBsaW1lbnQ6KG1hcCk9PlxyXG4gICAge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGlmICghbWFwKVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIm1hcCBpcyBudWxsIG9yIGVtcHR5XCIsIFwiNmVlNzc1NjMtMGU5Yy00ZTA1LWE1ZDEtYTQwYjE3NWIzMWI5XCIpO1xyXG5cclxuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkobWFwWzBdKSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHJlc3VsdCA9IG5ldyBBcnJheSgpO1xyXG5cclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGggPSAwOyBoIDwgbWFwLmxlbmd0aDsgaCsrKVxyXG4gICAgICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHRyYW5zZm9ybS50cmFuc2Zvcm1hdGlvbkNvbXBsaW1lbnQobWFwW2hdKSk7XHJcblxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGxldCByZXN1bHQgPSBuZXcgQXJyYXkobWFwLmxlbmd0aCk7XHJcblxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCBtYXAubGVuZ3RoOyB4KyspXHJcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0W21hcFt4XV0gPSB4O1xyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcIjZlZTc3NTYzLTBlOWMtNGUwNS1hNWQxLWE0MGIxNzViMzFiOVwiKTtcclxuICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICBzdWJzdGl0dXRlOihvcGVyYW5kX0EsIG9wZXJhbmRfQik9PlxyXG4gICAge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGlmICghb3BlcmFuZF9BKVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIm9wZXJhbmRfQSBpcyBudWxsIG9yIGVtcHR5XCIsIFwiZDI5YjI4NTEtNWI2YS00MjYwLWI0YTItOTEwZWU5NTdkMTZlXCIpO1xyXG5cclxuICAgICAgICAgICAgaWYgKCFvcGVyYW5kX0IpXHJcbiAgICAgICAgICAgICAgICB0aHJvdyBjb21tb24uY3JlYXRlRXJyb3JXaXRoTmtvZGVNZXRob2RJZGVudGlmaWVyKFwib3BlcmFuZF9CIGlzIG51bGwgb3IgZW1wdHlcIiwgXCJkMjliMjg1MS01YjZhLTQyNjAtYjRhMi05MTBlZTk1N2QxNmVcIik7XHJcblxyXG4gICAgICAgICAgICBpZiAob3BlcmFuZEFEYXJjS2V5TGVuZ3RoICE9PSBkYXJjQ29tbW9uLmdldERhcmNLZXlMZW5ndGgob3BlcmFuZF9CKSlcclxuICAgICAgICAgICAgICAgIHRocm93IGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJBcmd1bWVudHMgYXJlIG5vdCBlcXVhbCBpbiBsZW5ndGhcIiwgXCJkMjliMjg1MS01YjZhLTQyNjAtYjRhMi05MTBlZTk1N2QxNmVcIik7XHJcblxyXG4gICAgICAgICAgICBsZXQgb3BlcmFuZEFEYXJjS2V5TGVuZ3RoID0gZGFyY0NvbW1vbi5nZXREYXJjS2V5TGVuZ3RoKG9wZXJhbmRfQSk7XHJcblxyXG4gICAgICAgICAgICBsZXQgcmVzdWx0ID0gbmV3IEFycmF5KG9wZXJhbmRBRGFyY0tleUxlbmd0aCk7XHJcblxyXG4gICAgICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IG9wZXJhbmRBRGFyY0tleUxlbmd0aDsgeCsrKVxyXG4gICAgICAgICAgICAgICAgcmVzdWx0W3hdID0gb3BlcmFuZF9BW3hdIF4gb3BlcmFuZF9CW3hdO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgICAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcImQyOWIyODUxLTViNmEtNDI2MC1iNGEyLTkxMGVlOTU3ZDE2ZVwiKTtcclxuICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBzdWJzdGl0dXRlT3BlcmFuZHM6KG9wZXJhbmQsIC4uLm9wZXJhbmRzKT0+XHJcbiAgICB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKCFvcGVyYW5kKVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIm9wZXJhbmQgaXMgbnVsbCBvciBlbXB0eVwiLCBcIjdmNzU5YTE1LTU1NjktNDBjOC05NjNiLWRjMjk1NDdjZDYzNVwiKTtcclxuXHJcbiAgICAgICAgICAgIGlmICghb3BlcmFuZHMpXHJcbiAgICAgICAgICAgICAgICB0aHJvdyBjb21tb24uY3JlYXRlRXJyb3JXaXRoTmtvZGVNZXRob2RJZGVudGlmaWVyKFwib3BlcmFuZHMgaXMgbnVsbCBvciBlbXB0eVwiLCBcIjdmNzU5YTE1LTU1NjktNDBjOC05NjNiLWRjMjk1NDdjZDYzNVwiKTtcclxuXHJcbiAgICAgICAgICAgIGZvciAobGV0IHggPSAwOyB4IDwgb3BlcmFuZHMubGVuZ3RoOyB4KyspXHJcbiAgICAgICAgICAgICAgICBvcGVyYW5kID0gc3Vic3RpdHV0ZU9wZXJhbmQob3BlcmFuZCwgb3BlcmFuZHNbeF0pO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIG9wZXJhbmQ7XHJcbiAgICAgICAgfSBjYXRjaCAoZXgpIHtcclxuICAgICAgICAgICAgY29tbW9uLmFkZE5Lb2RlTWV0aG9kSWRlbnRpZmllclN0YWNrSW5mbyhleCwgXCI3Zjc1OWExNS01NTY5LTQwYzgtOTYzYi1kYzI5NTQ3Y2Q2MzVcIik7XHJcbiAgICAgICAgICAgIHRocm93IGV4O1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgIHN1YnN0aXR1dGVPcGVyYW5kOihvcGVyYW5kX0EsIG9wZXJhbmRfQik9PlxyXG4gICAge1xyXG4gICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgaWYgKCFvcGVyYW5kX0EpXHJcbiAgICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIm9wZXJhbmRfQSBpcyBudWxsIG9yIGVtcHR5XCIsIFwiZGE0MGRmODAtZTg5NS00NzUwLTliYzUtOGQxZWExM2IwY2Y4XCIpO1xyXG4gICAgICAgICAgICAgaWYgKCFvcGVyYW5kX0IpXHJcbiAgICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIm9wZXJhbmRfQiBpcyBudWxsIG9yIGVtcHR5XCIsIFwiZGE0MGRmODAtZTg5NS00NzUwLTliYzUtOGQxZWExM2IwY2Y4XCIpO1xyXG5cclxuICAgICAgICAgICAgIGxldCByZXN1bHQgPSBuZXcgQXJyYXkoKTtcclxuXHJcbiAgICAgICAgICAgICBpZiAob3BlcmFuZF9BLmxlbmd0aCAhPT0gb3BlcmFuZF9CLmxlbmd0aCB8fCBkYXJjQ29tbW9uLmdldERhcmNLZXlMZW5ndGgob3BlcmFuZF9BKSAhPT0gZGFyY0NvbW1vbi5nZXREYXJjS2V5TGVuZ3RoKG9wZXJhbmRfQikgLyp8fCAhb3BlcmFuZF9BLlZhbGlkRGF0YSB8fCAhb3BlcmFuZF9CLlZhbGlkRGF0YSovKVxyXG4gICAgICAgICAgICAgICAgIHRocm93IGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJBcmd1bWVudHMgYXJlIG5vdCBlcXVhbCBpbiBsZW5ndGhcIiwgXCJkYTQwZGY4MC1lODk1LTQ3NTAtOWJjNS04ZDFlYTEzYjBjZjhcIik7XHJcblxyXG4gICAgICAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCBvcGVyYW5kX0EubGVuZ3RoOyB4KyspXHJcbiAgICAgICAgICAgICAgICAgcmVzdWx0LlZhbHVlcy5BZGQoc3Vic3RpdHV0ZShvcGVyYW5kX0FbeF0sIG9wZXJhbmRfQlt4XSkpO1xyXG5cclxuICAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgIH0gY2F0Y2ggKGV4KSB7XHJcbiAgICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcImRhNDBkZjgwLWU4OTUtNDc1MC05YmM1LThkMWVhMTNiMGNmOFwiKTtcclxuICAgICAgICAgICAgIHRocm93IGV4O1xyXG4gICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuXHJcblxyXG4gICAgc3Vic3RpdHV0ZUZ1bmN0aW9uOihmdW5jdGlvbktleXMsIG9wZXJhbmRfQSwgb3BlcmFuZF9CKT0+XHJcbiAgICB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKCFmdW5jdGlvbktleXMpXHJcbiAgICAgICAgICAgICAgICB0aHJvdyBjb21tb24uY3JlYXRlRXJyb3JXaXRoTmtvZGVNZXRob2RJZGVudGlmaWVyKFwiZnVuY3Rpb25LZXlzIGlzIG51bGwgb3IgZW1wdHlcIiwgXCIwZjg1N2UyZC1lNzUwLTRkYTUtOWZlZi0xMWNjZjQ3ZDIyOWNcIik7XHJcblxyXG4gICAgICAgICAgICBpZiAoIW9wZXJhbmRfQSlcclxuICAgICAgICAgICAgICAgIHRocm93IGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJvcGVyYW5kX0EgaXMgbnVsbCBvciBlbXB0eVwiLCBcIjBmODU3ZTJkLWU3NTAtNGRhNS05ZmVmLTExY2NmNDdkMjI5Y1wiKTtcclxuXHJcbiAgICAgICAgICAgIGlmICghb3BlcmFuZF9CKVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIm9wZXJhbmRfQiBpcyBudWxsIG9yIGVtcHR5XCIsIFwiMGY4NTdlMmQtZTc1MC00ZGE1LTlmZWYtMTFjY2Y0N2QyMjljXCIpO1xyXG5cclxuICAgICAgICAgICAgbGV0IG9wZXJhbmRBRGFyY0tleUxlbmd0aCA9IGRhcmNDb21tb24uZ2V0RGFyY0tleUxlbmd0aChvcGVyYW5kX0EpO1xyXG4gICAgICAgICAgICBsZXQgcmVzdWx0ID0gbmV3IEFycmF5KG9wZXJhbmRBRGFyY0tleUxlbmd0aCk7XHJcblxyXG4gICAgICAgICAgICBpZiAob3BlcmFuZEFEYXJjS2V5TGVuZ3RoICE9PSBkYXJjQ29tbW9uLmdldERhcmNLZXlMZW5ndGgoZnVuY3Rpb25LZXlzKSB8fCBkYXJjQ29tbW9uLmdldERhcmNLZXlMZW5ndGgob3BlcmFuZF9CKSAhPT0gZGFyY0NvbW1vbi5nZXREYXJjS2V5TGVuZ3RoKGZ1bmN0aW9uS2V5cykpXHJcbiAgICAgICAgICAgICAgICB0aHJvdyBjb21tb24uY3JlYXRlRXJyb3JXaXRoTmtvZGVNZXRob2RJZGVudGlmaWVyKFwiQXJndW1lbnRzIGFyZSBub3QgZXF1YWwgaW4gbGVuZ3RoXCIsIFwiMGY4NTdlMmQtZTc1MC00ZGE1LTlmZWYtMTFjY2Y0N2QyMjljXCIpO1xyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCBvcGVyYW5kQURhcmNLZXlMZW5ndGg7IHgrKykge1xyXG4gICAgICAgICAgICAgICAgbGV0IG5ld1ZhbCA9IG9wZXJhbmRfQVt4XSBeIG9wZXJhbmRfQltmdW5jdGlvbktleXNbeF1dO1xyXG4gICAgICAgICAgICAgICAgcmVzdWx0W3hdID0gbmV3VmFsO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgIH0gY2F0Y2ggKGV4KSB7XHJcbiAgICAgICAgICAgIGNvbW1vbi5hZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8oZXgsIFwiMGY4NTdlMmQtZTc1MC00ZGE1LTlmZWYtMTFjY2Y0N2QyMjljXCIpO1xyXG4gICAgICAgICAgICB0aHJvdyBleDtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIHN1YnN0aXR1dGVGdW5jdGlvbk9wZXJhbmRzOihvdXRlckZ1bmN0aW9uRnVuY3Rpb24sIGlubmVyRnVuY3Rpb24sIG91dGVyRnVuY3Rpb24sIG9wZXJhbmQsIC4uLm9wZXJhbmRzKT0+XHJcbiAgICB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKCFvdXRlckZ1bmN0aW9uRnVuY3Rpb24pXHJcbiAgICAgICAgICAgICAgICB0aHJvdyBjb21tb24uY3JlYXRlRXJyb3JXaXRoTmtvZGVNZXRob2RJZGVudGlmaWVyKFwib3V0ZXJGdW5jdGlvbkZ1bmN0aW9uIGlzIG51bGwgb3IgZW1wdHlcIiwgXCI5ZjhkMDUyMi0zZWQ1LTRkNzEtYTFjNC0zNWJhMzYzMzQzMzVcIik7XHJcblxyXG4gICAgICAgICAgICBpZiAoIWlubmVyRnVuY3Rpb24pXHJcbiAgICAgICAgICAgICAgICB0aHJvdyBjb21tb24uY3JlYXRlRXJyb3JXaXRoTmtvZGVNZXRob2RJZGVudGlmaWVyKFwiaW5uZXJGdW5jdGlvbiBpcyBudWxsIG9yIGVtcHR5XCIsIFwiOWY4ZDA1MjItM2VkNS00ZDcxLWExYzQtMzViYTM2MzM0MzM1XCIpO1xyXG5cclxuICAgICAgICAgICAgaWYgKCFvdXRlckZ1bmN0aW9uKVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIm91dGVyRnVuY3Rpb24gaXMgbnVsbCBvciBlbXB0eVwiLCBcIjlmOGQwNTIyLTNlZDUtNGQ3MS1hMWM0LTM1YmEzNjMzNDMzNVwiKTtcclxuXHJcbiAgICAgICAgICAgIGlmICghb3BlcmFuZClcclxuICAgICAgICAgICAgICAgIHRocm93IGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJvcGVyYW5kIGlzIG51bGwgb3IgZW1wdHlcIiwgXCI5ZjhkMDUyMi0zZWQ1LTRkNzEtYTFjNC0zNWJhMzYzMzQzMzVcIik7XHJcblxyXG4gICAgICAgICAgICBpZiAoIW9wZXJhbmRzKVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIm9wZXJhbmRzIGlzIG51bGwgb3IgZW1wdHlcIiwgXCI5ZjhkMDUyMi0zZWQ1LTRkNzEtYTFjNC0zNWJhMzYzMzQzMzVcIik7XHJcblxyXG4gICAgICAgICAgICBpZiAoZGFyY0NvbW1vbi5nZXREYXJjS2V5TGVuZ3RoKG91dGVyRnVuY3Rpb25GdW5jdGlvbikgIT09IGlubmVyRnVuY3Rpb24ubGVuZ3RoIHx8IGRhcmNDb21tb24uZ2V0RGFyY0tleUxlbmd0aChvdXRlckZ1bmN0aW9uKSAhPT0gb3BlcmFuZC5sZW5ndGggLyp8fCAhb3V0ZXJGdW5jdGlvbkZ1bmN0aW9uLlZhbGlkRGF0YSB8fCAhb3V0ZXJGdW5jdGlvbi5WYWxpZERhdGEqLylcclxuICAgICAgICAgICAgICAgIHRocm93IGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJBcmd1bWVudHMgYXJlIG5vdCBlcXVhbCBpbiBsZW5ndGhcIiwgXCI5ZjhkMDUyMi0zZWQ1LTRkNzEtYTFjNC0zNWJhMzYzMzQzMzVcIik7XHJcblxyXG4gICAgICAgICAgICBsZXQgb3V0ZXJGdW5jRnVuYyA9IGRhcmNDb21tb24uZmxhdHRlblR3b0RpbUFycmF5KG91dGVyRnVuY3Rpb25GdW5jdGlvbik7XHJcbiAgICAgICAgICAgIGxldCBvdXRlckZ1bmMgPSBkYXJjQ29tbW9uLmZsYXR0ZW5Ud29EaW1BcnJheShvdXRlckZ1bmN0aW9uKTtcclxuXHJcbiAgICAgICAgICAgIGZvciAobGV0IHggPSAwOyB4IDwgb3BlcmFuZHMubGVuZ3RoOyB4KyspXHJcbiAgICAgICAgICAgICAgICBvcGVyYW5kID0gdHJhbnNmb3JtLnN1YnN0aXR1dGVGdW5jdGlvbk9wZXJhbmQob3V0ZXJGdW5jRnVuYywgaW5uZXJGdW5jdGlvbiwgb3V0ZXJGdW5jLCBvcGVyYW5kLCBvcGVyYW5kc1t4XSk7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gb3BlcmFuZDtcclxuICAgICAgICB9IGNhdGNoIChleCkge1xyXG4gICAgICAgICAgICBjb21tb24uYWRkTktvZGVNZXRob2RJZGVudGlmaWVyU3RhY2tJbmZvKGV4LCBcIjlmOGQwNTIyLTNlZDUtNGQ3MS1hMWM0LTM1YmEzNjMzNDMzNVwiKTtcclxuICAgICAgICAgICAgdGhyb3cgZXg7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBzdWJzdGl0dXRlRnVuY3Rpb25PcGVyYW5kOihvdXRlckZ1bmN0aW9uRnVuY3Rpb24sIGlubmVyRnVuY3Rpb24sIG91dGVyRnVuY3Rpb24sIG9wZXJhbmRfQSwgIG9wZXJhbmRfQik9PlxyXG4gICAge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGlmICghb3V0ZXJGdW5jdGlvbkZ1bmN0aW9uKVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIm91dGVyRnVuY3Rpb25GdW5jdGlvbiBpcyBudWxsIG9yIGVtcHR5XCIsIFwiYTkxOTE2M2MtYzVlMi00Yjk3LTlmYzMtNjczYjkzMzE1ZWNjXCIpO1xyXG5cclxuICAgICAgICAgICAgaWYgKCFpbm5lckZ1bmN0aW9uKVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcImlubmVyRnVuY3Rpb24gaXMgbnVsbCBvciBlbXB0eVwiLCBcImE5MTkxNjNjLWM1ZTItNGI5Ny05ZmMzLTY3M2I5MzMxNWVjY1wiKTtcclxuXHJcbiAgICAgICAgICAgIGlmICghb3V0ZXJGdW5jdGlvbilcclxuICAgICAgICAgICAgICAgIHRocm93IGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJvdXRlckZ1bmN0aW9uIGlzIG51bGwgb3IgZW1wdHlcIiwgXCJhOTE5MTYzYy1jNWUyLTRiOTctOWZjMy02NzNiOTMzMTVlY2NcIik7XHJcblxyXG4gICAgICAgICAgICBpZiAoIW9wZXJhbmRfQSlcclxuICAgICAgICAgICAgICAgIHRocm93IGNvbW1vbi5jcmVhdGVFcnJvcldpdGhOa29kZU1ldGhvZElkZW50aWZpZXIoXCJvcGVyYW5kX0EgaXMgbnVsbCBvciBlbXB0eVwiLCBcImE5MTkxNjNjLWM1ZTItNGI5Ny05ZmMzLTY3M2I5MzMxNWVjY1wiKTtcclxuXHJcbiAgICAgICAgICAgIGlmICghb3BlcmFuZF9CKVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIm9wZXJhbmRfQiBpcyBudWxsIG9yIGVtcHR5XCIsIFwiYTkxOTE2M2MtYzVlMi00Yjk3LTlmYzMtNjczYjkzMzE1ZWNjXCIpO1xyXG5cclxuICAgICAgICAgICAgbGV0IHJlc3VsdCA9IG5ldyBBcnJheSgpO1xyXG5cclxuICAgICAgICAgICAgaWYgKG9wZXJhbmRfQS5sZW5ndGggIT09IGlubmVyRnVuY3Rpb24ubGVuZ3RoIHx8IG9wZXJhbmRfQi5sZW5ndGggIT09IGlubmVyRnVuY3Rpb24ubGVuZ3RoIHx8IGRhcmNDb21tb24uZ2V0RGFyY0tleUxlbmd0aChvcGVyYW5kX0EpICE9PSBkYXJjQ29tbW9uLmdldERhcmNLZXlMZW5ndGgoaW5uZXJGdW5jdGlvbikgfHwgZGFyY0NvbW1vbi5nZXREYXJjS2V5TGVuZ3RoKG9wZXJhbmRfQikgIT09IGRhcmNDb21tb24uZ2V0RGFyY0tleUxlbmd0aChpbm5lckZ1bmN0aW9uKSAvKnx8ICFvcGVyYW5kX0EuVmFsaWREYXRhIHx8ICFvcGVyYW5kX0IuVmFsaWREYXRhIHx8ICFpbm5lckZ1bmN0aW9uLlZhbGlkRGF0YSovKVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgY29tbW9uLmNyZWF0ZUVycm9yV2l0aE5rb2RlTWV0aG9kSWRlbnRpZmllcihcIkFyZ3VtZW50cyBhcmUgbm90IGVxdWFsIGluIGxlbmd0aFwiLCBcImE5MTkxNjNjLWM1ZTItNGI5Ny05ZmMzLTY3M2I5MzMxNWVjY1wiKTtcclxuXHJcbiAgICAgICAgICAgIGZvciAobGV0IHggPSAwOyB4IDwgb3BlcmFuZF9BLmxlbmd0aDsgeCsrKVxyXG4gICAgICAgICAgICAgICAgcmVzdWx0LnB1c2godHJhbnNmb3JtLnN1YnN0aXR1dGVGdW5jdGlvbihpbm5lckZ1bmN0aW9uW291dGVyRnVuY3Rpb25GdW5jdGlvblt4XV0sIG9wZXJhbmRfQVt4XSwgb3BlcmFuZF9CW291dGVyRnVuY3Rpb25beF1dKSk7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgIH0gY2F0Y2ggKGV4KSB7XHJcbiAgICAgICAgICAgIGNvbW1vbi5hZGROS29kZU1ldGhvZElkZW50aWZpZXJTdGFja0luZm8oZXgsIFwiYTkxOTE2M2MtYzVlMi00Yjk3LTlmYzMtNjczYjkzMzE1ZWNjXCIpO1xyXG4gICAgICAgICAgICB0aHJvdyBleDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgdHJhbnNmb3JtOyJdLCJzb3VyY2VSb290IjoiIn0=

/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! R:\Users\dannypopov\Documents\Visual Studio 2017\Projects\NKod\NKodeAdminPortal\nKodeAdminAngular\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map