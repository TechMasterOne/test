﻿using ArcanumTechnology.nKode;
using ArcanumTechnology.nKode.ServerDataProviders;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Web;

namespace NKodeAdminPortal
{
    
    public static class Utils
    {
        public const string PermissionIdsTokenString = "permissionIds";

     

        public static string GetHash(string input)
        {
            HashAlgorithm hashAlgorithm = new SHA256CryptoServiceProvider();

            byte[] byteValue = System.Text.Encoding.UTF8.GetBytes(input);

            byte[] byteHash = hashAlgorithm.ComputeHash(byteValue);

            return Convert.ToBase64String(byteHash);
        }

        public static Guid[] GetAllCustomerAccessGuids(this ClaimsIdentity claimsIdentity)
        {
            return claimsIdentity.FindAll(x => x.Type == NKodRoleClaim.CustomerGUIDClaimType).Select(x => Guid.Parse(x.Value)).ToArray();
        }

        public static int[] GetAllCanManageRoleIds(this ClaimsIdentity claimsIdentity)
        {
            return claimsIdentity.FindAll(x => x.Type == NKodRoleClaim.CanAddRemoveRoleIdClaimType).Select(x => int.Parse(x.Value)).ToArray();
        }

        public static bool HasPermission(this ClaimsIdentity claimsIdentity, params Permissions[] permissions)
        {
            IEnumerable<Permissions> userPermissions = claimsIdentity.Claims.Where(x => x.Type == NKodRoleClaim.PermissionIdClaimType).Select(x => (Permissions)int.Parse(x.Value));
                        
            return permissions.Any(x => userPermissions.Any(y => y == x));
        }

        public static bool UserCanAccessCustomer(Guid customer)
        {
            Guid[] customersUserCanAccess = GetCustomerAccessGuidsForUser();
            return customersUserCanAccess == null || customersUserCanAccess.Contains(customer);            
        }

        /// <summary>
        /// Returns null if the user can access all customers otherwise the list of customer GUIDs the user can access
        /// </summary>
        /// <returns></returns>
        public static Guid[] GetCustomerAccessGuidsForUser()
        {
            Guid[] customerFilter = null;
            ClaimsIdentity claimsIdentity = (HttpContext.Current.User.Identity as ClaimsIdentity);
            if (claimsIdentity.HasClaim(x => x.Type == NKodRoleClaim.AllCustomerAccessClaimType) || claimsIdentity.HasPermission(Permissions.All))
            {
                //Leave customer filter null--user can access all customers
            }
            else
            {
                customerFilter = claimsIdentity.GetAllCustomerAccessGuids();
                if (!customerFilter.Any()) //There are no customers explicitly listed, just allow access to the customer the user is associated with
                    customerFilter = new Guid[] { Guid.Parse(claimsIdentity.FindFirst(x => x.Type == "CustomerGUID").Value) };
            }

            return customerFilter;
        }

        /// <summary>
        /// Gets the roles the current user can manage
        /// </summary>
        /// <returns>Returns null if the user can manage all roles otherwise the list of role ids the user can manage</returns>
        public static int[] GetCanManageRoleIdsForUser()
        {
            int[] roleFilter = null;
            ClaimsIdentity claimsIdentity = (HttpContext.Current.User.Identity as ClaimsIdentity);
            if (claimsIdentity.HasPermission(Permissions.All))
            {
                //Leave customer filter null--user can access all customers
            }
            else
            {
                roleFilter = claimsIdentity.GetAllCanManageRoleIds();
                if (!roleFilter.Any()) //There are no customers explicitly listed, just allow access to the customer the user is associated with
                    roleFilter = new int[0];
            }

            return roleFilter;
        }

        public static string ToJSArrayString(this List<List<int>> data)
        {
            return JsonConvert.SerializeObject(data);
        }

        public static string ToJSArrayString(this List<List<byte>> data)
        {
            return JsonConvert.SerializeObject(data);
        }

        public static string ToJSArrayString(this List<int> data)
        {
            return JsonConvert.SerializeObject(data);
        }

        public static string ToJSArrayString(this List<byte> data)
        {
            return JsonConvert.SerializeObject(data);
        }
    }
}