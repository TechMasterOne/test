﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Web;

namespace NKodeAdminPortal
{
    public class EventLogWriter
    {
        private string _eventLogSourceName;

        public EventLogWriter(string eventLogSourceName)
        {
            _eventLogSourceName = eventLogSourceName;

            EnsureEventLogExists(eventLogSourceName, "Application");
        }

        public EventLogWriter(string eventLogSourceName, string eventLogName)
        {
            _eventLogSourceName = eventLogSourceName;

            EnsureEventLogExists(eventLogSourceName, eventLogName);
        }


        private void EnsureEventLogExists(string eventLogSourceName, string eventLogName)
        {
            // Create the source, if it does not already exist.
            try
            {
                if (!EventLog.SourceExists(eventLogSourceName))
                    EventLog.CreateEventSource(eventLogSourceName, eventLogName);
            }
            catch
            {
                //Swallow
            }
        }

        public void LogError<T>(StackFrame methodStackFrame, T ex) where T : Exception
        {
            Log(GetExceptionText(methodStackFrame, ex), EventLogEntryType.Error);
        }



        public string GetExceptionText<T>(StackFrame methodStackFrame, T ex) where T : Exception
        {
            MethodBase methodBase = methodStackFrame.GetMethod();

            //return string.Format("An exception occured in {0}: {1}\r\n\r\nError Message: {2}\r\n\r\nStack Trace: {3}",
            //                methodBase.MemberType,
            //                methodBase.Name,
            //                DataUtils.GetFullException(ex),
            //                //ex.Message,
            //                ex.StackTrace.ToString());

            return string.Format("An exception occured in {0}: {1}\r\n\r\n{2}",
                            methodBase.MemberType,
                            methodBase.Name,
                            ex.ToString());
        }

        public void Log(string message, EventLogEntryType entryType)
        {
            try
            {
                EventLog.WriteEntry(_eventLogSourceName, message, entryType);
            }
            catch
            {
                //swallow
            }
        }
    }
}