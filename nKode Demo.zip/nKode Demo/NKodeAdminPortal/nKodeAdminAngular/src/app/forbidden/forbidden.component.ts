import { Component, OnInit } from '@angular/core';
import { AuthorizationService } from '.././authorization.service';

@Component({
  selector: 'app-forbidden',
  templateUrl: './forbidden.component.html',
  styleUrls: ['./forbidden.component.css']
})
export class ForbiddenComponent implements OnInit {

  constructor(public authService: AuthorizationService) { }

  ngOnInit() {
  }

}
