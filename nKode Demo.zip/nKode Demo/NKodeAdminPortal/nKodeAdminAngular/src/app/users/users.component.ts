import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { EditUserViewModel } from '../models/EditUserViewModel';
import { Customer } from '../models/customer';
import { NKodRole } from '../models/NKodRole';
import { Utils } from '../utils';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  editUserVM: EditUserViewModel;
  userNotFound = false;
  customers: Customer[];
  customer: Customer;
  selectedRoleIds: number[];
  usernameSearchEntry: string;
  constructor(public httpService:HttpService) { }

  ngOnInit() {
    this.httpService.getCustomersForUser().subscribe(data => {
      this.customers = data;
      
      if (this.customers && this.customers.length == 1)
        this.customer = this.customers[0];
    });
  }

  findUser(username: string): void{
    this.userNotFound = false;
    this.httpService.editUser(username, this.customer.GUID).subscribe(data => {
      this.editUserVM = data;
      if (!data)
        this.userNotFound = true;
      else
        this.selectedRoleIds = this.editUserVM.User.Roles.map(x => x.Id);

    }); 
  } 

  public selectedCustomerChanged(): void
  {    
    this.editUserVM = null;
    this.userNotFound = false;
  }

  public unlockUser(): void {
    this.editUserVM.User.LockoutEndDateUtc = null;
  }

  roleAdded(role: any): void {    
    this.editUserVM.User.Roles.push(role);
  }

  roleRemoved(role: any): void {
    this.editUserVM.User.Roles.splice(this.editUserVM.User.Roles.findIndex(x => x.Id == role.value.Id), 1);
  }

  rolesCleared(): void {
    this.editUserVM.User.Roles = [];    
  }

  saveUser(): void {
    this.httpService.saveUser(this.editUserVM.User);
  }
}
