import { Component, OnInit, ViewChild } from '@angular/core';
import { BaseChartDirective } from 'ng2-charts';
import { Chart } from 'chart.js';
import * as annotationsPlugin from 'chartjs-plugin-annotation';
import { DataSeries, chartColors } from '../models/data-series';
import { NKodAdminDashboardSummary } from '../models/NKodAdminDashboardSummary';
import { HttpService } from '../http.service';
import { Customer } from '../models/customer';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  dashboardSummary: NKodAdminDashboardSummary
  customers: Customer[];
  customer: Customer;
  constructor(private httpService:HttpService) {
    Chart.pluginService.register(annotationsPlugin);
    this.refreshDataSeries();
  }

  dataSeries: DataSeries[] = [
    {
      index: 0,
      axisId: 'Registrations',
      colorName: 'green',
      label: 'Registrations',
      units: 'Users',
      activeInBypassMode: true,
    }
  ];

  ngOnInit() {
    this.httpService.getCustomersForUser().subscribe(data => {
      this.customers = data;
      
      if (this.customers && this.customers.length == 1)
        this.customer = this.customers[0];
      }
    );

    this.loadDashboardInfo();   
  }

  public loadDashboardInfo(): void {
    this.httpService.getAdminDashboardSummary(this.customer ? this.customer.GUID : null).subscribe(result => {
      
      this.barChartLabels = [];
      this.barChartData = [];
      for (let value of result.Registrations) {
        this.barChartLabels.push(`${value.Month}/${value.Year}`);
        this.barChartData.push(value.RegistrationCount);
      }

      this.dashboardSummary = result;      
    });
  }

  public selected(value: any): void {
    console.log('Selected value is: ', value);
  }

  public removed(value: any): void {
    console.log('Removed value is: ', value);
  }

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
        id: 'Registrations',
        type: 'linear',
        ticks: {
          beginAtZero:true
        },
        scaleLabel: {
          display: true,
          labelString: 'Registrations',
        },
      }]
    },
    tooltips: {
      mode: 'index',
      position: 'nearest',
      intersect: false,
    },
    animation: {
      duration: 0,
    },
    hover: {
      intersect: false,
    },
    maintainAspectRatio: false
    /*,
    annotation: {
      annotations: [       
        {
          type: 'box',
          yScaleID: 'Registrations',
          yMin: 104,
          yMax: 120.2,
          backgroundColor: 'rgba(0,255,0,0.15)',
          borderColor: 'rgba(0,255,0,0.05)',
          borderWidth: 0,
        }
      ]
    }*/
  };

  public barChartLabels: string[] = [];
  public barChartData = [];
  public barChartDataTemp = [];
  public barChartType = 'line';
  public barChartLegend = true;
  public barChartColors;

  @ViewChild(BaseChartDirective) ch: BaseChartDirective;

  refreshDataSeries() {
    // This is an ugly hack in ng2-charts, line colors will not work without this:
    this.barChartColors = this.dataSeries.map(r => ({
      backgroundColor: chartColors[r.colorName]
    }));

    this.barChartData = this.dataSeries.map(r => ({
      data: [],
      label: r.label,
      yAxisID: r.axisId,
      pointRadius: 3,
      pointBorderWidth: 1,
      pointHoverRadius: 4,
      pointHoverBorderWidth: 2,
      pointHitRadius: 1,
      borderWidth: 1,
      fill: false,
      borderColor: chartColors[r.colorName], // ...and this...
    }));

    this.barChartDataTemp = this.dataSeries.map(r => ({
      data: [],
      label: r.label,
    }));

    /*this.barChartLabels = [
      '10:00',
      '10:30',
      '11:00',
      '11:30',
      '12:00',
      '12:30',
      '13:00',
      '13:30',
      '14:00'
    ];

    this.barChartData[0].data = [
      50, 65, 68, 89, 92, 99, 108, 122, 130
    ];*/

  }

  

}
