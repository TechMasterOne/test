import { Observable, from, of, throwError, BehaviorSubject } from 'rxjs';
import { catchError, map, tap, retry, retryWhen, concatMap, delay, filter, take, switchMap, finalize, } from 'rxjs/operators';
import { Location } from '@angular/common';
import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { HttpRequest } from '@angular/common/http';
import { HttpHandler } from '@angular/common/http';
import { HttpEvent } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { AuthorizationService } from './authorization.service';
import { WaitDisplayService } from './wait-display.service';
import { HttpService } from './http.service';
import { Router } from '@angular/router';
import { ErrorService } from './error.service';

@Injectable({
  providedIn: 'root'
})
export class CustomHttpInterceptor implements HttpInterceptor {
  constructor(private _authorizationService: AuthorizationService, private _waitDisplayService: WaitDisplayService, private httpService: HttpService, private router: Router, private errorService: ErrorService) { }
  isRefreshingToken: boolean = false;
  tokenSubject: BehaviorSubject<string> = new BehaviorSubject<string>("refreshing");

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.errorService.errorMessage = "";
    this._waitDisplayService.showWait = true;

    return next.handle(this.addTokenToRequest(request)).pipe(
      /*retryWhen(errors => errors
        .pipe(
          concatMap((error, count) => {
            if (count < 2 && error.status != 401 && error.status != 500 && ) {
              return of(error.status);
            }

            return throwError(error);
          }),
          delay(200)          
        )
      ),*/ catchError(err =>
      {
        return this.handleError(request, err,next);
      }), finalize(() => this._waitDisplayService.showWait = false));
  }

  //See http://ericsmasal.com/2018/07/02/angular-6-with-jwt-and-refresh-tokens-and-a-little-rxjs-6/ for article on refreshing token
  private handleError(request: HttpRequest<any>,err: HttpErrorResponse, next: HttpHandler): Observable<any> {
    switch (err.status) {
      case 400:
        this._authorizationService.signOut();
        return of(err);
      case 401:
        let token = this._authorizationService.getBearerTokenInformation();
        if (token != null) //Try to refresh
        {
          if (!this.isRefreshingToken) {
            this.isRefreshingToken = true;
            this.tokenSubject.next("refreshing");
            return this.httpService.refreshToken(token.refresh_token).pipe(switchMap((data) => {
             
              this.tokenSubject.next("refreshed");
              this.isRefreshingToken = false;
              return next.handle(this.addTokenToRequest(request));

            }), catchError(err => {
              return of(err);
            }), finalize(() => this.isRefreshingToken = false));
          }
          else {
            this.isRefreshingToken = false;

            return this.tokenSubject
              .pipe(filter(call => call != "refreshing"),
                take(1),
                switchMap(call => {
                  return next.handle(this.addTokenToRequest(request));
                }));
          }
        }
        else {
          this._authorizationService.signOut();
          return of(err);
        }
      case 403:
        this.router.navigateByUrl("/forbidden");
        return of(err);
      default:
        this.errorService.errorMessage = err.message;
        return of(err);
                 
    }

    throw err;
  }

  private addTokenToRequest(request: HttpRequest<any>): HttpRequest<any> {
    if (!this.isRefreshingToken) {
      let token = this._authorizationService.getBearerTokenInformation();
      if (token) {
        let headers = request.headers.set("Authorization", `Bearer ${token.access_token}`);

        return request.clone({ headers });
      }  
    } 

    return request;
  }
}
