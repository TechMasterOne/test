import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { Customer } from '../models/customer';
import { FormBuilder, Validators } from '@angular/forms';
import { MinNKodeLengthExceedsMaxNKodeLength, DisparityExceedsMinNKodeLength, ComplexityExceedsDisparity } from '../validators/customerInfoValidators';
import config from '../../assets/config.js';
import { NKodPolicy } from '../models/NKodPolicy';
import { Utils } from '../utils';
import nKode from '../../assets/nKode.js';

@Component({
  selector: 'app-customer-management',
  templateUrl: './customer-management.component.html',
  styleUrls: ['./customer-management.component.css']
})
export class CustomerManagementComponent implements OnInit {
  customers: Customer[];
  selectedCustomer: Customer;
  customerToCopyFrom: Customer;
  customer: Customer;
  customerFormIsSubmitted = false;
  useKeyConfigFromExistingCustomer: boolean;
  labelColClass = "col-sm-5";
  dataColClass = "col-sm-7";
  constructor(public httpService: HttpService,private fb: FormBuilder) { }

  customerInfoForm = this.fb.group({
    Name: ['', Validators.required],
    Branch: [''],
    Active: [''],
    UserLoginLockoutTries: ['', [Validators.required, Validators.min(2)]],
    UserLoginLockoutDurationMinutes: ['', [Validators.required, Validators.min(0)]], 
    NKodPolicy: this.fb.group({
      MinLength: ['', [Validators.required, Validators.min(config.MIN_NKOD_LENGTH), Validators.max(config.MAX_NKOD_LENGTH)]],
      MaxLength: ['', [Validators.required, Validators.max(config.MAX_NKOD_LENGTH)]],
      Complexity: ['', [Validators.required, Validators.min(1), Validators.max(7)]], //Max needs to be the number of attribute sets used
      Disparity: ['', [Validators.required, Validators.min(1), Validators.max(config.MAX_NKOD_LENGTH)]]
    }, { validators: [MinNKodeLengthExceedsMaxNKodeLength, DisparityExceedsMinNKodeLength, ComplexityExceedsDisparity] })    
  });

  ngOnInit() {
    this.httpService.getCustomersForUser().subscribe(data => {
        this.customers = data;

        if (this.customers && this.customers.length == 1)
        {
          this.selectedCustomer = this.customers[0];
          this.selectedCustomerChanged()
        }
      }
    );
  }

  public selectedCustomerChanged(): void {
    this.customer = null;
    this.useKeyConfigFromExistingCustomer = false;
    this.httpService.getCustomer(this.selectedCustomer.GUID).subscribe(data => {
      this.customer = data;
      this.resetForm();
      this.customerInfoForm.patchValue(this.customer);
    });
  }

  private resetForm() {
    this.customerInfoForm.reset();
    this.customerFormIsSubmitted = false;
  }

  get f() {
    return this.customerInfoForm.controls;
  }

  get clientAttributeSetsAndValues() {
    return nKode.getClientAttributeSetsAndValues().slice(0,6);
  }

  customerInfoFormSubmitted(): void {
    this.customerFormIsSubmitted = true;
    if (!this.customerInfoForm.valid)
      return;
    this.customer = { ...this.customer, ...this.customerInfoForm.value };
    if (this.customer.GUID) {
      this.httpService.saveCustomer(this.customer);
    }
    else
    {
      if (this.useKeyConfigFromExistingCustomer)
      {
        this.httpService.createCustomerFromExisting(this.customer, this.customerToCopyFrom.GUID).subscribe(x => { this.processNewlyAddedCustomer(x); } );
      }
      else
      {
        this.httpService.createCustomer(this.customer).subscribe(x => { this.processNewlyAddedCustomer(x); } );
      }      
    }
  }

  private processNewlyAddedCustomer(customer: Customer): void {
    Utils.setCustomerNameForDisplay(customer);
    this.customer = customer;
    //this.customers.push(customer);
    this.customers = [...this.customers, customer]; //Must add this way for ng-select to detect change
    this.selectedCustomer = customer;
    this.customerToCopyFrom = null;
    this.useKeyConfigFromExistingCustomer = false;
  }

  addNewCustomer(): void
  {
    this.selectedCustomer = null;
    this.customer = new Customer();
    this.resetForm();
    this.customerInfoForm.patchValue(this.customer);

    if (this.customers && this.customers.length > 0)
    {
      this.useKeyConfigFromExistingCustomer = true;
      this.customerToCopyFrom = this.customers[0];
    }
    else {
      this.useKeyConfigFromExistingCustomer = false;
      this.customerToCopyFrom = null;
    }
     
    this.customer.Active = true;
    this.customer.UserLoginLockoutTries = 3;
    this.customer.UserLoginLockoutDurationMinutes = 5;
    this.customer.NKodPolicy = new NKodPolicy();
    this.customer.NKodPolicy.MinLength = 4;
    this.customer.NKodPolicy.MaxLength = 4;
    this.customer.NKodPolicy.Complexity = 2;
    this.customer.NKodPolicy.Disparity = 2;
    this.customerInfoForm.patchValue(this.customer);
  }
 
}
