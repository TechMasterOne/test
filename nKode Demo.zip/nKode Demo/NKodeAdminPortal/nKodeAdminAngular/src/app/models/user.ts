import { NKodRole } from './NKodRole';
export class User {
  public GUID: string; 
  public UserName: string;  
  public ActiveInterface: string;
  public Active: boolean;
  public CustomerGUID: string;
  public Renewed: Date;
  public Refreshed: Date;
  public TemplateIdentifier: string;
  public Pass: number;
  public Fail: number;
  public LockoutCount: number;
  public LockoutEndDateUtc: Date;
  public Updated: Date;
  public Created: Date;
  public Changed: Date;
  public Reset: Date;
  public Customer: string;
  public LastLogin: Date;
  public Roles: NKodRole[];
}
