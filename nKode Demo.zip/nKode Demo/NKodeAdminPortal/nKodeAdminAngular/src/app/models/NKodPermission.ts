export class NKodPermission {
  public Id: number;
  public Permission: string;
  public Selected: boolean;

}
