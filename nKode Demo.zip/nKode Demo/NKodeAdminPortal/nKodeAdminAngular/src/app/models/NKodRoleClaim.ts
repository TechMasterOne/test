export class NKodRoleClaim {
  public static AllCustomerAccessClaimType: string = "allCustomerAccess";
  public static readonly CanAddRemoveRoleIdClaimType = "canAddRemoveRoleId";
  public static readonly CanAccessCustomerClaimType = "canAccessCustomerGUID";
  public static readonly PermissionIdClaimType = "permissionId";
  public Id: number;
  public ClaimType: string;
  public ClaimValue: string;
  public RoleId: number;
  
}
