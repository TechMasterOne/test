import { NKodRegistrationSummary } from './NKodRegistrationSummary';

export class NKodAdminDashboardSummary 
{
    public TotalUsers: number ;
    public ActiveUsers: number ;
    public InactiveUsers: number ;
    public LockedOutUsers: number ;
    public Registrations: NKodRegistrationSummary[]  ; 
}
