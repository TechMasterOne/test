import { NKodRolePermission } from './NKodRolePermission';
import { NKodRoleClaim } from './NKodRoleClaim';

export class NKodRole {
  public Id: number;
  public Role: string;
  public AllCustomerAccess: boolean;
  public Permissions: NKodRolePermission[];
  public Claims: NKodRoleClaim[];
  public Selected: boolean;

}
