import { User } from './user';
import { NKodRole } from './NKodRole';

export class EditUserViewModel {
  public User: User;
  public AvailableRoles: NKodRole[];
}
