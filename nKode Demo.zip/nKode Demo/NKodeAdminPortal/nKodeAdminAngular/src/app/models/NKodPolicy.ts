export class NKodPolicy {
  public MinLength: number;
  public MaxLength: number;
  public Complexity: number;
  public Disparity: number;

}
