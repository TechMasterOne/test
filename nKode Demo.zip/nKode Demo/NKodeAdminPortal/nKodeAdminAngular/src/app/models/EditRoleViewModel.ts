import { NKodRole } from './NKodRole';
import { NKodPermission } from './NKodPermission';
import { Customer } from './customer';

export class EditRoleViewModel {
  public Role: NKodRole;
  public Permissions: NKodPermission[];
  public AvailableRoles: NKodRole[];
  public AvailableCustomers: Customer[];

}
