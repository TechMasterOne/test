import { NKodPolicy } from './NKodPolicy';

export class Customer {
  public GUID: string;
  public Name: string;
  public Branch: string;
  public Active: boolean;
  public NKodeMinLength: number;
  public NKodeMaxLength: number;
  public NKodeComplexity: number;
  public NKodeDisparity: number;
  public UserLoginLockoutTries: number;
  public UserLoginLockoutDurationMinutes: number;
  public ActiveInterface: string;
  public Updated: Date;
  public Created: Date;
  public Renewed: Date;
  public NameForDisplay: string;
  public NKodPolicy: NKodPolicy;
  public ClientAttributeValues: number[];
  public ClientDarcKeys: string;
  public ClientDarcKeysEncryptionKey: string;
}
