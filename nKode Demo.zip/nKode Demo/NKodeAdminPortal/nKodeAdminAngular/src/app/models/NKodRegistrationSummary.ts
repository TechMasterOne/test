export class NKodRegistrationSummary 
{
  public Month: number ;
  public Year: number ;
  public RegistrationCount: number ; 
}
