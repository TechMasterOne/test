import { NKodPermission } from './NKodPermission';


export class NKodRolePermission {
  public Id: number;
  public Permission: NKodPermission;
}
