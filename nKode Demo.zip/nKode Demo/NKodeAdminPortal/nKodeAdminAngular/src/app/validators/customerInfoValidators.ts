import {
   ValidatorFn, ValidationErrors, FormGroup
} from "@angular/forms";

export const MinNKodeLengthExceedsMaxNKodeLength: ValidatorFn = (control: FormGroup): ValidationErrors | null => {   
  return control.controls.MinLength.value > control.controls.MaxLength.value ? { 'minNKodeLengthExceedsMaxNKodeLength': true } : null;
};

export const DisparityExceedsMinNKodeLength: ValidatorFn = (control: FormGroup): ValidationErrors | null => {
  return control.controls.Disparity.value > control.controls.MinLength.value ? { 'disparityExceedsMinNKodeLength': true } : null;
};

export const ComplexityExceedsDisparity: ValidatorFn = (control: FormGroup): ValidationErrors | null => {
  return control.controls.Complexity.value > control.controls.Disparity.value ? { 'complexityExceedsDisparity': true } : null;
};
