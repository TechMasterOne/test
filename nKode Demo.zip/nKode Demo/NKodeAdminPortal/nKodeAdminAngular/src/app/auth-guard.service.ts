import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { AuthorizationService } from './authorization.service';
@Injectable(
  {
    providedIn: 'root'
  }
)
export class AuthGuardService implements CanActivate {
  constructor(private _authorizationService: AuthorizationService, private _router: Router) { }
  canActivate(): boolean {
    if (!this._authorizationService.isAuthenticated()) {
      this._router.navigateByUrl('/login');
      return false;
    }
    return true;
  }
}
