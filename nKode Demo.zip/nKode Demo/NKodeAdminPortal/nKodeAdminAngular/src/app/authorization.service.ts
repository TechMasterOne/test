import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Permissions } from './permissions-enum';

@Injectable({
  providedIn: 'root'
})
export class AuthorizationService {
  private static readonly BearerTokenKey = "nKodBearerToken";
  constructor(private _router: Router) { }
  private bearerTokenInfo: any = null;

  checkForAndHandleUnauthorizedUser() : boolean {    
    if (!this.isAuthenticated()) {
      this._router.navigateByUrl("/login");
      return false;
    }

    return true;
  }

  isAuthenticated(): boolean {
    let bearerToken = this.getBearerTokenInformation();
    if (!bearerToken)
      return false;

    return true;
  }

  getLoggedInUser(): string {
    let bearerToken = this.getBearerTokenInformation();
    return bearerToken ? bearerToken.userName : "";
  }

  storeBearerTokenInformation(bearerToken: any): void {
    bearerToken.permissionIds = JSON.parse(bearerToken.permissionIds);
    this.bearerTokenInfo = bearerToken;
    window.localStorage.setItem(AuthorizationService.BearerTokenKey, JSON.stringify(bearerToken));
    
  }

  userHasPermission(permission: Permissions): boolean {
    let bearerToken = this.getBearerTokenInformation();
    return bearerToken && bearerToken.permissionIds && bearerToken.permissionIds.some(x => x==Permissions.All || x == permission);
  }

  getBearerTokenInformation(): any
  {
    if (this.bearerTokenInfo == null) {
      let bearerInfoString = window.localStorage.getItem(AuthorizationService.BearerTokenKey);
      if (!bearerInfoString)
        return null;

      this.bearerTokenInfo = JSON.parse(bearerInfoString);
    }

    return this.bearerTokenInfo;
  }

  signOut(): void
  {
    this.bearerTokenInfo = null;
    window.localStorage.removeItem(AuthorizationService.BearerTokenKey);
    this._router.navigateByUrl("/login");
  }
}
