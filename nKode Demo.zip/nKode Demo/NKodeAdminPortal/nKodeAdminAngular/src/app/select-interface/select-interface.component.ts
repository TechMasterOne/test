import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-interface',
  templateUrl: './select-interface.component.html',
  styleUrls: ['./select-interface.component.css']
})
export class SelectInterfaceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
