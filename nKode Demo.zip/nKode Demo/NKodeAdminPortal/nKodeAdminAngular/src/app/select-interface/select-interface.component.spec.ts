import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectInterfaceComponent } from './select-interface.component';

describe('SelectInterfaceComponent', () => {
  let component: SelectInterfaceComponent;
  let fixture: ComponentFixture<SelectInterfaceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectInterfaceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectInterfaceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
