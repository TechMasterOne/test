import { Component, OnInit } from '@angular/core';
import { AuthorizationService } from '.././authorization.service';
import { Permissions } from '../permissions-enum';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-template',
  templateUrl: './admin-template.component.html',
  styleUrls: ['./admin-template.component.css']
})
export class AdminTemplateComponent implements OnInit {
  loggedInUser: string;
  public permissions = Permissions;

  constructor(public authService: AuthorizationService, private _router: Router) {
    
  }

  ngOnInit() {
    this.loggedInUser = this.authService.getBearerTokenInformation().userName;
  }

  signOut(): void {
    this.authService.signOut();
  }

  changeNkode(): void {
    this._router.navigateByUrl("/changeNKode");
  }


}
