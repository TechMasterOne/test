import { Component, OnInit } from '@angular/core';
import { WaitDisplayService } from '../wait-display.service';

@Component({
  selector: 'app-wait-display',
  templateUrl: './wait-display.component.html',
  styleUrls: ['./wait-display.component.css']
})
export class WaitDisplayComponent implements OnInit {

  constructor(public waitDisplayService:WaitDisplayService) { }

  ngOnInit() {

  }

}
