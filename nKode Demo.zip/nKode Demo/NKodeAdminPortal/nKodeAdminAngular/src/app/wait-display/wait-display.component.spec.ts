import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WaitDisplayComponent } from './wait-display.component';

describe('WaitDisplayComponent', () => {
  let component: WaitDisplayComponent;
  let fixture: ComponentFixture<WaitDisplayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WaitDisplayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WaitDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
