import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpService } from '../http.service';
import { EditRoleViewModel } from '../models/EditRoleViewModel';
import { NKodPermission } from '../models/NKodPermission';
import { NKodRolePermission } from '../models/NKodRolePermission';
import { NKodRole } from '../models/NKodRole';
import { NKodRoleClaim } from '../models/NKodRoleClaim';
import { Customer } from '../models/customer';
import { Utils } from '../utils';

@Component({
  selector: 'app-edit-role',
  templateUrl: './edit-role.component.html',
  styleUrls: ['./edit-role.component.css']
})
export class EditRoleComponent implements OnInit {
  editRoleVM: EditRoleViewModel;
  selectedCustomerIds: string[];
  constructor(private route: ActivatedRoute, private httpService: HttpService)
  {

  }

  ngOnInit()
  {
      this.getRole();
  }

  getRole(): void {
    const id = +this.route.snapshot.paramMap.get('id');
    this.httpService.getRole(id).subscribe(data => {
      this.editRoleVM = data;

      if (this.editRoleVM.Permissions)
      {
        for (let permission of this.editRoleVM.Permissions)
          permission.Selected = this.roleHasPermission(permission.Id);
      }

      if (this.editRoleVM.AvailableRoles)
      {
        for (let availableRole of this.editRoleVM.AvailableRoles)
          availableRole.Selected = this.roleHasClaim(NKodRoleClaim.CanAddRemoveRoleIdClaimType, String(availableRole.Id));
      }

      this.editRoleVM.AvailableCustomers = this.editRoleVM.AvailableCustomers.map(x => {
        Utils.setCustomerNameForDisplay(x);
        return x;
      });
      this.selectedCustomerIds = this.editRoleVM.Role.Claims.filter(x => x.ClaimType === NKodRoleClaim.CanAccessCustomerClaimType).map(x => x.ClaimValue);

    });
  }

  customerAdded(customer: Customer): void {
    let newClaim = new NKodRoleClaim();
    newClaim.ClaimType = NKodRoleClaim.CanAccessCustomerClaimType;
    newClaim.ClaimValue = customer.GUID;
    this.editRoleVM.Role.Claims.push(newClaim);
  }


  customerRemoved(customer: any): void {
    this.editRoleVM.Role.Claims.splice(this.editRoleVM.Role.Claims.findIndex(x => x.ClaimType === NKodRoleClaim.CanAccessCustomerClaimType && x.ClaimValue == customer.value.GUID), 1);
  }

  customerCleared(): void {
    let claimsToRemove = this.editRoleVM.Role.Claims.filter(x => x.ClaimType === NKodRoleClaim.CanAccessCustomerClaimType);
    for(let claim of claimsToRemove)
      this.editRoleVM.Role.Claims.splice(this.editRoleVM.Role.Claims.indexOf(claim), 1);
  }

  roleHasPermission(permissionId:number): boolean {
    return this.editRoleVM.Role.Permissions && this.editRoleVM.Role.Permissions.filter(e => e.Permission.Id === permissionId).length > 0;
  }

  roleHasClaim(claimType: string, claimValue: string): boolean
  {
    return this.editRoleVM.Role.Claims && this.editRoleVM.Role.Claims.filter(e => e.ClaimType === claimType && e.ClaimValue === claimValue).length > 0;
  }

  saveRole(): void {
    this.httpService.saveRole(this.editRoleVM.Role).subscribe();
  }

  canManageRoleRoleSelectionChanged(role: NKodRole):void
  {
    if (role.Selected) {
      let newRoleClaim = new NKodRoleClaim();
      newRoleClaim.ClaimType = NKodRoleClaim.CanAddRemoveRoleIdClaimType;
      newRoleClaim.ClaimValue = String(role.Id);
      newRoleClaim.RoleId = this.editRoleVM.Role.Id;
      this.editRoleVM.Role.Claims.push(newRoleClaim);
    }
    else
      this.editRoleVM.Role.Claims.splice(this.editRoleVM.Role.Claims.findIndex(x => x.ClaimType === NKodRoleClaim.CanAddRemoveRoleIdClaimType && x.ClaimValue == String(role.Id)), 1);
  }

  permissionSelectionChanged(permission: NKodPermission): void
  {
    if (permission.Selected)
    {
      let newRolePermission = new NKodRolePermission();
      newRolePermission.Permission = permission;
      this.editRoleVM.Role.Permissions.push(newRolePermission);
    }
    else
      this.editRoleVM.Role.Permissions.splice(this.editRoleVM.Role.Permissions.findIndex(x=>x.Permission.Id === permission.Id), 1);
  }
}
