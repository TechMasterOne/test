import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SelectInterfaceComponent } from './select-interface/select-interface.component';
import { NKodeComponent } from './n-kode/n-kode.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AdminTemplateComponent } from './admin-template/admin-template.component';
import { UsersComponent } from './users/users.component';
import { RolesComponent } from './roles/roles.component';
import { EditRoleComponent } from './edit-role/edit-role.component';
import { ForbiddenComponent } from './forbidden/forbidden.component';
import { CustomerManagementComponent } from './customer-management/customer-management.component'
import {
  AuthGuardService as AuthGuard
} from './auth-guard.service';

const routes: Routes = [
  { path: '', redirectTo: '/admin', pathMatch: 'full' },
  { path: 'forbidden', component: ForbiddenComponent },
  {
    path: 'admin', component: AdminTemplateComponent, canActivate: [AuthGuard],    
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'users', component: UsersComponent },
      { path: 'roles', component: RolesComponent },
      { path: 'editRole/:id', component: EditRoleComponent },
      { path: 'customerManagement', component: CustomerManagementComponent }
    ]
  },  
  { path: 'signup', component: NKodeComponent },
  { path: 'login', component: NKodeComponent },
  { path: 'changeNKode', component: NKodeComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
