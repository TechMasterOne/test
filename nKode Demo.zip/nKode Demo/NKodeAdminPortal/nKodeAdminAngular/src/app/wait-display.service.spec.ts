import { TestBed } from '@angular/core/testing';

import { WaitDisplayService } from './wait-display.service';

describe('WaitDisplayService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WaitDisplayService = TestBed.get(WaitDisplayService);
    expect(service).toBeTruthy();
  });
});
