import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, of,throwError,pipe } from 'rxjs';
import { catchError, map, tap, retry,retryWhen, concatMap, delay } from 'rxjs/operators';
import { User } from './models/user';
import { Router } from '@angular/router';
import { AuthorizationService } from './authorization.service';
import config from '../assets/config.js';
import { Customer } from './models/customer';
import { NKodAdminDashboardSummary } from './models/NKodAdminDashboardSummary';
import { EditRoleViewModel } from './models/EditRoleViewModel';
import { NKodRole } from './models/NKodRole';
import { EditUserViewModel } from './models/EditUserViewModel';
import { Utils } from './utils';

@Injectable({
  providedIn: 'root'
})
export class HttpService
{   
  constructor(private http: HttpClient, private _router: Router, private _authorizationService: AuthorizationService) { }
  
  private readonly apiBaseUrl = config.ADMIN_API_BASE_URL.replace(/\/$/, ''); //remove trailing slash if there

  getAdminDashboardSummary(customerId:string): Observable<NKodAdminDashboardSummary> {
    
    return this.http.get<NKodAdminDashboardSummary>(`${this.apiBaseUrl}/getDashboardSummary?customerGuid=${customerId || ""}`);
  }

  //getUser(username: string, customerId: string):Observable<User> {
  //  if (!this._authorizationService.checkForAndHandleUnauthorizedUser())
  //    return;

  //  return this.http.get<User>(`${this.apiBaseUrl}/getUser?username=${username}&customerId=${customerId}`);
  //}

  editUser(username: string, customerId: string): Observable<EditUserViewModel> {
    if (!this._authorizationService.checkForAndHandleUnauthorizedUser())
      return;

    return this.http.get<EditUserViewModel>(`${this.apiBaseUrl}/editUser?username=${username}&customerId=${customerId}`);
  }

  saveUser(user: User): void {
    this.http.post(`${this.apiBaseUrl}/saveUser`, user).subscribe();
  }

  getCustomer(guid: string): Observable<Customer> {
    return this.http.get<Customer>(`${this.apiBaseUrl}/getCustomer?customerGuid=${guid}`).pipe(
      map(x => {
        Utils.setCustomerNameForDisplay(x);
        return x;
      })
    );
  }

  createCustomerFromExisting(customer: Customer, customerToCopyFrom: string): Observable<Customer> {
    return this.http.post<Customer>(`${this.apiBaseUrl}/createCustomerFromExisting`, { Customer: customer, CustomerToCopyFrom: customerToCopyFrom });
  }

  createCustomer(customer:Customer): Observable<Customer> {
    return this.http.post<Customer>(`${this.apiBaseUrl}/createCustomer`, customer);
  }

  saveCustomer(customer: Customer):void {
    this.http.post(`${this.apiBaseUrl}/saveCustomer`, customer).subscribe();
  }

  getCustomersForUser(): Observable<Customer[]> {
    if (!this._authorizationService.checkForAndHandleUnauthorizedUser())
      return;

    return this.http.get<Customer[]>(`${this.apiBaseUrl}/getCustomersForUser`).pipe(
        map(x => {
          return x.map(y => {
            Utils.setCustomerNameForDisplay(y);
          return y;
        })
      })
    );
  }

  setUserActive(userId: string, active: boolean): void {
    this.http.post(`${this.apiBaseUrl}/SetUserActive`, { GUID: userId, Active: active }).subscribe();
  }

  //unlockUser(userId: string): void {
  //  this.http.post(`${this.apiBaseUrl}/UnlockUser/${userId}`, null).subscribe();
  //}

  getRoles(): Observable<NKodRole[]> {
    if (!this._authorizationService.checkForAndHandleUnauthorizedUser())
      return;

    return this.http.get<NKodRole[]>(`${this.apiBaseUrl}/getRoles`);
  }

  saveRole(role:NKodRole): Observable<NKodRole> {
    if (!this._authorizationService.checkForAndHandleUnauthorizedUser())
      return;

    return this.http.post<NKodRole>(`${this.apiBaseUrl}/SaveRole`, role);
  }

  deleteRole(id: number):Observable<any> {
    return this.http.post(`${this.apiBaseUrl}/deleteRole/${id}`, null);
  }

  getRole(id: number): Observable<EditRoleViewModel> {
    return this.http.get<EditRoleViewModel>(`${this.apiBaseUrl}/editRole?id=${id}`);

  }

  refreshToken(refreshToken: string): Observable<any> {
    let options = {
      headers: new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded')
    };
    const body = new HttpParams()
      .set('refresh_token', refreshToken)
      .set('grant_type', "refresh_token");
    return this.http.post<any>(`${config.API_URL}/token`, body, options).pipe(
      map(data => {
        if (data) {
          this._authorizationService.storeBearerTokenInformation(data);
        }

        return data;
      }));
  }
}
