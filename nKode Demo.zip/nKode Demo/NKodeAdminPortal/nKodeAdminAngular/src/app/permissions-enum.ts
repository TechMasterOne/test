export enum Permissions {
  All = 0, //System Admin
  Dashboard = 1,
  ManageUsers = 2,
  ManageUserRoles = 3
}
