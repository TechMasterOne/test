import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NKodeComponent } from './n-kode.component';

describe('NKodeComponent', () => {
  let component: NKodeComponent;
  let fixture: ComponentFixture<NKodeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NKodeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NKodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
