import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import nKode from '../../assets/nKode.js';
import config from '../../assets/config.js';
import Fingerprint2 from '../../../node_modules/fingerprintjs2/dist/fingerprint2.min.js';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { AuthorizationService } from '../authorization.service';
import { ErrorService } from '../error.service';

@Component({
  selector: 'app-n-kode',
  templateUrl: './n-kode.component.html',
  styleUrls: ['./n-kode.component.css',
    './sharedTemplate.css',
    './emojis.css'],
  encapsulation: ViewEncapsulation.None
})
export class NKodeComponent implements OnInit {
  private _fingerprint = "";
  static readonly fingerprintUnavailableValue = "unavailable";
  static readonly defaultLoginFailedMessage = "Login failed.  Please try again.";
  usernameInputError: boolean = false;
  nkodeEmptyError: boolean = false;
  username = ""; 
  isSignUp: boolean;
  isChange: boolean;
  isConfirmPasscodeStep: boolean = false;  
  keypadLoaded = false;
  showSpinner = false;
  password = "";
  loginFailed: boolean = false;
  loginFailedMessage = "";
  template = "shapes";
  minLengthError: boolean = false;
  maxLengthError: boolean = false;
  complexityError: boolean = false;
  disparityError: boolean = false;
  nKodeLengthsDoNotMatch: boolean = false;
  nKodeValuesDoNotMatch: boolean = false;
  minNKodeLength:any;
  maxNKodeLength: any;
  isNewRegistrant: boolean;


  constructor(private route: ActivatedRoute, private router: Router, private _authorizationService: AuthorizationService, private errorService: ErrorService) { 
    this.isSignUp = this.route.snapshot.routeConfig.path.toLowerCase() === "signup";
    this.isChange = this.route.snapshot.routeConfig.path.toLowerCase() === "changenkode";
    this.minNKodeLength = config.MIN_NKOD_LENGTH;
    this.maxNKodeLength = config.MAX_NKOD_LENGTH;
  }

  get enterButtonText(): string {
    if (!this.isSignUp)
      return this.isChange ? "Confim Login" : "Login";

    return this.isConfirmPasscodeStep ? "Finish" : "Next";
  }

  get nKodePlaceholderText(): string {
    if (!this.isSignUp)
      return "Enter your nKode";

    return this.isConfirmPasscodeStep ? "Re-enter nKode to confirm" : "Select keys to create your nKode";
  }

  ngOnInit() {
    if (window['requestIdleCallback'])    
      window['requestIdleCallback'](() => { this.setFingerprint(); }); //Note: must call like this to keep scope so that this is accessible.    
    else
      setTimeout(() => { this.setFingerprint(); }, 400);    

    this.isNewRegistrant = this.route.snapshot.queryParams.registered;

    nKode.setConfig(config);
    nKode.setKodChangedCallback(() => {
      this.password = "";

      let keyLength = nKode.currentNKodLength();

      for (let i = 1; i <= keyLength; i++) {
        this.password += "*";
      }

      this.nkodeEmptyError = false;
    });

    if (this.isSignUp)
      this.loadCreateInterface();
    else if (this.isChange)
      this.generateLoginInterface();       
  }

  interfaceTemplateChanged(): void {
    this.loadCreateInterface();
  }

  resetRegisterVariables(): void {
    this.isConfirmPasscodeStep = false;
    this.minLengthError = false;
    this.maxLengthError = false;
    this.complexityError = false;
    this.disparityError = false;
    this.nKodeLengthsDoNotMatch = false;
    this.nKodeValuesDoNotMatch = false;
  }

  setFingerprint(): void {    
    Fingerprint2.getPromise().then(components => {
      this._fingerprint = Fingerprint2.x64hash128(components.map(function (pair) { return pair.value; }).join(), 31);
    });
  }

  async ensureFingerprintIsSet() : Promise<any>{
    let tryCount = 1;
    while (this._fingerprint === "" && tryCount < 3) {
      await new Promise(res => setTimeout(res, 250));
    }
    if (this._fingerprint === "")
      this._fingerprint = NKodeComponent.fingerprintUnavailableValue;      
  }

  async loadCreateInterface(): Promise<any> {
    this.showSpinner = true;
    this.errorService.errorMessage = "";
    this.resetRegisterVariables();
    try {
      try {
        await nKode.generateRegisterInterface(this.template);
        this.keypadLoaded = true;
      }
      catch (ex) {
        this.keypadLoaded = false;
        this.errorService.errorMessage = "An unexpected error occurred";
        this.logError(ex);
      }
        
    }
    finally {
      this.showSpinner = false;
    } 
  }
 
  async generateLoginInterface(): Promise<any> {
    this.showSpinner = true;
    this.loginFailed = false;
    this.errorService.errorMessage = "";
    this.usernameInputError = false;
    try {
      await this.ensureFingerprintIsSet();

      let username: string;
      if (!this.isChange)
      {
        if (!this.username)
        {
          this.usernameInputError = true;
          return;
        }
        username = this.username;
      }
      else {
        username = this._authorizationService.getLoggedInUser();
        if (!username) {
          this._authorizationService.signOut();
          return;
        }
      }

      await nKode.generateLoginInterface(username, 'shapes', this._fingerprint);
      this.keypadLoaded = true;
    }
    catch (ex)
    {
      this.keypadLoaded = false;
      this.errorService.errorMessage = "An unexpected error occurred";
      this.logError(ex);
    }  
    finally {
      this.showSpinner = false;
    }    
  }

  async enter(): Promise<any> {
    try {
      this.showSpinner = true;
      this.errorService.errorMessage = "";
      this.loginFailed = false;

      if (!this.isSignUp)
        await this.login();
      else if (this.isConfirmPasscodeStep)
        await this.createNKodeStep2();
      else
        await this.createNKodeStep1();
    }    
    finally {
      this.showSpinner = false;
    }   
  }

  async createNKodeStep2(): Promise<any> {    
    await this.ensureFingerprintIsSet();

    let bearerToken: string;
    let username: string;
    if (!this.isChange)
      username = this.username
    else
    {
      let bearerTokenInfo = this._authorizationService.getBearerTokenInformation();
      if (bearerTokenInfo)
      {
        username = bearerTokenInfo.userName;
        bearerToken = bearerTokenInfo.access_token;
      }        
      
      if (!username) {
        this._authorizationService.signOut();
        return;
      }
    }

    try {
      let data = await nKode.createNKodeStep2(username, this._fingerprint, this.template, { isChange: this.isChange, bearerToken:bearerToken });

      if (data.Success) {
        if (this.isChange) {
          this.router.navigateByUrl("/");
        }
        else
          this.router.navigateByUrl("/login?registered=true");
      }
      else {
        if (data.NKodLengthUnequal) //Client side check of two lengths failed       
          this.nKodeLengthsDoNotMatch = true;
        else if (data.NKodCompareFailed) //Server side compare of entered nKod failed
          this.nKodeValuesDoNotMatch = true;
        else if (data.PolicyCompareResult) //Server side policy validation results
        {
          this.minLengthError = !data.PolicyCompareResult.MinLengthIsValid;
          this.maxLengthError = !data.PolicyCompareResult.MaxLengthIsValid;
          this.complexityError = !data.PolicyCompareResult.ComplexityIsValid;
          this.disparityError = !data.PolicyCompareResult.DisparityIsValid;
        }
      }
    }
    catch (ex)
    { 
      switch (ex.status) {
        case 401:
          if (this.isChange)
          {
            this.errorService.errorMessage = "You are either not authenticated or the allowed password change time has elapsed.  Please try again.";
            this.resetNKodeDisplay();
            this.generateLoginInterface();
          }
          else
            this.errorService.errorMessage = "Unauthorized"; //This shouldn't happen, but just in case
          break;       
        default:
          this.errorService.errorMessage = "An unexpected error occurred";
          this.logError(ex);
          break;
      }
    }
  }

  async createNKodeStep1(): Promise<any>
  {
    let username: string;
    if (!this.isChange)
      username = this.username
    else {
      username = this._authorizationService.getLoggedInUser();
      if (!username) {
        this._authorizationService.signOut();
        return;
      }
    }

    let data = await nKode.createNKodeStep1(username, { isChange: this.isChange });
    if (data.userExists)
    {
      this.loginFailed = true;
      this.loginFailedMessage = "Username already exists";
      await this.loadCreateInterface();
    }
    else    
      this.isConfirmPasscodeStep = true;
  }

  async login(): Promise<any> {    
    try {
      let username: string;
      this.usernameInputError = false;
      if (nKode.currentNKodLength() == 0)
      {
        this.nkodeEmptyError = true;
        return;
      }
              

      if (!this.isChange)
      {
        if (!this.username)
        {
          this.usernameInputError = true;
          return;
        }
        username = this.username
      }
      else {
        username = this._authorizationService.getLoggedInUser();
        if (!username) {
          this._authorizationService.signOut();
          return;
        }
      }

      let bearerToken = this._authorizationService.getBearerTokenInformation();
      let accessToken: string = null;
      if (bearerToken)
        accessToken = bearerToken.access_token;
      let success = await nKode.login(username, { isVerifyLoginForNKodeChange: this.isChange, bearerToken: accessToken });
      if (success && success.bearerToken) {
        this._authorizationService.storeBearerTokenInformation(success.bearerToken);

        if (this.isChange) {
          this.isSignUp = true;
          this.loadCreateInterface();
        }
        else
          this.router.navigateByUrl("/admin");
      }
      else
      {
        this.loginFailed = true;
        this.loginFailedMessage = NKodeComponent.defaultLoginFailedMessage;
        this.resetNKodeDisplay();
        if (this.isChange)
          this.generateLoginInterface();
      }
    }
    catch (ex) {
      this.resetNKodeDisplay();

      if (this.isChange)
        await this.generateLoginInterface();                
      
      // Show login error
      let responseText = (ex.responseText || "").replace(/^"+|"+$/g, '');
      switch (ex.status) {
        case 401:
          this.loginFailed = true;  
          if (responseText === "Account Inactive")
            this.loginFailedMessage = "Login failed -- this account is inactive";
          else if (responseText === "Account Locked")
            this.loginFailedMessage = "Login failed -- this account is currently locked out";          
          else
            this.loginFailedMessage = "Login failed";
          break;        
        default:
          this.errorService.errorMessage = "An unexpected error occurred";
          this.logError(ex);
          break;
      }
    }
  }

  changeLoginUsername(): void
  {
    document.getElementById("nkod").innerHTML = "";
    this.username = "";
    this.keypadLoaded = false;
    nKode.clear();
  }

  async changeRegisterUsername(): Promise<any>
  {
    this.username = "";
    this.isConfirmPasscodeStep = false;
    this.keypadLoaded = false;
    nKode.clear();
    await this.loadCreateInterface();
  }

  private resetNKodeDisplay(): void {    
    nKode.clear();
    document.getElementById(config.INTERFACE_HTML_PLACEHOLDER_ID).innerHTML = "";
    this.keypadLoaded = false;
    this.isConfirmPasscodeStep = false;
  }

  clear(): void {
    nKode.clear();
  }

  backspace(): void {
    nKode.removeLastEntry();
  }

  private logError(ex) {
    if (ex.nKodeMethodIdentifierStack)
      console.error(`nKode method identifier stack: ${ex.nKodeMethodIdentifierStack}`);
    console.error(ex);
  }

}
