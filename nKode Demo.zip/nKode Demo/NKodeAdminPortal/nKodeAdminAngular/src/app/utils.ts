import { Customer } from './models/customer';

export class Utils {
  

  public static setCustomerNameForDisplay(customer: Customer): void {
    if (customer.Branch)
      customer.NameForDisplay = `${customer.Name} [${customer.Branch}]`;
    else
      customer.NameForDisplay = customer.Name;
  }
}
