import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ChartsModule } from 'ng2-charts';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NKodeComponent } from './n-kode/n-kode.component';
import { SelectInterfaceComponent } from './select-interface/select-interface.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { library } from '@fortawesome/fontawesome-svg-core';
import { faSpinner,faBackspace,faFrown,faTachometerAlt, faUsers, faUserSecret, faCogs,faChartLine,faUserLock,faUser,faUserTimes,faTrash,faEdit,faTimes } from '@fortawesome/free-solid-svg-icons';
import { AdminTemplateComponent } from './admin-template/admin-template.component';
import { UsersComponent } from './users/users.component';
import { RolesComponent } from './roles/roles.component';
import { WaitDisplayComponent } from './wait-display/wait-display.component';
import { CustomHttpInterceptor } from './custom-http-interceptor';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmDeleteModalComponent } from './confirm-delete-modal/confirm-delete-modal.component';
import { EditRoleComponent } from './edit-role/edit-role.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { ForbiddenComponent } from './forbidden/forbidden.component';
import { CustomerManagementComponent } from './customer-management/customer-management.component';
import { ErrorComponent } from './error/error.component';

@NgModule({
  declarations: [
    AppComponent,
    NKodeComponent,
    SelectInterfaceComponent,
    DashboardComponent,
    AdminTemplateComponent,
    UsersComponent,
    RolesComponent,
    WaitDisplayComponent,
    ConfirmDeleteModalComponent,
    EditRoleComponent,
    ForbiddenComponent,
    CustomerManagementComponent,
    ErrorComponent    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    FontAwesomeModule,
    ChartsModule,
    NgbModule,
    NgSelectModule
  ],
  providers: [ {
    provide: HTTP_INTERCEPTORS,
    useClass: CustomHttpInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent],
  entryComponents: [ConfirmDeleteModalComponent]
})
export class AppModule
{
  constructor() {
    library.add(faSpinner, faBackspace, faFrown, faTachometerAlt, faUsers, faUserSecret, faCogs, faChartLine, faUserLock, faUser, faUserTimes,faTrash,faEdit,faTimes);

  }
}
