export class DashboardSummary {
  public TotalUsers: number;
}
