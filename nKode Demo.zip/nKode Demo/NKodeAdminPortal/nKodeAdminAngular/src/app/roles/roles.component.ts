import { Component, OnInit, ViewChild  } from '@angular/core';
import { NKodRole } from '../models/NKodRole';
import { HttpService } from '../http.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmDeleteModalComponent } from '../confirm-delete-modal/confirm-delete-modal.component';

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.css']
})
export class RolesComponent implements OnInit {
  roles: NKodRole[];
  newRole: string
  @ViewChild('addRoleForm') formValues;
  constructor(private httpService: HttpService, private modalService: NgbModal) { }

  ngOnInit() {
    this.httpService.getRoles().subscribe(data => this.roles = data);
  }

  public addRole(): void{
    this.httpService.saveRole(<NKodRole>{ Role: this.newRole, AllCustomerAccess:false }).subscribe(result => {
      this.roles.push(result);
      this.newRole = "";
      this.formValues.resetForm(); // Added this
    });
  }

  public deleteRole(role: NKodRole): void
  {
    let modal = this.modalService.open(ConfirmDeleteModalComponent);
    modal.componentInstance.deleteMessage = `Are you sure you wish to delete role: ${role.Role}?`;
    modal.result.then((value) => {
      this.httpService.deleteRole(role.Id).subscribe(data => {
      this.roles.splice(this.roles.indexOf(role), 1);
    });
    }, reason => {

      });
  }
}
