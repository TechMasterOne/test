//  ---------------------------------
//  ENVIRONMENT VARIABLES
//  ---------------------------------

var config = {
  API_URL: "http://localhost:58717",
  ADMIN_API_BASE_URL:"http://localhost:58717/api/NKodeAdminAPI",
    HTML_TEMPLATE_PATH: "assets/nKodeTemplates/${templateIdentifier}.html",    
  CLIENT_ID: "7ee607425af741dabc12e416afa02a47",//"498D12A91F604F8A82095AFA31FBE8CD", //"61db4bce45914bae9f6d364c67945e48",
    INTERFACE_HTML_PLACEHOLDER_ID: "nkod",   
    MAX_NKOD_LENGTH: 10,
    MIN_NKOD_LENGTH: 4
};

export default config;
