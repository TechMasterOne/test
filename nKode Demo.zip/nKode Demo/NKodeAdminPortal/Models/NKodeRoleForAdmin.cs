﻿using ArcanumTechnology.nKode;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NKodeAdminPortal.Models
{
    public class NKodeRoleForAdmin:NKodRole
    {
        public NKodeRoleForAdmin(NKodRole role)
        {
            this.Id = role.Id;
            this.AllCustomerAccess = role.AllCustomerAccess;
            this.Claims = role.Claims;
            this.Permissions = role.Permissions;
            this.Role = role.Role;
        }
        public bool disabled { get; set; }
    }
}