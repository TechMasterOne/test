﻿using ArcanumTechnology.nKode;
using ArcanumTechnology.nKode.DataTranslation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NKodeAdminPortal.Models
{
    public class EditUserViewModel
    {
        public User User { get; set; }
        public List<NKodeRoleForAdmin> AvailableRoles {get;set;}
    }
}