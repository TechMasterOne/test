﻿using ArcanumTechnology.nKode;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NKodeAdminPortal.Models
{
    public class NKodBindingModel
    {
        public Guid ClientId { get; set; }
        public string SessionId { get; set; }
        public string UserName { get; set; }
        //public List<string[]> Keys { get; set; }
        public string Keys { get; set; }
        public string TemplateIdentifier { get; set; }
        public string Fingerprint { get; set; }
        public string AttributeP1DARCData { get; set; }
        public string AttributeMutualEphemeralKeys { get; set; }
        /// <summary>
        /// Variable to hold any additional data the client wishes to send.
        /// </summary>
        public string AdditionalData { get; set; }       
    }    
}