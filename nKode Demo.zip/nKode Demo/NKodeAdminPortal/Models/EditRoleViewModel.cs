﻿using ArcanumTechnology.nKode;
using ArcanumTechnology.nKode.DataTranslation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NKodeAdminPortal.Models
{
    public class EditRoleViewModel
    {
        public NKodRole Role { get; set; }

        public List<NKodPermission> Permissions { get; set; }

        public List<NKodRole> AvailableRoles { get; set; }

        public List<Customer> AvailableCustomers { get; set; }
    }
}