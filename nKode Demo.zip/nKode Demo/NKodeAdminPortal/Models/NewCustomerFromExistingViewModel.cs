﻿using ArcanumTechnology.nKode.DataTranslation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NKodeAdminPortal.Models
{
    public class NewCustomerFromExistingViewModel
    {
        public Customer Customer { get; set; }
        public Guid CustomerToCopyFrom { get; set; }
    }
}