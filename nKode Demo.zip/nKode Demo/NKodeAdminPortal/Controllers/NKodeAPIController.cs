﻿using ArcanumTechnology.ArcanumCommon;
using ArcanumTechnology.DataTranslation;
using ArcanumTechnology.nKode;
using ArcanumTechnology.nKode.DataTranslation;
using ArcanumTechnology.nKode.Provider.JSON;
using ArcanumTechnology.nKode.ServerDataProviders;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.OAuth;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NKodeAdminPortal.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Caching;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web.Http;

namespace NKodeAdminPortal.Controllers
{
    [RoutePrefix("api/nkod"), CustomExceptionFilter]
    public class NKodeAPIController : ApiController
    {
        static readonly HashSet<string> ManuallyHandledClaimTypes = new HashSet<string>() { NKodRoleClaim.CustomerGUIDClaimType };
        private const int SessionCacheSeconds = 300;
        private const string UsernameVerified = "UsernameVerified|{0}";
        private const string UniqueIdCookieName = "NKodClientIdentifier";

        private void CacheUserLoginVerifiedForChange(string userName)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            memoryCache.Add(string.Format(UsernameVerified,userName), "" , new DateTimeOffset(DateTime.Now.AddSeconds(SessionCacheSeconds)));
        }

        private bool IsUsernameVerifiedForChange(string userName)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            string key = string.Format(UsernameVerified, userName);
            bool isVerified = memoryCache.Get(key) != null;

            return isVerified;
        }

        private void RemoveVerifiedUsernameFromCache(string userName)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            string key = string.Format(UsernameVerified, userName);
            memoryCache.Remove(key);
        }


        [HttpPost]
        [Route("generateInterface")]
        public async Task<HttpResponseMessage> GenerateInterface([FromBody]NKodBindingModel data)
        {            
            DARCData attributeP1DARCData = new DARCData(JsonConvert.DeserializeObject<RawDARCData>(data.AttributeP1DARCData));
            MutualEphemeralKeys attributeMutualEphemeralKeys = new MutualEphemeralKeys(JsonConvert.DeserializeObject<RawMutualEphemeralKeys>(data.AttributeMutualEphemeralKeys));

            nKodeJsonProvider provider = new nKodeJsonProvider();
            InterfaceData interfaceData = await provider.GenerateInterface(data.ClientId, attributeP1DARCData, attributeMutualEphemeralKeys);

            return Request.CreateResponse(HttpStatusCode.OK, interfaceData);            
        }

        [HttpPost]
        [Route("getLoginInterface")]
        public async Task<HttpResponseMessage> GetLoginInterface([FromBody]NKodBindingModel passcode)
        {            
            DARCData attributeP1DARCData = new DARCData(JsonConvert.DeserializeObject<RawDARCData>(passcode.AttributeP1DARCData));
            MutualEphemeralKeys attributeMutualEphemeralKeys = new MutualEphemeralKeys(JsonConvert.DeserializeObject<RawMutualEphemeralKeys>(passcode.AttributeMutualEphemeralKeys));

            NKodClientIdentifier identifier = CreateClientIdentifierFromFingerprint(passcode.Fingerprint);
            nKodeJsonProvider provider = new nKodeJsonProvider();
            InterfaceData interfaceData = await provider.GetLoginInterface(passcode.ClientId, passcode.UserName, identifier, attributeP1DARCData, attributeMutualEphemeralKeys);

            return Request.CreateResponse(HttpStatusCode.OK, interfaceData);            
        }


        private NKodClientIdentifier CreateClientIdentifierFromFingerprint(string fingerprint)
        {
            if (fingerprint == "unknown") //Browser was unable to generate a fingerprint for some reason
                return null;

            return new NKodClientIdentifier() { ClientType = ClientTypes.WebBrowser, ClientFingerprint = fingerprint };
        }


        // POST: api/PinDragon/login
        /// <summary>
        /// Confirms the user's authentication
        /// </summary>
        /// <param name="value">Keys passed in from UI</param>
        /// <returns>PindragonReturnStatus with code regarding success of failure of login</returns>
        [HttpPost, HttpOptions]
        [Route("")]
        public async Task<HttpResponseMessage> Login(NKodBindingModel login)
        {
            Dictionary<string, object> loginOptions = JsonConvert.DeserializeObject<Dictionary<string, object>>(login.AdditionalData);
            bool isVerifyForChange = (bool)loginOptions["isVerifyLoginForNKodeChange"];

            if (isVerifyForChange)
            {
                AuthenticationTicket ticket = Startup.OAuthOptions.AccessTokenFormat.Unprotect((string)loginOptions["bearerToken"]);
                
                if (!ticket.Identity.IsAuthenticated || login.UserName.ToLower() != ticket.Identity.Name.ToLower())
                    return Request.CreateResponse(HttpStatusCode.Unauthorized, "Confirm username doesn't match logged in user.");
            }

            List<List<byte>> keys = JsonConvert.DeserializeObject<List<List<byte>>>(login.Keys);
            nKodeJsonProvider jsonProvider = new nKodeJsonProvider();
                
            (AuthStatus result, User user) = await jsonProvider.IsValidUser(login.ClientId, login.SessionId, login.UserName, keys);
            switch (result)
            {
                case AuthStatus.Pass:
                    JObject token = await CreateTokenAsync(user, login.ClientId);                       
                    JObject response = new JObject(new JProperty("bearerToken", token));

                    if (isVerifyForChange)
                        CacheUserLoginVerifiedForChange(login.UserName);

                    return Request.CreateResponse(HttpStatusCode.OK, response, "application/json");
                case AuthStatus.Fail:
                    return Request.CreateResponse(HttpStatusCode.Unauthorized);
                case AuthStatus.AccountLocked:
                    return Request.CreateResponse(HttpStatusCode.Unauthorized, "Account Locked");
                case AuthStatus.AccountInactive:
                    return Request.CreateResponse(HttpStatusCode.Unauthorized, "Account Inactive");
                default:
                    return Request.CreateResponse(HttpStatusCode.Unauthorized);
            }
        }

       

        private async Task<JObject> CreateTokenAsync(User user, Guid customerGuid )
        {
            NKodServerDataProvider serverDataProvider = nKodeJsonProvider.GetNKodeDataProviderInstance();
            TimeSpan tokenExpiration = TimeSpan.FromMinutes(double.Parse(ConfigurationManager.AppSettings["AuthTokenLifeMinutes"]));
            TimeSpan refreshTokenExpiration = TimeSpan.FromMinutes(double.Parse(ConfigurationManager.AppSettings["RefreshTokenLifeMinutes"]));

            ClaimsIdentity identity = new ClaimsIdentity(OAuthDefaults.AuthenticationType);
            identity.AddClaim(new Claim(ClaimTypes.Name, user.UserName));
            identity.AddClaim(new Claim("CustomerGUID", Common.FormatGUID(user.CustomerGUID,GUIDFormats.Format.None)));

            if (user.Roles.Any(x => x.Id == 1)) //System Administrator
            {
                identity.AddClaim(new Claim(NKodRoleClaim.PermissionIdClaimType, ((int)Permissions.All).ToString()));
            }
            else
            {
                if (user.Roles.Any(x => x.AllCustomerAccess))
                    identity.AddClaim(new Claim(NKodRoleClaim.AllCustomerAccessClaimType, "true"));
                else
                    identity.AddClaims(user.Roles.SelectMany(x => x.Claims.Where(y => y.ClaimType == NKodRoleClaim.CustomerGUIDClaimType)).Distinct(new NKodRoleClaimComparer()).Select(x => new Claim(x.ClaimType, x.ClaimValue)));

                identity.AddClaims(user.Roles.SelectMany(x => x.Permissions).Select(x => x.Permission.Id).Distinct().Select(x => new Claim(NKodRoleClaim.PermissionIdClaimType, x.ToString())));

                identity.AddClaims(user.Roles.SelectMany(x => x.Claims.Where(y => !ManuallyHandledClaimTypes.Contains(y.ClaimType))).Distinct(new NKodRoleClaimComparer()).Select(x => new Claim(x.ClaimType, x.ClaimValue)));
            }            

            AuthenticationProperties authTokenProperties = new AuthenticationProperties()
            {
                IssuedUtc = DateTime.UtcNow,
                ExpiresUtc = DateTime.UtcNow.Add(tokenExpiration),
                AllowRefresh = true
            };
                        
            AuthenticationTicket accessTokenTicket = new AuthenticationTicket(identity, authTokenProperties);
            
            string accessToken = Startup.OAuthOptions.AccessTokenFormat.Protect(accessTokenTicket);

            string refreshTokenId = Common.FormatGUID(Guid.NewGuid(),GUIDFormats.Format.None);
            RefreshToken refreshToken = new RefreshToken() { TokenId = Utils.GetHash(refreshTokenId),User = user.UserName,CustomerGUID=customerGuid ,IssuedUtc = DateTime.UtcNow, ExpiresUtc = DateTime.UtcNow.Add(refreshTokenExpiration) };

            AuthenticationProperties refreshTokenProperties = new AuthenticationProperties()
            {
                IssuedUtc = DateTime.UtcNow,
                ExpiresUtc = DateTime.UtcNow.Add(refreshTokenExpiration),
                AllowRefresh = true
            };

            refreshTokenProperties.Dictionary["userName"] = user.UserName;
            refreshTokenProperties.Dictionary["CustomerGUID"] = Common.FormatGUID(customerGuid, GUIDFormats.Format.None);
            refreshTokenProperties.Dictionary[Utils.PermissionIdsTokenString] = JsonConvert.SerializeObject(identity.Claims.Where(x => x.Type == NKodRoleClaim.PermissionIdClaimType).Select(x => int.Parse(x.Value)).ToArray());
            
            AuthenticationTicket refreshTokenTicket = new AuthenticationTicket(identity, refreshTokenProperties);
            refreshToken.ProtectedTicket = Startup.OAuthOptions.RefreshTokenFormat.Protect(refreshTokenTicket);
            
            await serverDataProvider.AddRefreshTokenAsync(refreshToken);

            JObject tokenResponse = new JObject(
                                        new JProperty("userName", user.UserName),
                                        new JProperty("access_token", accessToken),
                                        new JProperty("refresh_token", refreshTokenId),
                                        new JProperty("token_type", "bearer"),
                                        new JProperty("expires_in", tokenExpiration.TotalSeconds.ToString()),
                                        new JProperty("CustomerGUID", Common.FormatGUID(customerGuid,GUIDFormats.Format.None)),
                                        new JProperty(Utils.PermissionIdsTokenString, refreshTokenProperties.Dictionary[Utils.PermissionIdsTokenString]),
                                        new JProperty(".issued", accessTokenTicket.Properties.IssuedUtc.ToString()),
                                        new JProperty(".expires", accessTokenTicket.Properties.ExpiresUtc.ToString())
            );

            return tokenResponse;           
        }

        [HttpPost, HttpOptions]
        [Route("confirm")]
        public async Task<HttpResponseMessage> Confirm(NKodBindingModel confirmation)
        {
            Dictionary<string, string> options = JsonConvert.DeserializeObject<Dictionary<string, string>>(confirmation.AdditionalData);
            bool isChange = bool.Parse(options["isChange"]);

            if (isChange)
            {
                AuthenticationTicket ticket = Startup.OAuthOptions.AccessTokenFormat.Unprotect(options["bearerToken"]);

                if (!ticket.Identity.IsAuthenticated || confirmation.UserName.ToLower() != ticket.Identity.Name.ToLower())
                    return Request.CreateResponse(HttpStatusCode.Unauthorized, "Username doesn't match logged in user.");
            }           

            List<List<byte>> keys = JsonConvert.DeserializeObject<List<List<byte>>>(confirmation.Keys);
            nKodeJsonProvider jsonProvider = new nKodeJsonProvider();

            NKodClientIdentifier identifier = CreateClientIdentifierFromFingerprint(confirmation.Fingerprint);

            (CreateNKodResult createNKodResult, NKodLicenseUserInfo licenseUserInfo) = await jsonProvider.ConfirmNKode(confirmation.ClientId, confirmation.SessionId, confirmation.UserName, confirmation.TemplateIdentifier, !isChange, keys, identifier);

            if (licenseUserInfo != null) //Perform license checks here to see if you're getting close to the user limit if applicable
            {
                if (licenseUserInfo.CurrentActiveUsers >= 0.9 * licenseUserInfo.LicenseUserLimit)
                {
                    //The number of users is within 10% of the license limit, send notification 

                }
            }

            if (createNKodResult.Success)
                RemoveVerifiedUsernameFromCache(confirmation.UserName);

            return Request.CreateResponse(HttpStatusCode.OK, createNKodResult);            
        }

        [HttpPost, HttpOptions]
        [Route("set")]
        public async Task<HttpResponseMessage> SetPasscode([FromBody]NKodBindingModel passcode)
        {
            Dictionary<string, bool> options = JsonConvert.DeserializeObject<Dictionary<string, bool>>(passcode.AdditionalData);
            List<List<byte>> keys = JsonConvert.DeserializeObject<List<List<byte>>>(passcode.Keys);
            DARCData attributeP1DARCData = new DARCData(JsonConvert.DeserializeObject<RawDARCData>(passcode.AttributeP1DARCData));
            MutualEphemeralKeys attributeMutualEphemeralKeys = new MutualEphemeralKeys(JsonConvert.DeserializeObject<RawMutualEphemeralKeys>(passcode.AttributeMutualEphemeralKeys));

            if(!options["isChange"]) //New user, ensure username doesn't exist
            {
                NKodServerDataProvider serverDataProvider = nKodeJsonProvider.GetNKodeDataProviderInstance();
                if (await serverDataProvider.UserExistsAsync(passcode.UserName, passcode.ClientId))
                    return Request.CreateResponse(HttpStatusCode.OK, new { userExists = true });
            }

            var jsonProvider = new nKodeJsonProvider();

            //Perform dispersion shuffle so that user can confim NKod
            InterfaceData interfaceData = await jsonProvider.CreateNKodeStep1(passcode.ClientId, passcode.SessionId, passcode.UserName, keys, attributeP1DARCData, attributeMutualEphemeralKeys);

            return Request.CreateResponse(HttpStatusCode.OK, interfaceData);            
        }
    }
}
