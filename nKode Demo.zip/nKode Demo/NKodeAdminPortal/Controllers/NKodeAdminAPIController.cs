﻿using ArcanumTechnology.ArcanumCommon;
using ArcanumTechnology.DataTranslation;
using ArcanumTechnology.nKode;
using ArcanumTechnology.nKode.DataTranslation;
using ArcanumTechnology.nKode.Provider.JSON;
using ArcanumTechnology.nKode.ServerDataProviders;
using NKodeAdminPortal.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;

namespace NKodeAdminPortal.Controllers
{
    [RoutePrefix("api/NKodeAdminAPI"), CustomExceptionFilter,CustomAuthorize]
    public class NKodeAdminAPIController : ApiController
    {
        private NKodServerDataProvider _dal = nKodeJsonProvider.GetNKodeDataProviderInstance();

        [HttpOptions, HttpGet, Route("editUser"), CustomAuthorize(Permissions.All, Permissions.ManageUsers)]
        public async Task<EditUserViewModel> EditUser(string username, Guid customerId)
        {            
            try
            {
                await _dal.ConnectAsync();
                EditUserViewModel vm = new EditUserViewModel();                                         

                vm.User = await _dal.GetUserAsync(username, customerId);

                if (vm.User == null)
                    return null;

                if((User.Identity as ClaimsIdentity).HasPermission(Permissions.All, Permissions.ManageUserRoles))
                {
                    vm.User.Roles = await _dal.GetUserRolesAsync(vm.User.GUID);
                    int[] rolesUserCanManage = Utils.GetCanManageRoleIdsForUser();
                    List<int> roleIds = rolesUserCanManage?.ToList();

                    if (roleIds == null || roleIds.Any())
                    {
                        HashSet<int> userRolesNotInPermissions = null;
                        if(roleIds != null && roleIds.Any())
                        {
                            userRolesNotInPermissions = new HashSet<int>(vm.User.Roles.Where(x => !roleIds.Contains(x.Id)).Select(x=>x.Id));
                            roleIds.AddRange(userRolesNotInPermissions);
                        }
                        vm.AvailableRoles = (await _dal.GetRolesAsync(roleIds?.ToArray())).Select(x=>new NKodeRoleForAdmin(x) { disabled = rolesUserCanManage != null && !rolesUserCanManage.Contains(x.Id) }).ToList();
                    }
                }
                
                return vm;
            }
            finally
            {
                _dal.Disconnect();
            }
        }

        [HttpOptions, HttpPost, Route("saveUser"), CustomAuthorize(Permissions.All, Permissions.ManageUsers)]
        public async Task<IHttpActionResult> SaveUser([FromBody]User user)
        {
            try
            {
                bool canManageRoles = (User.Identity as ClaimsIdentity).HasPermission(Permissions.All, Permissions.ManageUserRoles);

                if(canManageRoles)//Ensure current user can add/remove any roles being modified for user
                {
                    int[] rolesUserCanManage = Utils.GetCanManageRoleIdsForUser();
                    if(rolesUserCanManage != null) //NOTE null means user can manage all roles
                    {
                        HashSet<int> rolesUserCanManageHashSet = new HashSet<int>(rolesUserCanManage);
                        List<NKodRole> rolesFromDb = await _dal.GetUserRolesAsync(user.GUID); //Get existing roles for user

                        HashSet<int> rolesFromDbIds = new HashSet<int>(rolesFromDb.Select(x=>x.Id));

                        //Remove all roles user does not have permission to manage.  Any roles already associated with user in the db will be added back below
                        user.Roles.RemoveAll(x => !rolesUserCanManage.Contains(x.Id)); 
                        
                        foreach(int roleIdFromDb in rolesFromDbIds)
                        {
                            if(!rolesUserCanManageHashSet.Contains(roleIdFromDb)) //Current user cannot add/delete this role.  Ensure it exists on the user object being saved
                            {
                                if (!user.Roles.Any(x => x.Id == roleIdFromDb))
                                    user.Roles.Add(new NKodRole() { Id=roleIdFromDb }); //Add back to user object so it doesn't get removed
                            }
                        }

                    }
                    
                    //GetAllCanManageRoleIds
                }
                //TODO: Verify user is saving a user belonging to a company he/she can access
                await  _dal.SaveUserAsync(user, (User.Identity as ClaimsIdentity).HasPermission(Permissions.All, Permissions.ManageUserRoles));

                return Ok();
            }
            finally
            {
                _dal.Disconnect();
            }
        }

        [HttpOptions, HttpGet, Route("getRoles"), CustomAuthorize(Permissions.All)]
        public async Task<List<NKodRole>> GetRoles()
        {
            return await _dal.GetRolesAsync();
        }

        [HttpOptions, HttpGet, Route("getDashboardSummary"), CustomAuthorize(Permissions.All, Permissions.Dashboard)]
        public async Task<IHttpActionResult> GetAdminDashboardSummary(Guid? customerGuid)
        {
            Guid[] customerGuidFilter = null;

            if (customerGuid != null)
            {
                if (!Utils.UserCanAccessCustomer(customerGuid.GetValueOrDefault()))
                    return StatusCode(HttpStatusCode.Forbidden);

                customerGuidFilter = new Guid[] { customerGuid.GetValueOrDefault() };
            }
            else
                customerGuidFilter = Utils.GetCustomerAccessGuidsForUser();

            return Ok(await _dal.GetAdminDashboardSummaryAsync(customerGuidFilter));
        }

        [HttpOptions, HttpGet, Route("getCustomer"), CustomAuthorize(Permissions.All)]
        public async Task<Customer> GetCustomer(Guid customerGuid)
        {
            return await _dal.GetCustomerInfoAsync(customerGuid,ConfigurationManager.AppSettings["EncryptionKey"]);
        }

        //[AllowAnonymous] 
        [HttpOptions, HttpPost, Route("createCustomer"), CustomAuthorize(Permissions.All)]
        public async Task<IHttpActionResult> CreateNewCustomer(Customer customer)
        {
            NKodEngine engine = new NKodEngine(_dal);
                    
            customer.GUID = Guid.NewGuid();
            DarcConfig interfaceConfig = new DarcConfig() { Height=10,Width=7,InputBlockLength=10 };
            DarcConfig attributesConfig = new DarcConfig() { Height = 70, Width = 3, InputBlockLength = 70 };
            await engine.CreateNewCustomer(customer, interfaceConfig, attributesConfig, ConfigurationManager.AppSettings["EncryptionKey"], GetRSAPublicKey());
            
            return Ok(customer);
        }

        [HttpOptions, HttpPost, Route("createCustomerFromExisting"), CustomAuthorize(Permissions.All)]
        public async Task<IHttpActionResult> CreateNewCustomerFromExisting(NewCustomerFromExistingViewModel newCustomerFromExistingViewModel)
        {
            NKodEngine engine = new NKodEngine(_dal);

            newCustomerFromExistingViewModel.Customer.GUID = Guid.NewGuid();
            
            await engine.CreateNewCustomerFromExisting(newCustomerFromExistingViewModel.Customer, newCustomerFromExistingViewModel.CustomerToCopyFrom, ConfigurationManager.AppSettings["EncryptionKey"]);

            return Ok(newCustomerFromExistingViewModel.Customer);
        }

        [HttpOptions, HttpPost, Route("saveCustomer"), CustomAuthorize(Permissions.All)]
        public async Task<IHttpActionResult> SaveCustomer(Customer customer)
        {
            await _dal.SaveCustomerAsync(customer);
            
            return Ok();
        }

        private static string GetRSAPublicKey()
        {
            string licensePath = Path.Combine(Path.GetDirectoryName(new Uri(Assembly.GetExecutingAssembly().GetName().CodeBase).LocalPath), "nKodePublicKey.pem");
            return File.ReadAllText(licensePath);
        }  

        [HttpOptions, HttpGet, Route("getCustomers"), CustomAuthorize(Permissions.All)]
        public async Task<List<Customer>> GetCustomers()
        {
            return await _dal.GetSimpleCustomerListingAsync();
        }

        [HttpOptions, HttpGet, Route("getCustomersForUser"), CustomAuthorize(Permissions.All,Permissions.Dashboard, Permissions.ManageUsers)]
        public async Task<List<Customer>> GetCustomersForUser()
        {
            return await _dal.GetSimpleCustomerListingAsync(Utils.GetCustomerAccessGuidsForUser());
        }   

        [HttpOptions, HttpPost, Route("saveRole"), CustomAuthorize(Permissions.All)]
        public async Task<IHttpActionResult> SaveRole([FromBody]NKodRole role)
        {
            await _dal.SaveRoleAsync(role,role.Id !=0);
            return Ok(role);
        }

        [HttpOptions, HttpPost, Route("deleteRole/{id}"), CustomAuthorize(Permissions.All)]
        public async Task<IHttpActionResult> DeleteRole(int id)
        {
            await _dal.DeleteRoleAsync(id);
            return Ok();
        }

        [HttpOptions, HttpGet, Route("editRole"), CustomAuthorize(Permissions.All)]
        public async Task<IHttpActionResult> EditRole(int id)
        {
            EditRoleViewModel vm = new EditRoleViewModel();
            try
            {
                await _dal.ConnectAsync(); //manually open connection so that all operations are done on the same connection
                
                vm.Role = await _dal.GetRoleAsync(id);                
                vm.Permissions = await _dal.GetPermissionsAsync();
                vm.AvailableRoles = await _dal.GetRolesAsync();                              
                vm.AvailableCustomers = await _dal.GetSimpleCustomerListingAsync();
            }
            finally
            {
                _dal.Disconnect();
            }           

            return Ok(vm);
        }
    }
}