﻿
# nKode General Documentation
## Disclaimer
These demos are provided as examples of how to use the nKode API/SDK.  It is your responsibility to ensure everything is appropriately secured when migrating to a production environment.  You need to ensure CORS (Cross-origin resource sharing) is appropriately configured for the URLs the application will be running on for example.
## Prerequisites
  - .NET 4.7.2 SDK/Runtime
  - You must have node.js installed to make changes to the JavaScript files.  If using the Angular application you must have the Angular CLI installed to make changes to the Angular demo. See https://angular.io/guide/quickstart for instructions on environment setup.  

## Demo Development Setup/Execution/Notes
 1. Install database server (Currently only mySQL or SQLServer is supported)
 2. Run database create script.  A zip file containing this is in the solution/db folder.  Choose the one that corresponds to the DBMS you're using.
 3. The nKode API/SDK must be run in 64 bit mode to support the licensing provider.  If using IIS Express you can configure it to run in 64 bit mode by going to Tools->Options -> Project and Solutions -> Web Projects -> "Check" "Use 64 bit version of IIS Express for web sites and projects" in Visual Studio.  You may also need to install the latest Visual C++ runtime to support the licensing provider: https://support.microsoft.com/en-us/help/2977003/the-latest-supported-visual-c-downloads

Use the following default credentials to login.  This should be changed ASAP: 
	 username: administrator
	 nKode: Red D Diamond Zero

### Angular Application
 1. Set the database connection string in the web.config of the NKodeAdminPortal project for the DBMS you're using (NKodMySqlConnectionString for MySQL or NKodSqlServerConnectionString for SQLServer ).
 2. Set the database provider key (DBProvider) in the web.config to the appropriate DBMS (SQLServer or MySql)
 3. Build the project and place the nKode.lic license file in the bin directory (you will receive separate instructions for creating this)
 4. The project is currently configured to run in IIS Express with the Angular application files residing in the /wwwroot directory.  Run it in debug via Visual Studio to use the demo as is.   If you wish to setup the demo in IIS or make any changes to the Angular application you will need to perform the following steps:
 5.  Open the command prompt and navigate to the nKode Demo\NKodeAdminPortal\nKodeAdminAngular directory (the Angular application).
 6. type "npm install" to install the required packages.  You might get an error message about Python missing if you don't have Windows build tools installed.  If that's the case, you may need to run the following two commands then rerun "npm install": 
		npm --add-python-to-path='true' --debug install --global windows-build-tools
		npm install --global node-gyp
 7. Configure the Angular application to point to the web API back end if you have changed the URL it resides at.  This is done in NKodeAdminPortal/nKodeAdminAngular/src/assets/config.js.  
	API_URL is the base controller URL used for nKode itself.  ADMIN_API_BASE_URL is the base controller URL used for the rest of the admin Angular application.
 8. Type "ng build" to build for development or "ng build --prod" to build for production in the command prompt you opened earlier to build the Angular application.  Built files will go into the /wwwroot directory.  Note that you will need to build for development in order to debug any JavaScript.
### Web Forms Demo Application
 1. Set the database connection string in the web.config of the WebFormsExample project for the DBMS you're using (NKodMySqlConnectionString for MySQL or NKodSqlServerConnectionString for SQLServer ).
 2. Navigate to the WebFormsExample solution root directory in the command prompt.
 4. Run the application in debug mode via Visual Studio.  Note that this project is currently configured to run in IIS Express.  
*NOTE:  This demo project provides an example of how to use nKode in a modal popup and on a page by itself.  To see the modal example, login or signup from the homepage, otherwise click the login link.  When a user is logged in, there will be a link for the user to change his/her nKode.  The change nKode functionality is not implemented in a modal popup in this demo.*

#### JavaScript building/bundling
Webpack is used in the Web Forms Demo application to bundle script files related to nKode as well as provide polyfills for browsers that don't support some of the modern JavaScript syntax used.  There are several files used for Webpack to work:
 - *.babelrc*: Configures the Babel transpiler
 - *package.json*: npm (node package manager) file for packages that are used as well as predefined shortcut commands that can be run via npm
 - *webpack.config.js*: The Webpack configuration
 
When you make changes to [nkodeImplementation.js](#nkodeImplementation), you must rerun Webpack on it.  To do so, open the command prompt and change the directory to the root of the WebFormsExample project.  You will need to type "npm install" the first time to install the required packages.  To build it for development, which will allow you to debug scripts, type: "npm run build-dev".  To build it for production, type: "npm run build".  These commands are defined in package.json.  The output of these files will go into the /nKodeScriptDist folder.

## Notable File Descriptions
### General
#### nKode JS API
##### nKode.js 
The nKode JavaScript API used for development. This version allows JavaScript debugging.
##### nKode.prod.js
The nKode JavaScript API that needs to be used for production deployments. This file prevents anyone from stepping through code in the debugger. Note that this file is automatically referenced in the provided Angular Admin application when you build in production mode. This is configured in the fileReplacements section of the angular.json configuration file for the Angular application.
#### Templates
The template corresponds to the HTML generated for one key.  Attribute set placeholders in the templates are replaced with the shuffled numerical attribute values.  You may use the values however you wish to render the interface.  In the provided examples, the numerical values are used to resolve to either .svg images or css classes.  Required attribute set placeholders are:
    -   $\{attributeSetOne\}
    -   $\{attributeSetTwo\}
    -   $\{attributeSetThree\}
    -   $\{attributeSetFour\}
    -   $\{attributeSetFive\}
    -   $\{attributeSetSix\} 
In addition to the attribute set placeholders above, the following must exist somewhere in the HTML template as an attribute on an element: data-indexer='\$\{indexer\}'. 
### Client Angular Application (NKodeAdminPortal/nKodeAdminAngular)
 -  */src/app/n-kode*: This folder contains the majority of the files used by nKode itself.  
    -  *n-kode.component.ts*: This file contains the full example of how to consume the nKode client JavaScript API.  All calls starting with "nKode." are calls to the nKode JavaScript API.
    -   *sharedTemplate.css*: This file contains the styles shared by the two default templates that come with the demo
    -   *emojis.css*: This file contains the styles used just by the emojis interface
    -   *n-kode.component.html*: This file contains the Angular view for displaying and working with the nKode interface
 - */src/assets/nKodeTemplates*:  This folder contains the HTML templates used for the different interface choices. [See Templates General Documentation](#templates)  
 - */src/assets/config.js*: This is the config object used by both nKode and the admin application.  See the HTML JavaScript API documentation for more information on the config values required by the nKode JavaScript API.
 - */src/assets/nKode.js*: [See nKode.js General Documentation](#nkode.js) 
 - */src/assets/nKode.prod.js*: [See nKode.prod.js General Documentation](#nkode.prod.js) 
 
### C# .NET Server Side (General)
- *web.config (both demo projects*: App keys are defined in here for the database connection string as well as nKode configuration options.  
 - */lib/nKode.dll*: The C# nKode SDK
 - */lib/liblmxnet.dll*:  The X-Formation licensing SDK used by the application to verify the user is correctly licensed.
 - */lib/ArcanumCommon.dll*: A common library used by nKode.dll
 - */LicenseActivator/LicenseActivator.exe*:  Run this application and enter the license key you were provided with.  The activated license will be placed in the LicenseActivator folder the .exe resides in.  Rename the license to nKode.lic and move it to the bin folder of the C# application using nKode.
 - *NKodeAdminPortal/Controllers/NKodeAPIController.cs* and *WebFormsExample/Controllers/NKodeAPIController*:  This is the web API controller used by nKode.  The web methods in this controller do little processing and mostly handle communication with the nKode client application and make calls to the nKodeJsonProvider project.  Note that the route names on the methods cannot be changed as the nKode JavaScript API is hard-coded to reference those API paths.
 - *NKodeAdminPortal/Controllers/NKodeAdminAPIController.cs*: This is the web API controller used by the rest of the nKode administrative interface application
 - *nKodeJsonProvider Project*: This is the web oriented implementation of the nKode SDK.  It exposes an API that can easily be consumed by a web application.  
    - *nKodeJsonProvider/nKodeJsonProvider.cs*: This class is the main guts of the web specific implementation of nKode.  The main thing you should be aware of when implementing this is that by default it uses the .NET Memory Cache to store data that needs to persist across posts such as DARC session key encryption data, the shuffled interface the user is working with, and the first entered nKode when a user is creating or changing his/her nKode.  **NOTE**: If this will be implemented on a load balanced server farm with multiple web instances, a memory cache server that runs outside the web process such as redis will need to be used.
### WebFormsExample demo project
- */WebApiConfig.cs*:  This is necessary for a Web API controller to be used in a Web Forms project.  This must be called in the Application_Start event of Global.asax.cs: `GlobalConfiguration.Configure(WebApiConfig.Register);`
- */nKodeTemplates*: This folder contains the HTML templates used for the different interface choices. [See Templates General Documentation](#templates)  
- */nKodeCss*: CSS files used for the nKode interface and username input
	- *emojis.css*: This file contains the styles used just by the emojis interface
	- *sharedTemplate.css*: This file contains the styles shared by the two default templates that come with the demo
	- *main.css*:  General styles used for displaying the nKode interface
- */images/nKode*:  Images used on the nKode interface (emojis, shapes, button border colors, etc)
- */nKodeSrcScripts*: Script files used for implementing the nKode JavaScript API
	- *config.dev.js*: This is the development config object used by the nKode client JavaScript implementation and API.  See the HTML JavaScript API documentation for more information on the config values required by the nKode JavaScript API.
	- *config.prod.js*: This is the production config object used by the nKode client JavaScript implementation and API.  See the HTML JavaScript API documentation for more information on the config values required by the nKode JavaScript API.
	 - *nKode.dev.js*: [See nKode.js General Documentation](#nkode.js) 
	 - *nKode.prod.js*: [See nKode.prod.js General Documentation](#nkode.prod.js) 
	 - <a id="nkodeImplementation"></a>*nKodeImplementation.js*:  The demo implementation of nKode
 - */nKodeScriptDist*: The scripts that were bundled and minified by webpack.  See [https://webpack.js.org/](https://webpack.js.org/) for more information and documentation on webpack.  [See JavaScript building/bundling](#javascript-buildingbundling) for how to build these files in the demo.
	 - *index.js*: The combined result of nKodeImplementation.js and the develpment or production nKode JS API.  If this filename needs to be changed it can be done so in the webpack config (webpack.config.js in the project root directory).  Simply change 'index' in the following config line to whatever you wish the file to be named: `entry: { index:`
	 - *vendor.js*:  The 3rd party script files referenced by the nKode JS API and nKodeImplementation.js
	 


