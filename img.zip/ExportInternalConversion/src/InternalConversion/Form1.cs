﻿namespace InternalConversion
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Drawing;
    using System.Runtime.CompilerServices;
    using System.Text;
    using System.Windows.Forms;

    public class Form1 : Form
    {
        private IContainer components;
        private Button button1;
        private TextBox textBox1;
        private OpenFileDialog openFileDialog1;
        private TextBox textBox3;
        private Label label1;
        private Label label2;
        private Label label3;

        public Form1()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.ShowDialog();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.button1 = new Button();
            this.textBox1 = new TextBox();
            this.openFileDialog1 = new OpenFileDialog();
            this.textBox3 = new TextBox();
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            base.SuspendLayout();
            this.button1.Location = new Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0xa8, 0x17);
            this.button1.TabIndex = 0;
            this.button1.Text = "ProcessInternalConversion";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textBox1.Location = new Point(12, 0x42);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = ScrollBars.Vertical;
            this.textBox1.Size = new Size(0x1ee, 0x13d);
            this.textBox1.TabIndex = 1;
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new CancelEventHandler(this.openFileDialog1_FileOk);
            this.textBox3.Location = new Point(0x20a, 0x42);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ScrollBars = ScrollBars.Vertical;
            this.textBox3.Size = new Size(0x21b, 0x13d);
            this.textBox3.TabIndex = 3;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(12, 0x2f);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x25, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Result";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x207, 50);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x1d, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Error";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0xf7, 12);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x23, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "label3";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x42e, 0x191);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.textBox3);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.button1);
            base.Name = "Form1";
            this.Text = "Form1";
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        [AsyncStateMachine(typeof(<openFileDialog1_FileOk>d__2))]
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            <openFileDialog1_FileOk>d__2 d__;
            d__.<>4__this = this;
            d__.<>t__builder = AsyncVoidMethodBuilder.Create();
            d__.<>1__state = -1;
            d__.<>t__builder.Start<<openFileDialog1_FileOk>d__2>(ref d__);
        }

        [CompilerGenerated]
        private struct <openFileDialog1_FileOk>d__2 : IAsyncStateMachine
        {
            public int <>1__state;
            public AsyncVoidMethodBuilder <>t__builder;
            public Form1 <>4__this;

            private void MoveNext()
            {
                int num = this.<>1__state;
                Form1 form = this.<>4__this;
                try
                {
                    InternalConversion.InternalConversion conversion = new InternalConversion.InternalConversion();
                    List<string> errors = new List<string>();
                    form.textBox1.Text = conversion.Process("", "", form.openFileDialog1.FileName, out errors);
                    StringBuilder builder = new StringBuilder();
                    List<string>.Enumerator enumerator = errors.GetEnumerator();
                    try
                    {
                        while (enumerator.MoveNext())
                        {
                            string current = enumerator.Current;
                            builder.AppendLine(current);
                        }
                    }
                    finally
                    {
                        if (num < 0)
                        {
                            enumerator.Dispose();
                        }
                    }
                    form.textBox3.Text = builder.ToString();
                }
                catch (Exception exception)
                {
                    this.<>1__state = -2;
                    this.<>t__builder.SetException(exception);
                    return;
                }
                this.<>1__state = -2;
                this.<>t__builder.SetResult();
            }

            [DebuggerHidden]
            private void SetStateMachine(IAsyncStateMachine stateMachine)
            {
                this.<>t__builder.SetStateMachine(stateMachine);
            }
        }
    }
}

