﻿namespace InternalConversion
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Text;

    public class InternalConversion
    {
        private int _linesfailed;
        private int _linesprocessed;
        private int _linesprocessedfailed;
        private int _linesread;
        private string _newacctnumber = "";
        private string _newcompany = "";
        private string _newcorp = "";
        private string _newinst = "";
        private string _newproduct = "";
        private string _newsublevel2 = "";
        private string _newsublevel3 = "";
        private string _newsublevel4 = "";
        private string _newsublevel5 = "";
        private string _newsublevel6 = "";
        private string _oldacctnumber = "";
        private string _oldcompany = "";
        private string _oldcorp = "";
        private string _oldinst = "";
        private string _oldproduct = "";
        private string _oldsublevel2 = "";
        private string _oldsublevel3 = "";
        private string _oldsublevel4 = "";
        private string _oldsublevel5 = "";
        private string _oldsublevel6 = "";
        private string m_realm = string.Empty;
        private List<string> intErrors = new List<string>();

        private string FormatCompany(string company)
        {
            try
            {
                return ((Convert.ToInt32(company) <= 0) ? "00000000" : company);
            }
            catch (Exception)
            {
                return "00000000";
            }
        }

        private string FormatSublevel(string sublevel)
        {
            try
            {
                return ((Convert.ToInt32(sublevel) <= 0) ? "00000000" : sublevel);
            }
            catch (Exception)
            {
                return "00000000";
            }
        }

        private bool IsNewRetail(string newacctnum, string newcorp, string newinst, string newproduct)
        {
            bool flag = false;
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["eZCardConn"].ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand("eZ_InternalConversionNewRetail", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("newacctnum", newacctnum);
                        command.Parameters.AddWithValue("newcorp", newcorp);
                        command.Parameters.AddWithValue("newinst", newinst);
                        command.Parameters.AddWithValue("newproduct", newproduct);
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                flag = Convert.ToBoolean(reader["IsRetail"].ToString());
                            }
                        }
                        connection.Close();
                    }
                }
            }
            catch (Exception)
            {
                flag = false;
            }
            return flag;
        }

        private bool IsOldRetail(string oldacctnum, string oldcorp, string oldinst, string oldproduct)
        {
            bool flag = false;
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["eZCardConn"].ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand("eZ_InternalConversionOldRetail", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("oldacctnumber", oldacctnum);
                        command.Parameters.AddWithValue("oldcorp", oldcorp);
                        command.Parameters.AddWithValue("oldinst", oldinst);
                        command.Parameters.AddWithValue("oldproduct", oldproduct);
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                flag = Convert.ToBoolean(reader["IsRetail"].ToString());
                            }
                        }
                        connection.Close();
                    }
                }
            }
            catch (Exception)
            {
                flag = false;
            }
            return flag;
        }

        private bool NewValuesExists(string newacctnum, string newcorp, string newinst, string newproduct, string newcompany, string newsublevel2, string newsublevel3, string newsublevel4, string newsublevel5, string newsublevel6)
        {
            bool flag = false;
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["eZCardConn"].ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand("eZ_InternalConversionNewExists", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("newacctnumber", newacctnum);
                        command.Parameters.AddWithValue("newcorp", newcorp);
                        command.Parameters.AddWithValue("newinst", newinst);
                        command.Parameters.AddWithValue("newproduct", newproduct);
                        command.Parameters.AddWithValue("newcompany", newcompany);
                        command.Parameters.AddWithValue("newsublevel2", newsublevel2);
                        command.Parameters.AddWithValue("newsublevel3", newsublevel3);
                        command.Parameters.AddWithValue("newsublevel4", newsublevel4);
                        command.Parameters.AddWithValue("newsublevel5", newsublevel5);
                        command.Parameters.AddWithValue("newsublevel6", newsublevel6);
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                flag = Convert.ToBoolean(reader["NewExists"].ToString());
                            }
                        }
                        connection.Close();
                    }
                }
            }
            catch (Exception)
            {
                flag = false;
            }
            return flag;
        }

        private bool OldValuesExists(string oldacctnum, string oldcorp, string oldinst, string oldproduct, string oldcompany, string oldsublevel2, string oldsublevel3, string oldsublevel4, string oldsublevel5, string oldsublevel6)
        {
            bool flag = false;
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["eZCardConn"].ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand("eZ_InternalConversionOldExists", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("oldacctnumber", oldacctnum);
                        command.Parameters.AddWithValue("oldcorp", oldcorp);
                        command.Parameters.AddWithValue("oldinst", oldinst);
                        command.Parameters.AddWithValue("oldproduct", oldproduct);
                        command.Parameters.AddWithValue("oldcompany", oldcompany);
                        command.Parameters.AddWithValue("oldsublevel2", oldsublevel2);
                        command.Parameters.AddWithValue("oldsublevel3", oldsublevel3);
                        command.Parameters.AddWithValue("oldsublevel4", oldsublevel4);
                        command.Parameters.AddWithValue("oldsublevel5", oldsublevel5);
                        command.Parameters.AddWithValue("oldsublevel6", oldsublevel6);
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                flag = Convert.ToBoolean(reader["OldExists"].ToString());
                            }
                        }
                        connection.Close();
                    }
                }
            }
            catch (Exception)
            {
                flag = false;
            }
            return flag;
        }

        private bool ParseLine(string line)
        {
            this._oldacctnumber = line.Substring(0, 0x10).Trim();
            this._newacctnumber = line.Substring(0x10, 0x10).Trim();
            this._oldcorp = line.Substring(0x21, 6).Trim();
            this._newcorp = line.Substring(0x27, 6).Trim();
            this._oldinst = line.Substring(0x2d, 6).Trim();
            this._newinst = line.Substring(0x36, 6).Trim();
            this._oldproduct = line.Substring(0x3f, 6).Trim();
            this._newproduct = line.Substring(0x45, 6).Trim();
            this._oldcompany = this.FormatCompany(line.Substring(0x4b, 8).Trim());
            this._newcompany = this.FormatCompany(line.Substring(0x53, 8).Trim());
            this._oldsublevel2 = this.FormatSublevel(line.Substring(0x5b, 8).Trim());
            this._newsublevel2 = this.FormatSublevel(line.Substring(0x63, 8).Trim());
            this._oldsublevel3 = this.FormatSublevel(line.Substring(0x6b, 8).Trim());
            this._newsublevel3 = this.FormatSublevel(line.Substring(0x73, 8).Trim());
            this._oldsublevel4 = this.FormatSublevel(line.Substring(0x7b, 8).Trim());
            this._newsublevel4 = this.FormatSublevel(line.Substring(0x83, 8).Trim());
            this._oldsublevel5 = this.FormatSublevel(line.Substring(0x8b, 8).Trim());
            this._newsublevel5 = this.FormatSublevel(line.Substring(0x93, 8).Trim());
            this._oldsublevel6 = this.FormatSublevel(line.Substring(0x9b, 8).Trim());
            try
            {
                this._newsublevel6 = this.FormatSublevel(line.Substring(0xa3, 8).Trim());
            }
            catch (Exception)
            {
                this._newsublevel6 = "00000000";
            }
            if (!this.UpdateRecord(line, this._oldacctnumber, this._newacctnumber, this._oldcorp, this._newcorp, this._oldinst, this._newinst, this._oldproduct, this._newproduct, this._oldcompany, this._newcompany, this._oldsublevel2, this._newsublevel2, this._oldsublevel3, this._newsublevel3, this._oldsublevel4, this._newsublevel4, this._oldsublevel5, this._newsublevel5, this._oldsublevel6, this._newsublevel6))
            {
                this.intErrors.Add("ICException: UpdateRecord: " + line);
                this._linesfailed++;
            }
            return true;
        }

        public string Process(string realm, string param, string filePath, out List<string> errors)
        {
            string str3;
            this.m_realm = realm;
            FileStream stream = null;
            string path = "";
            this.intErrors = new List<string>();
            try
            {
                path = filePath;
                using (stream = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.None))
                {
                    StreamReader reader = new StreamReader(stream);
                    try
                    {
                        string line = reader.ReadLine();
                        this._linesread++;
                        do
                        {
                            this.intErrors.Add(this._linesread + "-------------------------------------------------------------------------------");
                            try
                            {
                                if (!this.ParseLine(line))
                                {
                                    this.intErrors.Add("ICException ParseLine Failed: " + line);
                                    this._linesfailed++;
                                }
                            }
                            catch (Exception)
                            {
                                this.intErrors.Add("ICException: ParseLine Exceptioned: " + line);
                                this._linesfailed++;
                            }
                            line = reader.ReadLine();
                            this._linesread++;
                        }
                        while ((line != null) && (line.Length > 0));
                    }
                    catch (Exception)
                    {
                        this.intErrors.Add("InternalConversion: Internal Conversion Failed: File was not processed.");
                    }
                }
                if (File.Exists(path))
                {
                    File.Move(path, path + DateTime.Now.ToString("yyyyMMddHHmmss"));
                }
                str3 = this.SendNotification();
            }
            catch (Exception exception)
            {
                this.intErrors.Add("InternalConversion: Internal Conversion Failed: File was not processed. Exception " + exception.Message);
                str3 = exception.ToString();
            }
            finally
            {
                stream.Close();
                errors = this.intErrors;
            }
            return str3;
        }

        private bool ProcessHistorical(string line, string oldacctnumber, string newacctnumber, string oldcorp, string newcorp, string oldinst, string newinst, string oldproduct, string newproduct, string oldcompany, string newcompany, string oldsublevel2, string newsublevel2, string oldsublevel3, string newsublevel3, string oldsublevel4, string newsublevel4, string oldsublevel5, string newsublevel5, string oldsublevel6, string newsublevel6)
        {
            bool flag = false;
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["eZCardConn"].ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand("eZ_InternalConversionTransfer", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("oldaccountnumber", oldacctnumber);
                        command.Parameters.AddWithValue("newaccountnumber", newacctnumber);
                        command.Parameters.AddWithValue("oldcorp", oldcorp);
                        command.Parameters.AddWithValue("newcorp", newcorp);
                        command.Parameters.AddWithValue("oldinst", oldinst);
                        command.Parameters.AddWithValue("newinst", newinst);
                        command.Parameters.AddWithValue("oldproduct", oldproduct);
                        command.Parameters.AddWithValue("newproduct", newproduct);
                        command.Parameters.AddWithValue("oldcompany", oldcompany);
                        command.Parameters.AddWithValue("newcompany", newcompany);
                        command.Parameters.AddWithValue("oldsublevel2", oldsublevel2);
                        command.Parameters.AddWithValue("newsublevel2", newsublevel2);
                        command.Parameters.AddWithValue("oldsublevel3", oldsublevel3);
                        command.Parameters.AddWithValue("newsublevel3", newsublevel3);
                        command.Parameters.AddWithValue("oldsublevel4", oldsublevel4);
                        command.Parameters.AddWithValue("newsublevel4", newsublevel4);
                        command.Parameters.AddWithValue("oldsublevel5", oldsublevel5);
                        command.Parameters.AddWithValue("newsublevel5", newsublevel5);
                        command.Parameters.AddWithValue("oldsublevel6", oldsublevel6);
                        command.Parameters.AddWithValue("newsublevel6", newsublevel6);
                        command.Parameters.AddWithValue("oldretail", 0);
                        command.Parameters.AddWithValue("newretail", 0);
                        command.Parameters.AddWithValue("oldexists", 0);
                        command.Parameters.AddWithValue("newexists", 0);
                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                    }
                }
                flag = true;
                this._linesprocessed++;
            }
            catch (Exception)
            {
                this.intErrors.Add("ICException: ProcessHistorical: " + line);
                this._linesfailed++;
            }
            return flag;
        }

        private string SendNotification()
        {
            string str;
            StringBuilder builder = new StringBuilder();
            try
            {
                builder.Append("Internal Conversion Complete for " + DateTime.Now.ToShortDateString() + " \r\n");
                builder.Append("Lines Read: " + this._linesread + " \r\n");
                builder.Append("Lines Processed: " + this._linesprocessed + " \r\n");
                builder.Append("Lines Failed: " + this._linesfailed + " \r\n");
                builder.Append("Lines Processed Failed: " + this._linesprocessedfailed + " \r\n\r\n");
                builder.Append("An exception file was produced that contains any records \r\n");
                builder.Append("that failed. This file is located under the logs directory \r\n");
                builder.Append("of the realm in the scheduler config entry. \r\n");
                builder.Append("Lines that where processed and failed in conversion \r\n");
                builder.Append("can be located in the InternalConversion table with the \r\n");
                builder.Append("processed bit set to 0 for the date the conversion was run.");
                str = builder.ToString();
            }
            catch (Exception)
            {
                throw;
            }
            return str;
        }

        private bool UpdateRecord(string line, string oldacctnumber, string newacctnumber, string oldcorp, string newcorp, string oldinst, string newinst, string oldproduct, string newproduct, string oldcompany, string newcompany, string oldsublevel2, string newsublevel2, string oldsublevel3, string newsublevel3, string oldsublevel4, string newsublevel4, string oldsublevel5, string newsublevel5, string oldsublevel6, string newsublevel6)
        {
            bool flag = false;
            try
            {
                bool oldretail = false;
                bool newretail = false;
                bool oldexists = false;
                bool newexists = false;
                if (!this.ValidRecord(line, oldacctnumber, newacctnumber, oldcorp, newcorp, oldinst, newinst, oldproduct, newproduct, oldcompany, newcompany, oldsublevel2, newsublevel2, oldsublevel3, newsublevel3, oldsublevel4, newsublevel4, oldsublevel5, newsublevel5, oldsublevel6, newsublevel6, out oldretail, out newretail, out oldexists, out newexists))
                {
                    return false;
                }
                else if (oldexists)
                {
                    using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["eZCardConn"].ConnectionString))
                    {
                        using (SqlCommand command = new SqlCommand("eZ_InternalConversion", connection))
                        {
                            command.CommandType = CommandType.StoredProcedure;
                            command.Parameters.AddWithValue("oldaccountnumber", oldacctnumber);
                            command.Parameters.AddWithValue("newaccountnumber", newacctnumber);
                            command.Parameters.AddWithValue("oldcorp", oldcorp);
                            command.Parameters.AddWithValue("newcorp", newcorp);
                            command.Parameters.AddWithValue("oldinst", oldinst);
                            command.Parameters.AddWithValue("newinst", newinst);
                            command.Parameters.AddWithValue("oldproduct", oldproduct);
                            command.Parameters.AddWithValue("newproduct", newproduct);
                            command.Parameters.AddWithValue("oldcompany", oldcompany);
                            command.Parameters.AddWithValue("newcompany", newcompany);
                            command.Parameters.AddWithValue("oldsublevel2", oldsublevel2);
                            command.Parameters.AddWithValue("newsublevel2", newsublevel2);
                            command.Parameters.AddWithValue("oldsublevel3", oldsublevel3);
                            command.Parameters.AddWithValue("newsublevel3", newsublevel3);
                            command.Parameters.AddWithValue("oldsublevel4", oldsublevel4);
                            command.Parameters.AddWithValue("newsublevel4", newsublevel4);
                            command.Parameters.AddWithValue("oldsublevel5", oldsublevel5);
                            command.Parameters.AddWithValue("newsublevel5", newsublevel5);
                            command.Parameters.AddWithValue("oldsublevel6", oldsublevel6);
                            command.Parameters.AddWithValue("newsublevel6", newsublevel6);
                            command.Parameters.AddWithValue("oldretail", oldretail);
                            command.Parameters.AddWithValue("newretail", newretail);
                            command.Parameters.AddWithValue("oldexists", oldexists);
                            command.Parameters.AddWithValue("newexists", newexists);
                            connection.Open();
                            command.ExecuteNonQuery();
                            connection.Close();
                        }
                    }
                }
                else
                {
                    return this.ProcessHistorical(line, oldacctnumber, newacctnumber, oldcorp, newcorp, oldinst, newinst, oldproduct, newproduct, oldcompany, newcompany, oldsublevel2, newsublevel2, oldsublevel3, newsublevel3, oldsublevel4, newsublevel4, oldsublevel5, newsublevel5, oldsublevel6, newsublevel6);
                }
                flag = true;
                this._linesprocessed++;
            }
            catch (Exception)
            {
                this.intErrors.Add("InternalConversion: Internal Conversion Failed: Update Record for " + line);
                flag = false;
            }
            return flag;
        }

        private bool ValidRecord(string line, string oldacctnumber, string newacctnumber, string oldcorp, string newcorp, string oldinst, string newinst, string oldproduct, string newproduct, string oldcompany, string newcompany, string oldsublevel2, string newsublevel2, string oldsublevel3, string newsublevel3, string oldsublevel4, string newsublevel4, string oldsublevel5, string newsublevel5, string oldsublevel6, string newsublevel6, out bool oldretail, out bool newretail, out bool oldexists, out bool newexists)
        {
            bool flag = false;
            oldretail = false;
            newretail = false;
            oldexists = false;
            newexists = false;
            try
            {
                bool flag2 = false;
                bool flag3 = false;
                if ((oldacctnumber.Length != 0x10) || ((newacctnumber.Length != 0x10) || ((oldcorp.Length != 6) || ((newcorp.Length != 6) || ((oldinst.Length != 6) || ((newinst.Length != 6) || ((oldproduct.Length != 6) || (newproduct.Length != 6))))))))
                {
                    flag2 = true;
                }
                if ((oldcompany.Length != 8) || ((newcompany.Length != 8) || ((oldsublevel2.Length != 8) || ((newsublevel2.Length != 8) || ((oldsublevel3.Length != 8) || ((newsublevel3.Length != 8) || ((oldsublevel4.Length != 8) || ((newsublevel4.Length != 8) || ((oldsublevel5.Length != 8) || ((newsublevel5.Length != 8) || ((oldsublevel6.Length != 8) || (newsublevel6.Length != 8))))))))))))
                {
                    flag3 = true;
                }
                if (flag2)
                {
                    flag = false;
                }
                if (flag3)
                {
                    flag = false;
                }
                if (!flag2 && !flag3)
                {
                    oldexists = this.OldValuesExists(oldacctnumber, oldcorp, oldinst, oldproduct, oldcompany, oldsublevel2, oldsublevel3, oldsublevel4, oldsublevel5, oldsublevel6);
                    if (oldexists)
                    {
                        newexists = this.NewValuesExists(newacctnumber, newcorp, newinst, newproduct, newcompany, newsublevel2, newsublevel3, newsublevel4, newsublevel5, newsublevel6);
                        oldretail = this.IsOldRetail(oldacctnumber, oldcorp, oldinst, oldproduct);
                        newretail = this.IsNewRetail(newacctnumber, newcorp, newinst, newproduct);
                    }
                    flag = true;
                }
            }
            catch (Exception)
            {
                this.intErrors.Add("InternalConversion: Internal Conversion Failed: Valid Record for " + line);
            }
            return flag;
        }
    }
}

