import 'package:ezcard_app/src/services/session_service.dart';
import 'package:flutter/material.dart';

import '../models/current_user.dart';
import '../services/branding_service.dart';
import '../widgets/bank_card.dart';
import '../widgets/user_info.dart';

class SettingsPage extends StatefulWidget {
  @override
  SettingsPageState createState() => SettingsPageState();
}

class SettingsPageState extends State<SettingsPage> {
  late Future<SettingPageModel> thisPageModel;
  Future<SettingPageModel> loadThisPageData() async {
    //var currentUser = await apiService.getCurrentUser();

    List<BankCardModel> cards = [];
    for (var account in SessionService.currentUser.accounts!) {
      cards.add(BankCardModel(
          'images/bg_red_card.png',
          account.accountNickname!,
          'xxxx xxxx xxxx ' + account.accountLast4!,
          account.expirationDate!.month.toString() +
              '/' +
              account.expirationDate!.year.toString(),
          account.creditLimit!.toInt(),
          false));
    }

    return SettingPageModel(
        currentUser: SessionService.currentUser, cards: cards);
  }

  @override
  void initState() {
    super.initState();

    thisPageModel = loadThisPageData();
    //dashboardData = loadDashboardData();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
        backgroundColor: Color(0xFFF4F4F4),
        body: FutureBuilder<SettingPageModel>(
            future: thisPageModel,
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 3.0, horizontal: 16.0),
                        child: Text(
                          ' ',
                          style: TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 20.0),
                        ),
                      ),
                      UserInfo(),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 30.0, left: 16.0, right: 16.0),
                        child: Text(
                          'Account Settings',
                          style: TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 20.0),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(left: 16.0, right: 16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: <Widget>[
                            Text(' '),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 5.0, vertical: 10.0),
                              child: Text(
                                'Personal Information',
                                style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 14.0),
                              ),
                            ),
                            Card(
                              color: BrandingService.getBrandingColor(
                                  'body-background-color', Colors.white),
                              child: Container(
                                margin: EdgeInsets.only(top: 8.0),
                                child: Padding(
                                  padding: const EdgeInsets.all(12.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.stretch,
                                    children: <Widget>[
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(bottom: 16.0),
                                        child: Row(
                                          children: <Widget>[
                                            Expanded(
                                              child: Text(
                                                  'Username: ' +
                                                      SessionService.currentUser
                                                          .username!,
                                                  style: TextStyle(
                                                    color: BrandingService
                                                        .getBrandingColor(
                                                            'body-text1-color',
                                                            Colors.black),
                                                  )),
                                            ),
                                            GestureDetector(
                                              child: Row(
                                                children: <Widget>[
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            right: 4.0),
                                                    child: Text('Edit',
                                                        style: TextStyle(
                                                          color: BrandingService
                                                              .getBrandingColor(
                                                                  'body-text1-color',
                                                                  Colors.black),
                                                        )),
                                                  ),
                                                  Icon(Icons.edit,
                                                      size: 10.0,
                                                      color: BrandingService
                                                          .getBrandingColor(
                                                              'body-text1-color',
                                                              Colors.black))
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(bottom: 16.0),
                                        child: Row(
                                          children: <Widget>[
                                            Expanded(
                                              child: Text(
                                                  'User Nickname: ' +
                                                      SessionService.currentUser
                                                          .userNickname!,
                                                  style: TextStyle(
                                                    color: BrandingService
                                                        .getBrandingColor(
                                                            'body-text1-color',
                                                            Colors.black),
                                                  )),
                                            ),
                                            GestureDetector(
                                              child: Row(
                                                children: <Widget>[
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            right: 4.0),
                                                    child: Text('Edit',
                                                        style: TextStyle(
                                                          color: BrandingService
                                                              .getBrandingColor(
                                                                  'body-text1-color',
                                                                  Colors.black),
                                                        )),
                                                  ),
                                                  Icon(Icons.edit,
                                                      size: 10.0,
                                                      color: BrandingService
                                                          .getBrandingColor(
                                                              'body-text1-color',
                                                              Colors.black))
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(bottom: 16.0),
                                        child: Row(
                                          children: <Widget>[
                                            Expanded(
                                              child: Text(
                                                  'First Name: ' +
                                                      SessionService.currentUser
                                                          .firstName!,
                                                  style: TextStyle(
                                                    color: BrandingService
                                                        .getBrandingColor(
                                                            'body-text1-color',
                                                            Colors.black),
                                                  )),
                                            ),
                                            GestureDetector(
                                              child: Row(
                                                children: <Widget>[
                                                  Icon(Icons.info_rounded,
                                                      color: BrandingService
                                                          .getBrandingColor(
                                                              'body-text1-color',
                                                              Colors.black))
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(bottom: 16.0),
                                        child: Row(
                                          children: <Widget>[
                                            Expanded(
                                              child: Text(
                                                  'Last Name: ' +
                                                      SessionService.currentUser
                                                          .lastName!,
                                                  style: TextStyle(
                                                    color: BrandingService
                                                        .getBrandingColor(
                                                            'body-text1-color',
                                                            Colors.black),
                                                  )),
                                            ),
                                            GestureDetector(
                                              child: Row(
                                                children: <Widget>[
                                                  Icon(Icons.info_rounded,
                                                      color: BrandingService
                                                          .getBrandingColor(
                                                              'body-text1-color',
                                                              Colors.black))
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                      _userBankCardsWidget(snapshot.data!.cards),
                    ],
                  ),
                );
              } else {
                return Center(
                  child: CircularProgressIndicator(
                    color: Colors.purple,
                  ),
                );
              }
            }));
  }

  Widget _userBankCardsWidget(List<BankCardModel> cards) {
    var size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.only(left: 16.0, right: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
              child: Text('')),
          Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 0.0),
              child: Row(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(right: 8.0),
                    child: Icon(Icons.account_balance),
                  ),
                  Text(
                    'My Accounts',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  )
                ],
              )),
          GridView.count(
            crossAxisCount: size.width > 320 ? 2 : 1,
            physics: ScrollPhysics(),
            shrinkWrap: true,
            childAspectRatio: (152 / 92),
            controller: new ScrollController(keepScrollOffset: false),
            children: List.generate(cards.length, (index) {
              return _getBankCard(cards, index);
            }),
          ),
        ],
      ),
    );
  }

  Widget _getBankCard(List<BankCardModel> cards, int index) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: SmallBankCard(
        card: cards[index],
        screenWidth: MediaQuery.of(context).size.width,
      ),
    );
  }
}

class SettingPageModel {
  CurrentUser currentUser;
  List<BankCardModel> cards;

  SettingPageModel({required this.currentUser, required this.cards});
}
