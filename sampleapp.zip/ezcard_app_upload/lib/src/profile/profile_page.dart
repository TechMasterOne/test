import 'package:flutter/material.dart';
import 'package:ezcard_app/src/widgets/bank_card.dart';

import '../models/history_model.dart';
import '../services/api_service.dart';
import '../widgets/history_item.dart';
import '../widgets/user_info.dart';

class ProfilePage extends StatefulWidget {
  @override
  ProfilePageState createState() => ProfilePageState();
}

class ProfilePageState extends State<ProfilePage> {
  late Future<List<HistoryModel>> histories;

  @override
  void initState() {
    super.initState();

    histories = loadHistoryData();
    //dashboardData = loadDashboardData();
  }

  Future<List<HistoryModel>> loadHistoryData() async {
    ApiService apiservice = ApiService();
    var statements = await apiservice.getStatements();

    List<HistoryModel> hists = [];

    for (var stat in statements) {
      hists.add(HistoryModel(
          '',
          stat.displayName!.replaceAll('Statement Period', ''),
          'Statement Period',
          stat.statementBalance!,
          'Statement Balance',
          ''));
    }

    return hists;
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
        backgroundColor: Color(0xFFF4F4F4),
        body: FutureBuilder<List<HistoryModel>>(
            future: histories,
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 3.0, horizontal: 16.0),
                        child: Text(
                          ' ',
                          style: TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 20.0),
                        ),
                      ),
                      UserInfo(),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 30.0, horizontal: 16.0),
                        child: Text(
                          'Statements',
                          style: TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 20.0),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Container(
//              height: 42.0,
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: Card(
                                  child: Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8.0, vertical: 16.0),
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: Text(
                                            'Month',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w700,
                                                fontSize: 14.0),
                                          ),
                                        ),
                                        Icon(Icons.keyboard_arrow_down)
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Expanded(
                                child: Card(
                                  child: Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8.0, vertical: 16.0),
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: Text(
                                            'Year',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w700,
                                                fontSize: 14.0),
                                          ),
                                        ),
                                        Icon(Icons.keyboard_arrow_down)
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                        child: ListView.builder(
                            itemCount: snapshot.data!.length,
                            itemBuilder: (BuildContext context, int index) {
                              return _historyWidget(snapshot.data![index]);
                            }),
                      ),
                    ],
                  ),
                );
              } else {
                return Center(
                  child: CircularProgressIndicator(
                    color: Colors.purple,
                  ),
                );
              }
            }));
  }

  Widget _historyWidget(HistoryModel history) {
    return HistoryItem(
      history: history,
      leftRightPadding: 16.0,
    );
  }
}
