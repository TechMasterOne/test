import 'package:flutter/cupertino.dart';

import '../models/config_key_model.dart';

class BrandingService {
  static List<ConfigKeyModel> brandingKeys = [];

  static void setBranding(List<ConfigKeyModel> brandings) {
    brandingKeys = brandings;
  }

  static Color getBrandingColor(String key, Color defaultcolor) {
    if (!key.contains('ThemeSetting.eZCardMobile')) {
      key = 'ThemeSetting.eZCardMobile.' + key;
    }

    if (brandingKeys
        .any((element) => element.keyName.toLowerCase() == key.toLowerCase())) {
      try {
        var keyValue = brandingKeys
            .where(
                (element) => element.keyName.toLowerCase() == key.toLowerCase())
            .first
            .keyValue
            .replaceAll('#', '');

        if (keyValue.length == 3) {
          keyValue = keyValue + keyValue;
        }

        keyValue = 'ff' + keyValue.toLowerCase();
        return Color(int.parse(keyValue, radix: 16));
      } on Exception {
        return defaultcolor;
      }
    } else {
      return defaultcolor;
    }
  }
}
