import 'package:ezcard_app/src/models/cardholder_model.dart';
import 'package:ezcard_app/src/models/config_key_model.dart';
import 'package:ezcard_app/src/models/mcc_category.dart';
import 'package:ezcard_app/src/models/statement_model.dart';
import 'package:ezcard_app/src/models/transaction.dart';
import 'package:ezcard_app/src/services/branding_service.dart';
import 'package:ezcard_app/src/services/session_service.dart';
import 'package:requests/requests.dart';

import '../models/current_user.dart';
import '../models/login_model.dart';

String apiUrl = "https://ezcardinfodemouat.fisglobal.com/api/";

class ApiService {
  Future<LoginModel> loginUserName(
      String username, String password, bool save) async {
    var r = await Requests.post(apiUrl + 'Login/ValidateUsername',
        body: {'devicePrint': 'testsamplefrommobile', 'userName': username},
        bodyEncoding: RequestBodyEncoding.JSON,
        timeoutSeconds: 60);

    if (r.statusCode == 200) {
      r.raiseForStatus();
      dynamic json = r.json();
      //print(json);
      var loginModel = LoginModel.fromJson(json);
      //print(loginModel.state);

      if (loginModel.state?.toLowerCase() == 'mfapassword') {
        //print('checking password');

        var rPass = await Requests.post(apiUrl + 'Login/ValidateLoginPassword',
            body: {
              'devicePrint': 'testsamplefrommobile',
              'token': loginModel.token,
              'password': password
            },
            bodyEncoding: RequestBodyEncoding.JSON,
            timeoutSeconds: 60);

        if (rPass.statusCode == 200) {
          rPass.raiseForStatus();
          dynamic jsonPass = rPass.json();

          //print(jsonPass);

          var loginModelPass = LoginModel.fromJson(jsonPass);

          if (loginModelPass.state?.toLowerCase() == 'authorized') {
            var currentUser = await getCurrentUser();
            var configKeys = await getGetConfigKeys('eZMobileThemes');

            BrandingService.setBranding(configKeys);

            SessionService.setLoginStatus(
                true,
                loginModelPass.typedUsername ?? '',
                loginModelPass,
                currentUser);
          }

          //print(jsonPass);

          return loginModelPass;
        }
      }

      return loginModel;
    }

    return LoginModel();
  }

  Future<CurrentUser> getCurrentUser() async {
    var r = await Requests.get(apiUrl + 'user/current', timeoutSeconds: 60);

    r.raiseForStatus();
    dynamic json = r.json();
    //print(json);

    var currentUser = CurrentUser.fromJson(json);

    return currentUser;
  }

  Future<List<ConfigKeyModel>> getGetConfigKeys(String configTags) async {
    var r = await Requests.post(apiUrl + 'ConfigKeyValueMultiTag',
        body: {
          'tagName': configTags,
        },
        bodyEncoding: RequestBodyEncoding.JSON,
        timeoutSeconds: 60);

    r.raiseForStatus();
    dynamic json = r.json();
    print(json);

    var keyValues = List<ConfigKeyModel>.from(
        json.map((model) => ConfigKeyModel.fromJson(model)));

    return keyValues;
  }

  Future<List<Transaction>> getTransactions() async {
    var r = await Requests.get(apiUrl + 'Transaction/TransactionGetAll',
        timeoutSeconds: 60);

    r.raiseForStatus();
    dynamic json = r.json();
    //print(json);

    var transaction = List<Transaction>.from(
        json.map((model) => Transaction.fromJson(model)));

    return transaction;
  }

  Future<List<MccCategory>> getMcc() async {
    var r = await Requests.get(apiUrl + 'MccCategory/MccCategoryGetAll',
        timeoutSeconds: 60);

    r.raiseForStatus();
    dynamic json = r.json();
    //print(json);

    var transaction = List<MccCategory>.from(
        json.map((model) => MccCategory.fromJson(model)));

    return transaction;
  }

  Future<List<StatementModel>> getStatements() async {
    var r = await Requests.get(apiUrl + 'Statement/StatementGetAll',
        timeoutSeconds: 60);

    r.raiseForStatus();
    dynamic json = r.json();
    //print(json);

    var statements = List<StatementModel>.from(
        json.map((model) => StatementModel.fromJson(model)));

    return statements;
  }

  Future<Cardholder> getCardholderDetails() async {
    var r = await Requests.get(apiUrl + 'CardHolder/', timeoutSeconds: 60);

    r.raiseForStatus();
    dynamic json = r.json();
    //print(json);

    var cardholder = Cardholder.fromJson(json);

    return cardholder;
  }
}
