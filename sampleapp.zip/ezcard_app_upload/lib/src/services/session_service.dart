import 'package:ezcard_app/src/models/current_user.dart';

import '../models/login_model.dart';

class SessionService {
  static bool loginStatus = false;
  static String username = '';
  static String xsrfToken = '';
  static LoginModel? loginModel = null;
  static CurrentUser currentUser = CurrentUser();

  static void setLoginStatus(bool isLoginSuccessful, String loggedinUsername,
      LoginModel? loginModelValue, CurrentUser currentUserValue) {
    loginStatus = isLoginSuccessful;
    username = loggedinUsername;
    loginModel = loginModelValue;
    currentUser = currentUserValue;
  }

  static CurrentUser getCurrentUser() {
    return currentUser;
  }

  static bool isLogin() {
    return loginStatus;
  }

  static String getUserName() {
    return username;
  }

  static String getXsrfToken() {
    return xsrfToken;
  }

  static void setXsrfToken(String token) {
    xsrfToken = token;
  }

  static LoginModel? getLoginModel() {
    return loginModel;
  }

  static void clear() {
    loginStatus = false;
    username = '';
    xsrfToken = '';
    loginModel = null;
  }
}
