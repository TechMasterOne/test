import 'package:ezcard_app/src/models/login_model.dart';
import 'package:ezcard_app/src/services/api_service.dart';
import 'package:flutter/material.dart';
import 'package:ezcard_app/src/widgets/singinContainer.dart';
import 'package:ezcard_app/src/home/myhomepage.dart';

class SignInPage extends StatefulWidget {
  const SignInPage({Key? key}) : super(key: key);

  @override
  _SignInPageState createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  int _state = 0;
  final usernameController = TextEditingController();
  final passwordController = TextEditingController();

  Future<LoginModel> _loginUser(
      String username, String password, bool save) async {
    var loginService = ApiService();

    setState(() {
      _state = 1;
    });
    var loginModel = await loginService.loginUserName(username, password, save);

    print(loginModel.state);

    setState(() {
      _state = 0;
    });
    return loginModel;
  }

  Widget _backButton() {
    return InkWell(
      onTap: () {
        Navigator.pop(context);
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 10),
        child: Row(
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(left: 0, top: 20, bottom: 10),
              child: Icon(Icons.keyboard_arrow_left, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }

  Widget _usernameWidget() {
    return Stack(
      children: [
        TextFormField(
          controller: usernameController,
          keyboardType: TextInputType.name,
          textInputAction: TextInputAction.next,
          decoration: InputDecoration(
            labelText: 'Username',
            labelStyle: TextStyle(
                color: Color.fromRGBO(173, 183, 192, 1),
                fontWeight: FontWeight.bold),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color.fromRGBO(173, 183, 192, 1)),
            ),
          ),
        ),
      ],
    );
  }

  Widget _passwordWidget() {
    return Stack(
      children: [
        TextFormField(
          controller: passwordController,
          obscureText: true,
          keyboardType: TextInputType.name,
          textInputAction: TextInputAction.next,
          decoration: InputDecoration(
            labelText: 'Password',
            labelStyle: TextStyle(
                color: Color.fromRGBO(173, 183, 192, 1),
                fontWeight: FontWeight.bold),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color.fromRGBO(173, 183, 192, 1)),
            ),
          ),
        ),
      ],
    );
  }

  Widget _submitButton() {
    if (_state == 0) {
      return Align(
        alignment: Alignment.centerRight,
        child: InkWell(
          onTap: () async {
            /*Navigator.push(
                context, MaterialPageRoute(builder: (context) => MyHomePage()));
            */

            setState(() {
              _state = 1;
            });

            var loginUser = await _loginUser(
                usernameController.text, passwordController.text, true);

            if (loginUser.state!.toLowerCase() == 'authorized') {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => MyHomePage()));
            }
          },
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(
              'Login',
              style: TextStyle(
                  color: Color.fromRGBO(76, 81, 93, 1),
                  fontSize: 25,
                  fontWeight: FontWeight.w500,
                  height: 1.6),
            ),
            SizedBox.fromSize(
              size: Size.square(70.0), // button width and height
              child: ClipOval(
                child: Material(
                  color: Color.fromRGBO(76, 81, 93, 1),
                  child: Icon(Icons.arrow_forward,
                      color: Colors.white), // button color
                ),
              ),
            ),
          ]),
        ),
      );
    } else {
      return CircularProgressIndicator(
        valueColor:
            AlwaysStoppedAnimation<Color>(Color.fromRGBO(76, 81, 93, 1)),
      );
    }
  }

  Widget _createAccountLabel() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 20),
      alignment: Alignment.bottomCenter,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          InkWell(
            onTap: () => {},
            child: Text(
              'Forget Username',
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.underline,
                  decorationThickness: 2),
            ),
          ),
          InkWell(
            // onTap: () {
            //   // Navigator.push(
            //   //     context, MaterialPageRoute(builder: (context) => SignUpPage()));
            // },
            child: Text(
              'Forgot Password',
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.underline,
                  decorationThickness: 2),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Scaffold(
      body: SizedBox(
        height: height,
        child: Stack(
          children: [
            Positioned(
                height: MediaQuery.of(context).size.height * 0.50,
                child: SigninContainer()),
            SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      children: [
                        SizedBox(height: height * .55),
                        _usernameWidget(),
                        SizedBox(height: 20),
                        _passwordWidget(),
                        SizedBox(height: 30),
                        _submitButton(),
                        SizedBox(height: height * .050),
                        _createAccountLabel(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            //Positioned(top: 60, left: 0, child: _backButton()),
          ],
        ),
      ),
    );
  }
}
