import 'package:flutter/material.dart';

import '../models/history_model.dart';
import '../services/branding_service.dart';

class HistoryItem extends StatelessWidget {
  final HistoryModel history;
  final double leftRightPadding;
  HistoryItem({required this.history, required this.leftRightPadding});

  @override
  Widget build(BuildContext context) {
    return Container(
//      height: 100.0,
      margin: EdgeInsets.only(
          bottom: 6.0, left: leftRightPadding, right: leftRightPadding),
      child: Card(
        color: BrandingService.getBrandingColor(
            'body-background-color', Colors.white),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Row(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(right: 16.0),
                child: Icon(
                  Icons.outbond,
                  color: BrandingService.getBrandingColor(
                      'body-text1-color', Colors.black),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        history.historyType,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: BrandingService.getBrandingColor(
                              'body-text1-color', Colors.black),
                        ),
                        textAlign: TextAlign.left,
                      ),
                      Text(history.receiverName,
                          style: TextStyle(
                            color: BrandingService.getBrandingColor(
                                'body-text2-color', Colors.black),
                          ))
                    ],
                  ),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        '\$${history.amount}',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: BrandingService.getBrandingColor(
                              'body-text1-color', Colors.black),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Expanded(
                            child: Text(
                              '${history.date}',
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                color: BrandingService.getBrandingColor(
                                    'body-text2-color', Colors.black),
                              ),
                            ),
                          )
                        ],
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
