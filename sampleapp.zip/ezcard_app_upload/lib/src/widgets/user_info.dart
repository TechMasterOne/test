import 'package:ezcard_app/src/models/current_user.dart';
import 'package:ezcard_app/src/services/branding_service.dart';
import 'package:flutter/material.dart';

import '../home/homepage.dart';
import '../services/session_service.dart';

class UserInfo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.0),
      color: BrandingService.getBrandingColor(
          'header-background-color', Colors.green[900]!),
      child: Row(
        children: <Widget>[
          Expanded(
              child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Container(
                  margin: EdgeInsets.symmetric(horizontal: 4.0),
                  child: Text(
                    'Welcome!',
                    style: TextStyle(
                        color: BrandingService.getBrandingColor(
                            'header-text-color', Colors.white),
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w700),
                  )),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 4.0),
                child: Text(
                  //SessionService.getUserName(),
                  SessionService.currentUser.firstName!,
                  style: TextStyle(
                      color: BrandingService.getBrandingColor(
                          'header-text-color', Colors.white),
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w700),
                ),
              )
            ],
          )),
          Stack(children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: new Icon(
                Icons.notifications_none,
                size: 30.0,
                color: BrandingService.getBrandingColor(
                    'header-text-color', Colors.white),
              ),
            ),
            new Positioned(
              // draw a red marble
              top: 3.0,
              left: 3.0,
              child: Container(
                decoration: BoxDecoration(
                    color: Color(0xFFE95482),
                    borderRadius: BorderRadius.circular(8.0)),
                child: Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: Text(
                    '04',
                    style: TextStyle(
                        color: BrandingService.getBrandingColor(
                            'header-text-color', Colors.white),
                        fontSize: 10.0,
                        fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            )
          ]),
          Stack(children: <Widget>[
            Padding(
                padding: EdgeInsets.all(8.0),
                child: IconButton(
                  icon: Icon(
                    Icons.logout,
                    size: 30.0,
                    color: BrandingService.getBrandingColor(
                        'header-text-color', Colors.white),
                  ),
                  onPressed: () {
                    SessionService.clear();
                    Navigator.pop(context);
                  },
                )),
          ]),
        ],
      ),
    );
  }
}
