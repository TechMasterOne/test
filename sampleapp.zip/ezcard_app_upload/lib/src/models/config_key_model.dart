class ConfigKeyModel {
  int id = 0;
  String keyName = '';
  String keyValue = '';
  String tagName = '';

  ConfigKeyModel(
      {required this.id,
      required this.keyName,
      required this.keyValue,
      required this.tagName});

  ConfigKeyModel.fromJson(Map<String, dynamic> json) {
    id = json['Id'];
    keyName = json['KeyName'];
    keyValue = json['KeyValue'];
    tagName = json['TagName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Id'] = this.id;
    data['KeyName'] = this.keyName;
    data['KeyValue'] = this.keyValue;
    data['TagName'] = this.tagName;
    return data;
  }
}
