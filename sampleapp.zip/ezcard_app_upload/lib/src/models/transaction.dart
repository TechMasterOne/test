class Transaction {
  int? id;
  int? transactionTypeId;
  DateTime? postingDate;
  String? description;
  double? amount;
  bool? isSuppressed;
  int? personalMccCategoryId;
  int? mccCategoryId;
  int? transactionTypeCategoryId;
  String? uniqueTransactionId;
  bool? isCovertToLoanVisible;
  int? ppilTransactionID;

  Transaction(
      {this.id,
      this.transactionTypeId,
      this.postingDate,
      this.description,
      this.amount,
      this.isSuppressed,
      this.personalMccCategoryId,
      this.mccCategoryId,
      this.transactionTypeCategoryId,
      this.uniqueTransactionId,
      this.isCovertToLoanVisible,
      this.ppilTransactionID});

  Transaction.fromJson(Map<String, dynamic> json) {
    id = json['Id'];
    transactionTypeId = json['TransactionTypeId'];
    postingDate = DateTime.parse(json['PostingDate']);
    description = json['Description'];
    amount = json['Amount'];
    isSuppressed = json['IsSuppressed'];
    personalMccCategoryId = json['PersonalMccCategoryId'];
    mccCategoryId = json['MccCategoryId'];
    transactionTypeCategoryId = json['TransactionTypeCategoryId'];
    uniqueTransactionId = json['UniqueTransactionId'];
    isCovertToLoanVisible = json['IsCovertToLoanVisible'];
    ppilTransactionID = json['PpilTransactionID'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['transactionTypeId'] = transactionTypeId;
    data['postingDate'] = postingDate;
    data['description'] = description;
    data['amount'] = amount;
    data['isSuppressed'] = isSuppressed;
    data['personalMccCategoryId'] = personalMccCategoryId;
    data['mccCategoryId'] = mccCategoryId;
    data['transactionTypeCategoryId'] = transactionTypeCategoryId;
    data['uniqueTransactionId'] = uniqueTransactionId;
    data['isCovertToLoanVisible'] = isCovertToLoanVisible;
    data['ppilTransactionID'] = ppilTransactionID;
    return data;
  }
}
