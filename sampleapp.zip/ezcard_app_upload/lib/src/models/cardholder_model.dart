class CardholderModel {
  CardholderModel({
    required this.cardholder,
    required this.cardHolderAddresses,
    required this.cardHolderPhones,
    required this.cardHolderExtraDetails,
  });
  late final Cardholder cardholder;
  late final List<CardHolderAddresses> cardHolderAddresses;
  late final List<CardHolderPhones> cardHolderPhones;
  late final List<CardHolderExtraDetails> cardHolderExtraDetails;

  CardholderModel.fromJson(Map<String, dynamic> json) {
    cardholder = Cardholder.fromJson(json['Cardholder']);
    cardHolderAddresses = List.from(json['CardHolderAddresses'])
        .map((e) => CardHolderAddresses.fromJson(e))
        .toList();
    cardHolderPhones = List.from(json['CardHolderPhones'])
        .map((e) => CardHolderPhones.fromJson(e))
        .toList();
    cardHolderExtraDetails = List.from(json['CardHolderExtraDetails'])
        .map((e) => CardHolderExtraDetails.fromJson(e))
        .toList();
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['Cardholder'] = cardholder.toJson();
    _data['CardHolderAddresses'] =
        cardHolderAddresses.map((e) => e.toJson()).toList();
    _data['CardHolderPhones'] =
        cardHolderPhones.map((e) => e.toJson()).toList();
    _data['CardHolderExtraDetails'] =
        cardHolderExtraDetails.map((e) => e.toJson()).toList();
    return _data;
  }
}

class Cardholder {
  Cardholder({
    required this.Id,
    required this.AccountId,
    required this.UserHierarchy,
    required this.CardHolderName,
    required this.Salutation,
    required this.FirstName,
    required this.MiddleName,
    required this.LastName,
    required this.Suffix,
    required this.TaxID,
    required this.EmployeeID,
    required this.DateOfBirth,
    required this.MaidenName,
    required this.MaxCreditLimit,
    this.MailDrop,
    this.Department,
    required this.UserId,
    this.SuccessAttempt,
    this.SuccessAttemptDate,
    this.FailureAttempt,
    this.FailureAttemptDate,
    this.Country,
    this.PostalCode,
    this.HomePhone,
    this.WorkPhone,
    required this.IsPinGenerationAllowed,
    required this.IsChipCard,
    required this.IsCustomPinAllowed,
    this.CardActivationLevel,
    this.CardActivationStatus,
    this.PreviousCardActivationStatus,
    this.CardSequenceNumber,
    this.PreviousCardSequenceNumber,
  });
  late final int Id;
  late final int AccountId;
  late final int UserHierarchy;
  late final String CardHolderName;
  late final String Salutation;
  late final String FirstName;
  late final String MiddleName;
  late final String LastName;
  late final String Suffix;
  late final String TaxID;
  late final String EmployeeID;
  late final String DateOfBirth;
  late final String MaidenName;
  late final int MaxCreditLimit;
  late final Null MailDrop;
  late final Null Department;
  late final int UserId;
  late final Null SuccessAttempt;
  late final Null SuccessAttemptDate;
  late final Null FailureAttempt;
  late final Null FailureAttemptDate;
  late final Null Country;
  late final Null PostalCode;
  late final Null HomePhone;
  late final Null WorkPhone;
  late final bool IsPinGenerationAllowed;
  late final bool IsChipCard;
  late final bool IsCustomPinAllowed;
  late final Null CardActivationLevel;
  late final Null CardActivationStatus;
  late final Null PreviousCardActivationStatus;
  late final Null CardSequenceNumber;
  late final Null PreviousCardSequenceNumber;

  Cardholder.fromJson(Map<String, dynamic> json) {
    Id = json['Id'];
    AccountId = json['AccountId'];
    UserHierarchy = json['UserHierarchy'];
    CardHolderName = json['CardHolderName'];
    Salutation = json['Salutation'];
    FirstName = json['FirstName'];
    MiddleName = json['MiddleName'];
    LastName = json['LastName'];
    Suffix = json['Suffix'];
    TaxID = json['TaxID'];
    EmployeeID = json['EmployeeID'];
    DateOfBirth = json['DateOfBirth'];
    MaidenName = json['MaidenName'];
    MaxCreditLimit = json['MaxCreditLimit'];
    MailDrop = null;
    Department = null;
    UserId = json['UserId'];
    SuccessAttempt = null;
    SuccessAttemptDate = null;
    FailureAttempt = null;
    FailureAttemptDate = null;
    Country = null;
    PostalCode = null;
    HomePhone = null;
    WorkPhone = null;
    IsPinGenerationAllowed = json['IsPinGenerationAllowed'];
    IsChipCard = json['IsChipCard'];
    IsCustomPinAllowed = json['IsCustomPinAllowed'];
    CardActivationLevel = null;
    CardActivationStatus = null;
    PreviousCardActivationStatus = null;
    CardSequenceNumber = null;
    PreviousCardSequenceNumber = null;
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['Id'] = Id;
    _data['AccountId'] = AccountId;
    _data['UserHierarchy'] = UserHierarchy;
    _data['CardHolderName'] = CardHolderName;
    _data['Salutation'] = Salutation;
    _data['FirstName'] = FirstName;
    _data['MiddleName'] = MiddleName;
    _data['LastName'] = LastName;
    _data['Suffix'] = Suffix;
    _data['TaxID'] = TaxID;
    _data['EmployeeID'] = EmployeeID;
    _data['DateOfBirth'] = DateOfBirth;
    _data['MaidenName'] = MaidenName;
    _data['MaxCreditLimit'] = MaxCreditLimit;
    _data['MailDrop'] = MailDrop;
    _data['Department'] = Department;
    _data['UserId'] = UserId;
    _data['SuccessAttempt'] = SuccessAttempt;
    _data['SuccessAttemptDate'] = SuccessAttemptDate;
    _data['FailureAttempt'] = FailureAttempt;
    _data['FailureAttemptDate'] = FailureAttemptDate;
    _data['Country'] = Country;
    _data['PostalCode'] = PostalCode;
    _data['HomePhone'] = HomePhone;
    _data['WorkPhone'] = WorkPhone;
    _data['IsPinGenerationAllowed'] = IsPinGenerationAllowed;
    _data['IsChipCard'] = IsChipCard;
    _data['IsCustomPinAllowed'] = IsCustomPinAllowed;
    _data['CardActivationLevel'] = CardActivationLevel;
    _data['CardActivationStatus'] = CardActivationStatus;
    _data['PreviousCardActivationStatus'] = PreviousCardActivationStatus;
    _data['CardSequenceNumber'] = CardSequenceNumber;
    _data['PreviousCardSequenceNumber'] = PreviousCardSequenceNumber;
    return _data;
  }
}

class CardHolderAddresses {
  CardHolderAddresses({
    required this.Id,
    required this.CardHolderId,
    required this.Address1,
    required this.Address2,
    required this.Address3,
    required this.City,
    required this.State,
    required this.Country,
    required this.PostalCode,
    required this.AddressType,
    required this.IsForeignAddress,
  });
  late final int Id;
  late final int CardHolderId;
  late final String Address1;
  late final String Address2;
  late final String Address3;
  late final String City;
  late final String State;
  late final String Country;
  late final String PostalCode;
  late final String AddressType;
  late final bool IsForeignAddress;

  CardHolderAddresses.fromJson(Map<String, dynamic> json) {
    Id = json['Id'];
    CardHolderId = json['CardHolderId'];
    Address1 = json['Address1'];
    Address2 = json['Address2'];
    Address3 = json['Address3'];
    City = json['City'];
    State = json['State'];
    Country = json['Country'];
    PostalCode = json['PostalCode'];
    AddressType = json['AddressType'];
    IsForeignAddress = json['IsForeignAddress'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['Id'] = Id;
    _data['CardHolderId'] = CardHolderId;
    _data['Address1'] = Address1;
    _data['Address2'] = Address2;
    _data['Address3'] = Address3;
    _data['City'] = City;
    _data['State'] = State;
    _data['Country'] = Country;
    _data['PostalCode'] = PostalCode;
    _data['AddressType'] = AddressType;
    _data['IsForeignAddress'] = IsForeignAddress;
    return _data;
  }
}

class CardHolderPhones {
  CardHolderPhones({
    required this.Id,
    required this.CardHolderId,
    required this.Phone,
    this.PhoneExt,
    this.PhoneCountryCode,
    this.PhoneAreaCode,
    this.PhoneCountryCallingCode,
    required this.PhoneType,
    required this.IsPhone,
    this.MaskedPhoneNumber,
  });
  late final int Id;
  late final int CardHolderId;
  late final String Phone;
  late final Null PhoneExt;
  late final Null PhoneCountryCode;
  late final Null PhoneAreaCode;
  late final Null PhoneCountryCallingCode;
  late final String PhoneType;
  late final bool IsPhone;
  late final Null MaskedPhoneNumber;

  CardHolderPhones.fromJson(Map<String, dynamic> json) {
    Id = json['Id'];
    CardHolderId = json['CardHolderId'];
    Phone = json['Phone'];
    PhoneExt = null;
    PhoneCountryCode = null;
    PhoneAreaCode = null;
    PhoneCountryCallingCode = null;
    PhoneType = json['PhoneType'];
    IsPhone = json['IsPhone'];
    MaskedPhoneNumber = null;
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['Id'] = Id;
    _data['CardHolderId'] = CardHolderId;
    _data['Phone'] = Phone;
    _data['PhoneExt'] = PhoneExt;
    _data['PhoneCountryCode'] = PhoneCountryCode;
    _data['PhoneAreaCode'] = PhoneAreaCode;
    _data['PhoneCountryCallingCode'] = PhoneCountryCallingCode;
    _data['PhoneType'] = PhoneType;
    _data['IsPhone'] = IsPhone;
    _data['MaskedPhoneNumber'] = MaskedPhoneNumber;
    return _data;
  }
}

class CardHolderExtraDetails {
  CardHolderExtraDetails({
    required this.CardHolderId,
    required this.CreditAssoc,
    required this.CoBorrowerCardHolderId,
    required this.HasCoborrowerAddress,
  });
  late final int CardHolderId;
  late final String CreditAssoc;
  late final int CoBorrowerCardHolderId;
  late final bool HasCoborrowerAddress;

  CardHolderExtraDetails.fromJson(Map<String, dynamic> json) {
    CardHolderId = json['CardHolderId'];
    CreditAssoc = json['CreditAssoc'];
    CoBorrowerCardHolderId = json['CoBorrowerCardHolderId'];
    HasCoborrowerAddress = json['HasCoborrowerAddress'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['CardHolderId'] = CardHolderId;
    _data['CreditAssoc'] = CreditAssoc;
    _data['CoBorrowerCardHolderId'] = CoBorrowerCardHolderId;
    _data['HasCoborrowerAddress'] = HasCoborrowerAddress;
    return _data;
  }
}
