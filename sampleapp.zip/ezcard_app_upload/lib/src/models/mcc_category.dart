class MccCategory {
  int id = 0;
  String displayName = '';
  int weight = 0;

  MccCategory(
      {required this.id, required this.displayName, required this.weight});

  MccCategory.fromJson(Map<String, dynamic> json) {
    id = json['Id'];
    displayName = json['DisplayName'];
    weight = json['Weight'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Id'] = this.id;
    data['DisplayName'] = this.displayName;
    data['Weight'] = this.weight;
    return data;
  }
}
