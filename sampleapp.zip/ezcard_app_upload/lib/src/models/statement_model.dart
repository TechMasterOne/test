class StatementModel {
  int? id;
  double? statementBalance;
  String? startDate;
  DateTime? endDate;
  String? displayName;

  StatementModel(
      {this.id,
      this.statementBalance,
      this.startDate,
      this.endDate,
      this.displayName});

  StatementModel.fromJson(Map<String, dynamic> json) {
    id = json['Id'];
    statementBalance = json['StatementBalance'];
    startDate = json['StartDate'];
    endDate = DateTime.parse(json['EndDate']);
    displayName = json['DisplayName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Id'] = this.id;
    data['StatementBalance'] = this.statementBalance;
    data['StartDate'] = this.startDate;
    data['EndDate'] = this.endDate;
    data['DisplayName'] = this.displayName;
    return data;
  }
}
