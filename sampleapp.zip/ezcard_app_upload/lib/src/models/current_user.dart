class CurrentUser {
  String? _username;
  String? _firstName;
  String? _lastName;
  String? _userNickname;
  List<Accounts>? _accounts;
  String? _previousSuccessfulLogin;
  UserAccountSettings? _userAccountSettings;
  bool? _tempBlock;
  int? _emulatingUserId;
  String? _associatedTrackingType;
  bool? _isPaymentBlocked;
  String? _systemCode;
  int? _id;
  int? _selectedAccountId;

  CurrentUser(
      {String? username,
      String? firstName,
      String? lastName,
      String? userNickname,
      List<Accounts>? accounts,
      String? previousSuccessfulLogin,
      Null? securitySettings,
      UserAccountSettings? userAccountSettings,
      bool? tempBlock,
      int? emulatingUserId,
      String? associatedTrackingType,
      bool? isPaymentBlocked,
      String? systemCode,
      int? id,
      int? selectedAccountId}) {
    if (username != null) {
      this._username = username;
    }
    if (firstName != null) {
      this._firstName = firstName;
    }
    if (lastName != null) {
      this._lastName = lastName;
    }
    if (userNickname != null) {
      this._userNickname = userNickname;
    }
    if (accounts != null) {
      this._accounts = accounts;
    }
    if (previousSuccessfulLogin != null) {
      this._previousSuccessfulLogin = previousSuccessfulLogin;
    }

    if (userAccountSettings != null) {
      this._userAccountSettings = userAccountSettings;
    }
    if (tempBlock != null) {
      this._tempBlock = tempBlock;
    }
    if (emulatingUserId != null) {
      this._emulatingUserId = emulatingUserId;
    }
    if (associatedTrackingType != null) {
      this._associatedTrackingType = associatedTrackingType;
    }
    if (isPaymentBlocked != null) {
      this._isPaymentBlocked = isPaymentBlocked;
    }
    if (systemCode != null) {
      this._systemCode = systemCode;
    }
    if (id != null) {
      this._id = id;
    }
    if (selectedAccountId != null) {
      this._selectedAccountId = selectedAccountId;
    }
  }

  String? get username => _username;
  set username(String? username) => _username = username;
  String? get firstName => _firstName;
  set firstName(String? firstName) => _firstName = firstName;
  String? get lastName => _lastName;
  set lastName(String? lastName) => _lastName = lastName;
  String? get userNickname => _userNickname;
  set userNickname(String? userNickname) => _userNickname = userNickname;
  List<Accounts>? get accounts => _accounts;
  set accounts(List<Accounts>? accounts) => _accounts = accounts;
  String? get previousSuccessfulLogin => _previousSuccessfulLogin;
  set previousSuccessfulLogin(String? previousSuccessfulLogin) =>
      _previousSuccessfulLogin = previousSuccessfulLogin;

  UserAccountSettings? get userAccountSettings => _userAccountSettings;
  set userAccountSettings(UserAccountSettings? userAccountSettings) =>
      _userAccountSettings = userAccountSettings;
  bool? get tempBlock => _tempBlock;
  set tempBlock(bool? tempBlock) => _tempBlock = tempBlock;
  int? get emulatingUserId => _emulatingUserId;
  set emulatingUserId(int? emulatingUserId) =>
      _emulatingUserId = emulatingUserId;
  String? get associatedTrackingType => _associatedTrackingType;
  set associatedTrackingType(String? associatedTrackingType) =>
      _associatedTrackingType = associatedTrackingType;
  bool? get isPaymentBlocked => _isPaymentBlocked;
  set isPaymentBlocked(bool? isPaymentBlocked) =>
      _isPaymentBlocked = isPaymentBlocked;
  String? get systemCode => _systemCode;
  set systemCode(String? systemCode) => _systemCode = systemCode;
  int? get id => _id;
  set id(int? id) => _id = id;
  int? get selectedAccountId => _selectedAccountId;
  set selectedAccountId(int? selectedAccountId) =>
      _selectedAccountId = selectedAccountId;

  CurrentUser.fromJson(Map<String, dynamic> json) {
    _username = json['Username'];
    _firstName = json['FirstName'];
    _lastName = json['LastName'];
    _userNickname = json['UserNickname'];
    if (json['Accounts'] != null) {
      _accounts = <Accounts>[];
      json['Accounts'].forEach((v) {
        _accounts!.add(new Accounts.fromJson(v));
      });
    }
    _previousSuccessfulLogin = json['PreviousSuccessfulLogin'];
    _userAccountSettings = json['UserAccountSettings'] != null
        ? new UserAccountSettings.fromJson(json['UserAccountSettings'])
        : null;
    _tempBlock = json['TempBlock'];
    _emulatingUserId = json['EmulatingUserId'];
    _associatedTrackingType = json['AssociatedTrackingType'];
    _isPaymentBlocked = json['IsPaymentBlocked'];
    _systemCode = json['SystemCode'];
    _id = json['Id'];
    _selectedAccountId = json['SelectedAccountId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Username'] = this._username;
    data['FirstName'] = this._firstName;
    data['LastName'] = this._lastName;
    data['UserNickname'] = this._userNickname;
    if (this._accounts != null) {
      data['Accounts'] = this._accounts!.map((v) => v.toJson()).toList();
    }
    data['PreviousSuccessfulLogin'] = this._previousSuccessfulLogin;

    if (this._userAccountSettings != null) {
      data['UserAccountSettings'] = this._userAccountSettings!.toJson();
    }
    data['TempBlock'] = this._tempBlock;
    data['EmulatingUserId'] = this._emulatingUserId;
    data['AssociatedTrackingType'] = this._associatedTrackingType;
    data['IsPaymentBlocked'] = this._isPaymentBlocked;
    data['SystemCode'] = this._systemCode;
    data['Id'] = this._id;
    data['SelectedAccountId'] = this._selectedAccountId;
    return data;
  }
}

class Accounts {
  int? _id;
  int? _userId;
  String? _customerId;
  String? _accountLast4;
  String? _accountNickname;
  String? _billingAccountLast4;
  String? _blockReclass;
  bool? _adminAccountLock;
  String? _procType;
  double? _accountBalance;
  double? _availableCredit;
  double? _availableCash;
  double? _creditLimit;
  double? _cashLimit;
  double? _minimumPaymentDue;
  double? _lastPaymentAmount;
  double? _cashBalance;
  double? _pastDueAmount;
  double? _lastStatementAmount;
  double? _pendingBalance;
  String? _lastUpdated;
  String? _cardholderSince;
  String? _paymentDueDate;
  String? _lastPaymentDate;
  DateTime? _expirationDate;
  String? _lastStatementDate;
  String? _lastActivityDate;
  String? _statementDeliveryOption;
  bool? _hasChipCard;
  String? _cardholderStatus;
  String? _cardholderBalanceSign;
  double? _cardholderBalance;
  String? _householdingFlag;
  String? _householdBalanceSign;
  String? _householdBalance;
  String? _associatedAccountTypeCode;
  bool? _isPrimary;
  bool? _isDefault;
  String? _planType;
  String? _mILIndicator;
  String? _businessCardAccountTypeIndicator;
  String? _associatedTrackingType;
  bool? _tempBlock;
  bool? _isPaymentBlocked;
  bool? _vCPSParticipation;
  String? _vCPSEnrollmentDate;
  String? _accountTermsId;

  Accounts(
      {int? id,
      int? userId,
      String? customerId,
      String? accountLast4,
      String? accountNickname,
      String? billingAccountLast4,
      String? blockReclass,
      bool? adminAccountLock,
      String? procType,
      double? accountBalance,
      double? availableCredit,
      double? availableCash,
      double? creditLimit,
      double? cashLimit,
      double? minimumPaymentDue,
      double? lastPaymentAmount,
      double? cashBalance,
      double? pastDueAmount,
      double? lastStatementAmount,
      double? pendingBalance,
      String? lastUpdated,
      String? cardholderSince,
      String? paymentDueDate,
      String? lastPaymentDate,
      DateTime? expirationDate,
      String? lastStatementDate,
      String? lastActivityDate,
      String? statementDeliveryOption,
      bool? hasChipCard,
      String? cardholderStatus,
      String? cardholderBalanceSign,
      double? cardholderBalance,
      String? householdingFlag,
      String? householdBalanceSign,
      String? householdBalance,
      String? associatedAccountTypeCode,
      bool? isPrimary,
      bool? isDefault,
      String? planType,
      String? mILIndicator,
      String? businessCardAccountTypeIndicator,
      String? associatedTrackingType,
      bool? tempBlock,
      bool? isPaymentBlocked,
      bool? vCPSParticipation,
      String? vCPSEnrollmentDate,
      String? accountTermsId}) {
    if (id != null) {
      this._id = id;
    }
    if (userId != null) {
      this._userId = userId;
    }
    if (customerId != null) {
      this._customerId = customerId;
    }
    if (accountLast4 != null) {
      this._accountLast4 = accountLast4;
    }
    if (accountNickname != null) {
      this._accountNickname = accountNickname;
    }
    if (billingAccountLast4 != null) {
      this._billingAccountLast4 = billingAccountLast4;
    }
    if (blockReclass != null) {
      this._blockReclass = blockReclass;
    }
    if (adminAccountLock != null) {
      this._adminAccountLock = adminAccountLock;
    }
    if (procType != null) {
      this._procType = procType;
    }
    if (accountBalance != null) {
      this._accountBalance = accountBalance;
    }
    if (availableCredit != null) {
      this._availableCredit = availableCredit;
    }
    if (availableCash != null) {
      this._availableCash = availableCash;
    }
    if (creditLimit != null) {
      this._creditLimit = creditLimit;
    }
    if (cashLimit != null) {
      this._cashLimit = cashLimit;
    }
    if (minimumPaymentDue != null) {
      this._minimumPaymentDue = minimumPaymentDue;
    }
    if (lastPaymentAmount != null) {
      this._lastPaymentAmount = lastPaymentAmount;
    }
    if (cashBalance != null) {
      this._cashBalance = cashBalance;
    }
    if (pastDueAmount != null) {
      this._pastDueAmount = pastDueAmount;
    }
    if (lastStatementAmount != null) {
      this._lastStatementAmount = lastStatementAmount;
    }
    if (pendingBalance != null) {
      this._pendingBalance = pendingBalance;
    }
    if (lastUpdated != null) {
      this._lastUpdated = lastUpdated;
    }
    if (cardholderSince != null) {
      this._cardholderSince = cardholderSince;
    }
    if (paymentDueDate != null) {
      this._paymentDueDate = paymentDueDate;
    }
    if (lastPaymentDate != null) {
      this._lastPaymentDate = lastPaymentDate;
    }
    if (expirationDate != null) {
      this._expirationDate = expirationDate;
    }
    if (lastStatementDate != null) {
      this._lastStatementDate = lastStatementDate;
    }
    if (lastActivityDate != null) {
      this._lastActivityDate = lastActivityDate;
    }
    if (statementDeliveryOption != null) {
      this._statementDeliveryOption = statementDeliveryOption;
    }
    if (hasChipCard != null) {
      this._hasChipCard = hasChipCard;
    }
    if (cardholderStatus != null) {
      this._cardholderStatus = cardholderStatus;
    }
    if (cardholderBalanceSign != null) {
      this._cardholderBalanceSign = cardholderBalanceSign;
    }
    if (cardholderBalance != null) {
      this._cardholderBalance = cardholderBalance;
    }
    if (householdingFlag != null) {
      this._householdingFlag = householdingFlag;
    }
    if (householdBalanceSign != null) {
      this._householdBalanceSign = householdBalanceSign;
    }
    if (householdBalance != null) {
      this._householdBalance = householdBalance;
    }
    if (associatedAccountTypeCode != null) {
      this._associatedAccountTypeCode = associatedAccountTypeCode;
    }
    if (isPrimary != null) {
      this._isPrimary = isPrimary;
    }
    if (isDefault != null) {
      this._isDefault = isDefault;
    }
    if (planType != null) {
      this._planType = planType;
    }
    if (mILIndicator != null) {
      this._mILIndicator = mILIndicator;
    }
    if (businessCardAccountTypeIndicator != null) {
      this._businessCardAccountTypeIndicator = businessCardAccountTypeIndicator;
    }
    if (associatedTrackingType != null) {
      this._associatedTrackingType = associatedTrackingType;
    }
    if (tempBlock != null) {
      this._tempBlock = tempBlock;
    }
    if (isPaymentBlocked != null) {
      this._isPaymentBlocked = isPaymentBlocked;
    }
    if (vCPSParticipation != null) {
      this._vCPSParticipation = vCPSParticipation;
    }
    if (vCPSEnrollmentDate != null) {
      this._vCPSEnrollmentDate = vCPSEnrollmentDate;
    }
    if (accountTermsId != null) {
      this._accountTermsId = accountTermsId;
    }
  }

  int? get id => _id;
  set id(int? id) => _id = id;
  int? get userId => _userId;
  set userId(int? userId) => _userId = userId;
  String? get customerId => _customerId;
  set customerId(String? customerId) => _customerId = customerId;
  String? get accountLast4 => _accountLast4;
  set accountLast4(String? accountLast4) => _accountLast4 = accountLast4;
  String? get accountNickname => _accountNickname;
  set accountNickname(String? accountNickname) =>
      _accountNickname = accountNickname;
  String? get billingAccountLast4 => _billingAccountLast4;
  set billingAccountLast4(String? billingAccountLast4) =>
      _billingAccountLast4 = billingAccountLast4;
  String? get blockReclass => _blockReclass;
  set blockReclass(String? blockReclass) => _blockReclass = blockReclass;
  bool? get adminAccountLock => _adminAccountLock;
  set adminAccountLock(bool? adminAccountLock) =>
      _adminAccountLock = adminAccountLock;
  String? get procType => _procType;
  set procType(String? procType) => _procType = procType;
  double? get accountBalance => _accountBalance;
  set accountBalance(double? accountBalance) =>
      _accountBalance = accountBalance;
  double? get availableCredit => _availableCredit;
  set availableCredit(double? availableCredit) =>
      _availableCredit = availableCredit;
  double? get availableCash => _availableCash;
  set availableCash(double? availableCash) => _availableCash = availableCash;
  double? get creditLimit => _creditLimit;
  set creditLimit(double? creditLimit) => _creditLimit = creditLimit;
  double? get cashLimit => _cashLimit;
  set cashLimit(double? cashLimit) => _cashLimit = cashLimit;
  double? get minimumPaymentDue => _minimumPaymentDue;
  set minimumPaymentDue(double? minimumPaymentDue) =>
      _minimumPaymentDue = minimumPaymentDue;
  double? get lastPaymentAmount => _lastPaymentAmount;
  set lastPaymentAmount(double? lastPaymentAmount) =>
      _lastPaymentAmount = lastPaymentAmount;
  double? get cashBalance => _cashBalance;
  set cashBalance(double? cashBalance) => _cashBalance = cashBalance;
  double? get pastDueAmount => _pastDueAmount;
  set pastDueAmount(double? pastDueAmount) => _pastDueAmount = pastDueAmount;
  double? get lastStatementAmount => _lastStatementAmount;
  set lastStatementAmount(double? lastStatementAmount) =>
      _lastStatementAmount = lastStatementAmount;
  double? get pendingBalance => _pendingBalance;
  set pendingBalance(double? pendingBalance) =>
      _pendingBalance = pendingBalance;
  String? get lastUpdated => _lastUpdated;
  set lastUpdated(String? lastUpdated) => _lastUpdated = lastUpdated;
  String? get cardholderSince => _cardholderSince;
  set cardholderSince(String? cardholderSince) =>
      _cardholderSince = cardholderSince;
  String? get paymentDueDate => _paymentDueDate;
  set paymentDueDate(String? paymentDueDate) =>
      _paymentDueDate = paymentDueDate;
  String? get lastPaymentDate => _lastPaymentDate;
  set lastPaymentDate(String? lastPaymentDate) =>
      _lastPaymentDate = lastPaymentDate;
  DateTime? get expirationDate => _expirationDate;
  set expirationDate(DateTime? expirationDate) =>
      _expirationDate = expirationDate;
  String? get lastStatementDate => _lastStatementDate;
  set lastStatementDate(String? lastStatementDate) =>
      _lastStatementDate = lastStatementDate;
  String? get lastActivityDate => _lastActivityDate;
  set lastActivityDate(String? lastActivityDate) =>
      _lastActivityDate = lastActivityDate;
  String? get statementDeliveryOption => _statementDeliveryOption;
  set statementDeliveryOption(String? statementDeliveryOption) =>
      _statementDeliveryOption = statementDeliveryOption;
  bool? get hasChipCard => _hasChipCard;
  set hasChipCard(bool? hasChipCard) => _hasChipCard = hasChipCard;
  String? get cardholderStatus => _cardholderStatus;
  set cardholderStatus(String? cardholderStatus) =>
      _cardholderStatus = cardholderStatus;
  String? get cardholderBalanceSign => _cardholderBalanceSign;
  set cardholderBalanceSign(String? cardholderBalanceSign) =>
      _cardholderBalanceSign = cardholderBalanceSign;
  double? get cardholderBalance => _cardholderBalance;
  set cardholderBalance(double? cardholderBalance) =>
      _cardholderBalance = cardholderBalance;
  String? get householdingFlag => _householdingFlag;
  set householdingFlag(String? householdingFlag) =>
      _householdingFlag = householdingFlag;
  String? get householdBalanceSign => _householdBalanceSign;
  set householdBalanceSign(String? householdBalanceSign) =>
      _householdBalanceSign = householdBalanceSign;
  String? get householdBalance => _householdBalance;
  set householdBalance(String? householdBalance) =>
      _householdBalance = householdBalance;
  String? get associatedAccountTypeCode => _associatedAccountTypeCode;
  set associatedAccountTypeCode(String? associatedAccountTypeCode) =>
      _associatedAccountTypeCode = associatedAccountTypeCode;
  bool? get isPrimary => _isPrimary;
  set isPrimary(bool? isPrimary) => _isPrimary = isPrimary;
  bool? get isDefault => _isDefault;
  set isDefault(bool? isDefault) => _isDefault = isDefault;
  String? get planType => _planType;
  set planType(String? planType) => _planType = planType;
  String? get mILIndicator => _mILIndicator;
  set mILIndicator(String? mILIndicator) => _mILIndicator = mILIndicator;
  String? get businessCardAccountTypeIndicator =>
      _businessCardAccountTypeIndicator;
  set businessCardAccountTypeIndicator(
          String? businessCardAccountTypeIndicator) =>
      _businessCardAccountTypeIndicator = businessCardAccountTypeIndicator;
  String? get associatedTrackingType => _associatedTrackingType;
  set associatedTrackingType(String? associatedTrackingType) =>
      _associatedTrackingType = associatedTrackingType;
  bool? get tempBlock => _tempBlock;
  set tempBlock(bool? tempBlock) => _tempBlock = tempBlock;
  bool? get isPaymentBlocked => _isPaymentBlocked;
  set isPaymentBlocked(bool? isPaymentBlocked) =>
      _isPaymentBlocked = isPaymentBlocked;
  bool? get vCPSParticipation => _vCPSParticipation;
  set vCPSParticipation(bool? vCPSParticipation) =>
      _vCPSParticipation = vCPSParticipation;
  String? get vCPSEnrollmentDate => _vCPSEnrollmentDate;
  set vCPSEnrollmentDate(String? vCPSEnrollmentDate) =>
      _vCPSEnrollmentDate = vCPSEnrollmentDate;
  String? get accountTermsId => _accountTermsId;
  set accountTermsId(String? accountTermsId) =>
      _accountTermsId = accountTermsId;

  Accounts.fromJson(Map<String, dynamic> json) {
    _id = json['Id'];
    _userId = json['UserId'];
    _customerId = json['CustomerId'];
    _accountLast4 = json['AccountLast4'];
    _accountNickname = json['AccountNickname'];
    _billingAccountLast4 = json['BillingAccountLast4'];
    _blockReclass = json['BlockReclass'];
    _adminAccountLock = json['AdminAccountLock'];
    _procType = json['ProcType'];
    _accountBalance = json['AccountBalance'];
    _availableCredit = json['AvailableCredit'];
    _availableCash = json['AvailableCash'];
    _creditLimit = json['CreditLimit'];
    _cashLimit = json['CashLimit'];
    _minimumPaymentDue = json['MinimumPaymentDue'];
    _lastPaymentAmount = json['LastPaymentAmount'];
    _cashBalance = json['CashBalance'];
    _pastDueAmount = json['PastDueAmount'];
    _lastStatementAmount = json['LastStatementAmount'];
    _pendingBalance = json['PendingBalance'];
    _lastUpdated = json['LastUpdated'];
    _cardholderSince = json['CardholderSince'];
    _paymentDueDate = json['PaymentDueDate'];
    _lastPaymentDate = json['LastPaymentDate'];
    _expirationDate = DateTime.parse(json['ExpirationDate']);
    _lastStatementDate = json['LastStatementDate'];
    _lastActivityDate = json['LastActivityDate'];
    _statementDeliveryOption = json['StatementDeliveryOption'];
    _hasChipCard = json['HasChipCard'];
    _cardholderStatus = json['CardholderStatus'];
    _cardholderBalanceSign = json['CardholderBalanceSign'];
    _cardholderBalance = json['CardholderBalance'];
    _householdingFlag = json['HouseholdingFlag'];
    _householdBalanceSign = json['HouseholdBalanceSign'];
    _householdBalance = json['HouseholdBalance'];
    _associatedAccountTypeCode = json['AssociatedAccountTypeCode'];
    _isPrimary = json['IsPrimary'];
    _isDefault = json['IsDefault'];
    _planType = json['PlanType'];
    _mILIndicator = json['MILIndicator'];
    _businessCardAccountTypeIndicator =
        json['BusinessCardAccountTypeIndicator'];
    _associatedTrackingType = json['AssociatedTrackingType'];
    _tempBlock = json['TempBlock'];
    _isPaymentBlocked = json['IsPaymentBlocked'];
    _vCPSParticipation = json['VCPSParticipation'];
    _vCPSEnrollmentDate = json['VCPSEnrollmentDate'];
    _accountTermsId = json['AccountTermsId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Id'] = this._id;
    data['UserId'] = this._userId;
    data['CustomerId'] = this._customerId;
    data['AccountLast4'] = this._accountLast4;
    data['AccountNickname'] = this._accountNickname;
    data['BillingAccountLast4'] = this._billingAccountLast4;
    data['BlockReclass'] = this._blockReclass;
    data['AdminAccountLock'] = this._adminAccountLock;
    data['ProcType'] = this._procType;
    data['AccountBalance'] = this._accountBalance;
    data['AvailableCredit'] = this._availableCredit;
    data['AvailableCash'] = this._availableCash;
    data['CreditLimit'] = this._creditLimit;
    data['CashLimit'] = this._cashLimit;
    data['MinimumPaymentDue'] = this._minimumPaymentDue;
    data['LastPaymentAmount'] = this._lastPaymentAmount;
    data['CashBalance'] = this._cashBalance;
    data['PastDueAmount'] = this._pastDueAmount;
    data['LastStatementAmount'] = this._lastStatementAmount;
    data['PendingBalance'] = this._pendingBalance;
    data['LastUpdated'] = this._lastUpdated;
    data['CardholderSince'] = this._cardholderSince;
    data['PaymentDueDate'] = this._paymentDueDate;
    data['LastPaymentDate'] = this._lastPaymentDate;
    data['ExpirationDate'] = this._expirationDate;
    data['LastStatementDate'] = this._lastStatementDate;
    data['LastActivityDate'] = this._lastActivityDate;
    data['StatementDeliveryOption'] = this._statementDeliveryOption;
    data['HasChipCard'] = this._hasChipCard;
    data['CardholderStatus'] = this._cardholderStatus;
    data['CardholderBalanceSign'] = this._cardholderBalanceSign;
    data['CardholderBalance'] = this._cardholderBalance;
    data['HouseholdingFlag'] = this._householdingFlag;
    data['HouseholdBalanceSign'] = this._householdBalanceSign;
    data['HouseholdBalance'] = this._householdBalance;
    data['AssociatedAccountTypeCode'] = this._associatedAccountTypeCode;
    data['IsPrimary'] = this._isPrimary;
    data['IsDefault'] = this._isDefault;
    data['PlanType'] = this._planType;
    data['MILIndicator'] = this._mILIndicator;
    data['BusinessCardAccountTypeIndicator'] =
        this._businessCardAccountTypeIndicator;
    data['AssociatedTrackingType'] = this._associatedTrackingType;
    data['TempBlock'] = this._tempBlock;
    data['IsPaymentBlocked'] = this._isPaymentBlocked;
    data['VCPSParticipation'] = this._vCPSParticipation;
    data['VCPSEnrollmentDate'] = this._vCPSEnrollmentDate;
    data['AccountTermsId'] = this._accountTermsId;
    return data;
  }
}

class UserAccountSettings {
  int? _accountId;
  int? _userId;
  Null? _displayExit;
  bool? _isWalkthrough;
  String? _homeUrl;
  List<String>? _securityRightsAssigned;

  UserAccountSettings(
      {int? accountId,
      int? userId,
      Null? displayExit,
      bool? isWalkthrough,
      String? homeUrl,
      SecuritySettings? securitySettings,
      List<String>? securityRightsAssigned}) {
    if (accountId != null) {
      this._accountId = accountId;
    }
    if (userId != null) {
      this._userId = userId;
    }
    if (displayExit != null) {
      this._displayExit = displayExit;
    }
    if (isWalkthrough != null) {
      this._isWalkthrough = isWalkthrough;
    }
    if (homeUrl != null) {
      this._homeUrl = homeUrl;
    }

    if (securityRightsAssigned != null) {
      this._securityRightsAssigned = securityRightsAssigned;
    }
  }

  int? get accountId => _accountId;
  set accountId(int? accountId) => _accountId = accountId;
  int? get userId => _userId;
  set userId(int? userId) => _userId = userId;
  Null? get displayExit => _displayExit;
  set displayExit(Null? displayExit) => _displayExit = displayExit;
  bool? get isWalkthrough => _isWalkthrough;
  set isWalkthrough(bool? isWalkthrough) => _isWalkthrough = isWalkthrough;
  String? get homeUrl => _homeUrl;
  set homeUrl(String? homeUrl) => _homeUrl = homeUrl;
  List<String>? get securityRightsAssigned => _securityRightsAssigned;
  set securityRightsAssigned(List<String>? securityRightsAssigned) =>
      _securityRightsAssigned = securityRightsAssigned;

  UserAccountSettings.fromJson(Map<String, dynamic> json) {
    _accountId = json['AccountId'];
    _userId = json['UserId'];
    _displayExit = json['DisplayExit'];
    _isWalkthrough = json['IsWalkthrough'];
    _homeUrl = json['HomeUrl'];

    _securityRightsAssigned = json['SecurityRightsAssigned'].cast<String>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['AccountId'] = this._accountId;
    data['UserId'] = this._userId;
    data['DisplayExit'] = this._displayExit;
    data['IsWalkthrough'] = this._isWalkthrough;
    data['HomeUrl'] = this._homeUrl;
    data['SecurityRightsAssigned'] = this._securityRightsAssigned;
    return data;
  }
}

class SecuritySettings {
  bool? _alerts;
  bool? _adminMessages;
  bool? _associatedAccounts;
  bool? _canLogin;
  bool? _canEnroll;
  bool? _cardActivation;
  bool? _centrallyBilled;
  bool? _chipCard;
  bool? _commercialCard;
  bool? _companySuppression;
  bool? _emulating;
  bool? _expenseManagement;
  bool? _isReceiptImageEnable;
  bool? _hasAssociatedAccounts;
  bool? _hideLogout;
  bool? _inquiries;
  bool? _isEmulating;
  bool? _merchantFundedReward;
  bool? _pINChange;
  bool? _passwordQa;
  bool? _payments;
  bool? _recurringPayments;
  bool? _forceUpdatePymntPln;
  bool? _scoreCard;
  bool? _serviceRequests;
  bool? _spendAnalyzer;
  bool? _sso;
  bool? _statementSuppression;
  bool? _transactionAddendum;
  bool? _transactionDisputes;
  bool? _transactionSearch;
  bool? _virtualCard;
  bool? _visa;
  bool? _creditScoreDisplay;
  bool? _creditScoreAvailable;
  bool? _creditScoreCardholderAcceptanceNeeded;
  bool? _creditScoreNotOlderThen90Day;
  bool? _balanceTransfer;
  bool? _passwordExpiry;

  SecuritySettings(
      {bool? alerts,
      bool? adminMessages,
      bool? associatedAccounts,
      bool? canLogin,
      bool? canEnroll,
      bool? cardActivation,
      bool? centrallyBilled,
      bool? chipCard,
      bool? commercialCard,
      bool? companySuppression,
      bool? emulating,
      bool? expenseManagement,
      bool? isReceiptImageEnable,
      bool? hasAssociatedAccounts,
      bool? hideLogout,
      bool? inquiries,
      bool? isEmulating,
      bool? merchantFundedReward,
      bool? pINChange,
      bool? passwordQa,
      bool? payments,
      bool? recurringPayments,
      bool? forceUpdatePymntPln,
      bool? scoreCard,
      bool? serviceRequests,
      bool? spendAnalyzer,
      bool? sso,
      bool? statementSuppression,
      bool? transactionAddendum,
      bool? transactionDisputes,
      bool? transactionSearch,
      bool? virtualCard,
      bool? visa,
      bool? creditScoreDisplay,
      bool? creditScoreAvailable,
      bool? creditScoreCardholderAcceptanceNeeded,
      bool? creditScoreNotOlderThen90Day,
      bool? balanceTransfer,
      bool? passwordExpiry}) {
    if (alerts != null) {
      this._alerts = alerts;
    }
    if (adminMessages != null) {
      this._adminMessages = adminMessages;
    }
    if (associatedAccounts != null) {
      this._associatedAccounts = associatedAccounts;
    }
    if (canLogin != null) {
      this._canLogin = canLogin;
    }
    if (canEnroll != null) {
      this._canEnroll = canEnroll;
    }
    if (cardActivation != null) {
      this._cardActivation = cardActivation;
    }
    if (centrallyBilled != null) {
      this._centrallyBilled = centrallyBilled;
    }
    if (chipCard != null) {
      this._chipCard = chipCard;
    }
    if (commercialCard != null) {
      this._commercialCard = commercialCard;
    }
    if (companySuppression != null) {
      this._companySuppression = companySuppression;
    }
    if (emulating != null) {
      this._emulating = emulating;
    }
    if (expenseManagement != null) {
      this._expenseManagement = expenseManagement;
    }
    if (isReceiptImageEnable != null) {
      this._isReceiptImageEnable = isReceiptImageEnable;
    }
    if (hasAssociatedAccounts != null) {
      this._hasAssociatedAccounts = hasAssociatedAccounts;
    }
    if (hideLogout != null) {
      this._hideLogout = hideLogout;
    }
    if (inquiries != null) {
      this._inquiries = inquiries;
    }
    if (isEmulating != null) {
      this._isEmulating = isEmulating;
    }
    if (merchantFundedReward != null) {
      this._merchantFundedReward = merchantFundedReward;
    }
    if (pINChange != null) {
      this._pINChange = pINChange;
    }
    if (passwordQa != null) {
      this._passwordQa = passwordQa;
    }
    if (payments != null) {
      this._payments = payments;
    }
    if (recurringPayments != null) {
      this._recurringPayments = recurringPayments;
    }
    if (forceUpdatePymntPln != null) {
      this._forceUpdatePymntPln = forceUpdatePymntPln;
    }
    if (scoreCard != null) {
      this._scoreCard = scoreCard;
    }
    if (serviceRequests != null) {
      this._serviceRequests = serviceRequests;
    }
    if (spendAnalyzer != null) {
      this._spendAnalyzer = spendAnalyzer;
    }
    if (sso != null) {
      this._sso = sso;
    }
    if (statementSuppression != null) {
      this._statementSuppression = statementSuppression;
    }
    if (transactionAddendum != null) {
      this._transactionAddendum = transactionAddendum;
    }
    if (transactionDisputes != null) {
      this._transactionDisputes = transactionDisputes;
    }
    if (transactionSearch != null) {
      this._transactionSearch = transactionSearch;
    }
    if (virtualCard != null) {
      this._virtualCard = virtualCard;
    }
    if (visa != null) {
      this._visa = visa;
    }
    if (creditScoreDisplay != null) {
      this._creditScoreDisplay = creditScoreDisplay;
    }
    if (creditScoreAvailable != null) {
      this._creditScoreAvailable = creditScoreAvailable;
    }
    if (creditScoreCardholderAcceptanceNeeded != null) {
      this._creditScoreCardholderAcceptanceNeeded =
          creditScoreCardholderAcceptanceNeeded;
    }
    if (creditScoreNotOlderThen90Day != null) {
      this._creditScoreNotOlderThen90Day = creditScoreNotOlderThen90Day;
    }
    if (balanceTransfer != null) {
      this._balanceTransfer = balanceTransfer;
    }
    if (passwordExpiry != null) {
      this._passwordExpiry = passwordExpiry;
    }
  }

  bool? get alerts => _alerts;
  set alerts(bool? alerts) => _alerts = alerts;
  bool? get adminMessages => _adminMessages;
  set adminMessages(bool? adminMessages) => _adminMessages = adminMessages;
  bool? get associatedAccounts => _associatedAccounts;
  set associatedAccounts(bool? associatedAccounts) =>
      _associatedAccounts = associatedAccounts;
  bool? get canLogin => _canLogin;
  set canLogin(bool? canLogin) => _canLogin = canLogin;
  bool? get canEnroll => _canEnroll;
  set canEnroll(bool? canEnroll) => _canEnroll = canEnroll;
  bool? get cardActivation => _cardActivation;
  set cardActivation(bool? cardActivation) => _cardActivation = cardActivation;
  bool? get centrallyBilled => _centrallyBilled;
  set centrallyBilled(bool? centrallyBilled) =>
      _centrallyBilled = centrallyBilled;
  bool? get chipCard => _chipCard;
  set chipCard(bool? chipCard) => _chipCard = chipCard;
  bool? get commercialCard => _commercialCard;
  set commercialCard(bool? commercialCard) => _commercialCard = commercialCard;
  bool? get companySuppression => _companySuppression;
  set companySuppression(bool? companySuppression) =>
      _companySuppression = companySuppression;
  bool? get emulating => _emulating;
  set emulating(bool? emulating) => _emulating = emulating;
  bool? get expenseManagement => _expenseManagement;
  set expenseManagement(bool? expenseManagement) =>
      _expenseManagement = expenseManagement;
  bool? get isReceiptImageEnable => _isReceiptImageEnable;
  set isReceiptImageEnable(bool? isReceiptImageEnable) =>
      _isReceiptImageEnable = isReceiptImageEnable;
  bool? get hasAssociatedAccounts => _hasAssociatedAccounts;
  set hasAssociatedAccounts(bool? hasAssociatedAccounts) =>
      _hasAssociatedAccounts = hasAssociatedAccounts;
  bool? get hideLogout => _hideLogout;
  set hideLogout(bool? hideLogout) => _hideLogout = hideLogout;
  bool? get inquiries => _inquiries;
  set inquiries(bool? inquiries) => _inquiries = inquiries;
  bool? get isEmulating => _isEmulating;
  set isEmulating(bool? isEmulating) => _isEmulating = isEmulating;
  bool? get merchantFundedReward => _merchantFundedReward;
  set merchantFundedReward(bool? merchantFundedReward) =>
      _merchantFundedReward = merchantFundedReward;
  bool? get pINChange => _pINChange;
  set pINChange(bool? pINChange) => _pINChange = pINChange;
  bool? get passwordQa => _passwordQa;
  set passwordQa(bool? passwordQa) => _passwordQa = passwordQa;
  bool? get payments => _payments;
  set payments(bool? payments) => _payments = payments;
  bool? get recurringPayments => _recurringPayments;
  set recurringPayments(bool? recurringPayments) =>
      _recurringPayments = recurringPayments;
  bool? get forceUpdatePymntPln => _forceUpdatePymntPln;
  set forceUpdatePymntPln(bool? forceUpdatePymntPln) =>
      _forceUpdatePymntPln = forceUpdatePymntPln;
  bool? get scoreCard => _scoreCard;
  set scoreCard(bool? scoreCard) => _scoreCard = scoreCard;
  bool? get serviceRequests => _serviceRequests;
  set serviceRequests(bool? serviceRequests) =>
      _serviceRequests = serviceRequests;
  bool? get spendAnalyzer => _spendAnalyzer;
  set spendAnalyzer(bool? spendAnalyzer) => _spendAnalyzer = spendAnalyzer;
  bool? get sso => _sso;
  set sso(bool? sso) => _sso = sso;
  bool? get statementSuppression => _statementSuppression;
  set statementSuppression(bool? statementSuppression) =>
      _statementSuppression = statementSuppression;
  bool? get transactionAddendum => _transactionAddendum;
  set transactionAddendum(bool? transactionAddendum) =>
      _transactionAddendum = transactionAddendum;
  bool? get transactionDisputes => _transactionDisputes;
  set transactionDisputes(bool? transactionDisputes) =>
      _transactionDisputes = transactionDisputes;
  bool? get transactionSearch => _transactionSearch;
  set transactionSearch(bool? transactionSearch) =>
      _transactionSearch = transactionSearch;
  bool? get virtualCard => _virtualCard;
  set virtualCard(bool? virtualCard) => _virtualCard = virtualCard;
  bool? get visa => _visa;
  set visa(bool? visa) => _visa = visa;
  bool? get creditScoreDisplay => _creditScoreDisplay;
  set creditScoreDisplay(bool? creditScoreDisplay) =>
      _creditScoreDisplay = creditScoreDisplay;
  bool? get creditScoreAvailable => _creditScoreAvailable;
  set creditScoreAvailable(bool? creditScoreAvailable) =>
      _creditScoreAvailable = creditScoreAvailable;
  bool? get creditScoreCardholderAcceptanceNeeded =>
      _creditScoreCardholderAcceptanceNeeded;
  set creditScoreCardholderAcceptanceNeeded(
          bool? creditScoreCardholderAcceptanceNeeded) =>
      _creditScoreCardholderAcceptanceNeeded =
          creditScoreCardholderAcceptanceNeeded;
  bool? get creditScoreNotOlderThen90Day => _creditScoreNotOlderThen90Day;
  set creditScoreNotOlderThen90Day(bool? creditScoreNotOlderThen90Day) =>
      _creditScoreNotOlderThen90Day = creditScoreNotOlderThen90Day;
  bool? get balanceTransfer => _balanceTransfer;
  set balanceTransfer(bool? balanceTransfer) =>
      _balanceTransfer = balanceTransfer;
  bool? get passwordExpiry => _passwordExpiry;
  set passwordExpiry(bool? passwordExpiry) => _passwordExpiry = passwordExpiry;

  SecuritySettings.fromJson(Map<String, dynamic> json) {
    _alerts = json['Alerts'];
    _adminMessages = json['AdminMessages'];
    _associatedAccounts = json['AssociatedAccounts'];
    _canLogin = json['CanLogin'];
    _canEnroll = json['CanEnroll'];
    _cardActivation = json['CardActivation'];
    _centrallyBilled = json['CentrallyBilled'];
    _chipCard = json['ChipCard'];
    _commercialCard = json['CommercialCard'];
    _companySuppression = json['CompanySuppression'];
    _emulating = json['Emulating'];
    _expenseManagement = json['ExpenseManagement'];
    _isReceiptImageEnable = json['IsReceiptImageEnable'];
    _hasAssociatedAccounts = json['HasAssociatedAccounts'];
    _hideLogout = json['HideLogout'];
    _inquiries = json['Inquiries'];
    _isEmulating = json['IsEmulating'];
    _merchantFundedReward = json['MerchantFundedReward'];
    _pINChange = json['PINChange'];
    _passwordQa = json['PasswordQa'];
    _payments = json['Payments'];
    _recurringPayments = json['RecurringPayments'];
    _forceUpdatePymntPln = json['ForceUpdatePymntPln'];
    _scoreCard = json['ScoreCard'];
    _serviceRequests = json['ServiceRequests'];
    _spendAnalyzer = json['SpendAnalyzer'];
    _sso = json['Sso'];
    _statementSuppression = json['StatementSuppression'];
    _transactionAddendum = json['TransactionAddendum'];
    _transactionDisputes = json['TransactionDisputes'];
    _transactionSearch = json['TransactionSearch'];
    _virtualCard = json['VirtualCard'];
    _visa = json['Visa'];
    _creditScoreDisplay = json['CreditScoreDisplay'];
    _creditScoreAvailable = json['CreditScoreAvailable'];
    _creditScoreCardholderAcceptanceNeeded =
        json['CreditScoreCardholderAcceptanceNeeded'];
    _creditScoreNotOlderThen90Day = json['CreditScoreNotOlderThen90Day'];
    _balanceTransfer = json['BalanceTransfer'];
    _passwordExpiry = json['PasswordExpiry'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Alerts'] = this._alerts;
    data['AdminMessages'] = this._adminMessages;
    data['AssociatedAccounts'] = this._associatedAccounts;
    data['CanLogin'] = this._canLogin;
    data['CanEnroll'] = this._canEnroll;
    data['CardActivation'] = this._cardActivation;
    data['CentrallyBilled'] = this._centrallyBilled;
    data['ChipCard'] = this._chipCard;
    data['CommercialCard'] = this._commercialCard;
    data['CompanySuppression'] = this._companySuppression;
    data['Emulating'] = this._emulating;
    data['ExpenseManagement'] = this._expenseManagement;
    data['IsReceiptImageEnable'] = this._isReceiptImageEnable;
    data['HasAssociatedAccounts'] = this._hasAssociatedAccounts;
    data['HideLogout'] = this._hideLogout;
    data['Inquiries'] = this._inquiries;
    data['IsEmulating'] = this._isEmulating;
    data['MerchantFundedReward'] = this._merchantFundedReward;
    data['PINChange'] = this._pINChange;
    data['PasswordQa'] = this._passwordQa;
    data['Payments'] = this._payments;
    data['RecurringPayments'] = this._recurringPayments;
    data['ForceUpdatePymntPln'] = this._forceUpdatePymntPln;
    data['ScoreCard'] = this._scoreCard;
    data['ServiceRequests'] = this._serviceRequests;
    data['SpendAnalyzer'] = this._spendAnalyzer;
    data['Sso'] = this._sso;
    data['StatementSuppression'] = this._statementSuppression;
    data['TransactionAddendum'] = this._transactionAddendum;
    data['TransactionDisputes'] = this._transactionDisputes;
    data['TransactionSearch'] = this._transactionSearch;
    data['VirtualCard'] = this._virtualCard;
    data['Visa'] = this._visa;
    data['CreditScoreDisplay'] = this._creditScoreDisplay;
    data['CreditScoreAvailable'] = this._creditScoreAvailable;
    data['CreditScoreCardholderAcceptanceNeeded'] =
        this._creditScoreCardholderAcceptanceNeeded;
    data['CreditScoreNotOlderThen90Day'] = this._creditScoreNotOlderThen90Day;
    data['BalanceTransfer'] = this._balanceTransfer;
    data['PasswordExpiry'] = this._passwordExpiry;
    return data;
  }
}
