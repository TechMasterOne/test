class LoginModel {
  int? id;
  String? token;
  String? state;
  String? isEnrollment;
  String? isForgotUsername;
  String? isResetSecurity;
  int? agreementId;
  String? initialRoute;
  bool? isAssociatedAccount;
  String? typedUsername;
  String? message;
  bool? canEnrollInGemini;
  bool? isEnrolledInGemini;
  bool? isRsaEnrollmentNeeded;
  bool? isBillingAccount;
  String? challengeMobileNumber;
  String? enrollmentOtpMethod;
  String? enrollmentOtpCode;
  String? loginOtpCode;
  String? loginOtpMethod;

  LoginModel(
      {this.id,
      this.token,
      this.state,
      this.isEnrollment,
      this.isForgotUsername,
      this.isResetSecurity,
      this.agreementId,
      this.initialRoute,
      this.isAssociatedAccount,
      this.typedUsername,
      this.message,
      this.canEnrollInGemini,
      this.isEnrolledInGemini,
      this.isRsaEnrollmentNeeded,
      this.isBillingAccount,
      this.challengeMobileNumber,
      this.enrollmentOtpMethod,
      this.enrollmentOtpCode,
      this.loginOtpCode,
      this.loginOtpMethod});

  LoginModel.fromJson(Map<String, dynamic> json) {
    id = json['Id'];
    token = json['Token'];
    state = json['State'];
    isEnrollment = json['IsEnrollment'];
    isForgotUsername = json['IsForgotUsername'];
    isResetSecurity = json['IsResetSecurity'];
    agreementId = json['AgreementId'];
    initialRoute = json['InitialRoute'];
    isAssociatedAccount = json['IsAssociatedAccount'];
    typedUsername = json['TypedUsername'];
    message = json['Message'];

    canEnrollInGemini = json['CanEnrollInGemini'];
    isEnrolledInGemini = json['IsEnrolledInGemini'];
    isRsaEnrollmentNeeded = json['IsRsaEnrollmentNeeded'];
    isBillingAccount = json['IsBillingAccount'];
    challengeMobileNumber = json['ChallengeMobileNumber'];
    enrollmentOtpMethod = json['EnrollmentOtpMethod'];
    enrollmentOtpCode = json['EnrollmentOtpCode'];
    loginOtpCode = json['LoginOtpCode'];
    loginOtpMethod = json['LoginOtpMethod'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['token'] = this.token;
    data['state'] = this.state;
    data['isEnrollment'] = this.isEnrollment;
    data['isForgotUsername'] = this.isForgotUsername;
    data['isResetSecurity'] = this.isResetSecurity;
    data['agreementId'] = this.agreementId;
    data['initialRoute'] = this.initialRoute;
    data['isAssociatedAccount'] = this.isAssociatedAccount;
    data['typedUsername'] = this.typedUsername;
    data['message'] = this.message;
    data['canEnrollInGemini'] = this.canEnrollInGemini;
    data['isEnrolledInGemini'] = this.isEnrolledInGemini;
    data['isRsaEnrollmentNeeded'] = this.isRsaEnrollmentNeeded;
    data['isBillingAccount'] = this.isBillingAccount;
    data['challengeMobileNumber'] = this.challengeMobileNumber;
    data['enrollmentOtpMethod'] = this.enrollmentOtpMethod;
    data['enrollmentOtpCode'] = this.enrollmentOtpCode;
    data['loginOtpCode'] = this.loginOtpCode;
    data['loginOtpMethod'] = this.loginOtpMethod;
    return data;
  }
}
