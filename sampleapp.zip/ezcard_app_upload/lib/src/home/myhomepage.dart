import 'package:flutter/material.dart';
import 'package:ezcard_app/src/history/history_page.dart';
import 'package:ezcard_app/src/home/homepage.dart';
import 'package:ezcard_app/src/profile/profile_page.dart';
import 'package:ezcard_app/src/settings/settings_page.dart';

import '../services/branding_service.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  _MyHomePageState createState() => new _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _curIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
          currentIndex: _curIndex,
//          iconSize: 22.0,
          onTap: (index) {
            _curIndex = index;
            setState(() {});
          },
          items: [
            BottomNavigationBarItem(
              /*icon: Image.asset(_curIndex == 0
                  ? 'images/ico_home_selected.png'
                  : 'images/ico_home.png'),*/
              icon: _curIndex == 0
                  ? Icon(
                      Icons.home,
                      color: BrandingService.getBrandingColor(
                          'footer-text-color', Colors.white),
                    )
                  : Icon(
                      Icons.home,
                      color: BrandingService.getBrandingColor(
                          'footer-text-secondary-color', Colors.grey),
                    ),
              label: 'Home',
              backgroundColor: BrandingService.getBrandingColor(
                  'footer-background-color', Colors.green[900]!),
            ),
            BottomNavigationBarItem(
              /*icon: Image.asset(_curIndex == 1
                  ? 'images/ico_history_selected.png'
                  : 'images/ico_history.png'),*/
              icon: _curIndex == 1
                  ? Icon(
                      Icons.payment,
                      color: BrandingService.getBrandingColor(
                          'footer-text-color', Colors.white),
                    )
                  : Icon(
                      Icons.payment,
                      color: BrandingService.getBrandingColor(
                          'footer-text-secondary-color', Colors.grey),
                    ),
              label: 'Transactions',
              backgroundColor: BrandingService.getBrandingColor(
                  'footer-background-color', Colors.green[900]!),
            ),
            BottomNavigationBarItem(
              /*icon: Image.asset(_curIndex == 2
                  ? 'images/ico_profile_selected.png'
                  : 'images/ico_profile.png'),*/
              icon: _curIndex == 2
                  ? Icon(
                      Icons.book,
                      color: BrandingService.getBrandingColor(
                          'footer-text-color', Colors.white),
                    )
                  : Icon(
                      Icons.verified_user,
                      color: BrandingService.getBrandingColor(
                          'footer-text-secondary-color', Colors.grey),
                    ),
              label: 'Statements',
              backgroundColor: BrandingService.getBrandingColor(
                  'footer-background-color', Colors.green[900]!),
            ),
            BottomNavigationBarItem(
              /*icon: Image.asset(_curIndex == 3
                  ? 'images/ico_settings_selected.png'
                  : 'images/ico_settings.png'),*/
              icon: _curIndex == 3
                  ? Icon(
                      Icons.settings,
                      color: BrandingService.getBrandingColor(
                          'footer-text-color', Colors.white),
                    )
                  : Icon(
                      Icons.settings,
                      color: BrandingService.getBrandingColor(
                          'footer-text-secondary-color', Colors.grey),
                    ),
              label: 'Account Settings',
              backgroundColor: BrandingService.getBrandingColor(
                  'footer-background-color', Colors.green[900]!),
            ),
          ]),
      body: new Center(
        child: _getWidget(),
      ),
    );
  }

  Widget _getWidget() {
    switch (_curIndex) {
      case 0:
        return Container(
          color: Colors.red,
          child: HomePage(),
        );
        break;
      case 1:
        return Container(
          child: HistoryPage(),
        );
        break;
      case 2:
        return Container(
          child: ProfilePage(),
        );
        break;
      default:
        return Container(
          child: SettingsPage(),
        );
        break;
    }
  }
}
