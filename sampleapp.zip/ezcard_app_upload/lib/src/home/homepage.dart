import 'package:ezcard_app/src/models/current_user.dart';
import 'package:ezcard_app/src/services/session_service.dart';
import 'package:ezcard_app/src/widgets/user_info.dart';
import 'package:flutter/material.dart';
import 'package:ezcard_app/src/payment_flow/payment_account.dart';
import 'package:ezcard_app/src/widgets/bank_card.dart';

import '../models/history_model.dart';
import '../services/api_service.dart';
import '../services/branding_service.dart';
import '../widgets/history_item.dart';

class HomePage extends StatefulWidget {
  @override
  HomePageState createState() => HomePageState();
}

class HomePageState extends State<HomePage> {
  var apiService = ApiService();
  late Future<HomePageModel> thisPageModel;

  List<HistoryModel> histories = [
    HistoryModel('', 'Publix', 'Grocery', 999.0, '11 July 2022', ''),
    HistoryModel('', 'HomeDepot.com', 'Home Repair', 830.0, '11 July 2022', ''),
    HistoryModel('', 'Wallmart', 'Grocery', 830.0, '11 July 2022', ''),
    HistoryModel('', 'Amazon', 'eStore', 30.0, '11 July 2022', ''),
  ];

  double screenWidth = 0.0;
//  EdgeInsets smallItemPadding;
  @override
  void initState() {
    super.initState();

    thisPageModel = loadThisPageData();
    //dashboardData = loadDashboardData();
  }

  Future<HomePageModel> loadThisPageData() async {
    //var currentUser = await apiService.getCurrentUser();

    List<BankCardModel> cards = [];
    for (var account in SessionService.currentUser.accounts!) {
      cards.add(BankCardModel(
          'images/bg_red_card.png',
          account.accountNickname!,
          'xxxx xxxx xxxx ' + account.accountLast4!,
          account.expirationDate!.month.toString() +
              '/' +
              account.expirationDate!.year.toString(),
          account.creditLimit!.toInt(),
          false));
    }

    cards.add(
        BankCardModel('images/bg_grey_blank_card.png', '', '', '', 0, true));

    return HomePageModel(currentUser: SessionService.currentUser, cards: cards);
  }

  @override
  Widget build(BuildContext context) {
    screenWidth = MediaQuery.of(context).size.width;
    // TODO: implement build
    return Scaffold(
        backgroundColor: Color(0xFFF4F4F4),
        body: FutureBuilder<HomePageModel>(
            future: thisPageModel,
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return ListView.builder(
                    itemCount: 4,
                    scrollDirection: Axis.vertical,
                    itemBuilder: (BuildContext context, int index) {
                      if (index == 0) {
                        return UserInfo();
                      } else if (index == 1) {
                        return _userBankCardsWidget(snapshot.data!.cards,
                            snapshot.data!.currentUser.accounts![0]);
                      } else if (index == 2) {
                        return _sendMoneySectionWidget(
                            snapshot.data!.currentUser.accounts![0]);
                      } else {
                        return _utilitesSectionWidget();
                      }
                    });
              } else {
                return Center(
                  child: CircularProgressIndicator(
                    color: Colors.purple,
                  ),
                );
              }
            }));
  }

  Widget _userBankCardsWidget(List<BankCardModel> cards, Accounts acctModel) {
    return Container(
      margin: EdgeInsets.only(top: 20.0),
//      height: 400.0,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 15.0),
              child: Text('Your Cards',
                  style:
                      TextStyle(fontSize: 14.0, fontWeight: FontWeight.bold))),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 13.0),
            height: 166.0,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: cards.length,
              itemBuilder: (BuildContext context, int index) {
                return _getBankCard(index, cards);
              },
            ),
          ),
          Container(
            height: 80.0,
            margin: EdgeInsets.symmetric(horizontal: 16.0, vertical: 15.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Expanded(
                  child: GestureDetector(
                    onTapUp: (tapDetail) {
                      Navigator.push(context, SelectAccountPageRoute());
                    },
                    child: Card(
                      color: BrandingService.getBrandingColor(
                          'body-background-color', Colors.white),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: <Widget>[
                            Icon(Icons.payments,
                                color: BrandingService.getBrandingColor(
                                    'body-text1-color', Colors.black)),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 8.0),
                              child: Text(
                                'Pay Min Due\n(\$' +
                                    acctModel.minimumPaymentDue!.toString() +
                                    ')',
                                style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    color: BrandingService.getBrandingColor(
                                        'body-text1-color', Colors.black)),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Card(
                    color: BrandingService.getBrandingColor(
                        'body-background-color', Colors.white),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        children: <Widget>[
                          Icon(
                            Icons.payments,
                            color: BrandingService.getBrandingColor(
                                'body-text1-color', Colors.black),
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Text(
                              'Pay Statement\n(\$' +
                                  acctModel.lastStatementAmount!.toString() +
                                  ')',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: BrandingService.getBrandingColor(
                                      'body-text1-color', Colors.black)),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _sendMoneySectionWidget(Accounts acctModel) {
    var smallItemPadding = EdgeInsets.only(left: 12.0, right: 12.0, top: 12.0);
    if (screenWidth <= 320) {
      smallItemPadding = EdgeInsets.only(left: 10.0, right: 10.0, top: 12.0);
    }
    return Container(
//      color: Colors.yellow,
      margin: EdgeInsets.all(16.0),
//      height: 200.0,
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(
                    'Your Financials',
                    style:
                        TextStyle(fontSize: 14.0, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              /*GestureDetector(
                onTapUp: null,
                child: Text('View all'),
              )*/
            ],
          ),
          Container(
            height: 100.0,
            child: Card(
                color: BrandingService.getBrandingColor(
                    'body-background-color', Colors.white),
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        _yourFinancialWidget(
                            edgeInsert: smallItemPadding,
                            amount: acctModel.accountBalance,
                            labelName: 'Current Balance'),
                        _yourFinancialWidget(
                            edgeInsert: smallItemPadding,
                            amount: acctModel.pendingBalance,
                            labelName: 'Pending Balance'),
                        _yourFinancialWidget(
                            edgeInsert: smallItemPadding,
                            amount: acctModel.lastStatementAmount,
                            labelName: 'Statement Balance'),
                        _yourFinancialWidget(
                            edgeInsert: smallItemPadding,
                            amount: acctModel.availableCredit,
                            labelName: 'Available Credit'),
                        _yourFinancialWidget(
                            edgeInsert: smallItemPadding,
                            amount: acctModel.creditLimit,
                            labelName: 'Credit Limit'),
                        _yourFinancialWidget(
                            edgeInsert: smallItemPadding,
                            amount: acctModel.lastPaymentAmount,
                            labelName: 'Last Payment'),
                        _yourFinancialWidget(
                            edgeInsert: smallItemPadding,
                            amount: acctModel.pastDueAmount,
                            labelName: 'Past Due Amount'),
                        _yourFinancialWidget(
                            edgeInsert: smallItemPadding,
                            amount: acctModel.minimumPaymentDue,
                            labelName: 'Min Payment'),
                      ],
                    ),
                  ],
                )),
          )
        ],
      ),
    );
  }

  Widget _yourFinancialWidget(
      {required EdgeInsets edgeInsert,
      required double? amount,
      required String labelName}) {
    return Padding(
      padding: edgeInsert,
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(top: 14.0),
            child: Text(
              '\$' + amount!.toString(),
              style: TextStyle(
                fontSize: 16.0,
                color: BrandingService.getBrandingColor(
                    'body-text1-color', Colors.black),
                fontStyle: FontStyle.normal,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8.0),
            child: Text(labelName,
                style: TextStyle(
                  color: BrandingService.getBrandingColor(
                      'body-text2-color', Colors.black),
                )),
          )
        ],
      ),
    );
  }

  Widget _utilitesSectionWidget() {
    var smallItemPadding = EdgeInsets.only(left: 12.0, right: 12.0, top: 12.0);
    if (screenWidth <= 320) {
      smallItemPadding = EdgeInsets.only(left: 10.0, right: 10.0, top: 12.0);
    }
    return Container(
//      color: Colors.yellow,
      margin: EdgeInsets.all(16.0),
//      height: 200.0,
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(
                    'Recent Auth',
                    style:
                        TextStyle(fontSize: 14.0, fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ],
          ),
          Column(
            children: <Widget>[
              ListView.builder(
                  scrollDirection: Axis.vertical,
                  itemCount: histories.length,
                  shrinkWrap: true,
                  itemBuilder: (BuildContext context, int index) {
                    return _historyWidget(histories[index]);
                  }),
            ],
          ),
        ],
      ),
    );
  }

  Widget _getBankCard(int index, List<BankCardModel> cards) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: BankCard(card: cards[index]),
    );
  }

  Widget _historyWidget(HistoryModel history) {
    return HistoryItem(
      history: history,
      leftRightPadding: 0.0,
    );
  }
}

class HomePageModel {
  CurrentUser currentUser;
  List<BankCardModel> cards;

  HomePageModel({required this.currentUser, required this.cards});
}
